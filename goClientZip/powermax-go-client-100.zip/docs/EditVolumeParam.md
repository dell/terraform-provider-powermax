# EditVolumeParam

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ExecutionOption** | Pointer to **string** |  | [optional] [default to "SYNCHRONOUS"]
**EditVolumeActionParam** | Pointer to [**EditVolumeActionParam**](EditVolumeActionParam.md) |  | [optional] 

## Methods

### NewEditVolumeParam

`func NewEditVolumeParam() *EditVolumeParam`

NewEditVolumeParam instantiates a new EditVolumeParam object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewEditVolumeParamWithDefaults

`func NewEditVolumeParamWithDefaults() *EditVolumeParam`

NewEditVolumeParamWithDefaults instantiates a new EditVolumeParam object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetExecutionOption

`func (o *EditVolumeParam) GetExecutionOption() string`

GetExecutionOption returns the ExecutionOption field if non-nil, zero value otherwise.

### GetExecutionOptionOk

`func (o *EditVolumeParam) GetExecutionOptionOk() (*string, bool)`

GetExecutionOptionOk returns a tuple with the ExecutionOption field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetExecutionOption

`func (o *EditVolumeParam) SetExecutionOption(v string)`

SetExecutionOption sets ExecutionOption field to given value.

### HasExecutionOption

`func (o *EditVolumeParam) HasExecutionOption() bool`

HasExecutionOption returns a boolean if a field has been set.

### GetEditVolumeActionParam

`func (o *EditVolumeParam) GetEditVolumeActionParam() EditVolumeActionParam`

GetEditVolumeActionParam returns the EditVolumeActionParam field if non-nil, zero value otherwise.

### GetEditVolumeActionParamOk

`func (o *EditVolumeParam) GetEditVolumeActionParamOk() (*EditVolumeActionParam, bool)`

GetEditVolumeActionParamOk returns a tuple with the EditVolumeActionParam field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetEditVolumeActionParam

`func (o *EditVolumeParam) SetEditVolumeActionParam(v EditVolumeActionParam)`

SetEditVolumeActionParam sets EditVolumeActionParam field to given value.

### HasEditVolumeActionParam

`func (o *EditVolumeParam) HasEditVolumeActionParam() bool`

HasEditVolumeActionParam returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


