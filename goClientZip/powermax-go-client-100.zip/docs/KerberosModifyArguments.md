# KerberosModifyArguments

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Realm** | Pointer to **string** |                          Realm name of the Kerberos Service                      | [optional] 
**KdcNames** | Pointer to **[]string** |                          Fully Qualified domain names of the Kerberos Key Distribution Center (KDC) servers.                      | [optional] 
**PortNumber** | Pointer to **int32** |                          KDC servers TCP port. Default: 88.                      | [optional] 

## Methods

### NewKerberosModifyArguments

`func NewKerberosModifyArguments() *KerberosModifyArguments`

NewKerberosModifyArguments instantiates a new KerberosModifyArguments object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewKerberosModifyArgumentsWithDefaults

`func NewKerberosModifyArgumentsWithDefaults() *KerberosModifyArguments`

NewKerberosModifyArgumentsWithDefaults instantiates a new KerberosModifyArguments object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetRealm

`func (o *KerberosModifyArguments) GetRealm() string`

GetRealm returns the Realm field if non-nil, zero value otherwise.

### GetRealmOk

`func (o *KerberosModifyArguments) GetRealmOk() (*string, bool)`

GetRealmOk returns a tuple with the Realm field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetRealm

`func (o *KerberosModifyArguments) SetRealm(v string)`

SetRealm sets Realm field to given value.

### HasRealm

`func (o *KerberosModifyArguments) HasRealm() bool`

HasRealm returns a boolean if a field has been set.

### GetKdcNames

`func (o *KerberosModifyArguments) GetKdcNames() []string`

GetKdcNames returns the KdcNames field if non-nil, zero value otherwise.

### GetKdcNamesOk

`func (o *KerberosModifyArguments) GetKdcNamesOk() (*[]string, bool)`

GetKdcNamesOk returns a tuple with the KdcNames field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetKdcNames

`func (o *KerberosModifyArguments) SetKdcNames(v []string)`

SetKdcNames sets KdcNames field to given value.

### HasKdcNames

`func (o *KerberosModifyArguments) HasKdcNames() bool`

HasKdcNames returns a boolean if a field has been set.

### GetPortNumber

`func (o *KerberosModifyArguments) GetPortNumber() int32`

GetPortNumber returns the PortNumber field if non-nil, zero value otherwise.

### GetPortNumberOk

`func (o *KerberosModifyArguments) GetPortNumberOk() (*int32, bool)`

GetPortNumberOk returns a tuple with the PortNumber field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetPortNumber

`func (o *KerberosModifyArguments) SetPortNumber(v int32)`

SetPortNumber sets PortNumber field to given value.

### HasPortNumber

`func (o *KerberosModifyArguments) HasPortNumber() bool`

HasPortNumber returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


