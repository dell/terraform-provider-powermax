# EventsPool

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Id** | Pointer to **string** |  Unique identifier Events Pool | [optional] 
**EventsPublisher** | Pointer to **string** |  Unique identifier Event Publisher  | [optional] 
**NasServer** | Pointer to **string** |  Unique Identifier of NASServer  | [optional] 
**Name** | Pointer to **string** |  Name of the eventspool | [optional] 
**EventsPublisherServers** | Pointer to **[]string** |                          Network identifier of the File Event Service servers. (fully qualified domain name or ip addresses).                         You can set at max 5 File Event Service Servers per Events Pool.                      | [optional] 
**PreEvents** | Pointer to [**PreEventsList**](PreEventsList.md) |  | [optional] 
**PostEvents** | Pointer to [**PostEventsList**](PostEventsList.md) |  | [optional] 
**PostErrorEvents** | Pointer to [**PostErrorEventsList**](PostErrorEventsList.md) |  | [optional] 
**Override** | Pointer to **bool** |                          In the context of a replication, tell if the eventsPublisherServers list has been overridden when this object is in destination mode                      | [optional] 
**Health** | Pointer to [**Health**](Health.md) |  | [optional] 

## Methods

### NewEventsPool

`func NewEventsPool() *EventsPool`

NewEventsPool instantiates a new EventsPool object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewEventsPoolWithDefaults

`func NewEventsPoolWithDefaults() *EventsPool`

NewEventsPoolWithDefaults instantiates a new EventsPool object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetId

`func (o *EventsPool) GetId() string`

GetId returns the Id field if non-nil, zero value otherwise.

### GetIdOk

`func (o *EventsPool) GetIdOk() (*string, bool)`

GetIdOk returns a tuple with the Id field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetId

`func (o *EventsPool) SetId(v string)`

SetId sets Id field to given value.

### HasId

`func (o *EventsPool) HasId() bool`

HasId returns a boolean if a field has been set.

### GetEventsPublisher

`func (o *EventsPool) GetEventsPublisher() string`

GetEventsPublisher returns the EventsPublisher field if non-nil, zero value otherwise.

### GetEventsPublisherOk

`func (o *EventsPool) GetEventsPublisherOk() (*string, bool)`

GetEventsPublisherOk returns a tuple with the EventsPublisher field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetEventsPublisher

`func (o *EventsPool) SetEventsPublisher(v string)`

SetEventsPublisher sets EventsPublisher field to given value.

### HasEventsPublisher

`func (o *EventsPool) HasEventsPublisher() bool`

HasEventsPublisher returns a boolean if a field has been set.

### GetNasServer

`func (o *EventsPool) GetNasServer() string`

GetNasServer returns the NasServer field if non-nil, zero value otherwise.

### GetNasServerOk

`func (o *EventsPool) GetNasServerOk() (*string, bool)`

GetNasServerOk returns a tuple with the NasServer field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetNasServer

`func (o *EventsPool) SetNasServer(v string)`

SetNasServer sets NasServer field to given value.

### HasNasServer

`func (o *EventsPool) HasNasServer() bool`

HasNasServer returns a boolean if a field has been set.

### GetName

`func (o *EventsPool) GetName() string`

GetName returns the Name field if non-nil, zero value otherwise.

### GetNameOk

`func (o *EventsPool) GetNameOk() (*string, bool)`

GetNameOk returns a tuple with the Name field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetName

`func (o *EventsPool) SetName(v string)`

SetName sets Name field to given value.

### HasName

`func (o *EventsPool) HasName() bool`

HasName returns a boolean if a field has been set.

### GetEventsPublisherServers

`func (o *EventsPool) GetEventsPublisherServers() []string`

GetEventsPublisherServers returns the EventsPublisherServers field if non-nil, zero value otherwise.

### GetEventsPublisherServersOk

`func (o *EventsPool) GetEventsPublisherServersOk() (*[]string, bool)`

GetEventsPublisherServersOk returns a tuple with the EventsPublisherServers field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetEventsPublisherServers

`func (o *EventsPool) SetEventsPublisherServers(v []string)`

SetEventsPublisherServers sets EventsPublisherServers field to given value.

### HasEventsPublisherServers

`func (o *EventsPool) HasEventsPublisherServers() bool`

HasEventsPublisherServers returns a boolean if a field has been set.

### GetPreEvents

`func (o *EventsPool) GetPreEvents() PreEventsList`

GetPreEvents returns the PreEvents field if non-nil, zero value otherwise.

### GetPreEventsOk

`func (o *EventsPool) GetPreEventsOk() (*PreEventsList, bool)`

GetPreEventsOk returns a tuple with the PreEvents field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetPreEvents

`func (o *EventsPool) SetPreEvents(v PreEventsList)`

SetPreEvents sets PreEvents field to given value.

### HasPreEvents

`func (o *EventsPool) HasPreEvents() bool`

HasPreEvents returns a boolean if a field has been set.

### GetPostEvents

`func (o *EventsPool) GetPostEvents() PostEventsList`

GetPostEvents returns the PostEvents field if non-nil, zero value otherwise.

### GetPostEventsOk

`func (o *EventsPool) GetPostEventsOk() (*PostEventsList, bool)`

GetPostEventsOk returns a tuple with the PostEvents field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetPostEvents

`func (o *EventsPool) SetPostEvents(v PostEventsList)`

SetPostEvents sets PostEvents field to given value.

### HasPostEvents

`func (o *EventsPool) HasPostEvents() bool`

HasPostEvents returns a boolean if a field has been set.

### GetPostErrorEvents

`func (o *EventsPool) GetPostErrorEvents() PostErrorEventsList`

GetPostErrorEvents returns the PostErrorEvents field if non-nil, zero value otherwise.

### GetPostErrorEventsOk

`func (o *EventsPool) GetPostErrorEventsOk() (*PostErrorEventsList, bool)`

GetPostErrorEventsOk returns a tuple with the PostErrorEvents field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetPostErrorEvents

`func (o *EventsPool) SetPostErrorEvents(v PostErrorEventsList)`

SetPostErrorEvents sets PostErrorEvents field to given value.

### HasPostErrorEvents

`func (o *EventsPool) HasPostErrorEvents() bool`

HasPostErrorEvents returns a boolean if a field has been set.

### GetOverride

`func (o *EventsPool) GetOverride() bool`

GetOverride returns the Override field if non-nil, zero value otherwise.

### GetOverrideOk

`func (o *EventsPool) GetOverrideOk() (*bool, bool)`

GetOverrideOk returns a tuple with the Override field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetOverride

`func (o *EventsPool) SetOverride(v bool)`

SetOverride sets Override field to given value.

### HasOverride

`func (o *EventsPool) HasOverride() bool`

HasOverride returns a boolean if a field has been set.

### GetHealth

`func (o *EventsPool) GetHealth() Health`

GetHealth returns the Health field if non-nil, zero value otherwise.

### GetHealthOk

`func (o *EventsPool) GetHealthOk() (*Health, bool)`

GetHealthOk returns a tuple with the Health field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetHealth

`func (o *EventsPool) SetHealth(v Health)`

SetHealth sets Health field to given value.

### HasHealth

`func (o *EventsPool) HasHealth() bool`

HasHealth returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


