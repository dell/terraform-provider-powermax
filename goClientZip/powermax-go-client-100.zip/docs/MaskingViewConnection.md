# MaskingViewConnection

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**VolumeId** | **string** | The volume in the connection. | 
**HostLunAddress** | Pointer to **string** | The host LUN address of the volume in the connection. | [optional] 
**CapGb** | Pointer to **string** | The volume capacity. | [optional] 
**InitiatorId** | Pointer to **string** | The initiator in the connection. | [optional] 
**Alias** | Pointer to **string** | The initiator alias. | [optional] 
**DirPort** | Pointer to **string** | The director port in the connection. | [optional] 
**LoggedIn** | Pointer to **bool** | The director port logged in status. | [optional] 
**OnFabric** | Pointer to **bool** | The director port on fabric status. | [optional] 

## Methods

### NewMaskingViewConnection

`func NewMaskingViewConnection(volumeId string, ) *MaskingViewConnection`

NewMaskingViewConnection instantiates a new MaskingViewConnection object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewMaskingViewConnectionWithDefaults

`func NewMaskingViewConnectionWithDefaults() *MaskingViewConnection`

NewMaskingViewConnectionWithDefaults instantiates a new MaskingViewConnection object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetVolumeId

`func (o *MaskingViewConnection) GetVolumeId() string`

GetVolumeId returns the VolumeId field if non-nil, zero value otherwise.

### GetVolumeIdOk

`func (o *MaskingViewConnection) GetVolumeIdOk() (*string, bool)`

GetVolumeIdOk returns a tuple with the VolumeId field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetVolumeId

`func (o *MaskingViewConnection) SetVolumeId(v string)`

SetVolumeId sets VolumeId field to given value.


### GetHostLunAddress

`func (o *MaskingViewConnection) GetHostLunAddress() string`

GetHostLunAddress returns the HostLunAddress field if non-nil, zero value otherwise.

### GetHostLunAddressOk

`func (o *MaskingViewConnection) GetHostLunAddressOk() (*string, bool)`

GetHostLunAddressOk returns a tuple with the HostLunAddress field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetHostLunAddress

`func (o *MaskingViewConnection) SetHostLunAddress(v string)`

SetHostLunAddress sets HostLunAddress field to given value.

### HasHostLunAddress

`func (o *MaskingViewConnection) HasHostLunAddress() bool`

HasHostLunAddress returns a boolean if a field has been set.

### GetCapGb

`func (o *MaskingViewConnection) GetCapGb() string`

GetCapGb returns the CapGb field if non-nil, zero value otherwise.

### GetCapGbOk

`func (o *MaskingViewConnection) GetCapGbOk() (*string, bool)`

GetCapGbOk returns a tuple with the CapGb field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetCapGb

`func (o *MaskingViewConnection) SetCapGb(v string)`

SetCapGb sets CapGb field to given value.

### HasCapGb

`func (o *MaskingViewConnection) HasCapGb() bool`

HasCapGb returns a boolean if a field has been set.

### GetInitiatorId

`func (o *MaskingViewConnection) GetInitiatorId() string`

GetInitiatorId returns the InitiatorId field if non-nil, zero value otherwise.

### GetInitiatorIdOk

`func (o *MaskingViewConnection) GetInitiatorIdOk() (*string, bool)`

GetInitiatorIdOk returns a tuple with the InitiatorId field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetInitiatorId

`func (o *MaskingViewConnection) SetInitiatorId(v string)`

SetInitiatorId sets InitiatorId field to given value.

### HasInitiatorId

`func (o *MaskingViewConnection) HasInitiatorId() bool`

HasInitiatorId returns a boolean if a field has been set.

### GetAlias

`func (o *MaskingViewConnection) GetAlias() string`

GetAlias returns the Alias field if non-nil, zero value otherwise.

### GetAliasOk

`func (o *MaskingViewConnection) GetAliasOk() (*string, bool)`

GetAliasOk returns a tuple with the Alias field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetAlias

`func (o *MaskingViewConnection) SetAlias(v string)`

SetAlias sets Alias field to given value.

### HasAlias

`func (o *MaskingViewConnection) HasAlias() bool`

HasAlias returns a boolean if a field has been set.

### GetDirPort

`func (o *MaskingViewConnection) GetDirPort() string`

GetDirPort returns the DirPort field if non-nil, zero value otherwise.

### GetDirPortOk

`func (o *MaskingViewConnection) GetDirPortOk() (*string, bool)`

GetDirPortOk returns a tuple with the DirPort field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetDirPort

`func (o *MaskingViewConnection) SetDirPort(v string)`

SetDirPort sets DirPort field to given value.

### HasDirPort

`func (o *MaskingViewConnection) HasDirPort() bool`

HasDirPort returns a boolean if a field has been set.

### GetLoggedIn

`func (o *MaskingViewConnection) GetLoggedIn() bool`

GetLoggedIn returns the LoggedIn field if non-nil, zero value otherwise.

### GetLoggedInOk

`func (o *MaskingViewConnection) GetLoggedInOk() (*bool, bool)`

GetLoggedInOk returns a tuple with the LoggedIn field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetLoggedIn

`func (o *MaskingViewConnection) SetLoggedIn(v bool)`

SetLoggedIn sets LoggedIn field to given value.

### HasLoggedIn

`func (o *MaskingViewConnection) HasLoggedIn() bool`

HasLoggedIn returns a boolean if a field has been set.

### GetOnFabric

`func (o *MaskingViewConnection) GetOnFabric() bool`

GetOnFabric returns the OnFabric field if non-nil, zero value otherwise.

### GetOnFabricOk

`func (o *MaskingViewConnection) GetOnFabricOk() (*bool, bool)`

GetOnFabricOk returns a tuple with the OnFabric field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetOnFabric

`func (o *MaskingViewConnection) SetOnFabric(v bool)`

SetOnFabric sets OnFabric field to given value.

### HasOnFabric

`func (o *MaskingViewConnection) HasOnFabric() bool`

HasOnFabric returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


