# AddSpecificVolumeParam

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**VolumeId** | **[]string** | VolumeId to be added. | 
**RemoteSymmSGInfoParam** | Pointer to [**RemoteSymmSGInfoParam**](RemoteSymmSGInfoParam.md) |  | [optional] 

## Methods

### NewAddSpecificVolumeParam

`func NewAddSpecificVolumeParam(volumeId []string, ) *AddSpecificVolumeParam`

NewAddSpecificVolumeParam instantiates a new AddSpecificVolumeParam object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewAddSpecificVolumeParamWithDefaults

`func NewAddSpecificVolumeParamWithDefaults() *AddSpecificVolumeParam`

NewAddSpecificVolumeParamWithDefaults instantiates a new AddSpecificVolumeParam object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetVolumeId

`func (o *AddSpecificVolumeParam) GetVolumeId() []string`

GetVolumeId returns the VolumeId field if non-nil, zero value otherwise.

### GetVolumeIdOk

`func (o *AddSpecificVolumeParam) GetVolumeIdOk() (*[]string, bool)`

GetVolumeIdOk returns a tuple with the VolumeId field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetVolumeId

`func (o *AddSpecificVolumeParam) SetVolumeId(v []string)`

SetVolumeId sets VolumeId field to given value.


### GetRemoteSymmSGInfoParam

`func (o *AddSpecificVolumeParam) GetRemoteSymmSGInfoParam() RemoteSymmSGInfoParam`

GetRemoteSymmSGInfoParam returns the RemoteSymmSGInfoParam field if non-nil, zero value otherwise.

### GetRemoteSymmSGInfoParamOk

`func (o *AddSpecificVolumeParam) GetRemoteSymmSGInfoParamOk() (*RemoteSymmSGInfoParam, bool)`

GetRemoteSymmSGInfoParamOk returns a tuple with the RemoteSymmSGInfoParam field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetRemoteSymmSGInfoParam

`func (o *AddSpecificVolumeParam) SetRemoteSymmSGInfoParam(v RemoteSymmSGInfoParam)`

SetRemoteSymmSGInfoParam sets RemoteSymmSGInfoParam field to given value.

### HasRemoteSymmSGInfoParam

`func (o *AddSpecificVolumeParam) HasRemoteSymmSGInfoParam() bool`

HasRemoteSymmSGInfoParam returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


