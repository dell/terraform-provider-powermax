# CreateStorageGroupParamTypeVvol

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**StorageGroupId** | **string** | The Name of the new Storage Group. | 

## Methods

### NewCreateStorageGroupParamTypeVvol

`func NewCreateStorageGroupParamTypeVvol(storageGroupId string, ) *CreateStorageGroupParamTypeVvol`

NewCreateStorageGroupParamTypeVvol instantiates a new CreateStorageGroupParamTypeVvol object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewCreateStorageGroupParamTypeVvolWithDefaults

`func NewCreateStorageGroupParamTypeVvolWithDefaults() *CreateStorageGroupParamTypeVvol`

NewCreateStorageGroupParamTypeVvolWithDefaults instantiates a new CreateStorageGroupParamTypeVvol object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetStorageGroupId

`func (o *CreateStorageGroupParamTypeVvol) GetStorageGroupId() string`

GetStorageGroupId returns the StorageGroupId field if non-nil, zero value otherwise.

### GetStorageGroupIdOk

`func (o *CreateStorageGroupParamTypeVvol) GetStorageGroupIdOk() (*string, bool)`

GetStorageGroupIdOk returns a tuple with the StorageGroupId field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetStorageGroupId

`func (o *CreateStorageGroupParamTypeVvol) SetStorageGroupId(v string)`

SetStorageGroupId sets StorageGroupId field to given value.



[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


