# BoardKeyResult

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**BoardInfo** | Pointer to [**[]BoardInfo**](BoardInfo.md) | boardInfo | [optional] 

## Methods

### NewBoardKeyResult

`func NewBoardKeyResult() *BoardKeyResult`

NewBoardKeyResult instantiates a new BoardKeyResult object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewBoardKeyResultWithDefaults

`func NewBoardKeyResultWithDefaults() *BoardKeyResult`

NewBoardKeyResultWithDefaults instantiates a new BoardKeyResult object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetBoardInfo

`func (o *BoardKeyResult) GetBoardInfo() []BoardInfo`

GetBoardInfo returns the BoardInfo field if non-nil, zero value otherwise.

### GetBoardInfoOk

`func (o *BoardKeyResult) GetBoardInfoOk() (*[]BoardInfo, bool)`

GetBoardInfoOk returns a tuple with the BoardInfo field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetBoardInfo

`func (o *BoardKeyResult) SetBoardInfo(v []BoardInfo)`

SetBoardInfo sets BoardInfo field to given value.

### HasBoardInfo

`func (o *BoardKeyResult) HasBoardInfo() bool`

HasBoardInfo returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


