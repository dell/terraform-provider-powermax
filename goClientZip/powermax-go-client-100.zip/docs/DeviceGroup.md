# DeviceGroup

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Name** | **string** | The Device Group name. | 
**SymmetrixId** | **string** | The local System ID. | 
**IsValid** | **bool** | Set if the Device Group is valid. | [default to false]
**IsConcurrentRdf** | **bool** | Set if the Device Group is involved in a Concurrent SRDF setup. | [default to false]
**IsCascadedRdf** | **bool** | Set if the Device Group is involved in a Cascaded SRDF setup. | [default to false]
**NumStandards** | Pointer to **[]int32** | The number of volumes in the Standard section of the group. | [optional] 
**StandardRdfgs** | Pointer to **[]int64** | The numbers of the SRDF Groups that the volumes in the Standard section of the group are in. | [optional] 
**StandardPairStates** | Pointer to **[]string** | The pair states of the SRDF pairs for volumes in the Standard section of the group. | [optional] 
**StandardHop2PairStates** | Pointer to **[]string** | The pair states of the SRDF pairs for second hop for volumes in the Standard section of the group. | [optional] 
**NumBcvs** | Pointer to **[]int32** | The number of volumes in the BCV section of the group. | [optional] 
**BcvRdfgs** | Pointer to **[]int64** | The numbers of the SRDF Groups that the volumes in the BCV section of the group are in. | [optional] 
**BcvPairStates** | Pointer to **[]string** | The pair states of the SRDF pairs for volumes in the BCV section of the group. | [optional] 
**BcvHop2PairStates** | Pointer to **[]string** | The pair states of the SRDF pairs for second hop for volumes in the BCV section of the group. | [optional] 
**GroupType** | **string** | The type of the Device Group, e.g. Regular, RDF1, RDF21, RDF2, Any | 

## Methods

### NewDeviceGroup

`func NewDeviceGroup(name string, symmetrixId string, isValid bool, isConcurrentRdf bool, isCascadedRdf bool, groupType string, ) *DeviceGroup`

NewDeviceGroup instantiates a new DeviceGroup object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewDeviceGroupWithDefaults

`func NewDeviceGroupWithDefaults() *DeviceGroup`

NewDeviceGroupWithDefaults instantiates a new DeviceGroup object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetName

`func (o *DeviceGroup) GetName() string`

GetName returns the Name field if non-nil, zero value otherwise.

### GetNameOk

`func (o *DeviceGroup) GetNameOk() (*string, bool)`

GetNameOk returns a tuple with the Name field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetName

`func (o *DeviceGroup) SetName(v string)`

SetName sets Name field to given value.


### GetSymmetrixId

`func (o *DeviceGroup) GetSymmetrixId() string`

GetSymmetrixId returns the SymmetrixId field if non-nil, zero value otherwise.

### GetSymmetrixIdOk

`func (o *DeviceGroup) GetSymmetrixIdOk() (*string, bool)`

GetSymmetrixIdOk returns a tuple with the SymmetrixId field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetSymmetrixId

`func (o *DeviceGroup) SetSymmetrixId(v string)`

SetSymmetrixId sets SymmetrixId field to given value.


### GetIsValid

`func (o *DeviceGroup) GetIsValid() bool`

GetIsValid returns the IsValid field if non-nil, zero value otherwise.

### GetIsValidOk

`func (o *DeviceGroup) GetIsValidOk() (*bool, bool)`

GetIsValidOk returns a tuple with the IsValid field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetIsValid

`func (o *DeviceGroup) SetIsValid(v bool)`

SetIsValid sets IsValid field to given value.


### GetIsConcurrentRdf

`func (o *DeviceGroup) GetIsConcurrentRdf() bool`

GetIsConcurrentRdf returns the IsConcurrentRdf field if non-nil, zero value otherwise.

### GetIsConcurrentRdfOk

`func (o *DeviceGroup) GetIsConcurrentRdfOk() (*bool, bool)`

GetIsConcurrentRdfOk returns a tuple with the IsConcurrentRdf field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetIsConcurrentRdf

`func (o *DeviceGroup) SetIsConcurrentRdf(v bool)`

SetIsConcurrentRdf sets IsConcurrentRdf field to given value.


### GetIsCascadedRdf

`func (o *DeviceGroup) GetIsCascadedRdf() bool`

GetIsCascadedRdf returns the IsCascadedRdf field if non-nil, zero value otherwise.

### GetIsCascadedRdfOk

`func (o *DeviceGroup) GetIsCascadedRdfOk() (*bool, bool)`

GetIsCascadedRdfOk returns a tuple with the IsCascadedRdf field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetIsCascadedRdf

`func (o *DeviceGroup) SetIsCascadedRdf(v bool)`

SetIsCascadedRdf sets IsCascadedRdf field to given value.


### GetNumStandards

`func (o *DeviceGroup) GetNumStandards() []int32`

GetNumStandards returns the NumStandards field if non-nil, zero value otherwise.

### GetNumStandardsOk

`func (o *DeviceGroup) GetNumStandardsOk() (*[]int32, bool)`

GetNumStandardsOk returns a tuple with the NumStandards field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetNumStandards

`func (o *DeviceGroup) SetNumStandards(v []int32)`

SetNumStandards sets NumStandards field to given value.

### HasNumStandards

`func (o *DeviceGroup) HasNumStandards() bool`

HasNumStandards returns a boolean if a field has been set.

### GetStandardRdfgs

`func (o *DeviceGroup) GetStandardRdfgs() []int64`

GetStandardRdfgs returns the StandardRdfgs field if non-nil, zero value otherwise.

### GetStandardRdfgsOk

`func (o *DeviceGroup) GetStandardRdfgsOk() (*[]int64, bool)`

GetStandardRdfgsOk returns a tuple with the StandardRdfgs field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetStandardRdfgs

`func (o *DeviceGroup) SetStandardRdfgs(v []int64)`

SetStandardRdfgs sets StandardRdfgs field to given value.

### HasStandardRdfgs

`func (o *DeviceGroup) HasStandardRdfgs() bool`

HasStandardRdfgs returns a boolean if a field has been set.

### GetStandardPairStates

`func (o *DeviceGroup) GetStandardPairStates() []string`

GetStandardPairStates returns the StandardPairStates field if non-nil, zero value otherwise.

### GetStandardPairStatesOk

`func (o *DeviceGroup) GetStandardPairStatesOk() (*[]string, bool)`

GetStandardPairStatesOk returns a tuple with the StandardPairStates field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetStandardPairStates

`func (o *DeviceGroup) SetStandardPairStates(v []string)`

SetStandardPairStates sets StandardPairStates field to given value.

### HasStandardPairStates

`func (o *DeviceGroup) HasStandardPairStates() bool`

HasStandardPairStates returns a boolean if a field has been set.

### GetStandardHop2PairStates

`func (o *DeviceGroup) GetStandardHop2PairStates() []string`

GetStandardHop2PairStates returns the StandardHop2PairStates field if non-nil, zero value otherwise.

### GetStandardHop2PairStatesOk

`func (o *DeviceGroup) GetStandardHop2PairStatesOk() (*[]string, bool)`

GetStandardHop2PairStatesOk returns a tuple with the StandardHop2PairStates field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetStandardHop2PairStates

`func (o *DeviceGroup) SetStandardHop2PairStates(v []string)`

SetStandardHop2PairStates sets StandardHop2PairStates field to given value.

### HasStandardHop2PairStates

`func (o *DeviceGroup) HasStandardHop2PairStates() bool`

HasStandardHop2PairStates returns a boolean if a field has been set.

### GetNumBcvs

`func (o *DeviceGroup) GetNumBcvs() []int32`

GetNumBcvs returns the NumBcvs field if non-nil, zero value otherwise.

### GetNumBcvsOk

`func (o *DeviceGroup) GetNumBcvsOk() (*[]int32, bool)`

GetNumBcvsOk returns a tuple with the NumBcvs field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetNumBcvs

`func (o *DeviceGroup) SetNumBcvs(v []int32)`

SetNumBcvs sets NumBcvs field to given value.

### HasNumBcvs

`func (o *DeviceGroup) HasNumBcvs() bool`

HasNumBcvs returns a boolean if a field has been set.

### GetBcvRdfgs

`func (o *DeviceGroup) GetBcvRdfgs() []int64`

GetBcvRdfgs returns the BcvRdfgs field if non-nil, zero value otherwise.

### GetBcvRdfgsOk

`func (o *DeviceGroup) GetBcvRdfgsOk() (*[]int64, bool)`

GetBcvRdfgsOk returns a tuple with the BcvRdfgs field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetBcvRdfgs

`func (o *DeviceGroup) SetBcvRdfgs(v []int64)`

SetBcvRdfgs sets BcvRdfgs field to given value.

### HasBcvRdfgs

`func (o *DeviceGroup) HasBcvRdfgs() bool`

HasBcvRdfgs returns a boolean if a field has been set.

### GetBcvPairStates

`func (o *DeviceGroup) GetBcvPairStates() []string`

GetBcvPairStates returns the BcvPairStates field if non-nil, zero value otherwise.

### GetBcvPairStatesOk

`func (o *DeviceGroup) GetBcvPairStatesOk() (*[]string, bool)`

GetBcvPairStatesOk returns a tuple with the BcvPairStates field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetBcvPairStates

`func (o *DeviceGroup) SetBcvPairStates(v []string)`

SetBcvPairStates sets BcvPairStates field to given value.

### HasBcvPairStates

`func (o *DeviceGroup) HasBcvPairStates() bool`

HasBcvPairStates returns a boolean if a field has been set.

### GetBcvHop2PairStates

`func (o *DeviceGroup) GetBcvHop2PairStates() []string`

GetBcvHop2PairStates returns the BcvHop2PairStates field if non-nil, zero value otherwise.

### GetBcvHop2PairStatesOk

`func (o *DeviceGroup) GetBcvHop2PairStatesOk() (*[]string, bool)`

GetBcvHop2PairStatesOk returns a tuple with the BcvHop2PairStates field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetBcvHop2PairStates

`func (o *DeviceGroup) SetBcvHop2PairStates(v []string)`

SetBcvHop2PairStates sets BcvHop2PairStates field to given value.

### HasBcvHop2PairStates

`func (o *DeviceGroup) HasBcvHop2PairStates() bool`

HasBcvHop2PairStates returns a boolean if a field has been set.

### GetGroupType

`func (o *DeviceGroup) GetGroupType() string`

GetGroupType returns the GroupType field if non-nil, zero value otherwise.

### GetGroupTypeOk

`func (o *DeviceGroup) GetGroupTypeOk() (*string, bool)`

GetGroupTypeOk returns a tuple with the GroupType field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetGroupType

`func (o *DeviceGroup) SetGroupType(v string)`

SetGroupType sets GroupType field to given value.



[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


