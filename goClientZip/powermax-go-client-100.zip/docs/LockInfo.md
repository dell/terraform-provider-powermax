# LockInfo

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**LockNumber** | **int64** | The Lock Number | 
**LockUsage** | Pointer to **string** | The origin of the lock | [optional] 
**LockHost** | Pointer to **string** | The Host were the lock was initiated | [optional] 
**LockUser** | Pointer to **string** | The User that initiated the lock | [optional] 
**TimeHeldSeconds** | Pointer to **int64** | The Time in Seconds that the lock has been held for | [optional] 

## Methods

### NewLockInfo

`func NewLockInfo(lockNumber int64, ) *LockInfo`

NewLockInfo instantiates a new LockInfo object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewLockInfoWithDefaults

`func NewLockInfoWithDefaults() *LockInfo`

NewLockInfoWithDefaults instantiates a new LockInfo object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetLockNumber

`func (o *LockInfo) GetLockNumber() int64`

GetLockNumber returns the LockNumber field if non-nil, zero value otherwise.

### GetLockNumberOk

`func (o *LockInfo) GetLockNumberOk() (*int64, bool)`

GetLockNumberOk returns a tuple with the LockNumber field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetLockNumber

`func (o *LockInfo) SetLockNumber(v int64)`

SetLockNumber sets LockNumber field to given value.


### GetLockUsage

`func (o *LockInfo) GetLockUsage() string`

GetLockUsage returns the LockUsage field if non-nil, zero value otherwise.

### GetLockUsageOk

`func (o *LockInfo) GetLockUsageOk() (*string, bool)`

GetLockUsageOk returns a tuple with the LockUsage field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetLockUsage

`func (o *LockInfo) SetLockUsage(v string)`

SetLockUsage sets LockUsage field to given value.

### HasLockUsage

`func (o *LockInfo) HasLockUsage() bool`

HasLockUsage returns a boolean if a field has been set.

### GetLockHost

`func (o *LockInfo) GetLockHost() string`

GetLockHost returns the LockHost field if non-nil, zero value otherwise.

### GetLockHostOk

`func (o *LockInfo) GetLockHostOk() (*string, bool)`

GetLockHostOk returns a tuple with the LockHost field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetLockHost

`func (o *LockInfo) SetLockHost(v string)`

SetLockHost sets LockHost field to given value.

### HasLockHost

`func (o *LockInfo) HasLockHost() bool`

HasLockHost returns a boolean if a field has been set.

### GetLockUser

`func (o *LockInfo) GetLockUser() string`

GetLockUser returns the LockUser field if non-nil, zero value otherwise.

### GetLockUserOk

`func (o *LockInfo) GetLockUserOk() (*string, bool)`

GetLockUserOk returns a tuple with the LockUser field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetLockUser

`func (o *LockInfo) SetLockUser(v string)`

SetLockUser sets LockUser field to given value.

### HasLockUser

`func (o *LockInfo) HasLockUser() bool`

HasLockUser returns a boolean if a field has been set.

### GetTimeHeldSeconds

`func (o *LockInfo) GetTimeHeldSeconds() int64`

GetTimeHeldSeconds returns the TimeHeldSeconds field if non-nil, zero value otherwise.

### GetTimeHeldSecondsOk

`func (o *LockInfo) GetTimeHeldSecondsOk() (*int64, bool)`

GetTimeHeldSecondsOk returns a tuple with the TimeHeldSeconds field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetTimeHeldSeconds

`func (o *LockInfo) SetTimeHeldSeconds(v int64)`

SetTimeHeldSeconds sets TimeHeldSeconds field to given value.

### HasTimeHeldSeconds

`func (o *LockInfo) HasTimeHeldSeconds() bool`

HasTimeHeldSeconds returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


