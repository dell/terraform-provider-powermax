# MixtureType

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**RandomReadHit** | [**MixtureIoType**](MixtureIoType.md) |  | 
**ReadMiss** | [**MixtureIoType**](MixtureIoType.md) |  | 
**RandomWrite** | [**MixtureIoType**](MixtureIoType.md) |  | 
**SequentialRead** | [**MixtureIoType**](MixtureIoType.md) |  | 
**SequentialWrite** | [**MixtureIoType**](MixtureIoType.md) |  | 

## Methods

### NewMixtureType

`func NewMixtureType(randomReadHit MixtureIoType, readMiss MixtureIoType, randomWrite MixtureIoType, sequentialRead MixtureIoType, sequentialWrite MixtureIoType, ) *MixtureType`

NewMixtureType instantiates a new MixtureType object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewMixtureTypeWithDefaults

`func NewMixtureTypeWithDefaults() *MixtureType`

NewMixtureTypeWithDefaults instantiates a new MixtureType object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetRandomReadHit

`func (o *MixtureType) GetRandomReadHit() MixtureIoType`

GetRandomReadHit returns the RandomReadHit field if non-nil, zero value otherwise.

### GetRandomReadHitOk

`func (o *MixtureType) GetRandomReadHitOk() (*MixtureIoType, bool)`

GetRandomReadHitOk returns a tuple with the RandomReadHit field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetRandomReadHit

`func (o *MixtureType) SetRandomReadHit(v MixtureIoType)`

SetRandomReadHit sets RandomReadHit field to given value.


### GetReadMiss

`func (o *MixtureType) GetReadMiss() MixtureIoType`

GetReadMiss returns the ReadMiss field if non-nil, zero value otherwise.

### GetReadMissOk

`func (o *MixtureType) GetReadMissOk() (*MixtureIoType, bool)`

GetReadMissOk returns a tuple with the ReadMiss field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetReadMiss

`func (o *MixtureType) SetReadMiss(v MixtureIoType)`

SetReadMiss sets ReadMiss field to given value.


### GetRandomWrite

`func (o *MixtureType) GetRandomWrite() MixtureIoType`

GetRandomWrite returns the RandomWrite field if non-nil, zero value otherwise.

### GetRandomWriteOk

`func (o *MixtureType) GetRandomWriteOk() (*MixtureIoType, bool)`

GetRandomWriteOk returns a tuple with the RandomWrite field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetRandomWrite

`func (o *MixtureType) SetRandomWrite(v MixtureIoType)`

SetRandomWrite sets RandomWrite field to given value.


### GetSequentialRead

`func (o *MixtureType) GetSequentialRead() MixtureIoType`

GetSequentialRead returns the SequentialRead field if non-nil, zero value otherwise.

### GetSequentialReadOk

`func (o *MixtureType) GetSequentialReadOk() (*MixtureIoType, bool)`

GetSequentialReadOk returns a tuple with the SequentialRead field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetSequentialRead

`func (o *MixtureType) SetSequentialRead(v MixtureIoType)`

SetSequentialRead sets SequentialRead field to given value.


### GetSequentialWrite

`func (o *MixtureType) GetSequentialWrite() MixtureIoType`

GetSequentialWrite returns the SequentialWrite field if non-nil, zero value otherwise.

### GetSequentialWriteOk

`func (o *MixtureType) GetSequentialWriteOk() (*MixtureIoType, bool)`

GetSequentialWriteOk returns a tuple with the SequentialWrite field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetSequentialWrite

`func (o *MixtureType) SetSequentialWrite(v MixtureIoType)`

SetSequentialWrite sets SequentialWrite field to given value.



[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


