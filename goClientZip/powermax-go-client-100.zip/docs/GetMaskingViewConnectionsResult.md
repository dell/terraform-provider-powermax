# GetMaskingViewConnectionsResult

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**MaskingViewConnection** | Pointer to [**[]MaskingViewConnection**](MaskingViewConnection.md) | maskingViewConnection | [optional] 

## Methods

### NewGetMaskingViewConnectionsResult

`func NewGetMaskingViewConnectionsResult() *GetMaskingViewConnectionsResult`

NewGetMaskingViewConnectionsResult instantiates a new GetMaskingViewConnectionsResult object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewGetMaskingViewConnectionsResultWithDefaults

`func NewGetMaskingViewConnectionsResultWithDefaults() *GetMaskingViewConnectionsResult`

NewGetMaskingViewConnectionsResultWithDefaults instantiates a new GetMaskingViewConnectionsResult object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetMaskingViewConnection

`func (o *GetMaskingViewConnectionsResult) GetMaskingViewConnection() []MaskingViewConnection`

GetMaskingViewConnection returns the MaskingViewConnection field if non-nil, zero value otherwise.

### GetMaskingViewConnectionOk

`func (o *GetMaskingViewConnectionsResult) GetMaskingViewConnectionOk() (*[]MaskingViewConnection, bool)`

GetMaskingViewConnectionOk returns a tuple with the MaskingViewConnection field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetMaskingViewConnection

`func (o *GetMaskingViewConnectionsResult) SetMaskingViewConnection(v []MaskingViewConnection)`

SetMaskingViewConnection sets MaskingViewConnection field to given value.

### HasMaskingViewConnection

`func (o *GetMaskingViewConnectionsResult) HasMaskingViewConnection() bool`

HasMaskingViewConnection returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


