# ISCSIClientKeyResult

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**IscsiclientInfos** | Pointer to [**[]ISCSIClientInfo**](ISCSIClientInfo.md) |  | [optional] 

## Methods

### NewISCSIClientKeyResult

`func NewISCSIClientKeyResult() *ISCSIClientKeyResult`

NewISCSIClientKeyResult instantiates a new ISCSIClientKeyResult object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewISCSIClientKeyResultWithDefaults

`func NewISCSIClientKeyResultWithDefaults() *ISCSIClientKeyResult`

NewISCSIClientKeyResultWithDefaults instantiates a new ISCSIClientKeyResult object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetIscsiclientInfos

`func (o *ISCSIClientKeyResult) GetIscsiclientInfos() []ISCSIClientInfo`

GetIscsiclientInfos returns the IscsiclientInfos field if non-nil, zero value otherwise.

### GetIscsiclientInfosOk

`func (o *ISCSIClientKeyResult) GetIscsiclientInfosOk() (*[]ISCSIClientInfo, bool)`

GetIscsiclientInfosOk returns a tuple with the IscsiclientInfos field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetIscsiclientInfos

`func (o *ISCSIClientKeyResult) SetIscsiclientInfos(v []ISCSIClientInfo)`

SetIscsiclientInfos sets IscsiclientInfos field to given value.

### HasIscsiclientInfos

`func (o *ISCSIClientKeyResult) HasIscsiclientInfos() bool`

HasIscsiclientInfos returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


