# ListInitiatorResult

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**InitiatorId** | Pointer to **[]string** | ID of the initiator | [optional] 

## Methods

### NewListInitiatorResult

`func NewListInitiatorResult() *ListInitiatorResult`

NewListInitiatorResult instantiates a new ListInitiatorResult object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewListInitiatorResultWithDefaults

`func NewListInitiatorResultWithDefaults() *ListInitiatorResult`

NewListInitiatorResultWithDefaults instantiates a new ListInitiatorResult object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetInitiatorId

`func (o *ListInitiatorResult) GetInitiatorId() []string`

GetInitiatorId returns the InitiatorId field if non-nil, zero value otherwise.

### GetInitiatorIdOk

`func (o *ListInitiatorResult) GetInitiatorIdOk() (*[]string, bool)`

GetInitiatorIdOk returns a tuple with the InitiatorId field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetInitiatorId

`func (o *ListInitiatorResult) SetInitiatorId(v []string)`

SetInitiatorId sets InitiatorId field to given value.

### HasInitiatorId

`func (o *ListInitiatorResult) HasInitiatorId() bool`

HasInitiatorId returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


