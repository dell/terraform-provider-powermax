# ListSloResult

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**SloId** | Pointer to **[]string** | The SLO Name | [optional] 

## Methods

### NewListSloResult

`func NewListSloResult() *ListSloResult`

NewListSloResult instantiates a new ListSloResult object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewListSloResultWithDefaults

`func NewListSloResultWithDefaults() *ListSloResult`

NewListSloResultWithDefaults instantiates a new ListSloResult object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetSloId

`func (o *ListSloResult) GetSloId() []string`

GetSloId returns the SloId field if non-nil, zero value otherwise.

### GetSloIdOk

`func (o *ListSloResult) GetSloIdOk() (*[]string, bool)`

GetSloIdOk returns a tuple with the SloId field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetSloId

`func (o *ListSloResult) SetSloId(v []string)`

SetSloId sets SloId field to given value.

### HasSloId

`func (o *ListSloResult) HasSloId() bool`

HasSloId returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


