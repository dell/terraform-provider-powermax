# ListPerformanceThresholdResult

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Success** | Pointer to **bool** |  | [optional] [default to false]
**Message** | Pointer to **string** |  | [optional] 
**Category** | **string** | SPA category that we are listing metric names and thresholds for. | 
**NumOfMetricPerformanceThresholds** | Pointer to **int32** | The Total number of returned Performance Thresholds for giving category. | [optional] 
**PerformanceThreshold** | Pointer to [**[]PerformanceThresholdType**](PerformanceThresholdType.md) | The Performance Thresholds. | [optional] 

## Methods

### NewListPerformanceThresholdResult

`func NewListPerformanceThresholdResult(category string, ) *ListPerformanceThresholdResult`

NewListPerformanceThresholdResult instantiates a new ListPerformanceThresholdResult object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewListPerformanceThresholdResultWithDefaults

`func NewListPerformanceThresholdResultWithDefaults() *ListPerformanceThresholdResult`

NewListPerformanceThresholdResultWithDefaults instantiates a new ListPerformanceThresholdResult object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetSuccess

`func (o *ListPerformanceThresholdResult) GetSuccess() bool`

GetSuccess returns the Success field if non-nil, zero value otherwise.

### GetSuccessOk

`func (o *ListPerformanceThresholdResult) GetSuccessOk() (*bool, bool)`

GetSuccessOk returns a tuple with the Success field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetSuccess

`func (o *ListPerformanceThresholdResult) SetSuccess(v bool)`

SetSuccess sets Success field to given value.

### HasSuccess

`func (o *ListPerformanceThresholdResult) HasSuccess() bool`

HasSuccess returns a boolean if a field has been set.

### GetMessage

`func (o *ListPerformanceThresholdResult) GetMessage() string`

GetMessage returns the Message field if non-nil, zero value otherwise.

### GetMessageOk

`func (o *ListPerformanceThresholdResult) GetMessageOk() (*string, bool)`

GetMessageOk returns a tuple with the Message field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetMessage

`func (o *ListPerformanceThresholdResult) SetMessage(v string)`

SetMessage sets Message field to given value.

### HasMessage

`func (o *ListPerformanceThresholdResult) HasMessage() bool`

HasMessage returns a boolean if a field has been set.

### GetCategory

`func (o *ListPerformanceThresholdResult) GetCategory() string`

GetCategory returns the Category field if non-nil, zero value otherwise.

### GetCategoryOk

`func (o *ListPerformanceThresholdResult) GetCategoryOk() (*string, bool)`

GetCategoryOk returns a tuple with the Category field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetCategory

`func (o *ListPerformanceThresholdResult) SetCategory(v string)`

SetCategory sets Category field to given value.


### GetNumOfMetricPerformanceThresholds

`func (o *ListPerformanceThresholdResult) GetNumOfMetricPerformanceThresholds() int32`

GetNumOfMetricPerformanceThresholds returns the NumOfMetricPerformanceThresholds field if non-nil, zero value otherwise.

### GetNumOfMetricPerformanceThresholdsOk

`func (o *ListPerformanceThresholdResult) GetNumOfMetricPerformanceThresholdsOk() (*int32, bool)`

GetNumOfMetricPerformanceThresholdsOk returns a tuple with the NumOfMetricPerformanceThresholds field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetNumOfMetricPerformanceThresholds

`func (o *ListPerformanceThresholdResult) SetNumOfMetricPerformanceThresholds(v int32)`

SetNumOfMetricPerformanceThresholds sets NumOfMetricPerformanceThresholds field to given value.

### HasNumOfMetricPerformanceThresholds

`func (o *ListPerformanceThresholdResult) HasNumOfMetricPerformanceThresholds() bool`

HasNumOfMetricPerformanceThresholds returns a boolean if a field has been set.

### GetPerformanceThreshold

`func (o *ListPerformanceThresholdResult) GetPerformanceThreshold() []PerformanceThresholdType`

GetPerformanceThreshold returns the PerformanceThreshold field if non-nil, zero value otherwise.

### GetPerformanceThresholdOk

`func (o *ListPerformanceThresholdResult) GetPerformanceThresholdOk() (*[]PerformanceThresholdType, bool)`

GetPerformanceThresholdOk returns a tuple with the PerformanceThreshold field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetPerformanceThreshold

`func (o *ListPerformanceThresholdResult) SetPerformanceThreshold(v []PerformanceThresholdType)`

SetPerformanceThreshold sets PerformanceThreshold field to given value.

### HasPerformanceThreshold

`func (o *ListPerformanceThresholdResult) HasPerformanceThreshold() bool`

HasPerformanceThreshold returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


