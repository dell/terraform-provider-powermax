# DirectorPortList

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ExecutionOption** | Pointer to **string** |  | [optional] [default to "SYNCHRONOUS"]
**SymmetrixPortKey** | Pointer to [**[]SymmetrixPortKey**](SymmetrixPortKey.md) | symmetrixPortKey | [optional] 

## Methods

### NewDirectorPortList

`func NewDirectorPortList() *DirectorPortList`

NewDirectorPortList instantiates a new DirectorPortList object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewDirectorPortListWithDefaults

`func NewDirectorPortListWithDefaults() *DirectorPortList`

NewDirectorPortListWithDefaults instantiates a new DirectorPortList object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetExecutionOption

`func (o *DirectorPortList) GetExecutionOption() string`

GetExecutionOption returns the ExecutionOption field if non-nil, zero value otherwise.

### GetExecutionOptionOk

`func (o *DirectorPortList) GetExecutionOptionOk() (*string, bool)`

GetExecutionOptionOk returns a tuple with the ExecutionOption field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetExecutionOption

`func (o *DirectorPortList) SetExecutionOption(v string)`

SetExecutionOption sets ExecutionOption field to given value.

### HasExecutionOption

`func (o *DirectorPortList) HasExecutionOption() bool`

HasExecutionOption returns a boolean if a field has been set.

### GetSymmetrixPortKey

`func (o *DirectorPortList) GetSymmetrixPortKey() []SymmetrixPortKey`

GetSymmetrixPortKey returns the SymmetrixPortKey field if non-nil, zero value otherwise.

### GetSymmetrixPortKeyOk

`func (o *DirectorPortList) GetSymmetrixPortKeyOk() (*[]SymmetrixPortKey, bool)`

GetSymmetrixPortKeyOk returns a tuple with the SymmetrixPortKey field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetSymmetrixPortKey

`func (o *DirectorPortList) SetSymmetrixPortKey(v []SymmetrixPortKey)`

SetSymmetrixPortKey sets SymmetrixPortKey field to given value.

### HasSymmetrixPortKey

`func (o *DirectorPortList) HasSymmetrixPortKey() bool`

HasSymmetrixPortKey returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


