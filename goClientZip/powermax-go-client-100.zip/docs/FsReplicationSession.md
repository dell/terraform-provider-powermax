# FsReplicationSession

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Id** | Pointer to **string** |                          Specify the Object ID  of filesystem replication session                      | [optional] 
**Name** | Pointer to **string** |                          Fs replication session internally generated name, that include filesystem name at the end of the name                      | [optional] 
**IsDestination** | Pointer to **bool** | is_destination | [optional] 
**SrcFsId** | Pointer to **string** | src_fs_id | [optional] 
**DestFsId** | Pointer to **string** | dest_fs_id | [optional] 
**SrcRepStatus** | Pointer to [**FsRepStatus**](FsRepStatus.md) |  | [optional] 
**DestRepStatus** | Pointer to [**FsRepStatus**](FsRepStatus.md) |  | [optional] 
**RepSessionId** | Pointer to **string** | rep_session_id | [optional] 
**RepSessionState** | Pointer to **string** |                          FS replication session state                      | [optional] 
**RepStoppedReasons** | Pointer to **string** |                          FS replication session stopped and the reason for it                      | [optional] 
**SrcFsInternalId** | Pointer to **int32** |                          Specify the Id of the source resource involved in replication                      | [optional] 
**DestFsInternalId** | Pointer to **int32** |                          Specify the Id of the source resource involved in replication                      | [optional] 
**SrcLunWwn** | Pointer to **string** |                          Source FS LUN                      | [optional] 
**DestLunWwn** | Pointer to **string** |                          Destination FS LUN                      | [optional] 
**LastSyncTime** | Pointer to **string** |                          last successful sync                      | [optional] 
**TransferProgress** | Pointer to **int32** |                          Percentage of the data transfer that has been completed.  This shows the data transfer progress.                      | [optional] 
**CurrentTransferRate** | Pointer to **int32** |                          Rate of the data transfer in the unit of KBytes/sec.                      | [optional] 
**CurrentDiskReadRate** | Pointer to **int32** |                          Rate of the disk rate in the unit of KBytes/sec.                      | [optional] 
**CurrentDiskWriteRate** | Pointer to **int32** |                          Rate of the disk write in the unit of KBytes/sec.                      | [optional] 
**TotalBytesTransferred** | Pointer to **int32** |                          Total amount of data that has been transferred in unit of bytes.                      | [optional] 

## Methods

### NewFsReplicationSession

`func NewFsReplicationSession() *FsReplicationSession`

NewFsReplicationSession instantiates a new FsReplicationSession object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewFsReplicationSessionWithDefaults

`func NewFsReplicationSessionWithDefaults() *FsReplicationSession`

NewFsReplicationSessionWithDefaults instantiates a new FsReplicationSession object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetId

`func (o *FsReplicationSession) GetId() string`

GetId returns the Id field if non-nil, zero value otherwise.

### GetIdOk

`func (o *FsReplicationSession) GetIdOk() (*string, bool)`

GetIdOk returns a tuple with the Id field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetId

`func (o *FsReplicationSession) SetId(v string)`

SetId sets Id field to given value.

### HasId

`func (o *FsReplicationSession) HasId() bool`

HasId returns a boolean if a field has been set.

### GetName

`func (o *FsReplicationSession) GetName() string`

GetName returns the Name field if non-nil, zero value otherwise.

### GetNameOk

`func (o *FsReplicationSession) GetNameOk() (*string, bool)`

GetNameOk returns a tuple with the Name field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetName

`func (o *FsReplicationSession) SetName(v string)`

SetName sets Name field to given value.

### HasName

`func (o *FsReplicationSession) HasName() bool`

HasName returns a boolean if a field has been set.

### GetIsDestination

`func (o *FsReplicationSession) GetIsDestination() bool`

GetIsDestination returns the IsDestination field if non-nil, zero value otherwise.

### GetIsDestinationOk

`func (o *FsReplicationSession) GetIsDestinationOk() (*bool, bool)`

GetIsDestinationOk returns a tuple with the IsDestination field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetIsDestination

`func (o *FsReplicationSession) SetIsDestination(v bool)`

SetIsDestination sets IsDestination field to given value.

### HasIsDestination

`func (o *FsReplicationSession) HasIsDestination() bool`

HasIsDestination returns a boolean if a field has been set.

### GetSrcFsId

`func (o *FsReplicationSession) GetSrcFsId() string`

GetSrcFsId returns the SrcFsId field if non-nil, zero value otherwise.

### GetSrcFsIdOk

`func (o *FsReplicationSession) GetSrcFsIdOk() (*string, bool)`

GetSrcFsIdOk returns a tuple with the SrcFsId field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetSrcFsId

`func (o *FsReplicationSession) SetSrcFsId(v string)`

SetSrcFsId sets SrcFsId field to given value.

### HasSrcFsId

`func (o *FsReplicationSession) HasSrcFsId() bool`

HasSrcFsId returns a boolean if a field has been set.

### GetDestFsId

`func (o *FsReplicationSession) GetDestFsId() string`

GetDestFsId returns the DestFsId field if non-nil, zero value otherwise.

### GetDestFsIdOk

`func (o *FsReplicationSession) GetDestFsIdOk() (*string, bool)`

GetDestFsIdOk returns a tuple with the DestFsId field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetDestFsId

`func (o *FsReplicationSession) SetDestFsId(v string)`

SetDestFsId sets DestFsId field to given value.

### HasDestFsId

`func (o *FsReplicationSession) HasDestFsId() bool`

HasDestFsId returns a boolean if a field has been set.

### GetSrcRepStatus

`func (o *FsReplicationSession) GetSrcRepStatus() FsRepStatus`

GetSrcRepStatus returns the SrcRepStatus field if non-nil, zero value otherwise.

### GetSrcRepStatusOk

`func (o *FsReplicationSession) GetSrcRepStatusOk() (*FsRepStatus, bool)`

GetSrcRepStatusOk returns a tuple with the SrcRepStatus field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetSrcRepStatus

`func (o *FsReplicationSession) SetSrcRepStatus(v FsRepStatus)`

SetSrcRepStatus sets SrcRepStatus field to given value.

### HasSrcRepStatus

`func (o *FsReplicationSession) HasSrcRepStatus() bool`

HasSrcRepStatus returns a boolean if a field has been set.

### GetDestRepStatus

`func (o *FsReplicationSession) GetDestRepStatus() FsRepStatus`

GetDestRepStatus returns the DestRepStatus field if non-nil, zero value otherwise.

### GetDestRepStatusOk

`func (o *FsReplicationSession) GetDestRepStatusOk() (*FsRepStatus, bool)`

GetDestRepStatusOk returns a tuple with the DestRepStatus field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetDestRepStatus

`func (o *FsReplicationSession) SetDestRepStatus(v FsRepStatus)`

SetDestRepStatus sets DestRepStatus field to given value.

### HasDestRepStatus

`func (o *FsReplicationSession) HasDestRepStatus() bool`

HasDestRepStatus returns a boolean if a field has been set.

### GetRepSessionId

`func (o *FsReplicationSession) GetRepSessionId() string`

GetRepSessionId returns the RepSessionId field if non-nil, zero value otherwise.

### GetRepSessionIdOk

`func (o *FsReplicationSession) GetRepSessionIdOk() (*string, bool)`

GetRepSessionIdOk returns a tuple with the RepSessionId field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetRepSessionId

`func (o *FsReplicationSession) SetRepSessionId(v string)`

SetRepSessionId sets RepSessionId field to given value.

### HasRepSessionId

`func (o *FsReplicationSession) HasRepSessionId() bool`

HasRepSessionId returns a boolean if a field has been set.

### GetRepSessionState

`func (o *FsReplicationSession) GetRepSessionState() string`

GetRepSessionState returns the RepSessionState field if non-nil, zero value otherwise.

### GetRepSessionStateOk

`func (o *FsReplicationSession) GetRepSessionStateOk() (*string, bool)`

GetRepSessionStateOk returns a tuple with the RepSessionState field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetRepSessionState

`func (o *FsReplicationSession) SetRepSessionState(v string)`

SetRepSessionState sets RepSessionState field to given value.

### HasRepSessionState

`func (o *FsReplicationSession) HasRepSessionState() bool`

HasRepSessionState returns a boolean if a field has been set.

### GetRepStoppedReasons

`func (o *FsReplicationSession) GetRepStoppedReasons() string`

GetRepStoppedReasons returns the RepStoppedReasons field if non-nil, zero value otherwise.

### GetRepStoppedReasonsOk

`func (o *FsReplicationSession) GetRepStoppedReasonsOk() (*string, bool)`

GetRepStoppedReasonsOk returns a tuple with the RepStoppedReasons field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetRepStoppedReasons

`func (o *FsReplicationSession) SetRepStoppedReasons(v string)`

SetRepStoppedReasons sets RepStoppedReasons field to given value.

### HasRepStoppedReasons

`func (o *FsReplicationSession) HasRepStoppedReasons() bool`

HasRepStoppedReasons returns a boolean if a field has been set.

### GetSrcFsInternalId

`func (o *FsReplicationSession) GetSrcFsInternalId() int32`

GetSrcFsInternalId returns the SrcFsInternalId field if non-nil, zero value otherwise.

### GetSrcFsInternalIdOk

`func (o *FsReplicationSession) GetSrcFsInternalIdOk() (*int32, bool)`

GetSrcFsInternalIdOk returns a tuple with the SrcFsInternalId field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetSrcFsInternalId

`func (o *FsReplicationSession) SetSrcFsInternalId(v int32)`

SetSrcFsInternalId sets SrcFsInternalId field to given value.

### HasSrcFsInternalId

`func (o *FsReplicationSession) HasSrcFsInternalId() bool`

HasSrcFsInternalId returns a boolean if a field has been set.

### GetDestFsInternalId

`func (o *FsReplicationSession) GetDestFsInternalId() int32`

GetDestFsInternalId returns the DestFsInternalId field if non-nil, zero value otherwise.

### GetDestFsInternalIdOk

`func (o *FsReplicationSession) GetDestFsInternalIdOk() (*int32, bool)`

GetDestFsInternalIdOk returns a tuple with the DestFsInternalId field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetDestFsInternalId

`func (o *FsReplicationSession) SetDestFsInternalId(v int32)`

SetDestFsInternalId sets DestFsInternalId field to given value.

### HasDestFsInternalId

`func (o *FsReplicationSession) HasDestFsInternalId() bool`

HasDestFsInternalId returns a boolean if a field has been set.

### GetSrcLunWwn

`func (o *FsReplicationSession) GetSrcLunWwn() string`

GetSrcLunWwn returns the SrcLunWwn field if non-nil, zero value otherwise.

### GetSrcLunWwnOk

`func (o *FsReplicationSession) GetSrcLunWwnOk() (*string, bool)`

GetSrcLunWwnOk returns a tuple with the SrcLunWwn field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetSrcLunWwn

`func (o *FsReplicationSession) SetSrcLunWwn(v string)`

SetSrcLunWwn sets SrcLunWwn field to given value.

### HasSrcLunWwn

`func (o *FsReplicationSession) HasSrcLunWwn() bool`

HasSrcLunWwn returns a boolean if a field has been set.

### GetDestLunWwn

`func (o *FsReplicationSession) GetDestLunWwn() string`

GetDestLunWwn returns the DestLunWwn field if non-nil, zero value otherwise.

### GetDestLunWwnOk

`func (o *FsReplicationSession) GetDestLunWwnOk() (*string, bool)`

GetDestLunWwnOk returns a tuple with the DestLunWwn field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetDestLunWwn

`func (o *FsReplicationSession) SetDestLunWwn(v string)`

SetDestLunWwn sets DestLunWwn field to given value.

### HasDestLunWwn

`func (o *FsReplicationSession) HasDestLunWwn() bool`

HasDestLunWwn returns a boolean if a field has been set.

### GetLastSyncTime

`func (o *FsReplicationSession) GetLastSyncTime() string`

GetLastSyncTime returns the LastSyncTime field if non-nil, zero value otherwise.

### GetLastSyncTimeOk

`func (o *FsReplicationSession) GetLastSyncTimeOk() (*string, bool)`

GetLastSyncTimeOk returns a tuple with the LastSyncTime field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetLastSyncTime

`func (o *FsReplicationSession) SetLastSyncTime(v string)`

SetLastSyncTime sets LastSyncTime field to given value.

### HasLastSyncTime

`func (o *FsReplicationSession) HasLastSyncTime() bool`

HasLastSyncTime returns a boolean if a field has been set.

### GetTransferProgress

`func (o *FsReplicationSession) GetTransferProgress() int32`

GetTransferProgress returns the TransferProgress field if non-nil, zero value otherwise.

### GetTransferProgressOk

`func (o *FsReplicationSession) GetTransferProgressOk() (*int32, bool)`

GetTransferProgressOk returns a tuple with the TransferProgress field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetTransferProgress

`func (o *FsReplicationSession) SetTransferProgress(v int32)`

SetTransferProgress sets TransferProgress field to given value.

### HasTransferProgress

`func (o *FsReplicationSession) HasTransferProgress() bool`

HasTransferProgress returns a boolean if a field has been set.

### GetCurrentTransferRate

`func (o *FsReplicationSession) GetCurrentTransferRate() int32`

GetCurrentTransferRate returns the CurrentTransferRate field if non-nil, zero value otherwise.

### GetCurrentTransferRateOk

`func (o *FsReplicationSession) GetCurrentTransferRateOk() (*int32, bool)`

GetCurrentTransferRateOk returns a tuple with the CurrentTransferRate field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetCurrentTransferRate

`func (o *FsReplicationSession) SetCurrentTransferRate(v int32)`

SetCurrentTransferRate sets CurrentTransferRate field to given value.

### HasCurrentTransferRate

`func (o *FsReplicationSession) HasCurrentTransferRate() bool`

HasCurrentTransferRate returns a boolean if a field has been set.

### GetCurrentDiskReadRate

`func (o *FsReplicationSession) GetCurrentDiskReadRate() int32`

GetCurrentDiskReadRate returns the CurrentDiskReadRate field if non-nil, zero value otherwise.

### GetCurrentDiskReadRateOk

`func (o *FsReplicationSession) GetCurrentDiskReadRateOk() (*int32, bool)`

GetCurrentDiskReadRateOk returns a tuple with the CurrentDiskReadRate field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetCurrentDiskReadRate

`func (o *FsReplicationSession) SetCurrentDiskReadRate(v int32)`

SetCurrentDiskReadRate sets CurrentDiskReadRate field to given value.

### HasCurrentDiskReadRate

`func (o *FsReplicationSession) HasCurrentDiskReadRate() bool`

HasCurrentDiskReadRate returns a boolean if a field has been set.

### GetCurrentDiskWriteRate

`func (o *FsReplicationSession) GetCurrentDiskWriteRate() int32`

GetCurrentDiskWriteRate returns the CurrentDiskWriteRate field if non-nil, zero value otherwise.

### GetCurrentDiskWriteRateOk

`func (o *FsReplicationSession) GetCurrentDiskWriteRateOk() (*int32, bool)`

GetCurrentDiskWriteRateOk returns a tuple with the CurrentDiskWriteRate field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetCurrentDiskWriteRate

`func (o *FsReplicationSession) SetCurrentDiskWriteRate(v int32)`

SetCurrentDiskWriteRate sets CurrentDiskWriteRate field to given value.

### HasCurrentDiskWriteRate

`func (o *FsReplicationSession) HasCurrentDiskWriteRate() bool`

HasCurrentDiskWriteRate returns a boolean if a field has been set.

### GetTotalBytesTransferred

`func (o *FsReplicationSession) GetTotalBytesTransferred() int32`

GetTotalBytesTransferred returns the TotalBytesTransferred field if non-nil, zero value otherwise.

### GetTotalBytesTransferredOk

`func (o *FsReplicationSession) GetTotalBytesTransferredOk() (*int32, bool)`

GetTotalBytesTransferredOk returns a tuple with the TotalBytesTransferred field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetTotalBytesTransferred

`func (o *FsReplicationSession) SetTotalBytesTransferred(v int32)`

SetTotalBytesTransferred sets TotalBytesTransferred field to given value.

### HasTotalBytesTransferred

`func (o *FsReplicationSession) HasTotalBytesTransferred() bool`

HasTotalBytesTransferred returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


