# EditHostGroupActionParam

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**SetHostGroupFlagsParam** | Pointer to [**SetHostGroupFlagsParam**](SetHostGroupFlagsParam.md) |  | [optional] 
**RemoveHostParam** | Pointer to [**RemoveHostParam**](RemoveHostParam.md) |  | [optional] 
**AddHostParam** | Pointer to [**AddHostParam**](AddHostParam.md) |  | [optional] 
**RenameHostGroupParam** | Pointer to [**RenameHostGroupParam**](RenameHostGroupParam.md) |  | [optional] 

## Methods

### NewEditHostGroupActionParam

`func NewEditHostGroupActionParam() *EditHostGroupActionParam`

NewEditHostGroupActionParam instantiates a new EditHostGroupActionParam object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewEditHostGroupActionParamWithDefaults

`func NewEditHostGroupActionParamWithDefaults() *EditHostGroupActionParam`

NewEditHostGroupActionParamWithDefaults instantiates a new EditHostGroupActionParam object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetSetHostGroupFlagsParam

`func (o *EditHostGroupActionParam) GetSetHostGroupFlagsParam() SetHostGroupFlagsParam`

GetSetHostGroupFlagsParam returns the SetHostGroupFlagsParam field if non-nil, zero value otherwise.

### GetSetHostGroupFlagsParamOk

`func (o *EditHostGroupActionParam) GetSetHostGroupFlagsParamOk() (*SetHostGroupFlagsParam, bool)`

GetSetHostGroupFlagsParamOk returns a tuple with the SetHostGroupFlagsParam field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetSetHostGroupFlagsParam

`func (o *EditHostGroupActionParam) SetSetHostGroupFlagsParam(v SetHostGroupFlagsParam)`

SetSetHostGroupFlagsParam sets SetHostGroupFlagsParam field to given value.

### HasSetHostGroupFlagsParam

`func (o *EditHostGroupActionParam) HasSetHostGroupFlagsParam() bool`

HasSetHostGroupFlagsParam returns a boolean if a field has been set.

### GetRemoveHostParam

`func (o *EditHostGroupActionParam) GetRemoveHostParam() RemoveHostParam`

GetRemoveHostParam returns the RemoveHostParam field if non-nil, zero value otherwise.

### GetRemoveHostParamOk

`func (o *EditHostGroupActionParam) GetRemoveHostParamOk() (*RemoveHostParam, bool)`

GetRemoveHostParamOk returns a tuple with the RemoveHostParam field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetRemoveHostParam

`func (o *EditHostGroupActionParam) SetRemoveHostParam(v RemoveHostParam)`

SetRemoveHostParam sets RemoveHostParam field to given value.

### HasRemoveHostParam

`func (o *EditHostGroupActionParam) HasRemoveHostParam() bool`

HasRemoveHostParam returns a boolean if a field has been set.

### GetAddHostParam

`func (o *EditHostGroupActionParam) GetAddHostParam() AddHostParam`

GetAddHostParam returns the AddHostParam field if non-nil, zero value otherwise.

### GetAddHostParamOk

`func (o *EditHostGroupActionParam) GetAddHostParamOk() (*AddHostParam, bool)`

GetAddHostParamOk returns a tuple with the AddHostParam field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetAddHostParam

`func (o *EditHostGroupActionParam) SetAddHostParam(v AddHostParam)`

SetAddHostParam sets AddHostParam field to given value.

### HasAddHostParam

`func (o *EditHostGroupActionParam) HasAddHostParam() bool`

HasAddHostParam returns a boolean if a field has been set.

### GetRenameHostGroupParam

`func (o *EditHostGroupActionParam) GetRenameHostGroupParam() RenameHostGroupParam`

GetRenameHostGroupParam returns the RenameHostGroupParam field if non-nil, zero value otherwise.

### GetRenameHostGroupParamOk

`func (o *EditHostGroupActionParam) GetRenameHostGroupParamOk() (*RenameHostGroupParam, bool)`

GetRenameHostGroupParamOk returns a tuple with the RenameHostGroupParam field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetRenameHostGroupParam

`func (o *EditHostGroupActionParam) SetRenameHostGroupParam(v RenameHostGroupParam)`

SetRenameHostGroupParam sets RenameHostGroupParam field to given value.

### HasRenameHostGroupParam

`func (o *EditHostGroupActionParam) HasRenameHostGroupParam() bool`

HasRenameHostGroupParam returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


