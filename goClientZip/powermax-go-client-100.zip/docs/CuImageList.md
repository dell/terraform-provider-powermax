# CuImageList

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**CuImageSSID** | Pointer to **[]string** | The CU images configured on a specific System | [optional] 

## Methods

### NewCuImageList

`func NewCuImageList() *CuImageList`

NewCuImageList instantiates a new CuImageList object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewCuImageListWithDefaults

`func NewCuImageListWithDefaults() *CuImageList`

NewCuImageListWithDefaults instantiates a new CuImageList object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetCuImageSSID

`func (o *CuImageList) GetCuImageSSID() []string`

GetCuImageSSID returns the CuImageSSID field if non-nil, zero value otherwise.

### GetCuImageSSIDOk

`func (o *CuImageList) GetCuImageSSIDOk() (*[]string, bool)`

GetCuImageSSIDOk returns a tuple with the CuImageSSID field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetCuImageSSID

`func (o *CuImageList) SetCuImageSSID(v []string)`

SetCuImageSSID sets CuImageSSID field to given value.

### HasCuImageSSID

`func (o *CuImageList) HasCuImageSSID() bool`

HasCuImageSSID returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


