# Host

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**HostId** | **string** | Host name | 
**NumOfMaskingViews** | Pointer to **int64** | Number of masking views associated with the host | [optional] 
**NumOfInitiators** | Pointer to **int32** | Number of initiators associated with the host | [optional] 
**NumOfHostGroups** | Pointer to **int32** | Number of host groups associated with the host | [optional] 
**PortFlagsOverride** | Pointer to **bool** | States whether port flags override is enabled on the host | [optional] 
**ConsistentLun** | Pointer to **bool** | States whether consistent LUNs is enabled on the host | [optional] 
**EnabledFlags** | Pointer to **string** | Flags enabled on the host | [optional] 
**DisabledFlags** | Pointer to **string** | Flags disabled on the host | [optional] 
**Type** | Pointer to **string** | Host type | [optional] 
**Initiator** | Pointer to **[]string** | Initiators associated with the host | [optional] 
**Hostgroup** | Pointer to **[]string** | Host group associated with the host | [optional] 
**Maskingview** | Pointer to **[]string** | Masking view associated with the host | [optional] 
**Powerpathhosts** | Pointer to **[]string** | The PowerPath hosts associated with the host | [optional] 
**NumOfPowerpathHosts** | Pointer to **int64** | Number of PowerPath hosts associated with the host | [optional] 
**BwLimit** | Pointer to **int64** | The host bandwidth limit | [optional] 

## Methods

### NewHost

`func NewHost(hostId string, ) *Host`

NewHost instantiates a new Host object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewHostWithDefaults

`func NewHostWithDefaults() *Host`

NewHostWithDefaults instantiates a new Host object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetHostId

`func (o *Host) GetHostId() string`

GetHostId returns the HostId field if non-nil, zero value otherwise.

### GetHostIdOk

`func (o *Host) GetHostIdOk() (*string, bool)`

GetHostIdOk returns a tuple with the HostId field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetHostId

`func (o *Host) SetHostId(v string)`

SetHostId sets HostId field to given value.


### GetNumOfMaskingViews

`func (o *Host) GetNumOfMaskingViews() int64`

GetNumOfMaskingViews returns the NumOfMaskingViews field if non-nil, zero value otherwise.

### GetNumOfMaskingViewsOk

`func (o *Host) GetNumOfMaskingViewsOk() (*int64, bool)`

GetNumOfMaskingViewsOk returns a tuple with the NumOfMaskingViews field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetNumOfMaskingViews

`func (o *Host) SetNumOfMaskingViews(v int64)`

SetNumOfMaskingViews sets NumOfMaskingViews field to given value.

### HasNumOfMaskingViews

`func (o *Host) HasNumOfMaskingViews() bool`

HasNumOfMaskingViews returns a boolean if a field has been set.

### GetNumOfInitiators

`func (o *Host) GetNumOfInitiators() int32`

GetNumOfInitiators returns the NumOfInitiators field if non-nil, zero value otherwise.

### GetNumOfInitiatorsOk

`func (o *Host) GetNumOfInitiatorsOk() (*int32, bool)`

GetNumOfInitiatorsOk returns a tuple with the NumOfInitiators field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetNumOfInitiators

`func (o *Host) SetNumOfInitiators(v int32)`

SetNumOfInitiators sets NumOfInitiators field to given value.

### HasNumOfInitiators

`func (o *Host) HasNumOfInitiators() bool`

HasNumOfInitiators returns a boolean if a field has been set.

### GetNumOfHostGroups

`func (o *Host) GetNumOfHostGroups() int32`

GetNumOfHostGroups returns the NumOfHostGroups field if non-nil, zero value otherwise.

### GetNumOfHostGroupsOk

`func (o *Host) GetNumOfHostGroupsOk() (*int32, bool)`

GetNumOfHostGroupsOk returns a tuple with the NumOfHostGroups field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetNumOfHostGroups

`func (o *Host) SetNumOfHostGroups(v int32)`

SetNumOfHostGroups sets NumOfHostGroups field to given value.

### HasNumOfHostGroups

`func (o *Host) HasNumOfHostGroups() bool`

HasNumOfHostGroups returns a boolean if a field has been set.

### GetPortFlagsOverride

`func (o *Host) GetPortFlagsOverride() bool`

GetPortFlagsOverride returns the PortFlagsOverride field if non-nil, zero value otherwise.

### GetPortFlagsOverrideOk

`func (o *Host) GetPortFlagsOverrideOk() (*bool, bool)`

GetPortFlagsOverrideOk returns a tuple with the PortFlagsOverride field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetPortFlagsOverride

`func (o *Host) SetPortFlagsOverride(v bool)`

SetPortFlagsOverride sets PortFlagsOverride field to given value.

### HasPortFlagsOverride

`func (o *Host) HasPortFlagsOverride() bool`

HasPortFlagsOverride returns a boolean if a field has been set.

### GetConsistentLun

`func (o *Host) GetConsistentLun() bool`

GetConsistentLun returns the ConsistentLun field if non-nil, zero value otherwise.

### GetConsistentLunOk

`func (o *Host) GetConsistentLunOk() (*bool, bool)`

GetConsistentLunOk returns a tuple with the ConsistentLun field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetConsistentLun

`func (o *Host) SetConsistentLun(v bool)`

SetConsistentLun sets ConsistentLun field to given value.

### HasConsistentLun

`func (o *Host) HasConsistentLun() bool`

HasConsistentLun returns a boolean if a field has been set.

### GetEnabledFlags

`func (o *Host) GetEnabledFlags() string`

GetEnabledFlags returns the EnabledFlags field if non-nil, zero value otherwise.

### GetEnabledFlagsOk

`func (o *Host) GetEnabledFlagsOk() (*string, bool)`

GetEnabledFlagsOk returns a tuple with the EnabledFlags field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetEnabledFlags

`func (o *Host) SetEnabledFlags(v string)`

SetEnabledFlags sets EnabledFlags field to given value.

### HasEnabledFlags

`func (o *Host) HasEnabledFlags() bool`

HasEnabledFlags returns a boolean if a field has been set.

### GetDisabledFlags

`func (o *Host) GetDisabledFlags() string`

GetDisabledFlags returns the DisabledFlags field if non-nil, zero value otherwise.

### GetDisabledFlagsOk

`func (o *Host) GetDisabledFlagsOk() (*string, bool)`

GetDisabledFlagsOk returns a tuple with the DisabledFlags field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetDisabledFlags

`func (o *Host) SetDisabledFlags(v string)`

SetDisabledFlags sets DisabledFlags field to given value.

### HasDisabledFlags

`func (o *Host) HasDisabledFlags() bool`

HasDisabledFlags returns a boolean if a field has been set.

### GetType

`func (o *Host) GetType() string`

GetType returns the Type field if non-nil, zero value otherwise.

### GetTypeOk

`func (o *Host) GetTypeOk() (*string, bool)`

GetTypeOk returns a tuple with the Type field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetType

`func (o *Host) SetType(v string)`

SetType sets Type field to given value.

### HasType

`func (o *Host) HasType() bool`

HasType returns a boolean if a field has been set.

### GetInitiator

`func (o *Host) GetInitiator() []string`

GetInitiator returns the Initiator field if non-nil, zero value otherwise.

### GetInitiatorOk

`func (o *Host) GetInitiatorOk() (*[]string, bool)`

GetInitiatorOk returns a tuple with the Initiator field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetInitiator

`func (o *Host) SetInitiator(v []string)`

SetInitiator sets Initiator field to given value.

### HasInitiator

`func (o *Host) HasInitiator() bool`

HasInitiator returns a boolean if a field has been set.

### GetHostgroup

`func (o *Host) GetHostgroup() []string`

GetHostgroup returns the Hostgroup field if non-nil, zero value otherwise.

### GetHostgroupOk

`func (o *Host) GetHostgroupOk() (*[]string, bool)`

GetHostgroupOk returns a tuple with the Hostgroup field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetHostgroup

`func (o *Host) SetHostgroup(v []string)`

SetHostgroup sets Hostgroup field to given value.

### HasHostgroup

`func (o *Host) HasHostgroup() bool`

HasHostgroup returns a boolean if a field has been set.

### GetMaskingview

`func (o *Host) GetMaskingview() []string`

GetMaskingview returns the Maskingview field if non-nil, zero value otherwise.

### GetMaskingviewOk

`func (o *Host) GetMaskingviewOk() (*[]string, bool)`

GetMaskingviewOk returns a tuple with the Maskingview field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetMaskingview

`func (o *Host) SetMaskingview(v []string)`

SetMaskingview sets Maskingview field to given value.

### HasMaskingview

`func (o *Host) HasMaskingview() bool`

HasMaskingview returns a boolean if a field has been set.

### GetPowerpathhosts

`func (o *Host) GetPowerpathhosts() []string`

GetPowerpathhosts returns the Powerpathhosts field if non-nil, zero value otherwise.

### GetPowerpathhostsOk

`func (o *Host) GetPowerpathhostsOk() (*[]string, bool)`

GetPowerpathhostsOk returns a tuple with the Powerpathhosts field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetPowerpathhosts

`func (o *Host) SetPowerpathhosts(v []string)`

SetPowerpathhosts sets Powerpathhosts field to given value.

### HasPowerpathhosts

`func (o *Host) HasPowerpathhosts() bool`

HasPowerpathhosts returns a boolean if a field has been set.

### GetNumOfPowerpathHosts

`func (o *Host) GetNumOfPowerpathHosts() int64`

GetNumOfPowerpathHosts returns the NumOfPowerpathHosts field if non-nil, zero value otherwise.

### GetNumOfPowerpathHostsOk

`func (o *Host) GetNumOfPowerpathHostsOk() (*int64, bool)`

GetNumOfPowerpathHostsOk returns a tuple with the NumOfPowerpathHosts field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetNumOfPowerpathHosts

`func (o *Host) SetNumOfPowerpathHosts(v int64)`

SetNumOfPowerpathHosts sets NumOfPowerpathHosts field to given value.

### HasNumOfPowerpathHosts

`func (o *Host) HasNumOfPowerpathHosts() bool`

HasNumOfPowerpathHosts returns a boolean if a field has been set.

### GetBwLimit

`func (o *Host) GetBwLimit() int64`

GetBwLimit returns the BwLimit field if non-nil, zero value otherwise.

### GetBwLimitOk

`func (o *Host) GetBwLimitOk() (*int64, bool)`

GetBwLimitOk returns a tuple with the BwLimit field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetBwLimit

`func (o *Host) SetBwLimit(v int64)`

SetBwLimit sets BwLimit field to given value.

### HasBwLimit

`func (o *Host) HasBwLimit() bool`

HasBwLimit returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


