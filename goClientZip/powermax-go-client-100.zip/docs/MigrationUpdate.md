# MigrationUpdate

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ExecutionOption** | Pointer to **string** |  | [optional] [default to "SYNCHRONOUS"]
**Action** | **string** | The action to be performed.   Enumeration values: * **Cutover** - Cutover the migration session to the target System * **Sync** - Start or stop synchronisation of the migration session back to the source System * **Commit** - Commit the migration session to the target System and remove the linking back to the source System * **Recover** - Recover the migration session from a failed state * **ReadyTgt** - Make the migration target ready  | 
**Sync** | Pointer to [**SyncParam**](SyncParam.md) |  | [optional] 
**Recover** | Pointer to [**RecoverParam**](RecoverParam.md) |  | [optional] 
**Cutover** | Pointer to [**CutoverParam**](CutoverParam.md) |  | [optional] 

## Methods

### NewMigrationUpdate

`func NewMigrationUpdate(action string, ) *MigrationUpdate`

NewMigrationUpdate instantiates a new MigrationUpdate object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewMigrationUpdateWithDefaults

`func NewMigrationUpdateWithDefaults() *MigrationUpdate`

NewMigrationUpdateWithDefaults instantiates a new MigrationUpdate object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetExecutionOption

`func (o *MigrationUpdate) GetExecutionOption() string`

GetExecutionOption returns the ExecutionOption field if non-nil, zero value otherwise.

### GetExecutionOptionOk

`func (o *MigrationUpdate) GetExecutionOptionOk() (*string, bool)`

GetExecutionOptionOk returns a tuple with the ExecutionOption field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetExecutionOption

`func (o *MigrationUpdate) SetExecutionOption(v string)`

SetExecutionOption sets ExecutionOption field to given value.

### HasExecutionOption

`func (o *MigrationUpdate) HasExecutionOption() bool`

HasExecutionOption returns a boolean if a field has been set.

### GetAction

`func (o *MigrationUpdate) GetAction() string`

GetAction returns the Action field if non-nil, zero value otherwise.

### GetActionOk

`func (o *MigrationUpdate) GetActionOk() (*string, bool)`

GetActionOk returns a tuple with the Action field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetAction

`func (o *MigrationUpdate) SetAction(v string)`

SetAction sets Action field to given value.


### GetSync

`func (o *MigrationUpdate) GetSync() SyncParam`

GetSync returns the Sync field if non-nil, zero value otherwise.

### GetSyncOk

`func (o *MigrationUpdate) GetSyncOk() (*SyncParam, bool)`

GetSyncOk returns a tuple with the Sync field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetSync

`func (o *MigrationUpdate) SetSync(v SyncParam)`

SetSync sets Sync field to given value.

### HasSync

`func (o *MigrationUpdate) HasSync() bool`

HasSync returns a boolean if a field has been set.

### GetRecover

`func (o *MigrationUpdate) GetRecover() RecoverParam`

GetRecover returns the Recover field if non-nil, zero value otherwise.

### GetRecoverOk

`func (o *MigrationUpdate) GetRecoverOk() (*RecoverParam, bool)`

GetRecoverOk returns a tuple with the Recover field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetRecover

`func (o *MigrationUpdate) SetRecover(v RecoverParam)`

SetRecover sets Recover field to given value.

### HasRecover

`func (o *MigrationUpdate) HasRecover() bool`

HasRecover returns a boolean if a field has been set.

### GetCutover

`func (o *MigrationUpdate) GetCutover() CutoverParam`

GetCutover returns the Cutover field if non-nil, zero value otherwise.

### GetCutoverOk

`func (o *MigrationUpdate) GetCutoverOk() (*CutoverParam, bool)`

GetCutoverOk returns a tuple with the Cutover field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetCutover

`func (o *MigrationUpdate) SetCutover(v CutoverParam)`

SetCutover sets Cutover field to given value.

### HasCutover

`func (o *MigrationUpdate) HasCutover() bool`

HasCutover returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


