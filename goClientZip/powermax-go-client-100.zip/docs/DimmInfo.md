# DimmInfo

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**FirstAvailableDate** | Pointer to **int64** |  | [optional] 
**LastAvailableDate** | Pointer to **int64** |  | [optional] 
**DimmId** | **string** | dimmId | 

## Methods

### NewDimmInfo

`func NewDimmInfo(dimmId string, ) *DimmInfo`

NewDimmInfo instantiates a new DimmInfo object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewDimmInfoWithDefaults

`func NewDimmInfoWithDefaults() *DimmInfo`

NewDimmInfoWithDefaults instantiates a new DimmInfo object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetFirstAvailableDate

`func (o *DimmInfo) GetFirstAvailableDate() int64`

GetFirstAvailableDate returns the FirstAvailableDate field if non-nil, zero value otherwise.

### GetFirstAvailableDateOk

`func (o *DimmInfo) GetFirstAvailableDateOk() (*int64, bool)`

GetFirstAvailableDateOk returns a tuple with the FirstAvailableDate field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetFirstAvailableDate

`func (o *DimmInfo) SetFirstAvailableDate(v int64)`

SetFirstAvailableDate sets FirstAvailableDate field to given value.

### HasFirstAvailableDate

`func (o *DimmInfo) HasFirstAvailableDate() bool`

HasFirstAvailableDate returns a boolean if a field has been set.

### GetLastAvailableDate

`func (o *DimmInfo) GetLastAvailableDate() int64`

GetLastAvailableDate returns the LastAvailableDate field if non-nil, zero value otherwise.

### GetLastAvailableDateOk

`func (o *DimmInfo) GetLastAvailableDateOk() (*int64, bool)`

GetLastAvailableDateOk returns a tuple with the LastAvailableDate field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetLastAvailableDate

`func (o *DimmInfo) SetLastAvailableDate(v int64)`

SetLastAvailableDate sets LastAvailableDate field to given value.

### HasLastAvailableDate

`func (o *DimmInfo) HasLastAvailableDate() bool`

HasLastAvailableDate returns a boolean if a field has been set.

### GetDimmId

`func (o *DimmInfo) GetDimmId() string`

GetDimmId returns the DimmId field if non-nil, zero value otherwise.

### GetDimmIdOk

`func (o *DimmInfo) GetDimmIdOk() (*string, bool)`

GetDimmIdOk returns a tuple with the DimmId field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetDimmId

`func (o *DimmInfo) SetDimmId(v string)`

SetDimmId sets DimmId field to given value.



[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


