# CloudProviderInfo

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**FirstAvailableDate** | Pointer to **int64** |  | [optional] 
**LastAvailableDate** | Pointer to **int64** |  | [optional] 
**Name** | **string** | name | 

## Methods

### NewCloudProviderInfo

`func NewCloudProviderInfo(name string, ) *CloudProviderInfo`

NewCloudProviderInfo instantiates a new CloudProviderInfo object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewCloudProviderInfoWithDefaults

`func NewCloudProviderInfoWithDefaults() *CloudProviderInfo`

NewCloudProviderInfoWithDefaults instantiates a new CloudProviderInfo object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetFirstAvailableDate

`func (o *CloudProviderInfo) GetFirstAvailableDate() int64`

GetFirstAvailableDate returns the FirstAvailableDate field if non-nil, zero value otherwise.

### GetFirstAvailableDateOk

`func (o *CloudProviderInfo) GetFirstAvailableDateOk() (*int64, bool)`

GetFirstAvailableDateOk returns a tuple with the FirstAvailableDate field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetFirstAvailableDate

`func (o *CloudProviderInfo) SetFirstAvailableDate(v int64)`

SetFirstAvailableDate sets FirstAvailableDate field to given value.

### HasFirstAvailableDate

`func (o *CloudProviderInfo) HasFirstAvailableDate() bool`

HasFirstAvailableDate returns a boolean if a field has been set.

### GetLastAvailableDate

`func (o *CloudProviderInfo) GetLastAvailableDate() int64`

GetLastAvailableDate returns the LastAvailableDate field if non-nil, zero value otherwise.

### GetLastAvailableDateOk

`func (o *CloudProviderInfo) GetLastAvailableDateOk() (*int64, bool)`

GetLastAvailableDateOk returns a tuple with the LastAvailableDate field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetLastAvailableDate

`func (o *CloudProviderInfo) SetLastAvailableDate(v int64)`

SetLastAvailableDate sets LastAvailableDate field to given value.

### HasLastAvailableDate

`func (o *CloudProviderInfo) HasLastAvailableDate() bool`

HasLastAvailableDate returns a boolean if a field has been set.

### GetName

`func (o *CloudProviderInfo) GetName() string`

GetName returns the Name field if non-nil, zero value otherwise.

### GetNameOk

`func (o *CloudProviderInfo) GetNameOk() (*string, bool)`

GetNameOk returns a tuple with the Name field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetName

`func (o *CloudProviderInfo) SetName(v string)`

SetName sets Name field to given value.



[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


