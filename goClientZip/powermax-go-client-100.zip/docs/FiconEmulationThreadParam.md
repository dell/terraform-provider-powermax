# FiconEmulationThreadParam

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**StartDate** | **int64** | Starting date in millisecond. | 
**EndDate** | **int64** | Ending date in millisecond. | 
**SymmetrixId** | **string** | &lt;p&gt;The Symmetrix array ID.&lt;/p&gt; | 
**FiconEmulationThreadId** | **string** | ficonEmulationThreadId | 
**DataFormat** | Pointer to **string** | &lt;p&gt;Data Format (Average or Maximum).&lt;/p&gt;   Enumeration values: * **Average** * **Maximum**  | [optional] 
**Metrics** | **[]string** | metrics   Enumeration values: * **PercentBusy** - % Busy * **PercentIdle** - % Idle  | 

## Methods

### NewFiconEmulationThreadParam

`func NewFiconEmulationThreadParam(startDate int64, endDate int64, symmetrixId string, ficonEmulationThreadId string, metrics []string, ) *FiconEmulationThreadParam`

NewFiconEmulationThreadParam instantiates a new FiconEmulationThreadParam object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewFiconEmulationThreadParamWithDefaults

`func NewFiconEmulationThreadParamWithDefaults() *FiconEmulationThreadParam`

NewFiconEmulationThreadParamWithDefaults instantiates a new FiconEmulationThreadParam object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetStartDate

`func (o *FiconEmulationThreadParam) GetStartDate() int64`

GetStartDate returns the StartDate field if non-nil, zero value otherwise.

### GetStartDateOk

`func (o *FiconEmulationThreadParam) GetStartDateOk() (*int64, bool)`

GetStartDateOk returns a tuple with the StartDate field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetStartDate

`func (o *FiconEmulationThreadParam) SetStartDate(v int64)`

SetStartDate sets StartDate field to given value.


### GetEndDate

`func (o *FiconEmulationThreadParam) GetEndDate() int64`

GetEndDate returns the EndDate field if non-nil, zero value otherwise.

### GetEndDateOk

`func (o *FiconEmulationThreadParam) GetEndDateOk() (*int64, bool)`

GetEndDateOk returns a tuple with the EndDate field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetEndDate

`func (o *FiconEmulationThreadParam) SetEndDate(v int64)`

SetEndDate sets EndDate field to given value.


### GetSymmetrixId

`func (o *FiconEmulationThreadParam) GetSymmetrixId() string`

GetSymmetrixId returns the SymmetrixId field if non-nil, zero value otherwise.

### GetSymmetrixIdOk

`func (o *FiconEmulationThreadParam) GetSymmetrixIdOk() (*string, bool)`

GetSymmetrixIdOk returns a tuple with the SymmetrixId field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetSymmetrixId

`func (o *FiconEmulationThreadParam) SetSymmetrixId(v string)`

SetSymmetrixId sets SymmetrixId field to given value.


### GetFiconEmulationThreadId

`func (o *FiconEmulationThreadParam) GetFiconEmulationThreadId() string`

GetFiconEmulationThreadId returns the FiconEmulationThreadId field if non-nil, zero value otherwise.

### GetFiconEmulationThreadIdOk

`func (o *FiconEmulationThreadParam) GetFiconEmulationThreadIdOk() (*string, bool)`

GetFiconEmulationThreadIdOk returns a tuple with the FiconEmulationThreadId field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetFiconEmulationThreadId

`func (o *FiconEmulationThreadParam) SetFiconEmulationThreadId(v string)`

SetFiconEmulationThreadId sets FiconEmulationThreadId field to given value.


### GetDataFormat

`func (o *FiconEmulationThreadParam) GetDataFormat() string`

GetDataFormat returns the DataFormat field if non-nil, zero value otherwise.

### GetDataFormatOk

`func (o *FiconEmulationThreadParam) GetDataFormatOk() (*string, bool)`

GetDataFormatOk returns a tuple with the DataFormat field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetDataFormat

`func (o *FiconEmulationThreadParam) SetDataFormat(v string)`

SetDataFormat sets DataFormat field to given value.

### HasDataFormat

`func (o *FiconEmulationThreadParam) HasDataFormat() bool`

HasDataFormat returns a boolean if a field has been set.

### GetMetrics

`func (o *FiconEmulationThreadParam) GetMetrics() []string`

GetMetrics returns the Metrics field if non-nil, zero value otherwise.

### GetMetricsOk

`func (o *FiconEmulationThreadParam) GetMetricsOk() (*[]string, bool)`

GetMetricsOk returns a tuple with the Metrics field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetMetrics

`func (o *FiconEmulationThreadParam) SetMetrics(v []string)`

SetMetrics sets Metrics field to given value.



[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


