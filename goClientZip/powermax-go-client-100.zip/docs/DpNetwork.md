# DpNetwork

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Id** | Pointer to **string** |                          Unique identifier of the dpNetwork instance.                      | [optional] 
**Type** | Pointer to **string** |                          Type of DP Network.                         - 0 - Any.                         - 1 - Import                        Enumeration values: * **Any** * **Import**  | [optional] 
**Name** | Pointer to **string** |                          User friendly name of the data protection network                      | [optional] 
**NetDevice** | Pointer to **string** |                          Virtual port or link aggregation on which the network interface is running.                      | [optional] 
**ClusterIpAddress** | Pointer to **string** |                          IP address for the cluster on the network interface.                      | [optional] 
**PrefixLength** | Pointer to **int32** |                          IP address prefix length for the interface.                      | [optional] 
**Gateway** | Pointer to **string** |                          IPv4 or IPv6 gateway address for the network interface.                      | [optional] 
**VlanId** | Pointer to **int32** |  Indicates the VLAN this File Interface part of.  | [optional] 
**NodeAddresses** | Pointer to **[]string** |                          The list of addresses for the nodes, starting with node 1.                      | [optional] 
**State** | Pointer to **string** |                          Consistency state of data protection network.                         - 0: OK - dpNetwork is consistent                         - 1: BadDelete - dpNetwork is incosistent, needs to be deleted                         - 2: BadModifyAuto - dpNetwork is incosistent, can be modified automatically                         - 3: BadModifyManual - dpNetwork is incosistent, needs to be modified manually                        Enumeration values: * **OK** * **BadDelete** * **BadModifyAuto** * **BadModifyManual**  | [optional] 

## Methods

### NewDpNetwork

`func NewDpNetwork() *DpNetwork`

NewDpNetwork instantiates a new DpNetwork object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewDpNetworkWithDefaults

`func NewDpNetworkWithDefaults() *DpNetwork`

NewDpNetworkWithDefaults instantiates a new DpNetwork object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetId

`func (o *DpNetwork) GetId() string`

GetId returns the Id field if non-nil, zero value otherwise.

### GetIdOk

`func (o *DpNetwork) GetIdOk() (*string, bool)`

GetIdOk returns a tuple with the Id field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetId

`func (o *DpNetwork) SetId(v string)`

SetId sets Id field to given value.

### HasId

`func (o *DpNetwork) HasId() bool`

HasId returns a boolean if a field has been set.

### GetType

`func (o *DpNetwork) GetType() string`

GetType returns the Type field if non-nil, zero value otherwise.

### GetTypeOk

`func (o *DpNetwork) GetTypeOk() (*string, bool)`

GetTypeOk returns a tuple with the Type field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetType

`func (o *DpNetwork) SetType(v string)`

SetType sets Type field to given value.

### HasType

`func (o *DpNetwork) HasType() bool`

HasType returns a boolean if a field has been set.

### GetName

`func (o *DpNetwork) GetName() string`

GetName returns the Name field if non-nil, zero value otherwise.

### GetNameOk

`func (o *DpNetwork) GetNameOk() (*string, bool)`

GetNameOk returns a tuple with the Name field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetName

`func (o *DpNetwork) SetName(v string)`

SetName sets Name field to given value.

### HasName

`func (o *DpNetwork) HasName() bool`

HasName returns a boolean if a field has been set.

### GetNetDevice

`func (o *DpNetwork) GetNetDevice() string`

GetNetDevice returns the NetDevice field if non-nil, zero value otherwise.

### GetNetDeviceOk

`func (o *DpNetwork) GetNetDeviceOk() (*string, bool)`

GetNetDeviceOk returns a tuple with the NetDevice field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetNetDevice

`func (o *DpNetwork) SetNetDevice(v string)`

SetNetDevice sets NetDevice field to given value.

### HasNetDevice

`func (o *DpNetwork) HasNetDevice() bool`

HasNetDevice returns a boolean if a field has been set.

### GetClusterIpAddress

`func (o *DpNetwork) GetClusterIpAddress() string`

GetClusterIpAddress returns the ClusterIpAddress field if non-nil, zero value otherwise.

### GetClusterIpAddressOk

`func (o *DpNetwork) GetClusterIpAddressOk() (*string, bool)`

GetClusterIpAddressOk returns a tuple with the ClusterIpAddress field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetClusterIpAddress

`func (o *DpNetwork) SetClusterIpAddress(v string)`

SetClusterIpAddress sets ClusterIpAddress field to given value.

### HasClusterIpAddress

`func (o *DpNetwork) HasClusterIpAddress() bool`

HasClusterIpAddress returns a boolean if a field has been set.

### GetPrefixLength

`func (o *DpNetwork) GetPrefixLength() int32`

GetPrefixLength returns the PrefixLength field if non-nil, zero value otherwise.

### GetPrefixLengthOk

`func (o *DpNetwork) GetPrefixLengthOk() (*int32, bool)`

GetPrefixLengthOk returns a tuple with the PrefixLength field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetPrefixLength

`func (o *DpNetwork) SetPrefixLength(v int32)`

SetPrefixLength sets PrefixLength field to given value.

### HasPrefixLength

`func (o *DpNetwork) HasPrefixLength() bool`

HasPrefixLength returns a boolean if a field has been set.

### GetGateway

`func (o *DpNetwork) GetGateway() string`

GetGateway returns the Gateway field if non-nil, zero value otherwise.

### GetGatewayOk

`func (o *DpNetwork) GetGatewayOk() (*string, bool)`

GetGatewayOk returns a tuple with the Gateway field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetGateway

`func (o *DpNetwork) SetGateway(v string)`

SetGateway sets Gateway field to given value.

### HasGateway

`func (o *DpNetwork) HasGateway() bool`

HasGateway returns a boolean if a field has been set.

### GetVlanId

`func (o *DpNetwork) GetVlanId() int32`

GetVlanId returns the VlanId field if non-nil, zero value otherwise.

### GetVlanIdOk

`func (o *DpNetwork) GetVlanIdOk() (*int32, bool)`

GetVlanIdOk returns a tuple with the VlanId field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetVlanId

`func (o *DpNetwork) SetVlanId(v int32)`

SetVlanId sets VlanId field to given value.

### HasVlanId

`func (o *DpNetwork) HasVlanId() bool`

HasVlanId returns a boolean if a field has been set.

### GetNodeAddresses

`func (o *DpNetwork) GetNodeAddresses() []string`

GetNodeAddresses returns the NodeAddresses field if non-nil, zero value otherwise.

### GetNodeAddressesOk

`func (o *DpNetwork) GetNodeAddressesOk() (*[]string, bool)`

GetNodeAddressesOk returns a tuple with the NodeAddresses field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetNodeAddresses

`func (o *DpNetwork) SetNodeAddresses(v []string)`

SetNodeAddresses sets NodeAddresses field to given value.

### HasNodeAddresses

`func (o *DpNetwork) HasNodeAddresses() bool`

HasNodeAddresses returns a boolean if a field has been set.

### GetState

`func (o *DpNetwork) GetState() string`

GetState returns the State field if non-nil, zero value otherwise.

### GetStateOk

`func (o *DpNetwork) GetStateOk() (*string, bool)`

GetStateOk returns a tuple with the State field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetState

`func (o *DpNetwork) SetState(v string)`

SetState sets State field to given value.

### HasState

`func (o *DpNetwork) HasState() bool`

HasState returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


