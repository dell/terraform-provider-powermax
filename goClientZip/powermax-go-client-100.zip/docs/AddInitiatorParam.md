# AddInitiatorParam

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Initiator** | **[]string** | ID of the initiator | 

## Methods

### NewAddInitiatorParam

`func NewAddInitiatorParam(initiator []string, ) *AddInitiatorParam`

NewAddInitiatorParam instantiates a new AddInitiatorParam object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewAddInitiatorParamWithDefaults

`func NewAddInitiatorParamWithDefaults() *AddInitiatorParam`

NewAddInitiatorParamWithDefaults instantiates a new AddInitiatorParam object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetInitiator

`func (o *AddInitiatorParam) GetInitiator() []string`

GetInitiator returns the Initiator field if non-nil, zero value otherwise.

### GetInitiatorOk

`func (o *AddInitiatorParam) GetInitiatorOk() (*[]string, bool)`

GetInitiatorOk returns a tuple with the Initiator field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetInitiator

`func (o *AddInitiatorParam) SetInitiator(v []string)`

SetInitiator sets Initiator field to given value.



[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


