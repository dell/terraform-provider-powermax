# \CommonApi

All URIs are relative to *https://localhost:8443/univmax/restapi*

Method | HTTP request | Description
------------- | ------------- | -------------
[**Close**](CommonApi.md#Close) | **Delete** /common/Iterator/{iteratorId} | Delete Iterator
[**Info**](CommonApi.md#Info) | **Get** /common/Iterator/{iteratorId} | Get Iterator
[**Page**](CommonApi.md#Page) | **Get** /common/Iterator/{iteratorId}/page | Get Iterator Page



## Close

> Close(ctx, iteratorId).Execute()

Delete Iterator



### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    iteratorId := "iteratorId_example" // string | The Iterator ID

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.CommonApi.Close(context.Background(), iteratorId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `CommonApi.Close``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**iteratorId** | **string** | The Iterator ID | 

### Other Parameters

Other parameters are passed through a pointer to a apiCloseRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


### Return type

 (empty response body)

### Authorization

[apiSecurity](../README.md#apiSecurity)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## Info

> Iterator Info(ctx, iteratorId).Execute()

Get Iterator



### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    iteratorId := "iteratorId_example" // string | The Iterator ID

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.CommonApi.Info(context.Background(), iteratorId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `CommonApi.Info``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `Info`: Iterator
    fmt.Fprintf(os.Stdout, "Response from `CommonApi.Info`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**iteratorId** | **string** | The Iterator ID | 

### Other Parameters

Other parameters are passed through a pointer to a apiInfoRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


### Return type

[**Iterator**](Iterator.md)

### Authorization

[apiSecurity](../README.md#apiSecurity)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json, application/xml

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## Page

> ResultList Page(ctx, iteratorId).From(from).To(to).Execute()

Get Iterator Page



### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    iteratorId := "iteratorId_example" // string | The Iterator ID
    from := int32(56) // int32 | Item number to start from
    to := int32(56) // int32 | Item number to end at

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.CommonApi.Page(context.Background(), iteratorId).From(from).To(to).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `CommonApi.Page``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `Page`: ResultList
    fmt.Fprintf(os.Stdout, "Response from `CommonApi.Page`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**iteratorId** | **string** | The Iterator ID | 

### Other Parameters

Other parameters are passed through a pointer to a apiPageRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **from** | **int32** | Item number to start from | 
 **to** | **int32** | Item number to end at | 

### Return type

[**ResultList**](ResultList.md)

### Authorization

[apiSecurity](../README.md#apiSecurity)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json, application/xml

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)

