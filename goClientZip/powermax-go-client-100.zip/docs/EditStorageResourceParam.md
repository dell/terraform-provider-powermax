# EditStorageResourceParam

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ExecutionOption** | Pointer to **string** |  | [optional] [default to "SYNCHRONOUS"]
**EditStorageResourceActionParam** | [**EditStorageResourceActionParam**](EditStorageResourceActionParam.md) |  | 

## Methods

### NewEditStorageResourceParam

`func NewEditStorageResourceParam(editStorageResourceActionParam EditStorageResourceActionParam, ) *EditStorageResourceParam`

NewEditStorageResourceParam instantiates a new EditStorageResourceParam object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewEditStorageResourceParamWithDefaults

`func NewEditStorageResourceParamWithDefaults() *EditStorageResourceParam`

NewEditStorageResourceParamWithDefaults instantiates a new EditStorageResourceParam object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetExecutionOption

`func (o *EditStorageResourceParam) GetExecutionOption() string`

GetExecutionOption returns the ExecutionOption field if non-nil, zero value otherwise.

### GetExecutionOptionOk

`func (o *EditStorageResourceParam) GetExecutionOptionOk() (*string, bool)`

GetExecutionOptionOk returns a tuple with the ExecutionOption field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetExecutionOption

`func (o *EditStorageResourceParam) SetExecutionOption(v string)`

SetExecutionOption sets ExecutionOption field to given value.

### HasExecutionOption

`func (o *EditStorageResourceParam) HasExecutionOption() bool`

HasExecutionOption returns a boolean if a field has been set.

### GetEditStorageResourceActionParam

`func (o *EditStorageResourceParam) GetEditStorageResourceActionParam() EditStorageResourceActionParam`

GetEditStorageResourceActionParam returns the EditStorageResourceActionParam field if non-nil, zero value otherwise.

### GetEditStorageResourceActionParamOk

`func (o *EditStorageResourceParam) GetEditStorageResourceActionParamOk() (*EditStorageResourceActionParam, bool)`

GetEditStorageResourceActionParamOk returns a tuple with the EditStorageResourceActionParam field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetEditStorageResourceActionParam

`func (o *EditStorageResourceParam) SetEditStorageResourceActionParam(v EditStorageResourceActionParam)`

SetEditStorageResourceActionParam sets EditStorageResourceActionParam field to given value.



[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


