# HostIOLimitAttributes

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**MetricLimit** | Pointer to **string** | The metric to which a limit should apply. Valid values are IOPS, MBPS, Both, or None.   Enumeration values: * **IOPS** - Set Host I/O Limits in IOPS on storage group. * **MBPS** - Set Host I/O Limits in MBPS on storage group. * **Both** - Set both IOPS and MBPS Host I/O Limits on storage group. * **None** - Do not set Host I/O Limits on storage group.  | [optional] [default to "IOPS"]
**ScaleLimits** | Pointer to **bool** | Scale Host I/O Limits if default capacity is overridden when                         provisioning from this template, so that the I/O density is preserved. | [optional] [default to true]
**HostIoLimitMbps** | Pointer to **int32** | The MBPS Host I/O limit for the specified provisioning template.                         If no value is specified, and metricLimit is MBPS or Both, a recommended limit is calculated. | [optional] 
**HostIoLimitIops** | Pointer to **int32** | The IOPS Host I/O limit for the specified provisioning template.                         If no value is specified, and metricLimit is IOPS or Both, a recommended limit is calculated.                         Must be a multiple of 100. | [optional] 
**DynamicDistribution** | Pointer to **string** | The dynamic distribution type. Valid values are Never, Always or OnFailure.   Enumeration values: * **Never** * **Always** * **OnFailure**  | [optional] 

## Methods

### NewHostIOLimitAttributes

`func NewHostIOLimitAttributes() *HostIOLimitAttributes`

NewHostIOLimitAttributes instantiates a new HostIOLimitAttributes object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewHostIOLimitAttributesWithDefaults

`func NewHostIOLimitAttributesWithDefaults() *HostIOLimitAttributes`

NewHostIOLimitAttributesWithDefaults instantiates a new HostIOLimitAttributes object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetMetricLimit

`func (o *HostIOLimitAttributes) GetMetricLimit() string`

GetMetricLimit returns the MetricLimit field if non-nil, zero value otherwise.

### GetMetricLimitOk

`func (o *HostIOLimitAttributes) GetMetricLimitOk() (*string, bool)`

GetMetricLimitOk returns a tuple with the MetricLimit field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetMetricLimit

`func (o *HostIOLimitAttributes) SetMetricLimit(v string)`

SetMetricLimit sets MetricLimit field to given value.

### HasMetricLimit

`func (o *HostIOLimitAttributes) HasMetricLimit() bool`

HasMetricLimit returns a boolean if a field has been set.

### GetScaleLimits

`func (o *HostIOLimitAttributes) GetScaleLimits() bool`

GetScaleLimits returns the ScaleLimits field if non-nil, zero value otherwise.

### GetScaleLimitsOk

`func (o *HostIOLimitAttributes) GetScaleLimitsOk() (*bool, bool)`

GetScaleLimitsOk returns a tuple with the ScaleLimits field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetScaleLimits

`func (o *HostIOLimitAttributes) SetScaleLimits(v bool)`

SetScaleLimits sets ScaleLimits field to given value.

### HasScaleLimits

`func (o *HostIOLimitAttributes) HasScaleLimits() bool`

HasScaleLimits returns a boolean if a field has been set.

### GetHostIoLimitMbps

`func (o *HostIOLimitAttributes) GetHostIoLimitMbps() int32`

GetHostIoLimitMbps returns the HostIoLimitMbps field if non-nil, zero value otherwise.

### GetHostIoLimitMbpsOk

`func (o *HostIOLimitAttributes) GetHostIoLimitMbpsOk() (*int32, bool)`

GetHostIoLimitMbpsOk returns a tuple with the HostIoLimitMbps field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetHostIoLimitMbps

`func (o *HostIOLimitAttributes) SetHostIoLimitMbps(v int32)`

SetHostIoLimitMbps sets HostIoLimitMbps field to given value.

### HasHostIoLimitMbps

`func (o *HostIOLimitAttributes) HasHostIoLimitMbps() bool`

HasHostIoLimitMbps returns a boolean if a field has been set.

### GetHostIoLimitIops

`func (o *HostIOLimitAttributes) GetHostIoLimitIops() int32`

GetHostIoLimitIops returns the HostIoLimitIops field if non-nil, zero value otherwise.

### GetHostIoLimitIopsOk

`func (o *HostIOLimitAttributes) GetHostIoLimitIopsOk() (*int32, bool)`

GetHostIoLimitIopsOk returns a tuple with the HostIoLimitIops field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetHostIoLimitIops

`func (o *HostIOLimitAttributes) SetHostIoLimitIops(v int32)`

SetHostIoLimitIops sets HostIoLimitIops field to given value.

### HasHostIoLimitIops

`func (o *HostIOLimitAttributes) HasHostIoLimitIops() bool`

HasHostIoLimitIops returns a boolean if a field has been set.

### GetDynamicDistribution

`func (o *HostIOLimitAttributes) GetDynamicDistribution() string`

GetDynamicDistribution returns the DynamicDistribution field if non-nil, zero value otherwise.

### GetDynamicDistributionOk

`func (o *HostIOLimitAttributes) GetDynamicDistributionOk() (*string, bool)`

GetDynamicDistributionOk returns a tuple with the DynamicDistribution field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetDynamicDistribution

`func (o *HostIOLimitAttributes) SetDynamicDistribution(v string)`

SetDynamicDistribution sets DynamicDistribution field to given value.

### HasDynamicDistribution

`func (o *HostIOLimitAttributes) HasDynamicDistribution() bool`

HasDynamicDistribution returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


