# DataExclusion

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**EpochTimestamp** | Pointer to **int64** | The workload planner epoch timestamp. Workload planner ignores all workload data before this timestamp. | [optional] 
**ExcludedBucket** | Pointer to **[]int32** | A bucket is a four hour time window. A week has 42 buckets (0-indexed). Bucket 0 is Sunday 12am-4am, 1 is Sunday 4am-8am, etc. | [optional] 
**LastModifiedTimestamp** | Pointer to **int64** | The server time when the exclusion settings were last modified. | [optional] 
**LastModifiedUser** | Pointer to **string** | The name of the user that last modified the exclusion settings. | [optional] 

## Methods

### NewDataExclusion

`func NewDataExclusion() *DataExclusion`

NewDataExclusion instantiates a new DataExclusion object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewDataExclusionWithDefaults

`func NewDataExclusionWithDefaults() *DataExclusion`

NewDataExclusionWithDefaults instantiates a new DataExclusion object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetEpochTimestamp

`func (o *DataExclusion) GetEpochTimestamp() int64`

GetEpochTimestamp returns the EpochTimestamp field if non-nil, zero value otherwise.

### GetEpochTimestampOk

`func (o *DataExclusion) GetEpochTimestampOk() (*int64, bool)`

GetEpochTimestampOk returns a tuple with the EpochTimestamp field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetEpochTimestamp

`func (o *DataExclusion) SetEpochTimestamp(v int64)`

SetEpochTimestamp sets EpochTimestamp field to given value.

### HasEpochTimestamp

`func (o *DataExclusion) HasEpochTimestamp() bool`

HasEpochTimestamp returns a boolean if a field has been set.

### GetExcludedBucket

`func (o *DataExclusion) GetExcludedBucket() []int32`

GetExcludedBucket returns the ExcludedBucket field if non-nil, zero value otherwise.

### GetExcludedBucketOk

`func (o *DataExclusion) GetExcludedBucketOk() (*[]int32, bool)`

GetExcludedBucketOk returns a tuple with the ExcludedBucket field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetExcludedBucket

`func (o *DataExclusion) SetExcludedBucket(v []int32)`

SetExcludedBucket sets ExcludedBucket field to given value.

### HasExcludedBucket

`func (o *DataExclusion) HasExcludedBucket() bool`

HasExcludedBucket returns a boolean if a field has been set.

### GetLastModifiedTimestamp

`func (o *DataExclusion) GetLastModifiedTimestamp() int64`

GetLastModifiedTimestamp returns the LastModifiedTimestamp field if non-nil, zero value otherwise.

### GetLastModifiedTimestampOk

`func (o *DataExclusion) GetLastModifiedTimestampOk() (*int64, bool)`

GetLastModifiedTimestampOk returns a tuple with the LastModifiedTimestamp field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetLastModifiedTimestamp

`func (o *DataExclusion) SetLastModifiedTimestamp(v int64)`

SetLastModifiedTimestamp sets LastModifiedTimestamp field to given value.

### HasLastModifiedTimestamp

`func (o *DataExclusion) HasLastModifiedTimestamp() bool`

HasLastModifiedTimestamp returns a boolean if a field has been set.

### GetLastModifiedUser

`func (o *DataExclusion) GetLastModifiedUser() string`

GetLastModifiedUser returns the LastModifiedUser field if non-nil, zero value otherwise.

### GetLastModifiedUserOk

`func (o *DataExclusion) GetLastModifiedUserOk() (*string, bool)`

GetLastModifiedUserOk returns a tuple with the LastModifiedUser field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetLastModifiedUser

`func (o *DataExclusion) SetLastModifiedUser(v string)`

SetLastModifiedUser sets LastModifiedUser field to given value.

### HasLastModifiedUser

`func (o *DataExclusion) HasLastModifiedUser() bool`

HasLastModifiedUser returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


