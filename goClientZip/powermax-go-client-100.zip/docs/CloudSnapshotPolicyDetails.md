# CloudSnapshotPolicyDetails

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**CloudRetentionDays** | Pointer to **int32** | The number of cloud retention days. Has to be a minimum of 3 days and maximum of 5110 days (14 years by assuming a year                                 contains                                 365 days) | [optional] 
**CloudProviderName** | Pointer to **string** | The name of the Cloud Provider | [optional] 

## Methods

### NewCloudSnapshotPolicyDetails

`func NewCloudSnapshotPolicyDetails() *CloudSnapshotPolicyDetails`

NewCloudSnapshotPolicyDetails instantiates a new CloudSnapshotPolicyDetails object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewCloudSnapshotPolicyDetailsWithDefaults

`func NewCloudSnapshotPolicyDetailsWithDefaults() *CloudSnapshotPolicyDetails`

NewCloudSnapshotPolicyDetailsWithDefaults instantiates a new CloudSnapshotPolicyDetails object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetCloudRetentionDays

`func (o *CloudSnapshotPolicyDetails) GetCloudRetentionDays() int32`

GetCloudRetentionDays returns the CloudRetentionDays field if non-nil, zero value otherwise.

### GetCloudRetentionDaysOk

`func (o *CloudSnapshotPolicyDetails) GetCloudRetentionDaysOk() (*int32, bool)`

GetCloudRetentionDaysOk returns a tuple with the CloudRetentionDays field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetCloudRetentionDays

`func (o *CloudSnapshotPolicyDetails) SetCloudRetentionDays(v int32)`

SetCloudRetentionDays sets CloudRetentionDays field to given value.

### HasCloudRetentionDays

`func (o *CloudSnapshotPolicyDetails) HasCloudRetentionDays() bool`

HasCloudRetentionDays returns a boolean if a field has been set.

### GetCloudProviderName

`func (o *CloudSnapshotPolicyDetails) GetCloudProviderName() string`

GetCloudProviderName returns the CloudProviderName field if non-nil, zero value otherwise.

### GetCloudProviderNameOk

`func (o *CloudSnapshotPolicyDetails) GetCloudProviderNameOk() (*string, bool)`

GetCloudProviderNameOk returns a tuple with the CloudProviderName field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetCloudProviderName

`func (o *CloudSnapshotPolicyDetails) SetCloudProviderName(v string)`

SetCloudProviderName sets CloudProviderName field to given value.

### HasCloudProviderName

`func (o *CloudSnapshotPolicyDetails) HasCloudProviderName() bool`

HasCloudProviderName returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


