# CloneVolumePairList

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**CloneCount** | Pointer to **int32** | The number of clone pairs being returned | [optional] 
**Clones** | Pointer to [**[]CloneVolumePair**](CloneVolumePair.md) | Clone pairs on the System | [optional] 

## Methods

### NewCloneVolumePairList

`func NewCloneVolumePairList() *CloneVolumePairList`

NewCloneVolumePairList instantiates a new CloneVolumePairList object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewCloneVolumePairListWithDefaults

`func NewCloneVolumePairListWithDefaults() *CloneVolumePairList`

NewCloneVolumePairListWithDefaults instantiates a new CloneVolumePairList object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetCloneCount

`func (o *CloneVolumePairList) GetCloneCount() int32`

GetCloneCount returns the CloneCount field if non-nil, zero value otherwise.

### GetCloneCountOk

`func (o *CloneVolumePairList) GetCloneCountOk() (*int32, bool)`

GetCloneCountOk returns a tuple with the CloneCount field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetCloneCount

`func (o *CloneVolumePairList) SetCloneCount(v int32)`

SetCloneCount sets CloneCount field to given value.

### HasCloneCount

`func (o *CloneVolumePairList) HasCloneCount() bool`

HasCloneCount returns a boolean if a field has been set.

### GetClones

`func (o *CloneVolumePairList) GetClones() []CloneVolumePair`

GetClones returns the Clones field if non-nil, zero value otherwise.

### GetClonesOk

`func (o *CloneVolumePairList) GetClonesOk() (*[]CloneVolumePair, bool)`

GetClonesOk returns a tuple with the Clones field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetClones

`func (o *CloneVolumePairList) SetClones(v []CloneVolumePair)`

SetClones sets Clones field to given value.

### HasClones

`func (o *CloneVolumePairList) HasClones() bool`

HasClones returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


