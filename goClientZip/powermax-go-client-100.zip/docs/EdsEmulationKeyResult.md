# EdsEmulationKeyResult

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**EdsEmulationInfo** | Pointer to [**[]EdsEmulationInfo**](EdsEmulationInfo.md) | edsEmulationInfo | [optional] 

## Methods

### NewEdsEmulationKeyResult

`func NewEdsEmulationKeyResult() *EdsEmulationKeyResult`

NewEdsEmulationKeyResult instantiates a new EdsEmulationKeyResult object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewEdsEmulationKeyResultWithDefaults

`func NewEdsEmulationKeyResultWithDefaults() *EdsEmulationKeyResult`

NewEdsEmulationKeyResultWithDefaults instantiates a new EdsEmulationKeyResult object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetEdsEmulationInfo

`func (o *EdsEmulationKeyResult) GetEdsEmulationInfo() []EdsEmulationInfo`

GetEdsEmulationInfo returns the EdsEmulationInfo field if non-nil, zero value otherwise.

### GetEdsEmulationInfoOk

`func (o *EdsEmulationKeyResult) GetEdsEmulationInfoOk() (*[]EdsEmulationInfo, bool)`

GetEdsEmulationInfoOk returns a tuple with the EdsEmulationInfo field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetEdsEmulationInfo

`func (o *EdsEmulationKeyResult) SetEdsEmulationInfo(v []EdsEmulationInfo)`

SetEdsEmulationInfo sets EdsEmulationInfo field to given value.

### HasEdsEmulationInfo

`func (o *EdsEmulationKeyResult) HasEdsEmulationInfo() bool`

HasEdsEmulationInfo returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


