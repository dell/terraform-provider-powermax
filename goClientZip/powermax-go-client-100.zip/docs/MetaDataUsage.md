# MetaDataUsage

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**SystemMetaDataUsedPercent** | Pointer to **float64** | System Meta Data Used Percent based on the number of subscribed volumes on the VMAX | [optional] 
**ReplicationCacheUsedPercent** | Pointer to **int64** | Cache percentage used for Replication | [optional] 
**FrontendMetaDataUsedPercent** | Pointer to **float64** | Frontend Meta Data Percent (only available on uCode 5978 or higher) | [optional] 
**BackendMetaDataUsedPercent** | Pointer to **float64** | Backend Meta Data Percent (only available on uCode 5978 or higher) | [optional] 

## Methods

### NewMetaDataUsage

`func NewMetaDataUsage() *MetaDataUsage`

NewMetaDataUsage instantiates a new MetaDataUsage object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewMetaDataUsageWithDefaults

`func NewMetaDataUsageWithDefaults() *MetaDataUsage`

NewMetaDataUsageWithDefaults instantiates a new MetaDataUsage object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetSystemMetaDataUsedPercent

`func (o *MetaDataUsage) GetSystemMetaDataUsedPercent() float64`

GetSystemMetaDataUsedPercent returns the SystemMetaDataUsedPercent field if non-nil, zero value otherwise.

### GetSystemMetaDataUsedPercentOk

`func (o *MetaDataUsage) GetSystemMetaDataUsedPercentOk() (*float64, bool)`

GetSystemMetaDataUsedPercentOk returns a tuple with the SystemMetaDataUsedPercent field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetSystemMetaDataUsedPercent

`func (o *MetaDataUsage) SetSystemMetaDataUsedPercent(v float64)`

SetSystemMetaDataUsedPercent sets SystemMetaDataUsedPercent field to given value.

### HasSystemMetaDataUsedPercent

`func (o *MetaDataUsage) HasSystemMetaDataUsedPercent() bool`

HasSystemMetaDataUsedPercent returns a boolean if a field has been set.

### GetReplicationCacheUsedPercent

`func (o *MetaDataUsage) GetReplicationCacheUsedPercent() int64`

GetReplicationCacheUsedPercent returns the ReplicationCacheUsedPercent field if non-nil, zero value otherwise.

### GetReplicationCacheUsedPercentOk

`func (o *MetaDataUsage) GetReplicationCacheUsedPercentOk() (*int64, bool)`

GetReplicationCacheUsedPercentOk returns a tuple with the ReplicationCacheUsedPercent field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetReplicationCacheUsedPercent

`func (o *MetaDataUsage) SetReplicationCacheUsedPercent(v int64)`

SetReplicationCacheUsedPercent sets ReplicationCacheUsedPercent field to given value.

### HasReplicationCacheUsedPercent

`func (o *MetaDataUsage) HasReplicationCacheUsedPercent() bool`

HasReplicationCacheUsedPercent returns a boolean if a field has been set.

### GetFrontendMetaDataUsedPercent

`func (o *MetaDataUsage) GetFrontendMetaDataUsedPercent() float64`

GetFrontendMetaDataUsedPercent returns the FrontendMetaDataUsedPercent field if non-nil, zero value otherwise.

### GetFrontendMetaDataUsedPercentOk

`func (o *MetaDataUsage) GetFrontendMetaDataUsedPercentOk() (*float64, bool)`

GetFrontendMetaDataUsedPercentOk returns a tuple with the FrontendMetaDataUsedPercent field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetFrontendMetaDataUsedPercent

`func (o *MetaDataUsage) SetFrontendMetaDataUsedPercent(v float64)`

SetFrontendMetaDataUsedPercent sets FrontendMetaDataUsedPercent field to given value.

### HasFrontendMetaDataUsedPercent

`func (o *MetaDataUsage) HasFrontendMetaDataUsedPercent() bool`

HasFrontendMetaDataUsedPercent returns a boolean if a field has been set.

### GetBackendMetaDataUsedPercent

`func (o *MetaDataUsage) GetBackendMetaDataUsedPercent() float64`

GetBackendMetaDataUsedPercent returns the BackendMetaDataUsedPercent field if non-nil, zero value otherwise.

### GetBackendMetaDataUsedPercentOk

`func (o *MetaDataUsage) GetBackendMetaDataUsedPercentOk() (*float64, bool)`

GetBackendMetaDataUsedPercentOk returns a tuple with the BackendMetaDataUsedPercent field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetBackendMetaDataUsedPercent

`func (o *MetaDataUsage) SetBackendMetaDataUsedPercent(v float64)`

SetBackendMetaDataUsedPercent sets BackendMetaDataUsedPercent field to given value.

### HasBackendMetaDataUsedPercent

`func (o *MetaDataUsage) HasBackendMetaDataUsedPercent() bool`

HasBackendMetaDataUsedPercent returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


