# DaysToFullInstancesResult

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**DaysToFullObjectResultType** | Pointer to [**[]DaysToFullObjectResultType**](DaysToFullObjectResultType.md) | daysToFullObjectResultType | [optional] 

## Methods

### NewDaysToFullInstancesResult

`func NewDaysToFullInstancesResult() *DaysToFullInstancesResult`

NewDaysToFullInstancesResult instantiates a new DaysToFullInstancesResult object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewDaysToFullInstancesResultWithDefaults

`func NewDaysToFullInstancesResultWithDefaults() *DaysToFullInstancesResult`

NewDaysToFullInstancesResultWithDefaults instantiates a new DaysToFullInstancesResult object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetDaysToFullObjectResultType

`func (o *DaysToFullInstancesResult) GetDaysToFullObjectResultType() []DaysToFullObjectResultType`

GetDaysToFullObjectResultType returns the DaysToFullObjectResultType field if non-nil, zero value otherwise.

### GetDaysToFullObjectResultTypeOk

`func (o *DaysToFullInstancesResult) GetDaysToFullObjectResultTypeOk() (*[]DaysToFullObjectResultType, bool)`

GetDaysToFullObjectResultTypeOk returns a tuple with the DaysToFullObjectResultType field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetDaysToFullObjectResultType

`func (o *DaysToFullInstancesResult) SetDaysToFullObjectResultType(v []DaysToFullObjectResultType)`

SetDaysToFullObjectResultType sets DaysToFullObjectResultType field to given value.

### HasDaysToFullObjectResultType

`func (o *DaysToFullInstancesResult) HasDaysToFullObjectResultType() bool`

HasDaysToFullObjectResultType returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


