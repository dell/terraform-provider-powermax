# ArrayParam

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**StartDate** | **int64** | &lt;p&gt;Starting date in millisecond.&lt;/p&gt; | 
**EndDate** | **int64** | &lt;p&gt;Ending date in millisecond.&lt;/p&gt; | 
**SymmetrixId** | **string** | &lt;p&gt;The Symmetrix array ID.&lt;/p&gt; | 
**DataFormat** | Pointer to **string** | &lt;p&gt;Data Format (Average or Maximum).&lt;/p&gt;   Enumeration values: * **Average** * **Maximum**  | [optional] 
**Metrics** | **[]string** | metrics   Enumeration values: * **OverallHealthScore** - Overall HealthScore. * **HardwareHealthScore** - Hardware HealthScore. * **SoftwareHealthScore** - Software HealthScore. * **SloHealthScore** - SLO HealthScore, checks the compliance of your SGs expected response times * **OverallCompressionRatio** - Overall Compression Ratio. * **OverallEfficiencyRatio** - OverallEfficiency Ratio. * **PercentVPSaved** - % Virtual Provisioning Saved. * **VPSharedRatio** - Virtual Provisioning Shared Ratio. * **VPCompressionRatio** - Virtual Provisioning Compression Ratio. * **VPEfficiencyRatio** - Virtual Provisioning Efficiency Ratio. * **PercentSnapshotSaved** - % Snapshot Saved. * **SnapshotSharedRatio** - Snapshot Shared Ratio. * **SnapshotCompressionRatio** - Snapshot Compression Ratio. * **SnapshotEfficiencyRatio** - Snapshot Efficiency Ratio. * **CopySlotCount** - Copy Slot Count. * **HostIOs** - The number of host IO operations performed each second by all Symmetrix volumes, including writes and random and sequential reads. * **HostReads** - The number of host read operations performed each second by all Symmetrix volumes. * **HostWrites** - The number of host write operations performed each second by all Symmetrix volumes. * **PercentReads** - The percent of total read IO operations performed each second by all of the Symmetrix volumes. * **PercentWrites** - he percent of total write IO operations performed by all of the Symmetrix volumes. * **PercentHit** - The percent of IO operations performed by all of the Symmetrix volumes, for which the read data was in cache and the write operation could be sent directly to cache without having to wait for data to be destaged from cache to the disks. * **HostMBs** - The total requests from all FE directors per second that were satisfied from cache. * **HostMBReads** - The number of host MBs read by all of the Symmetrix volumes each second. * **HostMBWritten** - The number of host MBs written by all of the Symmetrix volumes each second. * **FEReqs** - The calculated system read response time. * **FEReadReqs** - A read data transfer between the director and the cache. An IO may require multiple requests depending on IO size, alignment, or both. The requests rate should be either equal to or greater than the IO rate. * **FEWriteReqs** - A write data transfer between the director and the cache. An IO may require multiple requests depending on IO size, alignment, or both. The requests rate should be either equal to or greater than the IO rate. * **BEIOs** - A data transfer of a read between the cache and the director. * **BEReqs** - The percent of system cache that is write pending. * **BEReadReqs** - A data transfer of a read between the cache and the director. * **BEWriteReqs** - A data transfer of a write between the cache and the director. * **SystemWPEvents** - The number of times each second that write activity was heavy enough to use up the system limit set for write tracks occupying cache. When the limit is reached, writes are deferred until data in cache is written to disk. * **DeviceWPEvents** - The number of times each second that the write-pending limit for a specific Symmetrix volume was reached. * **WPCount** - The number of system cache slots that are write pending. * **SystemMaxWPLimit** - The percent of the target % at which writes are delayed. The range is from 40% to 80%. * **PercentCacheWP** - The percent of system cache that is write pending. * **AvgFallThruTime** - The average time it takes a cache slot in LRU0 to be freed up. It is the average time from the first use of the contents to its reuse by another address. * **FEHitReqs** - The total requests from all FE directors per second that were satisfied from cache. * **FEReadHitReqs** - The total read requests from all FE directors per second that were satisfied from cache. * **FEWriteHitReqs** - The total write requests from all FE directors per second that were satisfied from cache. * **PrefetchedTracks** - The tracks per second pre-fetched from disk to cache upon detection of a sequential read stream. * **FEReadMissReqs** - The total read requests from all FE directors per second that were satisfied from cache. * **FEWriteMissReqs** - The total write requests from all FE directors per second that were misses. A miss occurs when the write operation had to wait while data was destaged from cache to the disks. * **ReadResponseTime** - Avg Read Response Time (ms) * **WriteResponseTime** - The calculated system write response time. * **BEUtilization** - BE Utilization. * **DiskUtilization** - Disk Utilization. * **FEUtilization** - FE Utilization. * **RDFUtilization** - RDF Utilization. * **SCM_Balance** - A difference between most busy and less busy among the SCM instances percent Busy value. * **CompressionDedupSavingsCapacity** - Compression Dedup Savings Capacity * **PatternDetectionSavings** - Pattern Detection Savings * **DataReductionRatioOnReducible** - Data Reduction Ratio on Reducible * **MaxEffectiveCapacity** - Max Effective Capacity * **PhysicalCapacity** - Physical Capacity * **EffectiveResourcesCapacity** - Effective Resources Capacity * **EffectiveUsedCapacity** - Effective Used Capacity * **MaxProvisioning** - Max Provisioning * **ProvisionedCapacity** - Provisioned Capacity * **ProvisionedResourcesUsedPercent** - Provisioned Resources Used Percent * **ProvisionedPercent** - Provisioned Percent * **SnapshotResourcesCapacity** - Snapshot Resources Capacity * **SnapshotResourcesUsed** - Snapshot Resources Used * **SnapshotResourcesUsedPercent** - Snapshot Resources Used Percent * **DisabledCapacity** - Disabled Capacity * **NumberR1ActiveSessions** - Number of R1 Active Sessions * **NumberR1CacheSlotsInUse** - Number of R1 Cache Slots in Use * **NumberR1MscActiveSessions** - Number of R1 Msc Active Sessions * **NumberR1MscSessions** - Number of R1 Msc Sessions * **TotalNumberR1Sessions** - Total Number of R1 Sessions * **NumberR2ActiveSessions** - Number of R2 Active Sessions * **NumberR2CacheSlotsInUse** - Number of R2 Cache Slots in Use * **NumberR2MscActiveSessions** - Number of R2 Msc Active Sessions * **NumberR2MscSessions** - Number of R2 Msc Sessions * **TotalNumberR2Sessions** - Total Number of R2 Sessions * **TotalNumberRdfSessions** - Total Number of RDF Sessions * **ResponseTime** - Response Time * **VersionWritePendingCount** - Version WP Count * **CapacityR1CacheSlotsInUse** - Capacity R1 Cache Slots In Use * **CapacityR2CacheSlotsInUse** - Capacity R2 Cache Slots In Use * **CopySlotCountUsedCapacity** - Copy Slot Count Used Capacity * **RDFAWPCapacity** - RDFA WP Capacity * **ReducibleCapacity** - Reducible Capacity * **SystemMaxWPLimitCapacity** - System Max WP Limit Capacity * **UnreducibleCapacity** - Unreducible Capacity * **VersionWritePendingUsedCapacity** - Version Write Pending Used Capacity * **WPUsedCapacity** - WP Used Capacity * **PercentXtremSWCacheReadHits** - The percent of total XtremSW Cache read IO operations performed each second by all of the Symmetrix volumes that were served by the XtremSW Cache cache. * **XtremSWCacheMBs** - Cumulative number of host MBs read and written by the StremSW Cache per second. * **OptimizedReadMisses** - Number of read requests each second performed directly from disks bypassing the cache. * **OptimizedMBReadMisses** - Number of host MBs read each second directly from disks bypassing the cache. * **AvgOptimizedReadMissSize** - The average read size of the read requests performed directly from disks bypassing the cache. * **QueueDepthUtilization** - Front end director queue depth utilization, based on queue depth buckets * **InfoAlertCount** - Number of active performance alerts, information severity * **WarningAlertCount** - Number of active performance alerts, warning severity * **CriticalAlertCount** - // Number of active performance alerts, critical severity * **RDFA_WPCount** - Number of write pending cache slots across all SRDF/A groups that are used for remote cycles * **AllocatedCapacity** - The capacity of the storage group allocated. * **FE_Balance** - A difference between most busy and less busy among the FE instances percent Busy value * **DA_Balance** - A difference between most busy and less busy among the DA instances percent Busy value * **DX_Balance** - A difference between most busy and less busy among the DX instances percent Busy value * **RDF_Balance** - A difference between most busy and less busy among the RDF instances percent Busy value * **Cache_Balance** - A difference between most busy and less busy among the cache partition instances percent Busy value * **SATA_Balance** - A difference between most busy and less busy among the SATA partition instances percent Busy value * **FC_Balance** - A difference between most busy and less busy among the FC instances percent Busy value * **EFD_Balance** - A difference between most busy and less busy among the EFD instances percent Busy value * **PercentSubscribedCapacity** - % Subscribed Capacity * **PercentEffectiveUsedCapacity** - % Effective Used Capacity * **UsableCapacity** - Usable Capacity * **SubscribedCapacity** - Subscribed Capacity * **PercentMetaRepUsed** - % Meta Data Replication Used * **PercentMetaSystemUsed** - % Meta Data System Used * **HWConfigHS** - Tracks the Hardware Config Health Score. * **CapacityHS** - Tracks the Capacity Health Score. * **SubscribedCapacityTB** - Subscribed Capacity (TB). * **UsableCapacityTB** - Usable Capacity (TB). * **AllocatedCapacityTB** - Allocated Capacity (TB). * **PercentMetaBEUsed** - BE TID used percent. * **PercentMetaFEUsed** - FE TID used percent. * **SnapModifiedCapGB** - Total snapshot capacity for system data (GB). * **SnapModifiedCapTB** - Total snapshot modified capacity for system data (TB). * **SnapCapGB** - Total snapshot capacity for system data (GB). * **SnapCapTB** - Total snapshot capacity for system data (TB). * **UsedUsableCapGB** - Total user used capacity (GB). * **UsedUsableCapTB** - Total user used capacity (TB). * **SubscribedAllocatedCapGB** - Allocated Subscribed Capacity (GB). * **SubscribedAllocatedCapTB** - Allocated Subscribed Capacity (TB). * **AVG_LRU0_FALL_THRU_TIME** - The average time it takes a cache slot in LRU0 to be freed up. It is the average time from the first use of the contents to its reuse by another address. * **BE_IOS_PER_SEC** - The total IO from all BE directors to the disks per second. * **BE_READS** - A data transfer of a read between the cache and the director. * **BE_WRITES** - A data transfer of a write between the cache and the director. * **DESTAGED_TRACKS_PER_SEC** - The tracks per second saved into disks. * **DEV_WRITE_PENDING_EVENT_PER_SEC** - The number of times each second that the write-pending limit for a specific Symmetrix volume was reached. * **FE_READ_REQS_PER_SEC** - A read data transfer between the director and the cache. An IO may require multiple requests depending on IO size, alignment, or both. The requests rate should be either equal to or greater than the IO rate. * **FE_WRITE_REQS_PER_SEC** - A write data transfer between the director and the cache. An IO may require multiple requests depending on IO size, alignment, or both. The requests rate should be either equal to or greater than the IO rate. * **HA_MB_PER_SEC** - The number of host MBs written and read by all of the Symmetrix volumes each second. * **HIT_PER_SEC** - The total requests from all FE directors per second that were satisfied from cache. * **IO_RATE** - The number of host IO operations performed each second by all Symmetrix volumes, including writes and random and sequential reads. * **MB_READ_PER_SEC** - The number of host MBs read by all of the Symmetrix volumes each second. * **MB_WRITE_PER_SEC** - The number of host MBs written by all of the Symmetrix volumes each second. * **PERCENT_HIT** - The percent of IO operations performed by all of the Symmetrix volumes, for which the read data was in cache and the write operation could be sent directly to cache without having to wait for data to be destaged from cache to the disks. * **PERCENT_READ** - The percent of total read IO operations performed each second by all of the Symmetrix volumes. * **PERCENT_WRITE** - The percent of total write IO operations performed by all of the Symmetrix volumes. * **PREFETCHED_TRACK_PER_SEC** - The tracks per second pre-fetched from disk to cache upon detection of a sequential read stream. * **READS** - The number of host read operations performed each second by all Symmetrix volumes. * **READ_HIT_PER_SEC** - The total read requests from all FE directors per second that were satisfied from cache. * **READ_MISS_PER_SEC** - The total read requests from all FE directors per second that were satisfied from cache. * **REQUEST_PER_SEC** - A data transfer between the director and the cache. An IO may require multiple requests depending on IO size, alignment, or both. The requests rate should be either equal to or greater than the IO rate. * **RESPONSE_TIME_READ** - The calculated system read response time. * **RESPONSE_TIME_WRITE** - The calculated system write response time. * **SYS_WRITE_PENDING_EVENT_PER_SEC** - The number of times each second that write activity was heavy enough to use up the system limit set for write tracks occupying cache. When the limit is reached, writes are deferred until data in cache is written to disk. * **TOTAL_BE_REQ_PER_SEC** - A data transfer of a read or write between the cache and the director. * **TOTAL_CACHE_UTILIZATION** - The percent of system cache that is write pending. * **WP** - The number of system cache slots that are write pending. * **WP_LIMIT** - The percent of the target % at which writes are delayed. The range is from 40% to 80%. * **WRITE_HIT_PER_SEC** - The total write requests from all FE directors per second that were satisfied from cache. * **WRITE_MISS_PER_SEC** - The total write requests from all FE directors per second that were misses. A miss occurs when the write operation had to wait while data was destaged from cache to the disks. * **WRITES** - The number of host write operations performed each second by all Symmetrix volumes. * **XC_DEDUP_HITS** - The number of reads and writes per second that has been found in the XtremSW Cache de-dup cache. * **XC_DEDUP_READS** - The number of reads per second that has been found in the XtremSW Cache de-dup cache. * **XC_DEDUP_WRITES** - The number of writes per second that has been found in the XtremSW Cache de-dup cache. * **XC_IOS** - The number of IOs per second received in the XtremSW Cache cache. * **XC_PER_READS** - The percent of total XtremSW Cache read IO operations performed each second by all of the Symmetrix volumes. * **XC_PER_WRITES** - The percent of total XtremSW Cache write IO operations performed each second by all of the Symmetrix volumes. * **XC_PER_READ_HITS** - The percent of total XtremSW Cache read IO operations performed each second by all of the Symmetrix volumes that were served by the XtremSW Cache cache. * **XC_READ_HITS** - The number of Reads per second that found in the XtremSW Cache. * **XC_READS** - The number of Reads per second received in the XtremSW Cache. * **XC_SKIPPED_IOS** - The number of Reads/Writes that skipped the XtremSW Cache. * **XC_WRITE_HITS** - The number of Writes per second that found in the XtremSW Cache. * **XC_WRITES** - The number of Writes per second received in the XtremSW Cache. * **XC_TOTAL_MBS_READ** - Cumulative number of host MBs read by the StremSW Cache per second. * **XC_TOTAL_MBS_WRITTEN** - Cumulative number of host MBs written by the StremSW Cache per second. * **XC_TOTAL_MBS** - Cumulative number of host MBs read and written by the StremSW Cache per second. * **XC_READ_RESPONSE_TIME** - The average time it took the XtremSW cache to serve one read. * **XC_WRITE_RESPONSE_TIME** - The average time it took the XtremSW cache to serve one write. * **XC_RESPONSE_TIME** - The average time it took the XtremSW cache to serve one IO. * **XC_AVG_READ_SIZE** - The average size of a read served by the XtremSW Cache. * **XC_AVG_WRITE_SIZE** - The average size of a write served by the XtremSW Cache. * **XC_AVG_IO_SIZE** - The average size of an IO served by the XtremSW Cache. * **ORM_READS** - Number of read requests each second performed directly from disks bypassing the cache. * **ORM_MB_READ** - Number of host MBs read each second directly from disks bypassing the cache. * **ORM_AVG_READ_SIZE** - The average read size of the read requests performed directly from disks bypassing the cache.  | 

## Methods

### NewArrayParam

`func NewArrayParam(startDate int64, endDate int64, symmetrixId string, metrics []string, ) *ArrayParam`

NewArrayParam instantiates a new ArrayParam object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewArrayParamWithDefaults

`func NewArrayParamWithDefaults() *ArrayParam`

NewArrayParamWithDefaults instantiates a new ArrayParam object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetStartDate

`func (o *ArrayParam) GetStartDate() int64`

GetStartDate returns the StartDate field if non-nil, zero value otherwise.

### GetStartDateOk

`func (o *ArrayParam) GetStartDateOk() (*int64, bool)`

GetStartDateOk returns a tuple with the StartDate field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetStartDate

`func (o *ArrayParam) SetStartDate(v int64)`

SetStartDate sets StartDate field to given value.


### GetEndDate

`func (o *ArrayParam) GetEndDate() int64`

GetEndDate returns the EndDate field if non-nil, zero value otherwise.

### GetEndDateOk

`func (o *ArrayParam) GetEndDateOk() (*int64, bool)`

GetEndDateOk returns a tuple with the EndDate field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetEndDate

`func (o *ArrayParam) SetEndDate(v int64)`

SetEndDate sets EndDate field to given value.


### GetSymmetrixId

`func (o *ArrayParam) GetSymmetrixId() string`

GetSymmetrixId returns the SymmetrixId field if non-nil, zero value otherwise.

### GetSymmetrixIdOk

`func (o *ArrayParam) GetSymmetrixIdOk() (*string, bool)`

GetSymmetrixIdOk returns a tuple with the SymmetrixId field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetSymmetrixId

`func (o *ArrayParam) SetSymmetrixId(v string)`

SetSymmetrixId sets SymmetrixId field to given value.


### GetDataFormat

`func (o *ArrayParam) GetDataFormat() string`

GetDataFormat returns the DataFormat field if non-nil, zero value otherwise.

### GetDataFormatOk

`func (o *ArrayParam) GetDataFormatOk() (*string, bool)`

GetDataFormatOk returns a tuple with the DataFormat field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetDataFormat

`func (o *ArrayParam) SetDataFormat(v string)`

SetDataFormat sets DataFormat field to given value.

### HasDataFormat

`func (o *ArrayParam) HasDataFormat() bool`

HasDataFormat returns a boolean if a field has been set.

### GetMetrics

`func (o *ArrayParam) GetMetrics() []string`

GetMetrics returns the Metrics field if non-nil, zero value otherwise.

### GetMetricsOk

`func (o *ArrayParam) GetMetricsOk() (*[]string, bool)`

GetMetricsOk returns a tuple with the Metrics field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetMetrics

`func (o *ArrayParam) SetMetrics(v []string)`

SetMetrics sets Metrics field to given value.



[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


