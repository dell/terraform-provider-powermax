# AzureConnectionDetails

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**StorageAccount** | Pointer to **string** | The Cloud Provider Storage Account | [optional] 
**ManagedKey** | Pointer to **string** | The Cloud Provider Secret | [optional] 
**Secure** | Pointer to **bool** | Is The Cloud Provider Secure, HTTPS &#x3D; true | [optional] 
**Url** | Pointer to **string** | The Cloud Provider URL | [optional] 
**Port** | Pointer to **int32** | The Cloud Provider Port | [optional] 
**Container** | Pointer to **string** | The Cloud Provider Container id | [optional] 

## Methods

### NewAzureConnectionDetails

`func NewAzureConnectionDetails() *AzureConnectionDetails`

NewAzureConnectionDetails instantiates a new AzureConnectionDetails object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewAzureConnectionDetailsWithDefaults

`func NewAzureConnectionDetailsWithDefaults() *AzureConnectionDetails`

NewAzureConnectionDetailsWithDefaults instantiates a new AzureConnectionDetails object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetStorageAccount

`func (o *AzureConnectionDetails) GetStorageAccount() string`

GetStorageAccount returns the StorageAccount field if non-nil, zero value otherwise.

### GetStorageAccountOk

`func (o *AzureConnectionDetails) GetStorageAccountOk() (*string, bool)`

GetStorageAccountOk returns a tuple with the StorageAccount field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetStorageAccount

`func (o *AzureConnectionDetails) SetStorageAccount(v string)`

SetStorageAccount sets StorageAccount field to given value.

### HasStorageAccount

`func (o *AzureConnectionDetails) HasStorageAccount() bool`

HasStorageAccount returns a boolean if a field has been set.

### GetManagedKey

`func (o *AzureConnectionDetails) GetManagedKey() string`

GetManagedKey returns the ManagedKey field if non-nil, zero value otherwise.

### GetManagedKeyOk

`func (o *AzureConnectionDetails) GetManagedKeyOk() (*string, bool)`

GetManagedKeyOk returns a tuple with the ManagedKey field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetManagedKey

`func (o *AzureConnectionDetails) SetManagedKey(v string)`

SetManagedKey sets ManagedKey field to given value.

### HasManagedKey

`func (o *AzureConnectionDetails) HasManagedKey() bool`

HasManagedKey returns a boolean if a field has been set.

### GetSecure

`func (o *AzureConnectionDetails) GetSecure() bool`

GetSecure returns the Secure field if non-nil, zero value otherwise.

### GetSecureOk

`func (o *AzureConnectionDetails) GetSecureOk() (*bool, bool)`

GetSecureOk returns a tuple with the Secure field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetSecure

`func (o *AzureConnectionDetails) SetSecure(v bool)`

SetSecure sets Secure field to given value.

### HasSecure

`func (o *AzureConnectionDetails) HasSecure() bool`

HasSecure returns a boolean if a field has been set.

### GetUrl

`func (o *AzureConnectionDetails) GetUrl() string`

GetUrl returns the Url field if non-nil, zero value otherwise.

### GetUrlOk

`func (o *AzureConnectionDetails) GetUrlOk() (*string, bool)`

GetUrlOk returns a tuple with the Url field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetUrl

`func (o *AzureConnectionDetails) SetUrl(v string)`

SetUrl sets Url field to given value.

### HasUrl

`func (o *AzureConnectionDetails) HasUrl() bool`

HasUrl returns a boolean if a field has been set.

### GetPort

`func (o *AzureConnectionDetails) GetPort() int32`

GetPort returns the Port field if non-nil, zero value otherwise.

### GetPortOk

`func (o *AzureConnectionDetails) GetPortOk() (*int32, bool)`

GetPortOk returns a tuple with the Port field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetPort

`func (o *AzureConnectionDetails) SetPort(v int32)`

SetPort sets Port field to given value.

### HasPort

`func (o *AzureConnectionDetails) HasPort() bool`

HasPort returns a boolean if a field has been set.

### GetContainer

`func (o *AzureConnectionDetails) GetContainer() string`

GetContainer returns the Container field if non-nil, zero value otherwise.

### GetContainerOk

`func (o *AzureConnectionDetails) GetContainerOk() (*string, bool)`

GetContainerOk returns a tuple with the Container field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetContainer

`func (o *AzureConnectionDetails) SetContainer(v string)`

SetContainer sets Container field to given value.

### HasContainer

`func (o *AzureConnectionDetails) HasContainer() bool`

HasContainer returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


