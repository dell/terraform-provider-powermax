# DpNetworkList

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Entries** | Pointer to [**[]ProtectionIdentifier**](ProtectionIdentifier.md) |                                  list of data protection network objects                              | [optional] 

## Methods

### NewDpNetworkList

`func NewDpNetworkList() *DpNetworkList`

NewDpNetworkList instantiates a new DpNetworkList object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewDpNetworkListWithDefaults

`func NewDpNetworkListWithDefaults() *DpNetworkList`

NewDpNetworkListWithDefaults instantiates a new DpNetworkList object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetEntries

`func (o *DpNetworkList) GetEntries() []ProtectionIdentifier`

GetEntries returns the Entries field if non-nil, zero value otherwise.

### GetEntriesOk

`func (o *DpNetworkList) GetEntriesOk() (*[]ProtectionIdentifier, bool)`

GetEntriesOk returns a tuple with the Entries field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetEntries

`func (o *DpNetworkList) SetEntries(v []ProtectionIdentifier)`

SetEntries sets Entries field to given value.

### HasEntries

`func (o *DpNetworkList) HasEntries() bool`

HasEntries returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


