# Health

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**HealthStatus** | Pointer to **string** |                          Health Value:                         - 5: UNKNOWN - The health status cannot be determined (Object might be offline)                         - 4: OK - The object works properly.                         - 3: OK_BUT -  The object works but there is at least one issue that doesn&#39;t impact current functioning. For instance if the NAS server DNS client is configured with several servers but one doesn&#39;t work. The DNS client works but without degradation of service because only one server is used at a time. However this need to be fixed                         - 2: DEGRADED - The object works but there is at least one issue that degrades its functioning. For instance if the NAS server Virus Checker is configured with several servers but one doesn&#39;t work, the Virus Checker works but there are less servers available to run parallel check.                         - 1: CRITICAL - The object doesn&#39;t work and must be fixed. For instance, all configured DNS servers of the NAS Server DNS client don&#39;t work. In that case, the NAS server DNS client doesn&#39;t work.                         - 0: NON_RECOVERABLE - The object doesn&#39;t work and cannot be fixed. This may be the case in case of unrecoverable file system corruption.                        Enumeration values: * **NON_RECOVERABLE** * **CRITICAL** * **DEGRADED** * **OK_BUT** * **OK** * **UNKNOWN**  | [optional] 

## Methods

### NewHealth

`func NewHealth() *Health`

NewHealth instantiates a new Health object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewHealthWithDefaults

`func NewHealthWithDefaults() *Health`

NewHealthWithDefaults instantiates a new Health object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetHealthStatus

`func (o *Health) GetHealthStatus() string`

GetHealthStatus returns the HealthStatus field if non-nil, zero value otherwise.

### GetHealthStatusOk

`func (o *Health) GetHealthStatusOk() (*string, bool)`

GetHealthStatusOk returns a tuple with the HealthStatus field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetHealthStatus

`func (o *Health) SetHealthStatus(v string)`

SetHealthStatus sets HealthStatus field to given value.

### HasHealthStatus

`func (o *Health) HasHealthStatus() bool`

HasHealthStatus returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


