# DataReduction

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**DataReductionRatioToOne** | Pointer to **float64** | Data Reduction ratio on reducible data | [optional] 
**ReducingDataPercent** | Pointer to **float64** | Percentage of effective used which is reducible | [optional] 
**SavingsTb** | Pointer to **float64** | DR Savings in TB | [optional] 
**EffectiveUsed** | Pointer to [**DataReductionBreakdown**](DataReductionBreakdown.md) |  | [optional] 
**PhysicalUsed** | Pointer to [**DataReductionBreakdown**](DataReductionBreakdown.md) |  | [optional] 

## Methods

### NewDataReduction

`func NewDataReduction() *DataReduction`

NewDataReduction instantiates a new DataReduction object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewDataReductionWithDefaults

`func NewDataReductionWithDefaults() *DataReduction`

NewDataReductionWithDefaults instantiates a new DataReduction object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetDataReductionRatioToOne

`func (o *DataReduction) GetDataReductionRatioToOne() float64`

GetDataReductionRatioToOne returns the DataReductionRatioToOne field if non-nil, zero value otherwise.

### GetDataReductionRatioToOneOk

`func (o *DataReduction) GetDataReductionRatioToOneOk() (*float64, bool)`

GetDataReductionRatioToOneOk returns a tuple with the DataReductionRatioToOne field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetDataReductionRatioToOne

`func (o *DataReduction) SetDataReductionRatioToOne(v float64)`

SetDataReductionRatioToOne sets DataReductionRatioToOne field to given value.

### HasDataReductionRatioToOne

`func (o *DataReduction) HasDataReductionRatioToOne() bool`

HasDataReductionRatioToOne returns a boolean if a field has been set.

### GetReducingDataPercent

`func (o *DataReduction) GetReducingDataPercent() float64`

GetReducingDataPercent returns the ReducingDataPercent field if non-nil, zero value otherwise.

### GetReducingDataPercentOk

`func (o *DataReduction) GetReducingDataPercentOk() (*float64, bool)`

GetReducingDataPercentOk returns a tuple with the ReducingDataPercent field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetReducingDataPercent

`func (o *DataReduction) SetReducingDataPercent(v float64)`

SetReducingDataPercent sets ReducingDataPercent field to given value.

### HasReducingDataPercent

`func (o *DataReduction) HasReducingDataPercent() bool`

HasReducingDataPercent returns a boolean if a field has been set.

### GetSavingsTb

`func (o *DataReduction) GetSavingsTb() float64`

GetSavingsTb returns the SavingsTb field if non-nil, zero value otherwise.

### GetSavingsTbOk

`func (o *DataReduction) GetSavingsTbOk() (*float64, bool)`

GetSavingsTbOk returns a tuple with the SavingsTb field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetSavingsTb

`func (o *DataReduction) SetSavingsTb(v float64)`

SetSavingsTb sets SavingsTb field to given value.

### HasSavingsTb

`func (o *DataReduction) HasSavingsTb() bool`

HasSavingsTb returns a boolean if a field has been set.

### GetEffectiveUsed

`func (o *DataReduction) GetEffectiveUsed() DataReductionBreakdown`

GetEffectiveUsed returns the EffectiveUsed field if non-nil, zero value otherwise.

### GetEffectiveUsedOk

`func (o *DataReduction) GetEffectiveUsedOk() (*DataReductionBreakdown, bool)`

GetEffectiveUsedOk returns a tuple with the EffectiveUsed field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetEffectiveUsed

`func (o *DataReduction) SetEffectiveUsed(v DataReductionBreakdown)`

SetEffectiveUsed sets EffectiveUsed field to given value.

### HasEffectiveUsed

`func (o *DataReduction) HasEffectiveUsed() bool`

HasEffectiveUsed returns a boolean if a field has been set.

### GetPhysicalUsed

`func (o *DataReduction) GetPhysicalUsed() DataReductionBreakdown`

GetPhysicalUsed returns the PhysicalUsed field if non-nil, zero value otherwise.

### GetPhysicalUsedOk

`func (o *DataReduction) GetPhysicalUsedOk() (*DataReductionBreakdown, bool)`

GetPhysicalUsedOk returns a tuple with the PhysicalUsed field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetPhysicalUsed

`func (o *DataReduction) SetPhysicalUsed(v DataReductionBreakdown)`

SetPhysicalUsed sets PhysicalUsed field to given value.

### HasPhysicalUsed

`func (o *DataReduction) HasPhysicalUsed() bool`

HasPhysicalUsed returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


