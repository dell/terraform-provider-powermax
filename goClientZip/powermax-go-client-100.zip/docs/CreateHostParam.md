# CreateHostParam

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ExecutionOption** | Pointer to **string** |  | [optional] [default to "SYNCHRONOUS"]
**HostId** | **string** | ID/name of the host | 
**InitiatorId** | Pointer to **[]string** | ID/name of the initiator | [optional] 
**HostFlags** | Pointer to [**HostFlags**](HostFlags.md) |  | [optional] 

## Methods

### NewCreateHostParam

`func NewCreateHostParam(hostId string, ) *CreateHostParam`

NewCreateHostParam instantiates a new CreateHostParam object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewCreateHostParamWithDefaults

`func NewCreateHostParamWithDefaults() *CreateHostParam`

NewCreateHostParamWithDefaults instantiates a new CreateHostParam object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetExecutionOption

`func (o *CreateHostParam) GetExecutionOption() string`

GetExecutionOption returns the ExecutionOption field if non-nil, zero value otherwise.

### GetExecutionOptionOk

`func (o *CreateHostParam) GetExecutionOptionOk() (*string, bool)`

GetExecutionOptionOk returns a tuple with the ExecutionOption field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetExecutionOption

`func (o *CreateHostParam) SetExecutionOption(v string)`

SetExecutionOption sets ExecutionOption field to given value.

### HasExecutionOption

`func (o *CreateHostParam) HasExecutionOption() bool`

HasExecutionOption returns a boolean if a field has been set.

### GetHostId

`func (o *CreateHostParam) GetHostId() string`

GetHostId returns the HostId field if non-nil, zero value otherwise.

### GetHostIdOk

`func (o *CreateHostParam) GetHostIdOk() (*string, bool)`

GetHostIdOk returns a tuple with the HostId field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetHostId

`func (o *CreateHostParam) SetHostId(v string)`

SetHostId sets HostId field to given value.


### GetInitiatorId

`func (o *CreateHostParam) GetInitiatorId() []string`

GetInitiatorId returns the InitiatorId field if non-nil, zero value otherwise.

### GetInitiatorIdOk

`func (o *CreateHostParam) GetInitiatorIdOk() (*[]string, bool)`

GetInitiatorIdOk returns a tuple with the InitiatorId field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetInitiatorId

`func (o *CreateHostParam) SetInitiatorId(v []string)`

SetInitiatorId sets InitiatorId field to given value.

### HasInitiatorId

`func (o *CreateHostParam) HasInitiatorId() bool`

HasInitiatorId returns a boolean if a field has been set.

### GetHostFlags

`func (o *CreateHostParam) GetHostFlags() HostFlags`

GetHostFlags returns the HostFlags field if non-nil, zero value otherwise.

### GetHostFlagsOk

`func (o *CreateHostParam) GetHostFlagsOk() (*HostFlags, bool)`

GetHostFlagsOk returns a tuple with the HostFlags field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetHostFlags

`func (o *CreateHostParam) SetHostFlags(v HostFlags)`

SetHostFlags sets HostFlags field to given value.

### HasHostFlags

`func (o *CreateHostParam) HasHostFlags() bool`

HasHostFlags returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


