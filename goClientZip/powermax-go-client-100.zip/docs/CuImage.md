# CuImage

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ImageNumber** | **string** | The CU image number | 
**Ssid** | **string** | The CU image SSID | 
**NumMappedVolumes** | Pointer to **int32** | The number of volumes mapped to the CU image | [optional] 
**NumStorageGroups** | Pointer to **int32** | The number of storage groups that contain volumes mapped to the CU image | [optional] 
**NumBaseAddresses** | Pointer to **int32** | The total number of base addresses that can be used for volume mapping to the CU image | [optional] 
**NumAvailableBaseAddresses** | Pointer to **int32** | The number of base addresses that are available to be assigned to volume mappings to the                         CU                         image | [optional] 
**NextAvailableBaseAddress** | Pointer to **string** | The next available base address that can be used for a new volume mapping to the CU                         image | [optional] 
**NumAliases** | Pointer to **int32** | The total number of aliases configured on the CU image | [optional] 
**StartAliasAddress** | Pointer to **string** | The start alias address, if an alias range has been assigned. | [optional] 
**EndAliasAddress** | Pointer to **string** | The end alias address, if an alias range has been assigned. | [optional] 
**Status** | Pointer to **string** | The status of the CU image. | [optional] 

## Methods

### NewCuImage

`func NewCuImage(imageNumber string, ssid string, ) *CuImage`

NewCuImage instantiates a new CuImage object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewCuImageWithDefaults

`func NewCuImageWithDefaults() *CuImage`

NewCuImageWithDefaults instantiates a new CuImage object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetImageNumber

`func (o *CuImage) GetImageNumber() string`

GetImageNumber returns the ImageNumber field if non-nil, zero value otherwise.

### GetImageNumberOk

`func (o *CuImage) GetImageNumberOk() (*string, bool)`

GetImageNumberOk returns a tuple with the ImageNumber field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetImageNumber

`func (o *CuImage) SetImageNumber(v string)`

SetImageNumber sets ImageNumber field to given value.


### GetSsid

`func (o *CuImage) GetSsid() string`

GetSsid returns the Ssid field if non-nil, zero value otherwise.

### GetSsidOk

`func (o *CuImage) GetSsidOk() (*string, bool)`

GetSsidOk returns a tuple with the Ssid field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetSsid

`func (o *CuImage) SetSsid(v string)`

SetSsid sets Ssid field to given value.


### GetNumMappedVolumes

`func (o *CuImage) GetNumMappedVolumes() int32`

GetNumMappedVolumes returns the NumMappedVolumes field if non-nil, zero value otherwise.

### GetNumMappedVolumesOk

`func (o *CuImage) GetNumMappedVolumesOk() (*int32, bool)`

GetNumMappedVolumesOk returns a tuple with the NumMappedVolumes field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetNumMappedVolumes

`func (o *CuImage) SetNumMappedVolumes(v int32)`

SetNumMappedVolumes sets NumMappedVolumes field to given value.

### HasNumMappedVolumes

`func (o *CuImage) HasNumMappedVolumes() bool`

HasNumMappedVolumes returns a boolean if a field has been set.

### GetNumStorageGroups

`func (o *CuImage) GetNumStorageGroups() int32`

GetNumStorageGroups returns the NumStorageGroups field if non-nil, zero value otherwise.

### GetNumStorageGroupsOk

`func (o *CuImage) GetNumStorageGroupsOk() (*int32, bool)`

GetNumStorageGroupsOk returns a tuple with the NumStorageGroups field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetNumStorageGroups

`func (o *CuImage) SetNumStorageGroups(v int32)`

SetNumStorageGroups sets NumStorageGroups field to given value.

### HasNumStorageGroups

`func (o *CuImage) HasNumStorageGroups() bool`

HasNumStorageGroups returns a boolean if a field has been set.

### GetNumBaseAddresses

`func (o *CuImage) GetNumBaseAddresses() int32`

GetNumBaseAddresses returns the NumBaseAddresses field if non-nil, zero value otherwise.

### GetNumBaseAddressesOk

`func (o *CuImage) GetNumBaseAddressesOk() (*int32, bool)`

GetNumBaseAddressesOk returns a tuple with the NumBaseAddresses field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetNumBaseAddresses

`func (o *CuImage) SetNumBaseAddresses(v int32)`

SetNumBaseAddresses sets NumBaseAddresses field to given value.

### HasNumBaseAddresses

`func (o *CuImage) HasNumBaseAddresses() bool`

HasNumBaseAddresses returns a boolean if a field has been set.

### GetNumAvailableBaseAddresses

`func (o *CuImage) GetNumAvailableBaseAddresses() int32`

GetNumAvailableBaseAddresses returns the NumAvailableBaseAddresses field if non-nil, zero value otherwise.

### GetNumAvailableBaseAddressesOk

`func (o *CuImage) GetNumAvailableBaseAddressesOk() (*int32, bool)`

GetNumAvailableBaseAddressesOk returns a tuple with the NumAvailableBaseAddresses field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetNumAvailableBaseAddresses

`func (o *CuImage) SetNumAvailableBaseAddresses(v int32)`

SetNumAvailableBaseAddresses sets NumAvailableBaseAddresses field to given value.

### HasNumAvailableBaseAddresses

`func (o *CuImage) HasNumAvailableBaseAddresses() bool`

HasNumAvailableBaseAddresses returns a boolean if a field has been set.

### GetNextAvailableBaseAddress

`func (o *CuImage) GetNextAvailableBaseAddress() string`

GetNextAvailableBaseAddress returns the NextAvailableBaseAddress field if non-nil, zero value otherwise.

### GetNextAvailableBaseAddressOk

`func (o *CuImage) GetNextAvailableBaseAddressOk() (*string, bool)`

GetNextAvailableBaseAddressOk returns a tuple with the NextAvailableBaseAddress field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetNextAvailableBaseAddress

`func (o *CuImage) SetNextAvailableBaseAddress(v string)`

SetNextAvailableBaseAddress sets NextAvailableBaseAddress field to given value.

### HasNextAvailableBaseAddress

`func (o *CuImage) HasNextAvailableBaseAddress() bool`

HasNextAvailableBaseAddress returns a boolean if a field has been set.

### GetNumAliases

`func (o *CuImage) GetNumAliases() int32`

GetNumAliases returns the NumAliases field if non-nil, zero value otherwise.

### GetNumAliasesOk

`func (o *CuImage) GetNumAliasesOk() (*int32, bool)`

GetNumAliasesOk returns a tuple with the NumAliases field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetNumAliases

`func (o *CuImage) SetNumAliases(v int32)`

SetNumAliases sets NumAliases field to given value.

### HasNumAliases

`func (o *CuImage) HasNumAliases() bool`

HasNumAliases returns a boolean if a field has been set.

### GetStartAliasAddress

`func (o *CuImage) GetStartAliasAddress() string`

GetStartAliasAddress returns the StartAliasAddress field if non-nil, zero value otherwise.

### GetStartAliasAddressOk

`func (o *CuImage) GetStartAliasAddressOk() (*string, bool)`

GetStartAliasAddressOk returns a tuple with the StartAliasAddress field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetStartAliasAddress

`func (o *CuImage) SetStartAliasAddress(v string)`

SetStartAliasAddress sets StartAliasAddress field to given value.

### HasStartAliasAddress

`func (o *CuImage) HasStartAliasAddress() bool`

HasStartAliasAddress returns a boolean if a field has been set.

### GetEndAliasAddress

`func (o *CuImage) GetEndAliasAddress() string`

GetEndAliasAddress returns the EndAliasAddress field if non-nil, zero value otherwise.

### GetEndAliasAddressOk

`func (o *CuImage) GetEndAliasAddressOk() (*string, bool)`

GetEndAliasAddressOk returns a tuple with the EndAliasAddress field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetEndAliasAddress

`func (o *CuImage) SetEndAliasAddress(v string)`

SetEndAliasAddress sets EndAliasAddress field to given value.

### HasEndAliasAddress

`func (o *CuImage) HasEndAliasAddress() bool`

HasEndAliasAddress returns a boolean if a field has been set.

### GetStatus

`func (o *CuImage) GetStatus() string`

GetStatus returns the Status field if non-nil, zero value otherwise.

### GetStatusOk

`func (o *CuImage) GetStatusOk() (*string, bool)`

GetStatusOk returns a tuple with the Status field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetStatus

`func (o *CuImage) SetStatus(v string)`

SetStatus sets Status field to given value.

### HasStatus

`func (o *CuImage) HasStatus() bool`

HasStatus returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


