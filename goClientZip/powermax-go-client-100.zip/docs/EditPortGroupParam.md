# EditPortGroupParam

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ExecutionOption** | Pointer to **string** |  | [optional] [default to "SYNCHRONOUS"]
**EditPortGroupActionParam** | [**EditPortGroupActionParam**](EditPortGroupActionParam.md) |  | 

## Methods

### NewEditPortGroupParam

`func NewEditPortGroupParam(editPortGroupActionParam EditPortGroupActionParam, ) *EditPortGroupParam`

NewEditPortGroupParam instantiates a new EditPortGroupParam object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewEditPortGroupParamWithDefaults

`func NewEditPortGroupParamWithDefaults() *EditPortGroupParam`

NewEditPortGroupParamWithDefaults instantiates a new EditPortGroupParam object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetExecutionOption

`func (o *EditPortGroupParam) GetExecutionOption() string`

GetExecutionOption returns the ExecutionOption field if non-nil, zero value otherwise.

### GetExecutionOptionOk

`func (o *EditPortGroupParam) GetExecutionOptionOk() (*string, bool)`

GetExecutionOptionOk returns a tuple with the ExecutionOption field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetExecutionOption

`func (o *EditPortGroupParam) SetExecutionOption(v string)`

SetExecutionOption sets ExecutionOption field to given value.

### HasExecutionOption

`func (o *EditPortGroupParam) HasExecutionOption() bool`

HasExecutionOption returns a boolean if a field has been set.

### GetEditPortGroupActionParam

`func (o *EditPortGroupParam) GetEditPortGroupActionParam() EditPortGroupActionParam`

GetEditPortGroupActionParam returns the EditPortGroupActionParam field if non-nil, zero value otherwise.

### GetEditPortGroupActionParamOk

`func (o *EditPortGroupParam) GetEditPortGroupActionParamOk() (*EditPortGroupActionParam, bool)`

GetEditPortGroupActionParamOk returns a tuple with the EditPortGroupActionParam field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetEditPortGroupActionParam

`func (o *EditPortGroupParam) SetEditPortGroupActionParam(v EditPortGroupActionParam)`

SetEditPortGroupActionParam sets EditPortGroupActionParam field to given value.



[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


