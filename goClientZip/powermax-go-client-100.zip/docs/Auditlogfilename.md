# Auditlogfilename

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Auditlogfilename** | **string** | auditlogfilename | 

## Methods

### NewAuditlogfilename

`func NewAuditlogfilename(auditlogfilename string, ) *Auditlogfilename`

NewAuditlogfilename instantiates a new Auditlogfilename object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewAuditlogfilenameWithDefaults

`func NewAuditlogfilenameWithDefaults() *Auditlogfilename`

NewAuditlogfilenameWithDefaults instantiates a new Auditlogfilename object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetAuditlogfilename

`func (o *Auditlogfilename) GetAuditlogfilename() string`

GetAuditlogfilename returns the Auditlogfilename field if non-nil, zero value otherwise.

### GetAuditlogfilenameOk

`func (o *Auditlogfilename) GetAuditlogfilenameOk() (*string, bool)`

GetAuditlogfilenameOk returns a tuple with the Auditlogfilename field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetAuditlogfilename

`func (o *Auditlogfilename) SetAuditlogfilename(v string)`

SetAuditlogfilename sets Auditlogfilename field to given value.



[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


