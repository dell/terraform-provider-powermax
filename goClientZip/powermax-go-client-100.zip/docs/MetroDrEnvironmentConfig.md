# MetroDrEnvironmentConfig

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**MetroR1Array** | Pointer to **string** | The serial number for the Metro R1 System | [optional] 
**MetroR1MetroR2Rdfg** | Pointer to **int32** | The SRDF group number on the Metro R1 System to the Metro R2 System | [optional] 
**MetroR1DrRdfg** | Pointer to **int32** | The SRDF group number on the Metro R1 System to the DR System | [optional] 
**MetroR2Array** | Pointer to **string** | The serial number for the Metro R2 System | [optional] 
**MetroR2MetroR1Rdfg** | Pointer to **int32** | The SRDF group number on the Metro R2 System to the Metro R1 System | [optional] 
**MetroR2DrRdfg** | Pointer to **int32** | The SRDF group number on the Metro R2 System to the DR System | [optional] 
**DrArray** | Pointer to **string** | The serial number for the DR System | [optional] 
**DrMetroR1Rdfg** | Pointer to **int32** | The SRDF group number on the DR System to the Metro R1 System | [optional] 
**DrMetroR2Rdfg** | Pointer to **int32** | The SRDF group number on the DR System to the Metro R2 System | [optional] 
**MetroDrVolumePairing** | Pointer to [**[]MetroDrTriangle**](MetroDrTriangle.md) | metro_dr_volume_pairing | [optional] 

## Methods

### NewMetroDrEnvironmentConfig

`func NewMetroDrEnvironmentConfig() *MetroDrEnvironmentConfig`

NewMetroDrEnvironmentConfig instantiates a new MetroDrEnvironmentConfig object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewMetroDrEnvironmentConfigWithDefaults

`func NewMetroDrEnvironmentConfigWithDefaults() *MetroDrEnvironmentConfig`

NewMetroDrEnvironmentConfigWithDefaults instantiates a new MetroDrEnvironmentConfig object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetMetroR1Array

`func (o *MetroDrEnvironmentConfig) GetMetroR1Array() string`

GetMetroR1Array returns the MetroR1Array field if non-nil, zero value otherwise.

### GetMetroR1ArrayOk

`func (o *MetroDrEnvironmentConfig) GetMetroR1ArrayOk() (*string, bool)`

GetMetroR1ArrayOk returns a tuple with the MetroR1Array field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetMetroR1Array

`func (o *MetroDrEnvironmentConfig) SetMetroR1Array(v string)`

SetMetroR1Array sets MetroR1Array field to given value.

### HasMetroR1Array

`func (o *MetroDrEnvironmentConfig) HasMetroR1Array() bool`

HasMetroR1Array returns a boolean if a field has been set.

### GetMetroR1MetroR2Rdfg

`func (o *MetroDrEnvironmentConfig) GetMetroR1MetroR2Rdfg() int32`

GetMetroR1MetroR2Rdfg returns the MetroR1MetroR2Rdfg field if non-nil, zero value otherwise.

### GetMetroR1MetroR2RdfgOk

`func (o *MetroDrEnvironmentConfig) GetMetroR1MetroR2RdfgOk() (*int32, bool)`

GetMetroR1MetroR2RdfgOk returns a tuple with the MetroR1MetroR2Rdfg field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetMetroR1MetroR2Rdfg

`func (o *MetroDrEnvironmentConfig) SetMetroR1MetroR2Rdfg(v int32)`

SetMetroR1MetroR2Rdfg sets MetroR1MetroR2Rdfg field to given value.

### HasMetroR1MetroR2Rdfg

`func (o *MetroDrEnvironmentConfig) HasMetroR1MetroR2Rdfg() bool`

HasMetroR1MetroR2Rdfg returns a boolean if a field has been set.

### GetMetroR1DrRdfg

`func (o *MetroDrEnvironmentConfig) GetMetroR1DrRdfg() int32`

GetMetroR1DrRdfg returns the MetroR1DrRdfg field if non-nil, zero value otherwise.

### GetMetroR1DrRdfgOk

`func (o *MetroDrEnvironmentConfig) GetMetroR1DrRdfgOk() (*int32, bool)`

GetMetroR1DrRdfgOk returns a tuple with the MetroR1DrRdfg field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetMetroR1DrRdfg

`func (o *MetroDrEnvironmentConfig) SetMetroR1DrRdfg(v int32)`

SetMetroR1DrRdfg sets MetroR1DrRdfg field to given value.

### HasMetroR1DrRdfg

`func (o *MetroDrEnvironmentConfig) HasMetroR1DrRdfg() bool`

HasMetroR1DrRdfg returns a boolean if a field has been set.

### GetMetroR2Array

`func (o *MetroDrEnvironmentConfig) GetMetroR2Array() string`

GetMetroR2Array returns the MetroR2Array field if non-nil, zero value otherwise.

### GetMetroR2ArrayOk

`func (o *MetroDrEnvironmentConfig) GetMetroR2ArrayOk() (*string, bool)`

GetMetroR2ArrayOk returns a tuple with the MetroR2Array field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetMetroR2Array

`func (o *MetroDrEnvironmentConfig) SetMetroR2Array(v string)`

SetMetroR2Array sets MetroR2Array field to given value.

### HasMetroR2Array

`func (o *MetroDrEnvironmentConfig) HasMetroR2Array() bool`

HasMetroR2Array returns a boolean if a field has been set.

### GetMetroR2MetroR1Rdfg

`func (o *MetroDrEnvironmentConfig) GetMetroR2MetroR1Rdfg() int32`

GetMetroR2MetroR1Rdfg returns the MetroR2MetroR1Rdfg field if non-nil, zero value otherwise.

### GetMetroR2MetroR1RdfgOk

`func (o *MetroDrEnvironmentConfig) GetMetroR2MetroR1RdfgOk() (*int32, bool)`

GetMetroR2MetroR1RdfgOk returns a tuple with the MetroR2MetroR1Rdfg field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetMetroR2MetroR1Rdfg

`func (o *MetroDrEnvironmentConfig) SetMetroR2MetroR1Rdfg(v int32)`

SetMetroR2MetroR1Rdfg sets MetroR2MetroR1Rdfg field to given value.

### HasMetroR2MetroR1Rdfg

`func (o *MetroDrEnvironmentConfig) HasMetroR2MetroR1Rdfg() bool`

HasMetroR2MetroR1Rdfg returns a boolean if a field has been set.

### GetMetroR2DrRdfg

`func (o *MetroDrEnvironmentConfig) GetMetroR2DrRdfg() int32`

GetMetroR2DrRdfg returns the MetroR2DrRdfg field if non-nil, zero value otherwise.

### GetMetroR2DrRdfgOk

`func (o *MetroDrEnvironmentConfig) GetMetroR2DrRdfgOk() (*int32, bool)`

GetMetroR2DrRdfgOk returns a tuple with the MetroR2DrRdfg field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetMetroR2DrRdfg

`func (o *MetroDrEnvironmentConfig) SetMetroR2DrRdfg(v int32)`

SetMetroR2DrRdfg sets MetroR2DrRdfg field to given value.

### HasMetroR2DrRdfg

`func (o *MetroDrEnvironmentConfig) HasMetroR2DrRdfg() bool`

HasMetroR2DrRdfg returns a boolean if a field has been set.

### GetDrArray

`func (o *MetroDrEnvironmentConfig) GetDrArray() string`

GetDrArray returns the DrArray field if non-nil, zero value otherwise.

### GetDrArrayOk

`func (o *MetroDrEnvironmentConfig) GetDrArrayOk() (*string, bool)`

GetDrArrayOk returns a tuple with the DrArray field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetDrArray

`func (o *MetroDrEnvironmentConfig) SetDrArray(v string)`

SetDrArray sets DrArray field to given value.

### HasDrArray

`func (o *MetroDrEnvironmentConfig) HasDrArray() bool`

HasDrArray returns a boolean if a field has been set.

### GetDrMetroR1Rdfg

`func (o *MetroDrEnvironmentConfig) GetDrMetroR1Rdfg() int32`

GetDrMetroR1Rdfg returns the DrMetroR1Rdfg field if non-nil, zero value otherwise.

### GetDrMetroR1RdfgOk

`func (o *MetroDrEnvironmentConfig) GetDrMetroR1RdfgOk() (*int32, bool)`

GetDrMetroR1RdfgOk returns a tuple with the DrMetroR1Rdfg field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetDrMetroR1Rdfg

`func (o *MetroDrEnvironmentConfig) SetDrMetroR1Rdfg(v int32)`

SetDrMetroR1Rdfg sets DrMetroR1Rdfg field to given value.

### HasDrMetroR1Rdfg

`func (o *MetroDrEnvironmentConfig) HasDrMetroR1Rdfg() bool`

HasDrMetroR1Rdfg returns a boolean if a field has been set.

### GetDrMetroR2Rdfg

`func (o *MetroDrEnvironmentConfig) GetDrMetroR2Rdfg() int32`

GetDrMetroR2Rdfg returns the DrMetroR2Rdfg field if non-nil, zero value otherwise.

### GetDrMetroR2RdfgOk

`func (o *MetroDrEnvironmentConfig) GetDrMetroR2RdfgOk() (*int32, bool)`

GetDrMetroR2RdfgOk returns a tuple with the DrMetroR2Rdfg field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetDrMetroR2Rdfg

`func (o *MetroDrEnvironmentConfig) SetDrMetroR2Rdfg(v int32)`

SetDrMetroR2Rdfg sets DrMetroR2Rdfg field to given value.

### HasDrMetroR2Rdfg

`func (o *MetroDrEnvironmentConfig) HasDrMetroR2Rdfg() bool`

HasDrMetroR2Rdfg returns a boolean if a field has been set.

### GetMetroDrVolumePairing

`func (o *MetroDrEnvironmentConfig) GetMetroDrVolumePairing() []MetroDrTriangle`

GetMetroDrVolumePairing returns the MetroDrVolumePairing field if non-nil, zero value otherwise.

### GetMetroDrVolumePairingOk

`func (o *MetroDrEnvironmentConfig) GetMetroDrVolumePairingOk() (*[]MetroDrTriangle, bool)`

GetMetroDrVolumePairingOk returns a tuple with the MetroDrVolumePairing field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetMetroDrVolumePairing

`func (o *MetroDrEnvironmentConfig) SetMetroDrVolumePairing(v []MetroDrTriangle)`

SetMetroDrVolumePairing sets MetroDrVolumePairing field to given value.

### HasMetroDrVolumePairing

`func (o *MetroDrEnvironmentConfig) HasMetroDrVolumePairing() bool`

HasMetroDrVolumePairing returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


