# DgSwapParam

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Force** | Pointer to **bool** | Attempts to force the operation even though one or more volumes may not be in the normal, expected state(s) for the                                 specified                                 operation. | [optional] 
**SymForce** | Pointer to **bool** | Requests the System force operation be executed when normally it is rejected. Use extreme caution when using                                 this                                 option.                                  CAUTION: Use care when applying symforce, as data could be lost or corrupted. Use of this option is not recommended,                                 except in                                 an emergency.                                  NOTE: To enable symforce, a parameter called SYMAPI_ALLOW_RDF_SYMFORCE in the options file must be set to TRUE and                                 restart the                                 Unisphere server to pick up the change.                                  When used with symforce, a split command executes on an SRDF pair, even when the pair is sync in progress or restore in                                 progress.                                 During the execution of an establish or restore command, -symforce prohibits the verification of valid tracks on the                                 device at                                 the source. | [optional] 
**Star** | Pointer to **bool** | Targets the action at volumes in STAR mode. | [optional] 
**Hop2** | Pointer to **bool** | Targets the SRDF action at the group&#39;s second-hop volumes in a cascaded SRDF relationship. For example, in an RDF1                                 group, the                                 action                                 targets the R21-&gt;R2 pair of the R1-&gt;R21-&gt;R2 relationship. | [optional] 
**Bypass** | Pointer to **bool** | Bypasses any existing System exclusive locks during an SRDF operation.                                 WARNING: Only use this flag if you are certain no other SRDF operation is in progress at the local and/or remote                                 System. | [optional] 
**All** | Pointer to **bool** | Lists all SRDF mirrors of the selected devices. Used with symrdf list.                                 When performing an SRDF control or set operation, it targets the SRDF action at all devices in the device group:                                 Standard SRDF                                 devices                                 and locally-attached BCV SRDF devices.                                 This option is only supported for list and device group operations. | [optional] 
**Bcv** | Pointer to **bool** | Targets the SRDF action at the Device Group&#39;s locally-associated BCV volumes that are configured as SRDF BCV volumes. | [optional] 
**HalfSwap** | Pointer to **bool** | Swaps the SRDF personality of one-half of the designated dynamic SRDF pair. Source R1 devices become target R2 devices,                                 and                                 target R2 devices become source R1 devices. | [optional] 
**RefreshR1** | Pointer to **bool** | Marks the source (R1) devices to refresh from the remote mirror. | [optional] 
**RefreshR2** | Pointer to **bool** | Marks the target (R2) devices to refresh from the remote mirror. | [optional] 

## Methods

### NewDgSwapParam

`func NewDgSwapParam() *DgSwapParam`

NewDgSwapParam instantiates a new DgSwapParam object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewDgSwapParamWithDefaults

`func NewDgSwapParamWithDefaults() *DgSwapParam`

NewDgSwapParamWithDefaults instantiates a new DgSwapParam object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetForce

`func (o *DgSwapParam) GetForce() bool`

GetForce returns the Force field if non-nil, zero value otherwise.

### GetForceOk

`func (o *DgSwapParam) GetForceOk() (*bool, bool)`

GetForceOk returns a tuple with the Force field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetForce

`func (o *DgSwapParam) SetForce(v bool)`

SetForce sets Force field to given value.

### HasForce

`func (o *DgSwapParam) HasForce() bool`

HasForce returns a boolean if a field has been set.

### GetSymForce

`func (o *DgSwapParam) GetSymForce() bool`

GetSymForce returns the SymForce field if non-nil, zero value otherwise.

### GetSymForceOk

`func (o *DgSwapParam) GetSymForceOk() (*bool, bool)`

GetSymForceOk returns a tuple with the SymForce field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetSymForce

`func (o *DgSwapParam) SetSymForce(v bool)`

SetSymForce sets SymForce field to given value.

### HasSymForce

`func (o *DgSwapParam) HasSymForce() bool`

HasSymForce returns a boolean if a field has been set.

### GetStar

`func (o *DgSwapParam) GetStar() bool`

GetStar returns the Star field if non-nil, zero value otherwise.

### GetStarOk

`func (o *DgSwapParam) GetStarOk() (*bool, bool)`

GetStarOk returns a tuple with the Star field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetStar

`func (o *DgSwapParam) SetStar(v bool)`

SetStar sets Star field to given value.

### HasStar

`func (o *DgSwapParam) HasStar() bool`

HasStar returns a boolean if a field has been set.

### GetHop2

`func (o *DgSwapParam) GetHop2() bool`

GetHop2 returns the Hop2 field if non-nil, zero value otherwise.

### GetHop2Ok

`func (o *DgSwapParam) GetHop2Ok() (*bool, bool)`

GetHop2Ok returns a tuple with the Hop2 field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetHop2

`func (o *DgSwapParam) SetHop2(v bool)`

SetHop2 sets Hop2 field to given value.

### HasHop2

`func (o *DgSwapParam) HasHop2() bool`

HasHop2 returns a boolean if a field has been set.

### GetBypass

`func (o *DgSwapParam) GetBypass() bool`

GetBypass returns the Bypass field if non-nil, zero value otherwise.

### GetBypassOk

`func (o *DgSwapParam) GetBypassOk() (*bool, bool)`

GetBypassOk returns a tuple with the Bypass field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetBypass

`func (o *DgSwapParam) SetBypass(v bool)`

SetBypass sets Bypass field to given value.

### HasBypass

`func (o *DgSwapParam) HasBypass() bool`

HasBypass returns a boolean if a field has been set.

### GetAll

`func (o *DgSwapParam) GetAll() bool`

GetAll returns the All field if non-nil, zero value otherwise.

### GetAllOk

`func (o *DgSwapParam) GetAllOk() (*bool, bool)`

GetAllOk returns a tuple with the All field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetAll

`func (o *DgSwapParam) SetAll(v bool)`

SetAll sets All field to given value.

### HasAll

`func (o *DgSwapParam) HasAll() bool`

HasAll returns a boolean if a field has been set.

### GetBcv

`func (o *DgSwapParam) GetBcv() bool`

GetBcv returns the Bcv field if non-nil, zero value otherwise.

### GetBcvOk

`func (o *DgSwapParam) GetBcvOk() (*bool, bool)`

GetBcvOk returns a tuple with the Bcv field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetBcv

`func (o *DgSwapParam) SetBcv(v bool)`

SetBcv sets Bcv field to given value.

### HasBcv

`func (o *DgSwapParam) HasBcv() bool`

HasBcv returns a boolean if a field has been set.

### GetHalfSwap

`func (o *DgSwapParam) GetHalfSwap() bool`

GetHalfSwap returns the HalfSwap field if non-nil, zero value otherwise.

### GetHalfSwapOk

`func (o *DgSwapParam) GetHalfSwapOk() (*bool, bool)`

GetHalfSwapOk returns a tuple with the HalfSwap field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetHalfSwap

`func (o *DgSwapParam) SetHalfSwap(v bool)`

SetHalfSwap sets HalfSwap field to given value.

### HasHalfSwap

`func (o *DgSwapParam) HasHalfSwap() bool`

HasHalfSwap returns a boolean if a field has been set.

### GetRefreshR1

`func (o *DgSwapParam) GetRefreshR1() bool`

GetRefreshR1 returns the RefreshR1 field if non-nil, zero value otherwise.

### GetRefreshR1Ok

`func (o *DgSwapParam) GetRefreshR1Ok() (*bool, bool)`

GetRefreshR1Ok returns a tuple with the RefreshR1 field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetRefreshR1

`func (o *DgSwapParam) SetRefreshR1(v bool)`

SetRefreshR1 sets RefreshR1 field to given value.

### HasRefreshR1

`func (o *DgSwapParam) HasRefreshR1() bool`

HasRefreshR1 returns a boolean if a field has been set.

### GetRefreshR2

`func (o *DgSwapParam) GetRefreshR2() bool`

GetRefreshR2 returns the RefreshR2 field if non-nil, zero value otherwise.

### GetRefreshR2Ok

`func (o *DgSwapParam) GetRefreshR2Ok() (*bool, bool)`

GetRefreshR2Ok returns a tuple with the RefreshR2 field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetRefreshR2

`func (o *DgSwapParam) SetRefreshR2(v bool)`

SetRefreshR2 sets RefreshR2 field to given value.

### HasRefreshR2

`func (o *DgSwapParam) HasRefreshR2() bool`

HasRefreshR2 returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


