# HostSummary

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**HostId** | **string** | The host name. | 
**Initiator** | Pointer to **[]string** | The initiator name. | [optional] 

## Methods

### NewHostSummary

`func NewHostSummary(hostId string, ) *HostSummary`

NewHostSummary instantiates a new HostSummary object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewHostSummaryWithDefaults

`func NewHostSummaryWithDefaults() *HostSummary`

NewHostSummaryWithDefaults instantiates a new HostSummary object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetHostId

`func (o *HostSummary) GetHostId() string`

GetHostId returns the HostId field if non-nil, zero value otherwise.

### GetHostIdOk

`func (o *HostSummary) GetHostIdOk() (*string, bool)`

GetHostIdOk returns a tuple with the HostId field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetHostId

`func (o *HostSummary) SetHostId(v string)`

SetHostId sets HostId field to given value.


### GetInitiator

`func (o *HostSummary) GetInitiator() []string`

GetInitiator returns the Initiator field if non-nil, zero value otherwise.

### GetInitiatorOk

`func (o *HostSummary) GetInitiatorOk() (*[]string, bool)`

GetInitiatorOk returns a tuple with the Initiator field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetInitiator

`func (o *HostSummary) SetInitiator(v []string)`

SetInitiator sets Initiator field to given value.

### HasInitiator

`func (o *HostSummary) HasInitiator() bool`

HasInitiator returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


