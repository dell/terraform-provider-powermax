# ModifyAmazonConnectionDetails

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Key** | Pointer to **string** | The Cloud Provider Key | [optional] 
**Secret** | Pointer to **string** | The Cloud Provider Secret | [optional] 
**Secure** | Pointer to **bool** | Is The Cloud Provider Secure, HTTPS &#x3D; true | [optional] 
**Port** | Pointer to **string** | The Cloud Provider Port | [optional] 

## Methods

### NewModifyAmazonConnectionDetails

`func NewModifyAmazonConnectionDetails() *ModifyAmazonConnectionDetails`

NewModifyAmazonConnectionDetails instantiates a new ModifyAmazonConnectionDetails object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewModifyAmazonConnectionDetailsWithDefaults

`func NewModifyAmazonConnectionDetailsWithDefaults() *ModifyAmazonConnectionDetails`

NewModifyAmazonConnectionDetailsWithDefaults instantiates a new ModifyAmazonConnectionDetails object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetKey

`func (o *ModifyAmazonConnectionDetails) GetKey() string`

GetKey returns the Key field if non-nil, zero value otherwise.

### GetKeyOk

`func (o *ModifyAmazonConnectionDetails) GetKeyOk() (*string, bool)`

GetKeyOk returns a tuple with the Key field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetKey

`func (o *ModifyAmazonConnectionDetails) SetKey(v string)`

SetKey sets Key field to given value.

### HasKey

`func (o *ModifyAmazonConnectionDetails) HasKey() bool`

HasKey returns a boolean if a field has been set.

### GetSecret

`func (o *ModifyAmazonConnectionDetails) GetSecret() string`

GetSecret returns the Secret field if non-nil, zero value otherwise.

### GetSecretOk

`func (o *ModifyAmazonConnectionDetails) GetSecretOk() (*string, bool)`

GetSecretOk returns a tuple with the Secret field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetSecret

`func (o *ModifyAmazonConnectionDetails) SetSecret(v string)`

SetSecret sets Secret field to given value.

### HasSecret

`func (o *ModifyAmazonConnectionDetails) HasSecret() bool`

HasSecret returns a boolean if a field has been set.

### GetSecure

`func (o *ModifyAmazonConnectionDetails) GetSecure() bool`

GetSecure returns the Secure field if non-nil, zero value otherwise.

### GetSecureOk

`func (o *ModifyAmazonConnectionDetails) GetSecureOk() (*bool, bool)`

GetSecureOk returns a tuple with the Secure field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetSecure

`func (o *ModifyAmazonConnectionDetails) SetSecure(v bool)`

SetSecure sets Secure field to given value.

### HasSecure

`func (o *ModifyAmazonConnectionDetails) HasSecure() bool`

HasSecure returns a boolean if a field has been set.

### GetPort

`func (o *ModifyAmazonConnectionDetails) GetPort() string`

GetPort returns the Port field if non-nil, zero value otherwise.

### GetPortOk

`func (o *ModifyAmazonConnectionDetails) GetPortOk() (*string, bool)`

GetPortOk returns a tuple with the Port field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetPort

`func (o *ModifyAmazonConnectionDetails) SetPort(v string)`

SetPort sets Port field to given value.

### HasPort

`func (o *ModifyAmazonConnectionDetails) HasPort() bool`

HasPort returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


