# \FileApi

All URIs are relative to *https://localhost:8443/univmax/restapi*

Method | HTTP request | Description
------------- | ------------- | -------------
[**ActionMountSnapshot**](FileApi.md#ActionMountSnapshot) | **Post** /100/file/symmetrix/{symmetrix_id}/snapshot/{snapshot_id}/mount | mount Snapshot 
[**ActionUnmountSnapshot**](FileApi.md#ActionUnmountSnapshot) | **Post** /100/file/symmetrix/{symmetrix_id}/snapshot/{snapshot_id}/unmount | unmount Snapshot 
[**ActivateCloneGlobalNamespace**](FileApi.md#ActivateCloneGlobalNamespace) | **Post** /100/file/symmetrix/{symmetrix_id}/global_namespace/{unified_namespace_id}/activate_clone | Active Clone GlobalNameSpace
[**AddGlobalNamespaceLinkTarget**](FileApi.md#AddGlobalNamespaceLinkTarget) | **Post** /100/file/symmetrix/{symmetrix_id}/global_namespace_link/{global_namespace_link_id}/add_link_target | Create GlobalNameSpaceLink 
[**AssignSubnet**](FileApi.md#AssignSubnet) | **Post** /100/file/symmetrix/{symmetrix_id}/network_device/assign_subnet | Assign subnet Network Device 
[**AttachSchedule**](FileApi.md#AttachSchedule) | **Post** /100/file/symmetrix/{symmetrix_id}/snap_policy/{snap_policy_id}/attach | attach Snap Schedule  Snap Schedule 
[**CloneNasServer**](FileApi.md#CloneNasServer) | **Post** /100/file/symmetrix/{symmetrix_id}/nas_server/{nas_server_id}/clone | Create NASServer Clone 
[**CreateBondDevice**](FileApi.md#CreateBondDevice) | **Post** /100/file/symmetrix/{symmetrix_id}/bond_device | Create Bond Device 
[**CreateClone**](FileApi.md#CreateClone) | **Post** /100/file/symmetrix/{symmetrix_id}/file_system/{file_system_id}/clone | Create FileSystem Clone 
[**CreateDNSService**](FileApi.md#CreateDNSService) | **Post** /100/file/symmetrix/{symmetrix_id}/dns_service | Create DNSService  
[**CreateDhsmServer**](FileApi.md#CreateDhsmServer) | **Post** /100/file/symmetrix/{symmetrix_id}/dhsm_server | Create DHSMServer 
[**CreateDpNetwork**](FileApi.md#CreateDpNetwork) | **Post** /100/file/symmetrix/{symmetrix_id}/dp_network | Create Dp Network 
[**CreateEventPools**](FileApi.md#CreateEventPools) | **Post** /100/file/symmetrix/{symmetrix_id}/event_pool | Create Events Pool 
[**CreateEventPublishers**](FileApi.md#CreateEventPublishers) | **Post** /100/file/symmetrix/{symmetrix_id}/event_publisher | Create Event Publisher
[**CreateFileInterface**](FileApi.md#CreateFileInterface) | **Post** /100/file/symmetrix/{symmetrix_id}/file_interface | Create file Interface 
[**CreateFileSystem**](FileApi.md#CreateFileSystem) | **Post** /100/file/symmetrix/{symmetrix_id}/file_system | Create FileSystem 
[**CreateFtpServer**](FileApi.md#CreateFtpServer) | **Post** /100/file/symmetrix/{symmetrix_id}/ftp_server | Create FTP Server 
[**CreateGlobalNamespace**](FileApi.md#CreateGlobalNamespace) | **Post** /100/file/symmetrix/{symmetrix_id}/global_namespace | Create GlobalNameSpace 
[**CreateGlobalNamespaceLink**](FileApi.md#CreateGlobalNamespaceLink) | **Post** /100/file/symmetrix/{symmetrix_id}/global_namespace_link | Create GlobalNameSpaceLink 
[**CreateKerberosService**](FileApi.md#CreateKerberosService) | **Post** /100/file/symmetrix/{symmetrix_id}/kerberos_service | Create Kerberos Service 
[**CreateLDAPService**](FileApi.md#CreateLDAPService) | **Post** /100/file/symmetrix/{symmetrix_id}/ldap_service | Create Ldap Service 
[**CreateNASServer**](FileApi.md#CreateNASServer) | **Post** /100/file/symmetrix/{symmetrix_id}/nas_server | Create NASServer
[**CreateNDMPServer**](FileApi.md#CreateNDMPServer) | **Post** /100/file/symmetrix/{symmetrix_id}/ndmp_server | Create Ndmp server 
[**CreateNFSExports**](FileApi.md#CreateNFSExports) | **Post** /100/file/symmetrix/{symmetrix_id}/nfs_export | Create NFS Export 
[**CreateNFSServer**](FileApi.md#CreateNFSServer) | **Post** /100/file/symmetrix/{symmetrix_id}/nfs_server | Create NFS Server 
[**CreateNISService**](FileApi.md#CreateNISService) | **Post** /100/file/symmetrix/{symmetrix_id}/nis_service | Create Nis Service 
[**CreateRemoteSystem**](FileApi.md#CreateRemoteSystem) | **Post** /100/file/symmetrix/{symmetrix_id}/remote_system | Create Remote System 
[**CreateReplicationSession**](FileApi.md#CreateReplicationSession) | **Post** /100/file/symmetrix/{symmetrix_id}/replication_session | Create Replication Session
[**CreateRoute**](FileApi.md#CreateRoute) | **Post** /100/file/symmetrix/{symmetrix_id}/interface_route | Create Routes 
[**CreateSMBServer**](FileApi.md#CreateSMBServer) | **Post** /100/file/symmetrix/{symmetrix_id}/smb_server | Create SMB Server 
[**CreateSMBShares**](FileApi.md#CreateSMBShares) | **Post** /100/file/symmetrix/{symmetrix_id}/smb_share | Create SMB Share 
[**CreateSchedules**](FileApi.md#CreateSchedules) | **Post** /100/file/symmetrix/{symmetrix_id}/snap_policy | Create Snap Schedule 
[**CreateSnapshot**](FileApi.md#CreateSnapshot) | **Post** /100/file/symmetrix/{symmetrix_id}/snapshot | Create Snapshot 
[**CreateTreeQuota**](FileApi.md#CreateTreeQuota) | **Post** /100/file/symmetrix/{symmetrix_id}/file_system/{file_system_id}/tree_quota | Create Tree Quota 
[**CreateUserQuota**](FileApi.md#CreateUserQuota) | **Post** /100/file/symmetrix/{symmetrix_id}/file_system/{file_system_id}/user_quota | Create User Quota 
[**CreateVirusChecker**](FileApi.md#CreateVirusChecker) | **Post** /100/file/symmetrix/{symmetrix_id}/virus_checker | Create Virus checker 
[**DeleteBondDevice**](FileApi.md#DeleteBondDevice) | **Delete** /100/file/symmetrix/{symmetrix_id}/bond_device/{bond_device_id} | Delete Bond Device
[**DeleteDNSService**](FileApi.md#DeleteDNSService) | **Delete** /100/file/symmetrix/{symmetrix_id}/dns_service/{dns_service_id} | Delete DNS Service
[**DeleteDhsmServer**](FileApi.md#DeleteDhsmServer) | **Delete** /100/file/symmetrix/{symmetrix_id}/dhsm_server/{dhsm_server_id} | Delete DHSMServer
[**DeleteDpNetwork**](FileApi.md#DeleteDpNetwork) | **Delete** /100/file/symmetrix/{symmetrix_id}/dp_network/{dp_network_id} | Delete Dp Network
[**DeleteEventPool**](FileApi.md#DeleteEventPool) | **Delete** /100/file/symmetrix/{symmetrix_id}/event_pool/{event_pool_id} | Delete Events Pool
[**DeleteEventPublisher**](FileApi.md#DeleteEventPublisher) | **Delete** /100/file/symmetrix/{symmetrix_id}/event_publisher/{event_publisher_id} | Delete event publisher
[**DeleteFileInterface**](FileApi.md#DeleteFileInterface) | **Delete** /100/file/symmetrix/{symmetrix_id}/file_interface/{file_interface_id} | Delete file Interface
[**DeleteFileSystem**](FileApi.md#DeleteFileSystem) | **Delete** /100/file/symmetrix/{symmetrix_id}/file_system/{file_system_id} | Delete FileSystem
[**DeleteFtpServer**](FileApi.md#DeleteFtpServer) | **Delete** /100/file/symmetrix/{symmetrix_id}/ftp_server/{ftp_server_id} | Delete FTPServer
[**DeleteGlobalNamespace**](FileApi.md#DeleteGlobalNamespace) | **Delete** /100/file/symmetrix/{symmetrix_id}/global_namespace/{unified_namespace_id} | Delete GlobalNameSpace
[**DeleteGlobalNamespaceLink**](FileApi.md#DeleteGlobalNamespaceLink) | **Delete** /100/file/symmetrix/{symmetrix_id}/global_namespace_link/{global_namespace_link_id} | Delete GlobalNameSpaceLink
[**DeleteKerberosService**](FileApi.md#DeleteKerberosService) | **Delete** /100/file/symmetrix/{symmetrix_id}/kerberos_service/{kerberos_service_id} | Delete Kerberos Service
[**DeleteLDAPService**](FileApi.md#DeleteLDAPService) | **Delete** /100/file/symmetrix/{symmetrix_id}/ldap_service/{ldap_service_id} | Delete Ldap Service
[**DeleteNDMPServer**](FileApi.md#DeleteNDMPServer) | **Delete** /100/file/symmetrix/{symmetrix_id}/ndmp_server/{ndmp_server_id} | Delete Ndmp server
[**DeleteNFSExport**](FileApi.md#DeleteNFSExport) | **Delete** /100/file/symmetrix/{symmetrix_id}/nfs_export/{nfs_export_id} | Delete NFS Export
[**DeleteNFSServer**](FileApi.md#DeleteNFSServer) | **Delete** /100/file/symmetrix/{symmetrix_id}/nfs_server/{nfs_server_id} | Delete NFS Server
[**DeleteNIService**](FileApi.md#DeleteNIService) | **Delete** /100/file/symmetrix/{symmetrix_id}/nis_service/{nis_service_id} | Delete Nis Service
[**DeleteNasServer**](FileApi.md#DeleteNasServer) | **Delete** /100/file/symmetrix/{symmetrix_id}/nas_server/{nas_server_id} | Delete NAS Server
[**DeleteRemoteSystem**](FileApi.md#DeleteRemoteSystem) | **Delete** /100/file/symmetrix/{symmetrix_id}/remote_system/{remote_system_id} | Delete Remote System
[**DeleteReplicationSession**](FileApi.md#DeleteReplicationSession) | **Delete** /100/file/symmetrix/{symmetrix_id}/replication_session/{replication_session_id} | Delete Replication session
[**DeleteRoute**](FileApi.md#DeleteRoute) | **Delete** /100/file/symmetrix/{symmetrix_id}/interface_route/{route_id} | Delete Routes
[**DeleteSMBServer**](FileApi.md#DeleteSMBServer) | **Delete** /100/file/symmetrix/{symmetrix_id}/smb_server/{smb_server_id} | Delete SMB Server
[**DeleteSMBShare**](FileApi.md#DeleteSMBShare) | **Delete** /100/file/symmetrix/{symmetrix_id}/smb_share/{smb_share_id} | Delete SMB Share
[**DeleteSchedule**](FileApi.md#DeleteSchedule) | **Delete** /100/file/symmetrix/{symmetrix_id}/snap_policy/{snap_policy_id} | Delete Snap Schedule
[**DeleteSnapshot**](FileApi.md#DeleteSnapshot) | **Delete** /100/file/symmetrix/{symmetrix_id}/snapshot/{snapshot_id} | Delete Snapshot
[**DeleteTree**](FileApi.md#DeleteTree) | **Delete** /100/file/symmetrix/{symmetrix_id}/file_system/{file_system_id}/tree_quota/{tree_quota_id} | Delete Tree Quota
[**DeleteVirusChecker**](FileApi.md#DeleteVirusChecker) | **Delete** /100/file/symmetrix/{symmetrix_id}/virus_checker/{virus_checker_id} | Delete Virus checker
[**DetachSchedule**](FileApi.md#DetachSchedule) | **Post** /100/file/symmetrix/{symmetrix_id}/snap_policy/{snap_policy_id}/detach | detach Snap Schedule from file system 
[**DownloadCertificateLDAPService**](FileApi.md#DownloadCertificateLDAPService) | **Get** /100/file/symmetrix/{symmetrix_id}/ldap_service/{ldap_service_id}/download/certificate | upload Ldap Service certification
[**DownloadConfigLDAPService**](FileApi.md#DownloadConfigLDAPService) | **Get** /100/file/symmetrix/{symmetrix_id}/ldap_service/{ldap_service_id}/download/config | download Ldap Service config
[**DownloadConfigVirusChecker**](FileApi.md#DownloadConfigVirusChecker) | **Get** /100/file/symmetrix/{symmetrix_id}/virus_checker/{virus_checker_id}/download/config | Download Virus Checker
[**DownloadHostsNASServer**](FileApi.md#DownloadHostsNASServer) | **Get** /100/file/symmetrix/{symmetrix_id}/nas_server/{nas_server_id}/download/hosts | Get NAS Server hosts file
[**DownloadKeytabKerberosService**](FileApi.md#DownloadKeytabKerberosService) | **Get** /100/file/symmetrix/{symmetrix_id}/kerberos_service/{kerberos_service_id}/download/keytab | download Kerberos Service
[**DownloadPasswdNASServer**](FileApi.md#DownloadPasswdNASServer) | **Get** /100/file/symmetrix/{symmetrix_id}/nas_server/{nas_server_id}/download/passwd | Get NAS Server Password file
[**DownloadUserMapping**](FileApi.md#DownloadUserMapping) | **Get** /100/file/symmetrix/{symmetrix_id}/nas_server/{nas_server_id}/download/mapping_report | Get NAS Server mapping report file
[**DownlodGroupNASserver**](FileApi.md#DownlodGroupNASserver) | **Get** /100/file/symmetrix/{symmetrix_id}/nas_server/{nas_server_id}/download/group | Get NAS Server hosts file
[**DownlodHomedirNASserver**](FileApi.md#DownlodHomedirNASserver) | **Get** /100/file/symmetrix/{symmetrix_id}/nas_server/{nas_server_id}/download/home_dir | Get NAS Server home dir file
[**DownlodNSSwitchNASserver**](FileApi.md#DownlodNSSwitchNASserver) | **Get** /100/file/symmetrix/{symmetrix_id}/nas_server/{nas_server_id}/download/ns_switch | Get NAS Server ns switch file
[**DownlodNetGroupNASserver**](FileApi.md#DownlodNetGroupNASserver) | **Get** /100/file/symmetrix/{symmetrix_id}/nas_server/{nas_server_id}/download/net_group | Get NAS Server net group file
[**DownlodNtxmapNASserver**](FileApi.md#DownlodNtxmapNASserver) | **Get** /100/file/symmetrix/{symmetrix_id}/nas_server/{nas_server_id}/download/ntx_map | Get NAS Server ntx map file
[**FailoverReplicationSession**](FileApi.md#FailoverReplicationSession) | **Post** /100/file/symmetrix/{symmetrix_id}/replication_session/{replication_session_id}/failover | Failover Replication session 
[**FetchCompatibleNode**](FileApi.md#FetchCompatibleNode) | **Get** /100/file/symmetrix/{symmetrix_id}/nas_server/{nas_server_id}/compatible_node | compatible node NASServer 
[**GetDNSService**](FileApi.md#GetDNSService) | **Get** /100/file/symmetrix/{symmetrix_id}/dns_service/{dns_service_id} | Get DNS Service
[**GetDNSServices**](FileApi.md#GetDNSServices) | **Get** /100/file/symmetrix/{symmetrix_id}/dns_service | List DNS Service
[**GetDhsmServer**](FileApi.md#GetDhsmServer) | **Get** /100/file/symmetrix/{symmetrix_id}/dhsm_server/{dhsm_server_id} | Get DHSMServer Configuration
[**GetDpNetwork**](FileApi.md#GetDpNetwork) | **Get** /100/file/symmetrix/{symmetrix_id}/dp_network/{dp_network_id} | Get Dp Network
[**GetDpNetworks**](FileApi.md#GetDpNetworks) | **Get** /100/file/symmetrix/{symmetrix_id}/dp_network | List Dp Network
[**GetEventPool**](FileApi.md#GetEventPool) | **Get** /100/file/symmetrix/{symmetrix_id}/event_pool/{event_pool_id} | Get Events Pool
[**GetEventPublishers**](FileApi.md#GetEventPublishers) | **Get** /100/file/symmetrix/{symmetrix_id}/event_publisher | Event Publisher
[**GetEventsPostList**](FileApi.md#GetEventsPostList) | **Get** /100/file/symmetrix/{symmetrix_id}/event_pool | List Events Pool
[**GetEventsPublisher**](FileApi.md#GetEventsPublisher) | **Get** /100/file/symmetrix/{symmetrix_id}/event_publisher/{event_publisher_id} | Get event publisher
[**GetFSReplicationSession**](FileApi.md#GetFSReplicationSession) | **Get** /100/file/symmetrix/{symmetrix_id}/replication_session/fs_replication/{fs_replication_session_id} | Get FS Replication session
[**GetFSReplicationSessions**](FileApi.md#GetFSReplicationSessions) | **Get** /100/file/symmetrix/{symmetrix_id}/replication_session/fs_replication | List FS Replication session
[**GetFileInterface**](FileApi.md#GetFileInterface) | **Get** /100/file/symmetrix/{symmetrix_id}/file_interface/{file_interface_id} | Get file Interface
[**GetFileInterfaceList**](FileApi.md#GetFileInterfaceList) | **Get** /100/file/symmetrix/{symmetrix_id}/file_interface | List file Interface
[**GetFileSystem**](FileApi.md#GetFileSystem) | **Get** /100/file/symmetrix/{symmetrix_id}/file_system/{file_system_id} | Get FileSystem
[**GetFileSystems**](FileApi.md#GetFileSystems) | **Get** /100/file/symmetrix/{symmetrix_id}/file_system | List File System
[**GetFtpServer**](FileApi.md#GetFtpServer) | **Get** /100/file/symmetrix/{symmetrix_id}/ftp_server/{ftp_server_id} | Get FTPServer
[**GetFtpServers**](FileApi.md#GetFtpServers) | **Get** /100/file/symmetrix/{symmetrix_id}/ftp_server | Get List FTP Server
[**GetGlobalNamespace**](FileApi.md#GetGlobalNamespace) | **Get** /100/file/symmetrix/{symmetrix_id}/global_namespace | List GlobalNameSpace
[**GetGlobalNamespace1**](FileApi.md#GetGlobalNamespace1) | **Get** /100/file/symmetrix/{symmetrix_id}/global_namespace/{unified_namespace_id} | Get GlobalNameSpace
[**GetKerberosService**](FileApi.md#GetKerberosService) | **Get** /100/file/symmetrix/{symmetrix_id}/kerberos_service/{kerberos_service_id} | Get Kerberos Service
[**GetKerberosServices**](FileApi.md#GetKerberosServices) | **Get** /100/file/symmetrix/{symmetrix_id}/kerberos_service | List Kerberos services
[**GetLDAPService**](FileApi.md#GetLDAPService) | **Get** /100/file/symmetrix/{symmetrix_id}/ldap_service/{ldap_service_id} | Get Kerberos Service
[**GetLDAPServices**](FileApi.md#GetLDAPServices) | **Get** /100/file/symmetrix/{symmetrix_id}/ldap_service | List Ldap Service
[**GetListNasServers**](FileApi.md#GetListNasServers) | **Get** /100/file/symmetrix/{symmetrix_id}/nas_server | List NAS Server
[**GetNDMPServer**](FileApi.md#GetNDMPServer) | **Get** /100/file/symmetrix/{symmetrix_id}/ndmp_server/{ndmp_server_id} | Get Ndmp server
[**GetNDMPServers**](FileApi.md#GetNDMPServers) | **Get** /100/file/symmetrix/{symmetrix_id}/ndmp_server | List Ndmp server
[**GetNFSExport**](FileApi.md#GetNFSExport) | **Get** /100/file/symmetrix/{symmetrix_id}/nfs_export/{nfs_export_id} | Get NFS Export
[**GetNFSExports**](FileApi.md#GetNFSExports) | **Get** /100/file/symmetrix/{symmetrix_id}/nfs_export | List NFS Export
[**GetNFSServer**](FileApi.md#GetNFSServer) | **Get** /100/file/symmetrix/{symmetrix_id}/nfs_server/{nfs_server_id} | Get NFS Server
[**GetNFSServers**](FileApi.md#GetNFSServers) | **Get** /100/file/symmetrix/{symmetrix_id}/nfs_server | List NFS Server
[**GetNISService**](FileApi.md#GetNISService) | **Get** /100/file/symmetrix/{symmetrix_id}/nis_service/{nis_service_id} | Get Nis Service
[**GetNasServer**](FileApi.md#GetNasServer) | **Get** /100/file/symmetrix/{symmetrix_id}/nas_server/{nas_server_id} | Get NAS Server
[**GetNetworkDevice**](FileApi.md#GetNetworkDevice) | **Get** /100/file/symmetrix/{symmetrix_id}/network_device/{network_device_id} | Get Network Device
[**GetNetworkDevices**](FileApi.md#GetNetworkDevices) | **Get** /100/file/symmetrix/{symmetrix_id}/network_device | List Network Devices
[**GetNisServices**](FileApi.md#GetNisServices) | **Get** /100/file/symmetrix/{symmetrix_id}/nis_service | List Nis Service
[**GetNodeInventory**](FileApi.md#GetNodeInventory) | **Get** /100/file/symmetrix/{symmetrix_id}/node/{node_id} | Get Node Inventory
[**GetNodes**](FileApi.md#GetNodes) | **Get** /100/file/symmetrix/{symmetrix_id}/node | List Node Inventory
[**GetRemoteSystem**](FileApi.md#GetRemoteSystem) | **Get** /100/file/symmetrix/{symmetrix_id}/remote_system/{remote_system_id} | Get Remote System
[**GetRemoteSystems**](FileApi.md#GetRemoteSystems) | **Get** /100/file/symmetrix/{symmetrix_id}/remote_system | List Remote System
[**GetReplicationSession**](FileApi.md#GetReplicationSession) | **Get** /100/file/symmetrix/{symmetrix_id}/replication_session/{replication_session_id} | Get Replication Session
[**GetReplicationSessions**](FileApi.md#GetReplicationSessions) | **Get** /100/file/symmetrix/{symmetrix_id}/replication_session | List Replication Session
[**GetRoute**](FileApi.md#GetRoute) | **Get** /100/file/symmetrix/{symmetrix_id}/interface_route/{route_id} | Get Interface route
[**GetRouteList**](FileApi.md#GetRouteList) | **Get** /100/file/symmetrix/{symmetrix_id}/interface_route | List Interface route
[**GetSMBServer**](FileApi.md#GetSMBServer) | **Get** /100/file/symmetrix/{symmetrix_id}/smb_server/{smb_server_id} | Get SMB Server
[**GetSMBServers**](FileApi.md#GetSMBServers) | **Get** /100/file/symmetrix/{symmetrix_id}/smb_server | List SMB Server
[**GetSMBShare**](FileApi.md#GetSMBShare) | **Get** /100/file/symmetrix/{symmetrix_id}/smb_share/{smb_share_id} | Get SMB Share
[**GetSMBShares**](FileApi.md#GetSMBShares) | **Get** /100/file/symmetrix/{symmetrix_id}/smb_share | List SMB Share
[**GetSchedule**](FileApi.md#GetSchedule) | **Get** /100/file/symmetrix/{symmetrix_id}/snap_policy/{snap_policy_id} | Get Snap Schedule
[**GetSchedules**](FileApi.md#GetSchedules) | **Get** /100/file/symmetrix/{symmetrix_id}/snap_policy | List Snap Schedule
[**GetSnapshot**](FileApi.md#GetSnapshot) | **Get** /100/file/symmetrix/{symmetrix_id}/snapshot/{snapshot_id} | Get Snapshot
[**GetSnapshots**](FileApi.md#GetSnapshots) | **Get** /100/file/symmetrix/{symmetrix_id}/snapshot | List SMB Share
[**GetTreeQuota**](FileApi.md#GetTreeQuota) | **Get** /100/file/symmetrix/{symmetrix_id}/file_system/{file_system_id}/tree_quota/{tree_quota_id} | Get Tree Quota by ID
[**GetTreeQuotas**](FileApi.md#GetTreeQuotas) | **Get** /100/file/symmetrix/{symmetrix_id}/file_system/{file_system_id}/tree_quota | List Tree Quota
[**GetUnifiedNamespace**](FileApi.md#GetUnifiedNamespace) | **Get** /100/file/symmetrix/{symmetrix_id}/global_namespace_link | List GlobalNameSpace
[**GetUnifiedNamespace1**](FileApi.md#GetUnifiedNamespace1) | **Get** /100/file/symmetrix/{symmetrix_id}/global_namespace_link/{global_namespace_link_id} | Get GlobalNameSpace Link
[**GetUserQuota**](FileApi.md#GetUserQuota) | **Get** /100/file/symmetrix/{symmetrix_id}/file_system/{file_system_id}/user_quota/{user_quota_id} | Get User Quota
[**GetUserQuotas**](FileApi.md#GetUserQuotas) | **Get** /100/file/symmetrix/{symmetrix_id}/file_system/{file_system_id}/user_quota | List Tree Quota
[**GetVirusChecker**](FileApi.md#GetVirusChecker) | **Get** /100/file/symmetrix/{symmetrix_id}/virus_checker/{virus_checker_id} | Get Virus checker
[**GetVirusCheckers**](FileApi.md#GetVirusCheckers) | **Get** /100/file/symmetrix/{symmetrix_id}/virus_checker | List Virus Chcker
[**GetdhmServers**](FileApi.md#GetdhmServers) | **Get** /100/file/symmetrix/{symmetrix_id}/dhsm_server | List DHSMServer
[**JoinNFSServer**](FileApi.md#JoinNFSServer) | **Post** /100/file/symmetrix/{symmetrix_id}/nfs_server/{nfs_server_id}/join | Create NFS Server 
[**JoinSMBServer**](FileApi.md#JoinSMBServer) | **Post** /100/file/symmetrix/{symmetrix_id}/smb_server/{smb_server_id}/join | Join SMB Server to active directory
[**ModifyBondDevice**](FileApi.md#ModifyBondDevice) | **Put** /100/file/symmetrix/{symmetrix_id}/bond_device/{bond_device_id} | Modify Bond Device
[**ModifyDNSService**](FileApi.md#ModifyDNSService) | **Put** /100/file/symmetrix/{symmetrix_id}/dns_service/{dns_service_id} | Modify DNS service
[**ModifyDhsmServer**](FileApi.md#ModifyDhsmServer) | **Put** /100/file/symmetrix/{symmetrix_id}/dhsm_server/{dhsm_server_id} | Modify DHSMServer 
[**ModifyDpNetwork**](FileApi.md#ModifyDpNetwork) | **Put** /100/file/symmetrix/{symmetrix_id}/dp_network/{dp_network_id} | Modify Dp Network
[**ModifyEventPool**](FileApi.md#ModifyEventPool) | **Put** /100/file/symmetrix/{symmetrix_id}/event_pool/{event_pool_id} | Modify Events Pool
[**ModifyEventPublisher**](FileApi.md#ModifyEventPublisher) | **Put** /100/file/symmetrix/{symmetrix_id}/event_publisher/{event_publisher_id} | Modify Event Publisher
[**ModifyFileInterface**](FileApi.md#ModifyFileInterface) | **Put** /100/file/symmetrix/{symmetrix_id}/file_interface/{file_interface_id} | Modify file Interface
[**ModifyFileSystem**](FileApi.md#ModifyFileSystem) | **Put** /100/file/symmetrix/{symmetrix_id}/file_system/{file_system_id} | Modify FileSystem
[**ModifyFtpServer**](FileApi.md#ModifyFtpServer) | **Put** /100/file/symmetrix/{symmetrix_id}/ftp_server/{ftp_server_id} | Modify ftp server
[**ModifyGlobalNamespace**](FileApi.md#ModifyGlobalNamespace) | **Put** /100/file/symmetrix/{symmetrix_id}/global_namespace/{unified_namespace_id} | Modify GlobalNameSpace
[**ModifyGlobalNamespaceLink**](FileApi.md#ModifyGlobalNamespaceLink) | **Put** /100/file/symmetrix/{symmetrix_id}/global_namespace_link/{global_namespace_link_id} | Modify GlobalNameSpace
[**ModifyKerberosService**](FileApi.md#ModifyKerberosService) | **Put** /100/file/symmetrix/{symmetrix_id}/kerberos_service/{kerberos_service_id} | Modify Kerberos Service
[**ModifyLDAPService**](FileApi.md#ModifyLDAPService) | **Put** /100/file/symmetrix/{symmetrix_id}/ldap_service/{ldap_service_id} | Modify Ldap Service
[**ModifyNDMPServer**](FileApi.md#ModifyNDMPServer) | **Put** /100/file/symmetrix/{symmetrix_id}/ndmp_server/{ndmp_server_id} | Modify Ndmp server
[**ModifyNFSExport**](FileApi.md#ModifyNFSExport) | **Put** /100/file/symmetrix/{symmetrix_id}/nfs_export/{nfs_export_id} | Modify NFS Export
[**ModifyNFSServer**](FileApi.md#ModifyNFSServer) | **Put** /100/file/symmetrix/{symmetrix_id}/nfs_server/{nfs_server_id} | Modify NFS Server
[**ModifyNISService**](FileApi.md#ModifyNISService) | **Put** /100/file/symmetrix/{symmetrix_id}/nis_service/{nis_service_id} | Modify Nis Service
[**ModifyNasServer**](FileApi.md#ModifyNasServer) | **Put** /100/file/symmetrix/{symmetrix_id}/nas_server/{nas_server_id} | Modify Nas server
[**ModifyNetworkDeviceMtu**](FileApi.md#ModifyNetworkDeviceMtu) | **Post** /100/file/symmetrix/{symmetrix_id}/network_device/update | Network Device MTU Update
[**ModifyRemoteSystem**](FileApi.md#ModifyRemoteSystem) | **Put** /100/file/symmetrix/{symmetrix_id}/remote_system/{remote_system_id} | Modify Remote System
[**ModifyRoute**](FileApi.md#ModifyRoute) | **Put** /100/file/symmetrix/{symmetrix_id}/interface_route/{route_id} | Modify Routes
[**ModifySMBServer**](FileApi.md#ModifySMBServer) | **Put** /100/file/symmetrix/{symmetrix_id}/smb_server/{smb_server_id} | Modify SMB Server
[**ModifySMBShare**](FileApi.md#ModifySMBShare) | **Put** /100/file/symmetrix/{symmetrix_id}/smb_share/{smb_share_id} | Modify SMB Share
[**ModifySchedule**](FileApi.md#ModifySchedule) | **Put** /100/file/symmetrix/{symmetrix_id}/snap_policy/{snap_policy_id} | Modify Snap Schedule
[**ModifySnapshot**](FileApi.md#ModifySnapshot) | **Put** /100/file/symmetrix/{symmetrix_id}/snapshot/{snapshot_id} | Modify Snapshot
[**ModifySubnet**](FileApi.md#ModifySubnet) | **Post** /100/file/symmetrix/{symmetrix_id}/network_device/modify_subnet | Modify subnet 
[**ModifySubnet1**](FileApi.md#ModifySubnet1) | **Post** /100/file/symmetrix/{symmetrix_id}/network_device/display_all_modify_subnet | display Network Device 
[**ModifyTreeQuota**](FileApi.md#ModifyTreeQuota) | **Put** /100/file/symmetrix/{symmetrix_id}/file_system/{file_system_id}/tree_quota/{tree_quota_id} | Modify Tree Quota
[**ModifyUserQuota**](FileApi.md#ModifyUserQuota) | **Put** /100/file/symmetrix/{symmetrix_id}/file_system/{file_system_id}/user_quota/{user_quota_id} | Modify User Quota
[**ModifyVirusChecker**](FileApi.md#ModifyVirusChecker) | **Put** /100/file/symmetrix/{symmetrix_id}/virus_checker/{virus_checker_id} | Modify Virus checker
[**PingNasServer**](FileApi.md#PingNasServer) | **Post** /100/file/symmetrix/{symmetrix_id}/nas_server/{nas_server_id}/ping | Create NASServer Ping request 
[**RefreshQuotas**](FileApi.md#RefreshQuotas) | **Post** /100/file/symmetrix/{symmetrix_id}/file_system/{file_system_id}/refresh_quotas | refresh quotas FileSystem  
[**RefreshTreeQuota**](FileApi.md#RefreshTreeQuota) | **Post** /100/file/symmetrix/{symmetrix_id}/file_system/{file_system_id}/tree_quota/{tree_quota_id}/refresh | Refresh Tree Quota
[**RefreshUserQuota**](FileApi.md#RefreshUserQuota) | **Post** /100/file/symmetrix/{symmetrix_id}/file_system/{file_system_id}/user_quota/{user_quota_id}/refresh | Modify User Quota
[**RestoreAccessGlobalNamespace**](FileApi.md#RestoreAccessGlobalNamespace) | **Post** /100/file/symmetrix/{symmetrix_id}/global_namespace/{unified_namespace_id}/restore_access | restore access GlobalNameSpace
[**ReverseReplicationSession**](FileApi.md#ReverseReplicationSession) | **Post** /100/file/symmetrix/{symmetrix_id}/replication_session/{replication_session_id}/reverse | Reverse Replication session 
[**SetBackupNode**](FileApi.md#SetBackupNode) | **Post** /100/file/symmetrix/{symmetrix_id}/nas_server/{nas_server_id}/set_backup_node | Set Backup node 
[**SetPrimaryNode**](FileApi.md#SetPrimaryNode) | **Post** /100/file/symmetrix/{symmetrix_id}/nas_server/{nas_server_id}/set_primary_node | Set Primary node 
[**SetQuotaConfig**](FileApi.md#SetQuotaConfig) | **Post** /100/file/symmetrix/{symmetrix_id}/file_system/{file_system_id}/fs_quota_setting | Quota setting FileSystem  
[**SnapShotClone**](FileApi.md#SnapShotClone) | **Post** /100/file/symmetrix/{symmetrix_id}/snapshot/{snapshot_id}/clone | Create Snapshot 
[**SnapshotRefresh**](FileApi.md#SnapshotRefresh) | **Post** /100/file/symmetrix/{symmetrix_id}/snapshot/{snapshot_id}/refresh | Delete Snapshot
[**SnapshotRestore**](FileApi.md#SnapshotRestore) | **Post** /100/file/symmetrix/{symmetrix_id}/snapshot/{snapshot_id}/restore | Create Snapshot 
[**StartReplicationSession**](FileApi.md#StartReplicationSession) | **Post** /100/file/symmetrix/{symmetrix_id}/replication_session/{replication_session_id}/start | Start Replication session 
[**StopReplicationSession**](FileApi.md#StopReplicationSession) | **Post** /100/file/symmetrix/{symmetrix_id}/replication_session/{replication_session_id}/stop | Stop Replication session 
[**SwapNodesNasServer**](FileApi.md#SwapNodesNasServer) | **Post** /100/file/symmetrix/{symmetrix_id}/nas_server/{nas_server_id}/swap_nodes | Set swap node 
[**SwitchOverReplicationSession**](FileApi.md#SwitchOverReplicationSession) | **Post** /100/file/symmetrix/{symmetrix_id}/replication_session/{replication_session_id}/switchover | Switchover Replication session 
[**TestRemoteSystem**](FileApi.md#TestRemoteSystem) | **Post** /100/file/symmetrix/{symmetrix_id}/remote_system/{remote_system_id}/test | Test Remote System
[**UnJoinSMBServer**](FileApi.md#UnJoinSMBServer) | **Post** /100/file/symmetrix/{symmetrix_id}/smb_server/{smb_server_id}/unjoin | unjoin SMB Server to active directory
[**UnjoinNFSServer**](FileApi.md#UnjoinNFSServer) | **Post** /100/file/symmetrix/{symmetrix_id}/nfs_server/{nfs_server_id}/unjoin | Create NFS Server 
[**UpdateReplicationSession**](FileApi.md#UpdateReplicationSession) | **Post** /100/file/symmetrix/{symmetrix_id}/replication_session/{replication_session_id}/update | Update Replication session 
[**UploadCertificateLDAPService**](FileApi.md#UploadCertificateLDAPService) | **Post** /100/file/symmetrix/{symmetrix_id}/ldap_service/{ldap_service_id}/upload/certificate | upload Ldap Service certification
[**UploadConfigLDAPService**](FileApi.md#UploadConfigLDAPService) | **Post** /100/file/symmetrix/{symmetrix_id}/ldap_service/{ldap_service_id}/upload/config | Modify Ldap Service
[**UploadConfigVirusChecker**](FileApi.md#UploadConfigVirusChecker) | **Post** /100/file/symmetrix/{symmetrix_id}/virus_checker/{virus_checker_id}/upload/config | upload Virtus checker config
[**UploadGroupNasServer**](FileApi.md#UploadGroupNasServer) | **Post** /100/file/symmetrix/{symmetrix_id}/nas_server/{nas_server_id}/upload/group | NASServer upload group 
[**UploadHomedirNasServer**](FileApi.md#UploadHomedirNasServer) | **Post** /100/file/symmetrix/{symmetrix_id}/nas_server/{nas_server_id}/upload/home_dir | Create NASServer upload home dir 
[**UploadKeytabKerberosService**](FileApi.md#UploadKeytabKerberosService) | **Post** /100/file/symmetrix/{symmetrix_id}/kerberos_service/{kerberos_service_id}/upload/keytab | Upload Kerberos Service
[**UploadNSSwitchNasServer**](FileApi.md#UploadNSSwitchNasServer) | **Post** /100/file/symmetrix/{symmetrix_id}/nas_server/{nas_server_id}/upload/ns_switch | Create NASServer ns_switch hosts 
[**UploadNetGroupNasServer**](FileApi.md#UploadNetGroupNasServer) | **Post** /100/file/symmetrix/{symmetrix_id}/nas_server/{nas_server_id}/upload/net_group | Create NASServer upload net group 
[**UploadNtxmapNasServer**](FileApi.md#UploadNtxmapNasServer) | **Post** /100/file/symmetrix/{symmetrix_id}/nas_server/{nas_server_id}/upload/ntx_map | Create NASServer upload ntx map 
[**UploadPasswdNasServer**](FileApi.md#UploadPasswdNasServer) | **Post** /100/file/symmetrix/{symmetrix_id}/nas_server/{nas_server_id}/upload/passwd | Create NASServer Passwd upload 
[**UploadhostsNasServer**](FileApi.md#UploadhostsNasServer) | **Post** /100/file/symmetrix/{symmetrix_id}/nas_server/{nas_server_id}/upload/hosts | Create NASServer upload hosts 
[**UserMapping**](FileApi.md#UserMapping) | **Post** /100/file/symmetrix/{symmetrix_id}/nas_server/{nas_server_id}/user_mapping | NASServer user mapping 



## ActionMountSnapshot

> ActionMountSnapshot(ctx, symmetrixId, snapshotId).Execute()

mount Snapshot 



### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    symmetrixId := "symmetrixId_example" // string | The ArrayId
    snapshotId := "snapshotId_example" // string | The snapshot_id

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.FileApi.ActionMountSnapshot(context.Background(), symmetrixId, snapshotId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `FileApi.ActionMountSnapshot``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**symmetrixId** | **string** | The ArrayId | 
**snapshotId** | **string** | The snapshot_id | 

### Other Parameters

Other parameters are passed through a pointer to a apiActionMountSnapshotRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------



### Return type

 (empty response body)

### Authorization

[apiSecurity](../README.md#apiSecurity)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## ActionUnmountSnapshot

> ActionUnmountSnapshot(ctx, symmetrixId, snapshotId).Execute()

unmount Snapshot 



### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    symmetrixId := "symmetrixId_example" // string | The ArrayId
    snapshotId := "snapshotId_example" // string | The snapshot_id

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.FileApi.ActionUnmountSnapshot(context.Background(), symmetrixId, snapshotId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `FileApi.ActionUnmountSnapshot``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**symmetrixId** | **string** | The ArrayId | 
**snapshotId** | **string** | The snapshot_id | 

### Other Parameters

Other parameters are passed through a pointer to a apiActionUnmountSnapshotRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------



### Return type

 (empty response body)

### Authorization

[apiSecurity](../README.md#apiSecurity)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## ActivateCloneGlobalNamespace

> ActivateCloneGlobalNamespace(ctx, symmetrixId, unifiedNamespaceId).UnifiedNamespaceCloneArguments(unifiedNamespaceCloneArguments).Execute()

Active Clone GlobalNameSpace



### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    symmetrixId := "symmetrixId_example" // string | The ArrayId
    unifiedNamespaceId := "unifiedNamespaceId_example" // string | The unified_namespace_id
    unifiedNamespaceCloneArguments := *openapiclient.NewUnifiedNamespaceCloneArguments("Name_example") // UnifiedNamespaceCloneArguments |  (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.FileApi.ActivateCloneGlobalNamespace(context.Background(), symmetrixId, unifiedNamespaceId).UnifiedNamespaceCloneArguments(unifiedNamespaceCloneArguments).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `FileApi.ActivateCloneGlobalNamespace``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**symmetrixId** | **string** | The ArrayId | 
**unifiedNamespaceId** | **string** | The unified_namespace_id | 

### Other Parameters

Other parameters are passed through a pointer to a apiActivateCloneGlobalNamespaceRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


 **unifiedNamespaceCloneArguments** | [**UnifiedNamespaceCloneArguments**](UnifiedNamespaceCloneArguments.md) |  | 

### Return type

 (empty response body)

### Authorization

[apiSecurity](../README.md#apiSecurity)

### HTTP request headers

- **Content-Type**: application/json, application/xml
- **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## AddGlobalNamespaceLinkTarget

> AddGlobalNamespaceLinkTarget(ctx, symmetrixId, globalNamespaceLinkId).UnifiedNamespaceLinkAddTargetArguments(unifiedNamespaceLinkAddTargetArguments).Execute()

Create GlobalNameSpaceLink 



### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    symmetrixId := "symmetrixId_example" // string | The ArrayID
    globalNamespaceLinkId := "globalNamespaceLinkId_example" // string | The global_namespace_link_id
    unifiedNamespaceLinkAddTargetArguments := *openapiclient.NewUnifiedNamespaceLinkAddTargetArguments("TargetUncPath_example") // UnifiedNamespaceLinkAddTargetArguments | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.FileApi.AddGlobalNamespaceLinkTarget(context.Background(), symmetrixId, globalNamespaceLinkId).UnifiedNamespaceLinkAddTargetArguments(unifiedNamespaceLinkAddTargetArguments).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `FileApi.AddGlobalNamespaceLinkTarget``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**symmetrixId** | **string** | The ArrayID | 
**globalNamespaceLinkId** | **string** | The global_namespace_link_id | 

### Other Parameters

Other parameters are passed through a pointer to a apiAddGlobalNamespaceLinkTargetRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


 **unifiedNamespaceLinkAddTargetArguments** | [**UnifiedNamespaceLinkAddTargetArguments**](UnifiedNamespaceLinkAddTargetArguments.md) |  | 

### Return type

 (empty response body)

### Authorization

[apiSecurity](../README.md#apiSecurity)

### HTTP request headers

- **Content-Type**: application/json, application/xml
- **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## AssignSubnet

> NetworkDevice AssignSubnet(ctx, symmetrixId).NetworkAssignSubnetArguments(networkAssignSubnetArguments).Execute()

Assign subnet Network Device 



### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    symmetrixId := "symmetrixId_example" // string | The ArrayId
    networkAssignSubnetArguments := *openapiclient.NewNetworkAssignSubnetArguments() // NetworkAssignSubnetArguments | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.FileApi.AssignSubnet(context.Background(), symmetrixId).NetworkAssignSubnetArguments(networkAssignSubnetArguments).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `FileApi.AssignSubnet``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `AssignSubnet`: NetworkDevice
    fmt.Fprintf(os.Stdout, "Response from `FileApi.AssignSubnet`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**symmetrixId** | **string** | The ArrayId | 

### Other Parameters

Other parameters are passed through a pointer to a apiAssignSubnetRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **networkAssignSubnetArguments** | [**NetworkAssignSubnetArguments**](NetworkAssignSubnetArguments.md) |  | 

### Return type

[**NetworkDevice**](NetworkDevice.md)

### Authorization

[apiSecurity](../README.md#apiSecurity)

### HTTP request headers

- **Content-Type**: application/json, application/xml
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## AttachSchedule

> AttachSchedule(ctx, symmetrixId, snapPolicyId).ScheduleAttachArguments(scheduleAttachArguments).Execute()

attach Snap Schedule  Snap Schedule 



### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    symmetrixId := "symmetrixId_example" // string | The ArrayID
    snapPolicyId := "snapPolicyId_example" // string | The snap policy id
    scheduleAttachArguments := *openapiclient.NewScheduleAttachArguments() // ScheduleAttachArguments | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.FileApi.AttachSchedule(context.Background(), symmetrixId, snapPolicyId).ScheduleAttachArguments(scheduleAttachArguments).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `FileApi.AttachSchedule``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**symmetrixId** | **string** | The ArrayID | 
**snapPolicyId** | **string** | The snap policy id | 

### Other Parameters

Other parameters are passed through a pointer to a apiAttachScheduleRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


 **scheduleAttachArguments** | [**ScheduleAttachArguments**](ScheduleAttachArguments.md) |  | 

### Return type

 (empty response body)

### Authorization

[apiSecurity](../README.md#apiSecurity)

### HTTP request headers

- **Content-Type**: application/json, application/xml
- **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## CloneNasServer

> NasServer CloneNasServer(ctx, symmetrixId, nasServerId).NasServerCloneArguments(nasServerCloneArguments).Execute()

Create NASServer Clone 



### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    symmetrixId := "symmetrixId_example" // string | 
    nasServerId := "nasServerId_example" // string | 
    nasServerCloneArguments := *openapiclient.NewNasServerCloneArguments("Name_example") // NasServerCloneArguments | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.FileApi.CloneNasServer(context.Background(), symmetrixId, nasServerId).NasServerCloneArguments(nasServerCloneArguments).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `FileApi.CloneNasServer``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `CloneNasServer`: NasServer
    fmt.Fprintf(os.Stdout, "Response from `FileApi.CloneNasServer`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**symmetrixId** | **string** |  | 
**nasServerId** | **string** |  | 

### Other Parameters

Other parameters are passed through a pointer to a apiCloneNasServerRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


 **nasServerCloneArguments** | [**NasServerCloneArguments**](NasServerCloneArguments.md) |  | 

### Return type

[**NasServer**](NasServer.md)

### Authorization

[apiSecurity](../README.md#apiSecurity)

### HTTP request headers

- **Content-Type**: application/json, application/xml
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## CreateBondDevice

> NetworkDevice CreateBondDevice(ctx, symmetrixId).BondDeviceCreateArguments(bondDeviceCreateArguments).Execute()

Create Bond Device 



### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    symmetrixId := "symmetrixId_example" // string | The ArrayId
    bondDeviceCreateArguments := *openapiclient.NewBondDeviceCreateArguments(int32(123), []string{"FdnList_example"}) // BondDeviceCreateArguments | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.FileApi.CreateBondDevice(context.Background(), symmetrixId).BondDeviceCreateArguments(bondDeviceCreateArguments).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `FileApi.CreateBondDevice``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `CreateBondDevice`: NetworkDevice
    fmt.Fprintf(os.Stdout, "Response from `FileApi.CreateBondDevice`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**symmetrixId** | **string** | The ArrayId | 

### Other Parameters

Other parameters are passed through a pointer to a apiCreateBondDeviceRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **bondDeviceCreateArguments** | [**BondDeviceCreateArguments**](BondDeviceCreateArguments.md) |  | 

### Return type

[**NetworkDevice**](NetworkDevice.md)

### Authorization

[apiSecurity](../README.md#apiSecurity)

### HTTP request headers

- **Content-Type**: application/json, application/xml
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## CreateClone

> FileSystem CreateClone(ctx, symmetrixId, fileSystemId).FilesystemCloneArguments(filesystemCloneArguments).Execute()

Create FileSystem Clone 



### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    symmetrixId := "symmetrixId_example" // string | The Array ID
    fileSystemId := "fileSystemId_example" // string | The file_system_id
    filesystemCloneArguments := *openapiclient.NewFilesystemCloneArguments("Name_example", int64(123)) // FilesystemCloneArguments | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.FileApi.CreateClone(context.Background(), symmetrixId, fileSystemId).FilesystemCloneArguments(filesystemCloneArguments).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `FileApi.CreateClone``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `CreateClone`: FileSystem
    fmt.Fprintf(os.Stdout, "Response from `FileApi.CreateClone`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**symmetrixId** | **string** | The Array ID | 
**fileSystemId** | **string** | The file_system_id | 

### Other Parameters

Other parameters are passed through a pointer to a apiCreateCloneRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


 **filesystemCloneArguments** | [**FilesystemCloneArguments**](FilesystemCloneArguments.md) |  | 

### Return type

[**FileSystem**](FileSystem.md)

### Authorization

[apiSecurity](../README.md#apiSecurity)

### HTTP request headers

- **Content-Type**: application/json, application/xml
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## CreateDNSService

> DnsService CreateDNSService(ctx, symmetrixId).DnsCreateArguments(dnsCreateArguments).Execute()

Create DNSService  



### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    symmetrixId := "symmetrixId_example" // string | The Array ID
    dnsCreateArguments := *openapiclient.NewDnsCreateArguments("NasServer_example", "Domain_example", []string{"Addresses_example"}) // DnsCreateArguments | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.FileApi.CreateDNSService(context.Background(), symmetrixId).DnsCreateArguments(dnsCreateArguments).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `FileApi.CreateDNSService``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `CreateDNSService`: DnsService
    fmt.Fprintf(os.Stdout, "Response from `FileApi.CreateDNSService`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**symmetrixId** | **string** | The Array ID | 

### Other Parameters

Other parameters are passed through a pointer to a apiCreateDNSServiceRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **dnsCreateArguments** | [**DnsCreateArguments**](DnsCreateArguments.md) |  | 

### Return type

[**DnsService**](DnsService.md)

### Authorization

[apiSecurity](../README.md#apiSecurity)

### HTTP request headers

- **Content-Type**: application/json, application/xml
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## CreateDhsmServer

> DhsmServer CreateDhsmServer(ctx, symmetrixId).DhsmServerCreateArguments(dhsmServerCreateArguments).Execute()

Create DHSMServer 



### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    symmetrixId := "symmetrixId_example" // string | The ArrayID
    dhsmServerCreateArguments := *openapiclient.NewDhsmServerCreateArguments("NasServer_example", "Username_example", "Password_example") // DhsmServerCreateArguments | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.FileApi.CreateDhsmServer(context.Background(), symmetrixId).DhsmServerCreateArguments(dhsmServerCreateArguments).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `FileApi.CreateDhsmServer``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `CreateDhsmServer`: DhsmServer
    fmt.Fprintf(os.Stdout, "Response from `FileApi.CreateDhsmServer`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**symmetrixId** | **string** | The ArrayID | 

### Other Parameters

Other parameters are passed through a pointer to a apiCreateDhsmServerRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **dhsmServerCreateArguments** | [**DhsmServerCreateArguments**](DhsmServerCreateArguments.md) |  | 

### Return type

[**DhsmServer**](DhsmServer.md)

### Authorization

[apiSecurity](../README.md#apiSecurity)

### HTTP request headers

- **Content-Type**: application/json, application/xml
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## CreateDpNetwork

> DpNetwork CreateDpNetwork(ctx, symmetrixId).DpNetworkCreateArguments(dpNetworkCreateArguments).Execute()

Create Dp Network 



### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    symmetrixId := "symmetrixId_example" // string | The ArrayId
    dpNetworkCreateArguments := *openapiclient.NewDpNetworkCreateArguments([]openapiclient.NetworkDeviceArguments{*openapiclient.NewNetworkDeviceArguments(int32(123), "Fdn_example")}) // DpNetworkCreateArguments | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.FileApi.CreateDpNetwork(context.Background(), symmetrixId).DpNetworkCreateArguments(dpNetworkCreateArguments).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `FileApi.CreateDpNetwork``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `CreateDpNetwork`: DpNetwork
    fmt.Fprintf(os.Stdout, "Response from `FileApi.CreateDpNetwork`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**symmetrixId** | **string** | The ArrayId | 

### Other Parameters

Other parameters are passed through a pointer to a apiCreateDpNetworkRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **dpNetworkCreateArguments** | [**DpNetworkCreateArguments**](DpNetworkCreateArguments.md) |  | 

### Return type

[**DpNetwork**](DpNetwork.md)

### Authorization

[apiSecurity](../README.md#apiSecurity)

### HTTP request headers

- **Content-Type**: application/json, application/xml
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## CreateEventPools

> EventsPool CreateEventPools(ctx, symmetrixId).EventsPoolCreateArguments(eventsPoolCreateArguments).Execute()

Create Events Pool 



### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    symmetrixId := "symmetrixId_example" // string | The Array ID
    eventsPoolCreateArguments := *openapiclient.NewEventsPoolCreateArguments("Name_example", "EventsPublisher_example", []string{"EventsPublisherServers_example"}, *openapiclient.NewPreEventsList()) // EventsPoolCreateArguments | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.FileApi.CreateEventPools(context.Background(), symmetrixId).EventsPoolCreateArguments(eventsPoolCreateArguments).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `FileApi.CreateEventPools``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `CreateEventPools`: EventsPool
    fmt.Fprintf(os.Stdout, "Response from `FileApi.CreateEventPools`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**symmetrixId** | **string** | The Array ID | 

### Other Parameters

Other parameters are passed through a pointer to a apiCreateEventPoolsRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **eventsPoolCreateArguments** | [**EventsPoolCreateArguments**](EventsPoolCreateArguments.md) |  | 

### Return type

[**EventsPool**](EventsPool.md)

### Authorization

[apiSecurity](../README.md#apiSecurity)

### HTTP request headers

- **Content-Type**: application/json, application/xml
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## CreateEventPublishers

> EventsPublisher CreateEventPublishers(ctx, symmetrixId).EventsPublisherCreateArguments(eventsPublisherCreateArguments).Execute()

Create Event Publisher



### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    symmetrixId := "symmetrixId_example" // string | The Array ID
    eventsPublisherCreateArguments := *openapiclient.NewEventsPublisherCreateArguments("NasServer_example") // EventsPublisherCreateArguments | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.FileApi.CreateEventPublishers(context.Background(), symmetrixId).EventsPublisherCreateArguments(eventsPublisherCreateArguments).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `FileApi.CreateEventPublishers``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `CreateEventPublishers`: EventsPublisher
    fmt.Fprintf(os.Stdout, "Response from `FileApi.CreateEventPublishers`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**symmetrixId** | **string** | The Array ID | 

### Other Parameters

Other parameters are passed through a pointer to a apiCreateEventPublishersRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **eventsPublisherCreateArguments** | [**EventsPublisherCreateArguments**](EventsPublisherCreateArguments.md) |  | 

### Return type

[**EventsPublisher**](EventsPublisher.md)

### Authorization

[apiSecurity](../README.md#apiSecurity)

### HTTP request headers

- **Content-Type**: application/json, application/xml
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## CreateFileInterface

> FileInterface CreateFileInterface(ctx, symmetrixId).FileInterfaceCreateArguments(fileInterfaceCreateArguments).Execute()

Create file Interface 



### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    symmetrixId := "symmetrixId_example" // string | The ArrayId
    fileInterfaceCreateArguments := *openapiclient.NewFileInterfaceCreateArguments("NasServer_example", "IpAddress_example") // FileInterfaceCreateArguments | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.FileApi.CreateFileInterface(context.Background(), symmetrixId).FileInterfaceCreateArguments(fileInterfaceCreateArguments).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `FileApi.CreateFileInterface``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `CreateFileInterface`: FileInterface
    fmt.Fprintf(os.Stdout, "Response from `FileApi.CreateFileInterface`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**symmetrixId** | **string** | The ArrayId | 

### Other Parameters

Other parameters are passed through a pointer to a apiCreateFileInterfaceRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **fileInterfaceCreateArguments** | [**FileInterfaceCreateArguments**](FileInterfaceCreateArguments.md) |  | 

### Return type

[**FileInterface**](FileInterface.md)

### Authorization

[apiSecurity](../README.md#apiSecurity)

### HTTP request headers

- **Content-Type**: application/json, application/xml
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## CreateFileSystem

> FileSystem CreateFileSystem(ctx, symmetrixId).FilesystemCreateArguments(filesystemCreateArguments).Execute()

Create FileSystem 



### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    symmetrixId := "symmetrixId_example" // string | The array ID
    filesystemCreateArguments := *openapiclient.NewFilesystemCreateArguments("Name_example", "NasServer_example", int64(123)) // FilesystemCreateArguments | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.FileApi.CreateFileSystem(context.Background(), symmetrixId).FilesystemCreateArguments(filesystemCreateArguments).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `FileApi.CreateFileSystem``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `CreateFileSystem`: FileSystem
    fmt.Fprintf(os.Stdout, "Response from `FileApi.CreateFileSystem`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**symmetrixId** | **string** | The array ID | 

### Other Parameters

Other parameters are passed through a pointer to a apiCreateFileSystemRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **filesystemCreateArguments** | [**FilesystemCreateArguments**](FilesystemCreateArguments.md) |  | 

### Return type

[**FileSystem**](FileSystem.md)

### Authorization

[apiSecurity](../README.md#apiSecurity)

### HTTP request headers

- **Content-Type**: application/json, application/xml
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## CreateFtpServer

> FtpServer CreateFtpServer(ctx, symmetrixId).FtpServerCreateArguments(ftpServerCreateArguments).Execute()

Create FTP Server 



### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    symmetrixId := "symmetrixId_example" // string | The array ID
    ftpServerCreateArguments := *openapiclient.NewFtpServerCreateArguments("NasServer_example") // FtpServerCreateArguments | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.FileApi.CreateFtpServer(context.Background(), symmetrixId).FtpServerCreateArguments(ftpServerCreateArguments).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `FileApi.CreateFtpServer``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `CreateFtpServer`: FtpServer
    fmt.Fprintf(os.Stdout, "Response from `FileApi.CreateFtpServer`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**symmetrixId** | **string** | The array ID | 

### Other Parameters

Other parameters are passed through a pointer to a apiCreateFtpServerRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **ftpServerCreateArguments** | [**FtpServerCreateArguments**](FtpServerCreateArguments.md) |  | 

### Return type

[**FtpServer**](FtpServer.md)

### Authorization

[apiSecurity](../README.md#apiSecurity)

### HTTP request headers

- **Content-Type**: application/json, application/xml
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## CreateGlobalNamespace

> UnifiedNamespaceInstance CreateGlobalNamespace(ctx, symmetrixId).UnifiedNamespaceCreateArguments(unifiedNamespaceCreateArguments).Execute()

Create GlobalNameSpace 



### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    symmetrixId := "symmetrixId_example" // string | The ArrayId
    unifiedNamespaceCreateArguments := *openapiclient.NewUnifiedNamespaceCreateArguments("Type_example", "Filesystem_example", "FsPath_example", "Name_example") // UnifiedNamespaceCreateArguments | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.FileApi.CreateGlobalNamespace(context.Background(), symmetrixId).UnifiedNamespaceCreateArguments(unifiedNamespaceCreateArguments).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `FileApi.CreateGlobalNamespace``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `CreateGlobalNamespace`: UnifiedNamespaceInstance
    fmt.Fprintf(os.Stdout, "Response from `FileApi.CreateGlobalNamespace`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**symmetrixId** | **string** | The ArrayId | 

### Other Parameters

Other parameters are passed through a pointer to a apiCreateGlobalNamespaceRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **unifiedNamespaceCreateArguments** | [**UnifiedNamespaceCreateArguments**](UnifiedNamespaceCreateArguments.md) |  | 

### Return type

[**UnifiedNamespaceInstance**](UnifiedNamespaceInstance.md)

### Authorization

[apiSecurity](../README.md#apiSecurity)

### HTTP request headers

- **Content-Type**: application/json, application/xml
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## CreateGlobalNamespaceLink

> UnifiedNamespaceInstance CreateGlobalNamespaceLink(ctx, symmetrixId).UnifiedNamespaceLinkCreateArguments(unifiedNamespaceLinkCreateArguments).Execute()

Create GlobalNameSpaceLink 



### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    symmetrixId := "symmetrixId_example" // string | The ArrayID
    unifiedNamespaceLinkCreateArguments := *openapiclient.NewUnifiedNamespaceLinkCreateArguments("GlobalNamespace_example", "Path_example", "TargetUncPath_example") // UnifiedNamespaceLinkCreateArguments | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.FileApi.CreateGlobalNamespaceLink(context.Background(), symmetrixId).UnifiedNamespaceLinkCreateArguments(unifiedNamespaceLinkCreateArguments).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `FileApi.CreateGlobalNamespaceLink``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `CreateGlobalNamespaceLink`: UnifiedNamespaceInstance
    fmt.Fprintf(os.Stdout, "Response from `FileApi.CreateGlobalNamespaceLink`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**symmetrixId** | **string** | The ArrayID | 

### Other Parameters

Other parameters are passed through a pointer to a apiCreateGlobalNamespaceLinkRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **unifiedNamespaceLinkCreateArguments** | [**UnifiedNamespaceLinkCreateArguments**](UnifiedNamespaceLinkCreateArguments.md) |  | 

### Return type

[**UnifiedNamespaceInstance**](UnifiedNamespaceInstance.md)

### Authorization

[apiSecurity](../README.md#apiSecurity)

### HTTP request headers

- **Content-Type**: application/json, application/xml
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## CreateKerberosService

> Kerberos CreateKerberosService(ctx, symmetrixId).KerberosCreateArguments(kerberosCreateArguments).Execute()

Create Kerberos Service 



### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    symmetrixId := "symmetrixId_example" // string | The Array ID
    kerberosCreateArguments := *openapiclient.NewKerberosCreateArguments("NasServer_example", "Realm_example", []string{"KdcNames_example"}) // KerberosCreateArguments | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.FileApi.CreateKerberosService(context.Background(), symmetrixId).KerberosCreateArguments(kerberosCreateArguments).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `FileApi.CreateKerberosService``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `CreateKerberosService`: Kerberos
    fmt.Fprintf(os.Stdout, "Response from `FileApi.CreateKerberosService`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**symmetrixId** | **string** | The Array ID | 

### Other Parameters

Other parameters are passed through a pointer to a apiCreateKerberosServiceRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **kerberosCreateArguments** | [**KerberosCreateArguments**](KerberosCreateArguments.md) |  | 

### Return type

[**Kerberos**](Kerberos.md)

### Authorization

[apiSecurity](../README.md#apiSecurity)

### HTTP request headers

- **Content-Type**: application/json, application/xml
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## CreateLDAPService

> LdapService CreateLDAPService(ctx, symmetrixId).LdapCreateArguments(ldapCreateArguments).Execute()

Create Ldap Service 



### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    symmetrixId := "symmetrixId_example" // string | The Array ID
    ldapCreateArguments := *openapiclient.NewLdapCreateArguments("NasServer_example", "AuthenticationType_example", "BaseDn_example") // LdapCreateArguments | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.FileApi.CreateLDAPService(context.Background(), symmetrixId).LdapCreateArguments(ldapCreateArguments).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `FileApi.CreateLDAPService``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `CreateLDAPService`: LdapService
    fmt.Fprintf(os.Stdout, "Response from `FileApi.CreateLDAPService`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**symmetrixId** | **string** | The Array ID | 

### Other Parameters

Other parameters are passed through a pointer to a apiCreateLDAPServiceRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **ldapCreateArguments** | [**LdapCreateArguments**](LdapCreateArguments.md) |  | 

### Return type

[**LdapService**](LdapService.md)

### Authorization

[apiSecurity](../README.md#apiSecurity)

### HTTP request headers

- **Content-Type**: application/json, application/xml
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## CreateNASServer

> NasServer CreateNASServer(ctx, symmetrixId).NasServerCreateParams(nasServerCreateParams).Execute()

Create NASServer



### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    symmetrixId := "symmetrixId_example" // string | The array ID
    nasServerCreateParams := *openapiclient.NewNasServerCreateParams("Name_example", "PrimaryNode_example", "StorageResourcePool_example") // NasServerCreateParams | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.FileApi.CreateNASServer(context.Background(), symmetrixId).NasServerCreateParams(nasServerCreateParams).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `FileApi.CreateNASServer``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `CreateNASServer`: NasServer
    fmt.Fprintf(os.Stdout, "Response from `FileApi.CreateNASServer`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**symmetrixId** | **string** | The array ID | 

### Other Parameters

Other parameters are passed through a pointer to a apiCreateNASServerRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **nasServerCreateParams** | [**NasServerCreateParams**](NasServerCreateParams.md) |  | 

### Return type

[**NasServer**](NasServer.md)

### Authorization

[apiSecurity](../README.md#apiSecurity)

### HTTP request headers

- **Content-Type**: application/json, application/xml
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## CreateNDMPServer

> NdmpServer CreateNDMPServer(ctx, symmetrixId).NdmpServerCreateArguments(ndmpServerCreateArguments).Execute()

Create Ndmp server 



### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    symmetrixId := "symmetrixId_example" // string | The ArrayId
    ndmpServerCreateArguments := *openapiclient.NewNdmpServerCreateArguments() // NdmpServerCreateArguments | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.FileApi.CreateNDMPServer(context.Background(), symmetrixId).NdmpServerCreateArguments(ndmpServerCreateArguments).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `FileApi.CreateNDMPServer``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `CreateNDMPServer`: NdmpServer
    fmt.Fprintf(os.Stdout, "Response from `FileApi.CreateNDMPServer`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**symmetrixId** | **string** | The ArrayId | 

### Other Parameters

Other parameters are passed through a pointer to a apiCreateNDMPServerRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **ndmpServerCreateArguments** | [**NdmpServerCreateArguments**](NdmpServerCreateArguments.md) |  | 

### Return type

[**NdmpServer**](NdmpServer.md)

### Authorization

[apiSecurity](../README.md#apiSecurity)

### HTTP request headers

- **Content-Type**: application/json, application/xml
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## CreateNFSExports

> Export CreateNFSExports(ctx, symmetrixId).ExportCreateArguments(exportCreateArguments).Execute()

Create NFS Export 



### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    symmetrixId := "symmetrixId_example" // string | The ArrayId
    exportCreateArguments := *openapiclient.NewExportCreateArguments("StorageResource_example", "Path_example", "Name_example") // ExportCreateArguments | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.FileApi.CreateNFSExports(context.Background(), symmetrixId).ExportCreateArguments(exportCreateArguments).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `FileApi.CreateNFSExports``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `CreateNFSExports`: Export
    fmt.Fprintf(os.Stdout, "Response from `FileApi.CreateNFSExports`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**symmetrixId** | **string** | The ArrayId | 

### Other Parameters

Other parameters are passed through a pointer to a apiCreateNFSExportsRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **exportCreateArguments** | [**ExportCreateArguments**](ExportCreateArguments.md) |  | 

### Return type

[**Export**](Export.md)

### Authorization

[apiSecurity](../README.md#apiSecurity)

### HTTP request headers

- **Content-Type**: application/json, application/xml
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## CreateNFSServer

> NfsServer CreateNFSServer(ctx, symmetrixId).NfsServerCreateArguments(nfsServerCreateArguments).Execute()

Create NFS Server 



### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    symmetrixId := "symmetrixId_example" // string | The ArrayId
    nfsServerCreateArguments := *openapiclient.NewNfsServerCreateArguments("NasServer_example") // NfsServerCreateArguments | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.FileApi.CreateNFSServer(context.Background(), symmetrixId).NfsServerCreateArguments(nfsServerCreateArguments).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `FileApi.CreateNFSServer``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `CreateNFSServer`: NfsServer
    fmt.Fprintf(os.Stdout, "Response from `FileApi.CreateNFSServer`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**symmetrixId** | **string** | The ArrayId | 

### Other Parameters

Other parameters are passed through a pointer to a apiCreateNFSServerRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **nfsServerCreateArguments** | [**NfsServerCreateArguments**](NfsServerCreateArguments.md) |  | 

### Return type

[**NfsServer**](NfsServer.md)

### Authorization

[apiSecurity](../README.md#apiSecurity)

### HTTP request headers

- **Content-Type**: application/json, application/xml
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## CreateNISService

> NisService CreateNISService(ctx, symmetrixId).NisCreateArguments(nisCreateArguments).Execute()

Create Nis Service 



### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    symmetrixId := "symmetrixId_example" // string | The array ID
    nisCreateArguments := *openapiclient.NewNisCreateArguments("NasServer_example", "Domain_example", []string{"Addresses_example"}) // NisCreateArguments | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.FileApi.CreateNISService(context.Background(), symmetrixId).NisCreateArguments(nisCreateArguments).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `FileApi.CreateNISService``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `CreateNISService`: NisService
    fmt.Fprintf(os.Stdout, "Response from `FileApi.CreateNISService`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**symmetrixId** | **string** | The array ID | 

### Other Parameters

Other parameters are passed through a pointer to a apiCreateNISServiceRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **nisCreateArguments** | [**NisCreateArguments**](NisCreateArguments.md) |  | 

### Return type

[**NisService**](NisService.md)

### Authorization

[apiSecurity](../README.md#apiSecurity)

### HTTP request headers

- **Content-Type**: application/json, application/xml
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## CreateRemoteSystem

> RemoteSystem CreateRemoteSystem(ctx, symmetrixId).RemoteSystemCreateArguments(remoteSystemCreateArguments).Execute()

Create Remote System 



### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    symmetrixId := "symmetrixId_example" // string | The ArrayId
    remoteSystemCreateArguments := *openapiclient.NewRemoteSystemCreateArguments("RemoteClusterIpForRep_example", "Name_example") // RemoteSystemCreateArguments | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.FileApi.CreateRemoteSystem(context.Background(), symmetrixId).RemoteSystemCreateArguments(remoteSystemCreateArguments).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `FileApi.CreateRemoteSystem``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `CreateRemoteSystem`: RemoteSystem
    fmt.Fprintf(os.Stdout, "Response from `FileApi.CreateRemoteSystem`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**symmetrixId** | **string** | The ArrayId | 

### Other Parameters

Other parameters are passed through a pointer to a apiCreateRemoteSystemRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **remoteSystemCreateArguments** | [**RemoteSystemCreateArguments**](RemoteSystemCreateArguments.md) |  | 

### Return type

[**RemoteSystem**](RemoteSystem.md)

### Authorization

[apiSecurity](../README.md#apiSecurity)

### HTTP request headers

- **Content-Type**: application/json, application/xml
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## CreateReplicationSession

> ReplicationSession CreateReplicationSession(ctx, symmetrixId).ReplicationSessionCreateArguments(replicationSessionCreateArguments).Execute()

Create Replication Session



### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    symmetrixId := "symmetrixId_example" // string | The ArrayId
    replicationSessionCreateArguments := *openapiclient.NewReplicationSessionCreateArguments("Name_example", "RemoteSystemId_example", "SrcNasServerId_example", *openapiclient.NewReplicationPlatformAttribute("LocalDirector_example", "LocalPort_example", "RemoteSymmId_example", "RemoteDirector_example", "RemotePort_example", "ReplicationMode_example", "RemoteSrp_example", "CommunicationProtocol_example")) // ReplicationSessionCreateArguments | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.FileApi.CreateReplicationSession(context.Background(), symmetrixId).ReplicationSessionCreateArguments(replicationSessionCreateArguments).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `FileApi.CreateReplicationSession``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `CreateReplicationSession`: ReplicationSession
    fmt.Fprintf(os.Stdout, "Response from `FileApi.CreateReplicationSession`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**symmetrixId** | **string** | The ArrayId | 

### Other Parameters

Other parameters are passed through a pointer to a apiCreateReplicationSessionRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **replicationSessionCreateArguments** | [**ReplicationSessionCreateArguments**](ReplicationSessionCreateArguments.md) |  | 

### Return type

[**ReplicationSession**](ReplicationSession.md)

### Authorization

[apiSecurity](../README.md#apiSecurity)

### HTTP request headers

- **Content-Type**: application/json, application/xml
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## CreateRoute

> Route CreateRoute(ctx, symmetrixId).RouteCreateArguments(routeCreateArguments).Execute()

Create Routes 



### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    symmetrixId := "symmetrixId_example" // string | The ArrayId
    routeCreateArguments := *openapiclient.NewRouteCreateArguments("FileInterface_example", "Destination_example") // RouteCreateArguments | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.FileApi.CreateRoute(context.Background(), symmetrixId).RouteCreateArguments(routeCreateArguments).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `FileApi.CreateRoute``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `CreateRoute`: Route
    fmt.Fprintf(os.Stdout, "Response from `FileApi.CreateRoute`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**symmetrixId** | **string** | The ArrayId | 

### Other Parameters

Other parameters are passed through a pointer to a apiCreateRouteRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **routeCreateArguments** | [**RouteCreateArguments**](RouteCreateArguments.md) |  | 

### Return type

[**Route**](Route.md)

### Authorization

[apiSecurity](../README.md#apiSecurity)

### HTTP request headers

- **Content-Type**: application/json, application/xml
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## CreateSMBServer

> SmbServerInstance CreateSMBServer(ctx, symmetrixId).SmbServerCreateArguments(smbServerCreateArguments).Execute()

Create SMB Server 



### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    symmetrixId := "symmetrixId_example" // string | The ArrayId
    smbServerCreateArguments := *openapiclient.NewSmbServerCreateArguments("NasServer_example", false) // SmbServerCreateArguments | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.FileApi.CreateSMBServer(context.Background(), symmetrixId).SmbServerCreateArguments(smbServerCreateArguments).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `FileApi.CreateSMBServer``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `CreateSMBServer`: SmbServerInstance
    fmt.Fprintf(os.Stdout, "Response from `FileApi.CreateSMBServer`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**symmetrixId** | **string** | The ArrayId | 

### Other Parameters

Other parameters are passed through a pointer to a apiCreateSMBServerRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **smbServerCreateArguments** | [**SmbServerCreateArguments**](SmbServerCreateArguments.md) |  | 

### Return type

[**SmbServerInstance**](SmbServerInstance.md)

### Authorization

[apiSecurity](../README.md#apiSecurity)

### HTTP request headers

- **Content-Type**: application/json, application/xml
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## CreateSMBShares

> SmbShare CreateSMBShares(ctx, symmetrixId).SmbShareCreateArguments(smbShareCreateArguments).Execute()

Create SMB Share 



### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    symmetrixId := "symmetrixId_example" // string | The ArrayId
    smbShareCreateArguments := *openapiclient.NewSmbShareCreateArguments("StorageResource_example") // SmbShareCreateArguments | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.FileApi.CreateSMBShares(context.Background(), symmetrixId).SmbShareCreateArguments(smbShareCreateArguments).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `FileApi.CreateSMBShares``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `CreateSMBShares`: SmbShare
    fmt.Fprintf(os.Stdout, "Response from `FileApi.CreateSMBShares`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**symmetrixId** | **string** | The ArrayId | 

### Other Parameters

Other parameters are passed through a pointer to a apiCreateSMBSharesRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **smbShareCreateArguments** | [**SmbShareCreateArguments**](SmbShareCreateArguments.md) |  | 

### Return type

[**SmbShare**](SmbShare.md)

### Authorization

[apiSecurity](../README.md#apiSecurity)

### HTTP request headers

- **Content-Type**: application/json, application/xml
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## CreateSchedules

> Schedule CreateSchedules(ctx, symmetrixId).ScheduleCreateArguments(scheduleCreateArguments).Execute()

Create Snap Schedule 



### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    symmetrixId := "symmetrixId_example" // string | The ArrayID
    scheduleCreateArguments := *openapiclient.NewScheduleCreateArguments("Name_example", "NasServer_example", int32(123)) // ScheduleCreateArguments | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.FileApi.CreateSchedules(context.Background(), symmetrixId).ScheduleCreateArguments(scheduleCreateArguments).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `FileApi.CreateSchedules``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `CreateSchedules`: Schedule
    fmt.Fprintf(os.Stdout, "Response from `FileApi.CreateSchedules`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**symmetrixId** | **string** | The ArrayID | 

### Other Parameters

Other parameters are passed through a pointer to a apiCreateSchedulesRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **scheduleCreateArguments** | [**ScheduleCreateArguments**](ScheduleCreateArguments.md) |  | 

### Return type

[**Schedule**](Schedule.md)

### Authorization

[apiSecurity](../README.md#apiSecurity)

### HTTP request headers

- **Content-Type**: application/json, application/xml
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## CreateSnapshot

> Snapshot CreateSnapshot(ctx, symmetrixId).SnapCreateArguments(snapCreateArguments).Execute()

Create Snapshot 



### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    symmetrixId := "symmetrixId_example" // string | The ArrayId
    snapCreateArguments := *openapiclient.NewSnapCreateArguments() // SnapCreateArguments | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.FileApi.CreateSnapshot(context.Background(), symmetrixId).SnapCreateArguments(snapCreateArguments).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `FileApi.CreateSnapshot``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `CreateSnapshot`: Snapshot
    fmt.Fprintf(os.Stdout, "Response from `FileApi.CreateSnapshot`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**symmetrixId** | **string** | The ArrayId | 

### Other Parameters

Other parameters are passed through a pointer to a apiCreateSnapshotRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **snapCreateArguments** | [**SnapCreateArguments**](SnapCreateArguments.md) |  | 

### Return type

[**Snapshot**](Snapshot.md)

### Authorization

[apiSecurity](../README.md#apiSecurity)

### HTTP request headers

- **Content-Type**: application/json, application/xml
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## CreateTreeQuota

> TreeQuota CreateTreeQuota(ctx, symmetrixId, fileSystemId).TreeQuotaCreateArguments(treeQuotaCreateArguments).Execute()

Create Tree Quota 



### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    symmetrixId := "symmetrixId_example" // string | The ArrayId
    fileSystemId := "fileSystemId_example" // string | The file_system_id
    treeQuotaCreateArguments := *openapiclient.NewTreeQuotaCreateArguments() // TreeQuotaCreateArguments | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.FileApi.CreateTreeQuota(context.Background(), symmetrixId, fileSystemId).TreeQuotaCreateArguments(treeQuotaCreateArguments).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `FileApi.CreateTreeQuota``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `CreateTreeQuota`: TreeQuota
    fmt.Fprintf(os.Stdout, "Response from `FileApi.CreateTreeQuota`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**symmetrixId** | **string** | The ArrayId | 
**fileSystemId** | **string** | The file_system_id | 

### Other Parameters

Other parameters are passed through a pointer to a apiCreateTreeQuotaRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


 **treeQuotaCreateArguments** | [**TreeQuotaCreateArguments**](TreeQuotaCreateArguments.md) |  | 

### Return type

[**TreeQuota**](TreeQuota.md)

### Authorization

[apiSecurity](../README.md#apiSecurity)

### HTTP request headers

- **Content-Type**: application/json, application/xml
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## CreateUserQuota

> UserQuota CreateUserQuota(ctx, symmetrixId, fileSystemId).UserQuotaCreateArguments(userQuotaCreateArguments).Execute()

Create User Quota 



### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    symmetrixId := "symmetrixId_example" // string | The ArrayId
    fileSystemId := "fileSystemId_example" // string | The file_system_id
    userQuotaCreateArguments := *openapiclient.NewUserQuotaCreateArguments() // UserQuotaCreateArguments | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.FileApi.CreateUserQuota(context.Background(), symmetrixId, fileSystemId).UserQuotaCreateArguments(userQuotaCreateArguments).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `FileApi.CreateUserQuota``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `CreateUserQuota`: UserQuota
    fmt.Fprintf(os.Stdout, "Response from `FileApi.CreateUserQuota`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**symmetrixId** | **string** | The ArrayId | 
**fileSystemId** | **string** | The file_system_id | 

### Other Parameters

Other parameters are passed through a pointer to a apiCreateUserQuotaRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


 **userQuotaCreateArguments** | [**UserQuotaCreateArguments**](UserQuotaCreateArguments.md) |  | 

### Return type

[**UserQuota**](UserQuota.md)

### Authorization

[apiSecurity](../README.md#apiSecurity)

### HTTP request headers

- **Content-Type**: application/json, application/xml
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## CreateVirusChecker

> VirusChecker CreateVirusChecker(ctx, symmetrixId).VirusCheckerCreateArguments(virusCheckerCreateArguments).Execute()

Create Virus checker 



### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    symmetrixId := "symmetrixId_example" // string | The ArrayId
    virusCheckerCreateArguments := *openapiclient.NewVirusCheckerCreateArguments("NasServer_example") // VirusCheckerCreateArguments | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.FileApi.CreateVirusChecker(context.Background(), symmetrixId).VirusCheckerCreateArguments(virusCheckerCreateArguments).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `FileApi.CreateVirusChecker``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `CreateVirusChecker`: VirusChecker
    fmt.Fprintf(os.Stdout, "Response from `FileApi.CreateVirusChecker`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**symmetrixId** | **string** | The ArrayId | 

### Other Parameters

Other parameters are passed through a pointer to a apiCreateVirusCheckerRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **virusCheckerCreateArguments** | [**VirusCheckerCreateArguments**](VirusCheckerCreateArguments.md) |  | 

### Return type

[**VirusChecker**](VirusChecker.md)

### Authorization

[apiSecurity](../README.md#apiSecurity)

### HTTP request headers

- **Content-Type**: application/json, application/xml
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## DeleteBondDevice

> DeleteBondDevice(ctx, symmetrixId, bondDeviceId).Execute()

Delete Bond Device



### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    symmetrixId := "symmetrixId_example" // string | The ArrayId
    bondDeviceId := "bondDeviceId_example" // string | The bond_device_id

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.FileApi.DeleteBondDevice(context.Background(), symmetrixId, bondDeviceId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `FileApi.DeleteBondDevice``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**symmetrixId** | **string** | The ArrayId | 
**bondDeviceId** | **string** | The bond_device_id | 

### Other Parameters

Other parameters are passed through a pointer to a apiDeleteBondDeviceRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------



### Return type

 (empty response body)

### Authorization

[apiSecurity](../README.md#apiSecurity)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## DeleteDNSService

> DeleteDNSService(ctx, symmetrixId, dnsServiceId).Execute()

Delete DNS Service



### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    symmetrixId := "symmetrixId_example" // string | The Array ID
    dnsServiceId := "dnsServiceId_example" // string | The DNS Service ID

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.FileApi.DeleteDNSService(context.Background(), symmetrixId, dnsServiceId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `FileApi.DeleteDNSService``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**symmetrixId** | **string** | The Array ID | 
**dnsServiceId** | **string** | The DNS Service ID | 

### Other Parameters

Other parameters are passed through a pointer to a apiDeleteDNSServiceRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------



### Return type

 (empty response body)

### Authorization

[apiSecurity](../README.md#apiSecurity)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## DeleteDhsmServer

> DeleteDhsmServer(ctx, symmetrixId, dhsmServerId).Execute()

Delete DHSMServer



### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    symmetrixId := "symmetrixId_example" // string | The ArrayID
    dhsmServerId := "dhsmServerId_example" // string | The Unique identifier of DHSM Server

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.FileApi.DeleteDhsmServer(context.Background(), symmetrixId, dhsmServerId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `FileApi.DeleteDhsmServer``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**symmetrixId** | **string** | The ArrayID | 
**dhsmServerId** | **string** | The Unique identifier of DHSM Server | 

### Other Parameters

Other parameters are passed through a pointer to a apiDeleteDhsmServerRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------



### Return type

 (empty response body)

### Authorization

[apiSecurity](../README.md#apiSecurity)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## DeleteDpNetwork

> DeleteDpNetwork(ctx, symmetrixId, dpNetworkId).Execute()

Delete Dp Network



### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    symmetrixId := "symmetrixId_example" // string | The ArrayId
    dpNetworkId := "dpNetworkId_example" // string | The dp_network_id

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.FileApi.DeleteDpNetwork(context.Background(), symmetrixId, dpNetworkId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `FileApi.DeleteDpNetwork``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**symmetrixId** | **string** | The ArrayId | 
**dpNetworkId** | **string** | The dp_network_id | 

### Other Parameters

Other parameters are passed through a pointer to a apiDeleteDpNetworkRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------



### Return type

 (empty response body)

### Authorization

[apiSecurity](../README.md#apiSecurity)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## DeleteEventPool

> DeleteEventPool(ctx, symmetrixId, eventPoolId).Execute()

Delete Events Pool



### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    symmetrixId := "symmetrixId_example" // string | The Array ID
    eventPoolId := "eventPoolId_example" // string | The events pool id

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.FileApi.DeleteEventPool(context.Background(), symmetrixId, eventPoolId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `FileApi.DeleteEventPool``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**symmetrixId** | **string** | The Array ID | 
**eventPoolId** | **string** | The events pool id | 

### Other Parameters

Other parameters are passed through a pointer to a apiDeleteEventPoolRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------



### Return type

 (empty response body)

### Authorization

[apiSecurity](../README.md#apiSecurity)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## DeleteEventPublisher

> DeleteEventPublisher(ctx, symmetrixId, eventPublisherId).Execute()

Delete event publisher



### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    symmetrixId := "symmetrixId_example" // string | 
    eventPublisherId := "eventPublisherId_example" // string | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.FileApi.DeleteEventPublisher(context.Background(), symmetrixId, eventPublisherId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `FileApi.DeleteEventPublisher``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**symmetrixId** | **string** |  | 
**eventPublisherId** | **string** |  | 

### Other Parameters

Other parameters are passed through a pointer to a apiDeleteEventPublisherRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------



### Return type

 (empty response body)

### Authorization

[apiSecurity](../README.md#apiSecurity)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## DeleteFileInterface

> DeleteFileInterface(ctx, symmetrixId, fileInterfaceId).Execute()

Delete file Interface



### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    symmetrixId := "symmetrixId_example" // string | The ArrayID
    fileInterfaceId := "fileInterfaceId_example" // string | The file_interface_id

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.FileApi.DeleteFileInterface(context.Background(), symmetrixId, fileInterfaceId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `FileApi.DeleteFileInterface``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**symmetrixId** | **string** | The ArrayID | 
**fileInterfaceId** | **string** | The file_interface_id | 

### Other Parameters

Other parameters are passed through a pointer to a apiDeleteFileInterfaceRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------



### Return type

 (empty response body)

### Authorization

[apiSecurity](../README.md#apiSecurity)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## DeleteFileSystem

> DeleteFileSystem(ctx, symmetrixId, fileSystemId).Execute()

Delete FileSystem



### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    symmetrixId := "symmetrixId_example" // string | The array ID
    fileSystemId := "fileSystemId_example" // string | The file_system_id

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.FileApi.DeleteFileSystem(context.Background(), symmetrixId, fileSystemId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `FileApi.DeleteFileSystem``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**symmetrixId** | **string** | The array ID | 
**fileSystemId** | **string** | The file_system_id | 

### Other Parameters

Other parameters are passed through a pointer to a apiDeleteFileSystemRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------



### Return type

 (empty response body)

### Authorization

[apiSecurity](../README.md#apiSecurity)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## DeleteFtpServer

> DeleteFtpServer(ctx, symmetrixId, ftpServerId).Execute()

Delete FTPServer



### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    symmetrixId := "symmetrixId_example" // string | The Array id
    ftpServerId := "ftpServerId_example" // string | The ftp server id

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.FileApi.DeleteFtpServer(context.Background(), symmetrixId, ftpServerId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `FileApi.DeleteFtpServer``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**symmetrixId** | **string** | The Array id | 
**ftpServerId** | **string** | The ftp server id | 

### Other Parameters

Other parameters are passed through a pointer to a apiDeleteFtpServerRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------



### Return type

 (empty response body)

### Authorization

[apiSecurity](../README.md#apiSecurity)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## DeleteGlobalNamespace

> DeleteGlobalNamespace(ctx, symmetrixId, unifiedNamespaceId).Execute()

Delete GlobalNameSpace



### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    symmetrixId := "symmetrixId_example" // string | The ArrayId
    unifiedNamespaceId := "unifiedNamespaceId_example" // string | The unified_namespace_id

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.FileApi.DeleteGlobalNamespace(context.Background(), symmetrixId, unifiedNamespaceId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `FileApi.DeleteGlobalNamespace``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**symmetrixId** | **string** | The ArrayId | 
**unifiedNamespaceId** | **string** | The unified_namespace_id | 

### Other Parameters

Other parameters are passed through a pointer to a apiDeleteGlobalNamespaceRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------



### Return type

 (empty response body)

### Authorization

[apiSecurity](../README.md#apiSecurity)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## DeleteGlobalNamespaceLink

> DeleteGlobalNamespaceLink(ctx, symmetrixId, globalNamespaceLinkId).Execute()

Delete GlobalNameSpaceLink



### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    symmetrixId := "symmetrixId_example" // string | The ArrayID
    globalNamespaceLinkId := "globalNamespaceLinkId_example" // string | The global_namespace_link_id

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.FileApi.DeleteGlobalNamespaceLink(context.Background(), symmetrixId, globalNamespaceLinkId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `FileApi.DeleteGlobalNamespaceLink``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**symmetrixId** | **string** | The ArrayID | 
**globalNamespaceLinkId** | **string** | The global_namespace_link_id | 

### Other Parameters

Other parameters are passed through a pointer to a apiDeleteGlobalNamespaceLinkRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------



### Return type

 (empty response body)

### Authorization

[apiSecurity](../README.md#apiSecurity)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## DeleteKerberosService

> DeleteKerberosService(ctx, symmetrixId, kerberosServiceId).Execute()

Delete Kerberos Service



### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    symmetrixId := "symmetrixId_example" // string | The Array ID
    kerberosServiceId := "kerberosServiceId_example" // string | The kerbero service id

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.FileApi.DeleteKerberosService(context.Background(), symmetrixId, kerberosServiceId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `FileApi.DeleteKerberosService``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**symmetrixId** | **string** | The Array ID | 
**kerberosServiceId** | **string** | The kerbero service id | 

### Other Parameters

Other parameters are passed through a pointer to a apiDeleteKerberosServiceRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------



### Return type

 (empty response body)

### Authorization

[apiSecurity](../README.md#apiSecurity)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## DeleteLDAPService

> DeleteLDAPService(ctx, symmetrixId, ldapServiceId).Execute()

Delete Ldap Service



### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    symmetrixId := "symmetrixId_example" // string | The Array ID
    ldapServiceId := "ldapServiceId_example" // string | The ldap service Id

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.FileApi.DeleteLDAPService(context.Background(), symmetrixId, ldapServiceId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `FileApi.DeleteLDAPService``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**symmetrixId** | **string** | The Array ID | 
**ldapServiceId** | **string** | The ldap service Id | 

### Other Parameters

Other parameters are passed through a pointer to a apiDeleteLDAPServiceRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------



### Return type

 (empty response body)

### Authorization

[apiSecurity](../README.md#apiSecurity)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## DeleteNDMPServer

> DeleteNDMPServer(ctx, symmetrixId, ndmpServerId).Execute()

Delete Ndmp server



### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    symmetrixId := "symmetrixId_example" // string | The ArrayId
    ndmpServerId := "ndmpServerId_example" // string | The ndmp_server_id

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.FileApi.DeleteNDMPServer(context.Background(), symmetrixId, ndmpServerId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `FileApi.DeleteNDMPServer``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**symmetrixId** | **string** | The ArrayId | 
**ndmpServerId** | **string** | The ndmp_server_id | 

### Other Parameters

Other parameters are passed through a pointer to a apiDeleteNDMPServerRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------



### Return type

 (empty response body)

### Authorization

[apiSecurity](../README.md#apiSecurity)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## DeleteNFSExport

> DeleteNFSExport(ctx, symmetrixId, nfsExportId).Execute()

Delete NFS Export



### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    symmetrixId := "symmetrixId_example" // string | The ArrayId
    nfsExportId := "nfsExportId_example" // string | The nfs_export_id

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.FileApi.DeleteNFSExport(context.Background(), symmetrixId, nfsExportId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `FileApi.DeleteNFSExport``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**symmetrixId** | **string** | The ArrayId | 
**nfsExportId** | **string** | The nfs_export_id | 

### Other Parameters

Other parameters are passed through a pointer to a apiDeleteNFSExportRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------



### Return type

 (empty response body)

### Authorization

[apiSecurity](../README.md#apiSecurity)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## DeleteNFSServer

> DeleteNFSServer(ctx, symmetrixId, nfsServerId).Execute()

Delete NFS Server



### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    symmetrixId := "symmetrixId_example" // string | The ArrayId
    nfsServerId := "nfsServerId_example" // string | The nfs_server_id

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.FileApi.DeleteNFSServer(context.Background(), symmetrixId, nfsServerId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `FileApi.DeleteNFSServer``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**symmetrixId** | **string** | The ArrayId | 
**nfsServerId** | **string** | The nfs_server_id | 

### Other Parameters

Other parameters are passed through a pointer to a apiDeleteNFSServerRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------



### Return type

 (empty response body)

### Authorization

[apiSecurity](../README.md#apiSecurity)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## DeleteNIService

> DeleteNIService(ctx, symmetrixId, nisServiceId).Execute()

Delete Nis Service



### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    symmetrixId := "symmetrixId_example" // string | The Array ID
    nisServiceId := "nisServiceId_example" // string | The nis_service_id

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.FileApi.DeleteNIService(context.Background(), symmetrixId, nisServiceId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `FileApi.DeleteNIService``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**symmetrixId** | **string** | The Array ID | 
**nisServiceId** | **string** | The nis_service_id | 

### Other Parameters

Other parameters are passed through a pointer to a apiDeleteNIServiceRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------



### Return type

 (empty response body)

### Authorization

[apiSecurity](../README.md#apiSecurity)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## DeleteNasServer

> DeleteNasServer(ctx, symmetrixId, nasServerId).Execute()

Delete NAS Server



### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    symmetrixId := "symmetrixId_example" // string | The array ID
    nasServerId := "nasServerId_example" // string | The NAS Server ID

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.FileApi.DeleteNasServer(context.Background(), symmetrixId, nasServerId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `FileApi.DeleteNasServer``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**symmetrixId** | **string** | The array ID | 
**nasServerId** | **string** | The NAS Server ID | 

### Other Parameters

Other parameters are passed through a pointer to a apiDeleteNasServerRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------



### Return type

 (empty response body)

### Authorization

[apiSecurity](../README.md#apiSecurity)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## DeleteRemoteSystem

> DeleteRemoteSystem(ctx, symmetrixId, remoteSystemId).Execute()

Delete Remote System



### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    symmetrixId := "symmetrixId_example" // string | The ArrayId
    remoteSystemId := "remoteSystemId_example" // string | The remote_system_id

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.FileApi.DeleteRemoteSystem(context.Background(), symmetrixId, remoteSystemId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `FileApi.DeleteRemoteSystem``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**symmetrixId** | **string** | The ArrayId | 
**remoteSystemId** | **string** | The remote_system_id | 

### Other Parameters

Other parameters are passed through a pointer to a apiDeleteRemoteSystemRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------



### Return type

 (empty response body)

### Authorization

[apiSecurity](../README.md#apiSecurity)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## DeleteReplicationSession

> DeleteReplicationSession(ctx, symmetrixId, replicationSessionId).ReplicationSessionDeleteArguments(replicationSessionDeleteArguments).Execute()

Delete Replication session



### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    symmetrixId := "symmetrixId_example" // string | The ArrayId
    replicationSessionId := "replicationSessionId_example" // string | The replication_session_id
    replicationSessionDeleteArguments := *openapiclient.NewReplicationSessionDeleteArguments() // ReplicationSessionDeleteArguments | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.FileApi.DeleteReplicationSession(context.Background(), symmetrixId, replicationSessionId).ReplicationSessionDeleteArguments(replicationSessionDeleteArguments).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `FileApi.DeleteReplicationSession``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**symmetrixId** | **string** | The ArrayId | 
**replicationSessionId** | **string** | The replication_session_id | 

### Other Parameters

Other parameters are passed through a pointer to a apiDeleteReplicationSessionRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


 **replicationSessionDeleteArguments** | [**ReplicationSessionDeleteArguments**](ReplicationSessionDeleteArguments.md) |  | 

### Return type

 (empty response body)

### Authorization

[apiSecurity](../README.md#apiSecurity)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## DeleteRoute

> DeleteRoute(ctx, symmetrixId, routeId).Execute()

Delete Routes



### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    symmetrixId := "symmetrixId_example" // string | The ArrayId
    routeId := "routeId_example" // string | The route_id

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.FileApi.DeleteRoute(context.Background(), symmetrixId, routeId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `FileApi.DeleteRoute``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**symmetrixId** | **string** | The ArrayId | 
**routeId** | **string** | The route_id | 

### Other Parameters

Other parameters are passed through a pointer to a apiDeleteRouteRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------



### Return type

 (empty response body)

### Authorization

[apiSecurity](../README.md#apiSecurity)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## DeleteSMBServer

> DeleteSMBServer(ctx, symmetrixId, smbServerId).Execute()

Delete SMB Server



### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    symmetrixId := "symmetrixId_example" // string | The ArrayId
    smbServerId := "smbServerId_example" // string | The smb_server_id

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.FileApi.DeleteSMBServer(context.Background(), symmetrixId, smbServerId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `FileApi.DeleteSMBServer``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**symmetrixId** | **string** | The ArrayId | 
**smbServerId** | **string** | The smb_server_id | 

### Other Parameters

Other parameters are passed through a pointer to a apiDeleteSMBServerRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------



### Return type

 (empty response body)

### Authorization

[apiSecurity](../README.md#apiSecurity)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## DeleteSMBShare

> DeleteSMBShare(ctx, symmetrixId, smbShareId).Execute()

Delete SMB Share



### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    symmetrixId := "symmetrixId_example" // string | The ArrayId
    smbShareId := "smbShareId_example" // string | The smb_share_id

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.FileApi.DeleteSMBShare(context.Background(), symmetrixId, smbShareId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `FileApi.DeleteSMBShare``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**symmetrixId** | **string** | The ArrayId | 
**smbShareId** | **string** | The smb_share_id | 

### Other Parameters

Other parameters are passed through a pointer to a apiDeleteSMBShareRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------



### Return type

 (empty response body)

### Authorization

[apiSecurity](../README.md#apiSecurity)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## DeleteSchedule

> DeleteSchedule(ctx, symmetrixId, snapPolicyId).Execute()

Delete Snap Schedule



### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    symmetrixId := "symmetrixId_example" // string | The ArrayID
    snapPolicyId := "snapPolicyId_example" // string | The Snap Policy Id

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.FileApi.DeleteSchedule(context.Background(), symmetrixId, snapPolicyId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `FileApi.DeleteSchedule``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**symmetrixId** | **string** | The ArrayID | 
**snapPolicyId** | **string** | The Snap Policy Id | 

### Other Parameters

Other parameters are passed through a pointer to a apiDeleteScheduleRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------



### Return type

 (empty response body)

### Authorization

[apiSecurity](../README.md#apiSecurity)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## DeleteSnapshot

> DeleteSnapshot(ctx, symmetrixId, snapshotId).Execute()

Delete Snapshot



### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    symmetrixId := "symmetrixId_example" // string | The ArrayId
    snapshotId := "snapshotId_example" // string | The snapshot_id

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.FileApi.DeleteSnapshot(context.Background(), symmetrixId, snapshotId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `FileApi.DeleteSnapshot``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**symmetrixId** | **string** | The ArrayId | 
**snapshotId** | **string** | The snapshot_id | 

### Other Parameters

Other parameters are passed through a pointer to a apiDeleteSnapshotRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------



### Return type

 (empty response body)

### Authorization

[apiSecurity](../README.md#apiSecurity)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## DeleteTree

> DeleteTree(ctx, symmetrixId, fileSystemId, treeQuotaId).Execute()

Delete Tree Quota



### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    symmetrixId := "symmetrixId_example" // string | The ArrayId
    fileSystemId := "fileSystemId_example" // string | The file_system_id
    treeQuotaId := "treeQuotaId_example" // string | The tree_quota_id

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.FileApi.DeleteTree(context.Background(), symmetrixId, fileSystemId, treeQuotaId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `FileApi.DeleteTree``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**symmetrixId** | **string** | The ArrayId | 
**fileSystemId** | **string** | The file_system_id | 
**treeQuotaId** | **string** | The tree_quota_id | 

### Other Parameters

Other parameters are passed through a pointer to a apiDeleteTreeRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------




### Return type

 (empty response body)

### Authorization

[apiSecurity](../README.md#apiSecurity)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## DeleteVirusChecker

> DeleteVirusChecker(ctx, symmetrixId, virusCheckerId).Execute()

Delete Virus checker



### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    symmetrixId := "symmetrixId_example" // string | The ArrayId
    virusCheckerId := "virusCheckerId_example" // string | The virus_checker_id

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.FileApi.DeleteVirusChecker(context.Background(), symmetrixId, virusCheckerId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `FileApi.DeleteVirusChecker``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**symmetrixId** | **string** | The ArrayId | 
**virusCheckerId** | **string** | The virus_checker_id | 

### Other Parameters

Other parameters are passed through a pointer to a apiDeleteVirusCheckerRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------



### Return type

 (empty response body)

### Authorization

[apiSecurity](../README.md#apiSecurity)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## DetachSchedule

> DetachSchedule(ctx, symmetrixId, snapPolicyId).ScheduleAttachArguments(scheduleAttachArguments).Execute()

detach Snap Schedule from file system 



### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    symmetrixId := "symmetrixId_example" // string | The ArrayID
    snapPolicyId := "snapPolicyId_example" // string | The Snap Policy ID
    scheduleAttachArguments := *openapiclient.NewScheduleAttachArguments() // ScheduleAttachArguments | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.FileApi.DetachSchedule(context.Background(), symmetrixId, snapPolicyId).ScheduleAttachArguments(scheduleAttachArguments).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `FileApi.DetachSchedule``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**symmetrixId** | **string** | The ArrayID | 
**snapPolicyId** | **string** | The Snap Policy ID | 

### Other Parameters

Other parameters are passed through a pointer to a apiDetachScheduleRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


 **scheduleAttachArguments** | [**ScheduleAttachArguments**](ScheduleAttachArguments.md) |  | 

### Return type

 (empty response body)

### Authorization

[apiSecurity](../README.md#apiSecurity)

### HTTP request headers

- **Content-Type**: application/json, application/xml
- **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## DownloadCertificateLDAPService

> DownloadCertificateLDAPService(ctx, symmetrixId, ldapServiceId).MultipartFormDataInput(multipartFormDataInput).Execute()

upload Ldap Service certification



### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    symmetrixId := "symmetrixId_example" // string | The Array ID
    ldapServiceId := "ldapServiceId_example" // string | The ldap_service_id 
    multipartFormDataInput := *openapiclient.NewMultipartFormDataInput() // MultipartFormDataInput |  (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.FileApi.DownloadCertificateLDAPService(context.Background(), symmetrixId, ldapServiceId).MultipartFormDataInput(multipartFormDataInput).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `FileApi.DownloadCertificateLDAPService``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**symmetrixId** | **string** | The Array ID | 
**ldapServiceId** | **string** | The ldap_service_id  | 

### Other Parameters

Other parameters are passed through a pointer to a apiDownloadCertificateLDAPServiceRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


 **multipartFormDataInput** | [**MultipartFormDataInput**](MultipartFormDataInput.md) |  | 

### Return type

 (empty response body)

### Authorization

[apiSecurity](../README.md#apiSecurity)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## DownloadConfigLDAPService

> DownloadConfigLDAPService(ctx, symmetrixId, ldapServiceId).Execute()

download Ldap Service config



### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    symmetrixId := "symmetrixId_example" // string | The Array ID
    ldapServiceId := "ldapServiceId_example" // string | The ldap service id

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.FileApi.DownloadConfigLDAPService(context.Background(), symmetrixId, ldapServiceId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `FileApi.DownloadConfigLDAPService``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**symmetrixId** | **string** | The Array ID | 
**ldapServiceId** | **string** | The ldap service id | 

### Other Parameters

Other parameters are passed through a pointer to a apiDownloadConfigLDAPServiceRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------



### Return type

 (empty response body)

### Authorization

[apiSecurity](../README.md#apiSecurity)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## DownloadConfigVirusChecker

> DownloadConfigVirusChecker(ctx, symmetrixId, virusCheckerId).Execute()

Download Virus Checker



### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    symmetrixId := "symmetrixId_example" // string | The ArrayId
    virusCheckerId := "virusCheckerId_example" // string | The virus_checker_id

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.FileApi.DownloadConfigVirusChecker(context.Background(), symmetrixId, virusCheckerId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `FileApi.DownloadConfigVirusChecker``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**symmetrixId** | **string** | The ArrayId | 
**virusCheckerId** | **string** | The virus_checker_id | 

### Other Parameters

Other parameters are passed through a pointer to a apiDownloadConfigVirusCheckerRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------



### Return type

 (empty response body)

### Authorization

[apiSecurity](../README.md#apiSecurity)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: text/plain

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## DownloadHostsNASServer

> DownloadHostsNASServer(ctx, symmetrixId, nasServerId).Execute()

Get NAS Server hosts file



### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    symmetrixId := "symmetrixId_example" // string | 
    nasServerId := "nasServerId_example" // string | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.FileApi.DownloadHostsNASServer(context.Background(), symmetrixId, nasServerId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `FileApi.DownloadHostsNASServer``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**symmetrixId** | **string** |  | 
**nasServerId** | **string** |  | 

### Other Parameters

Other parameters are passed through a pointer to a apiDownloadHostsNASServerRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------



### Return type

 (empty response body)

### Authorization

[apiSecurity](../README.md#apiSecurity)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## DownloadKeytabKerberosService

> DownloadKeytabKerberosService(ctx, symmetrixId, kerberosServiceId).Execute()

download Kerberos Service



### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    symmetrixId := "symmetrixId_example" // string | 
    kerberosServiceId := "kerberosServiceId_example" // string | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.FileApi.DownloadKeytabKerberosService(context.Background(), symmetrixId, kerberosServiceId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `FileApi.DownloadKeytabKerberosService``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**symmetrixId** | **string** |  | 
**kerberosServiceId** | **string** |  | 

### Other Parameters

Other parameters are passed through a pointer to a apiDownloadKeytabKerberosServiceRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------



### Return type

 (empty response body)

### Authorization

[apiSecurity](../README.md#apiSecurity)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## DownloadPasswdNASServer

> DownloadPasswdNASServer(ctx, symmetrixId, nasServerId).Execute()

Get NAS Server Password file



### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    symmetrixId := "symmetrixId_example" // string | 
    nasServerId := "nasServerId_example" // string | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.FileApi.DownloadPasswdNASServer(context.Background(), symmetrixId, nasServerId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `FileApi.DownloadPasswdNASServer``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**symmetrixId** | **string** |  | 
**nasServerId** | **string** |  | 

### Other Parameters

Other parameters are passed through a pointer to a apiDownloadPasswdNASServerRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------



### Return type

 (empty response body)

### Authorization

[apiSecurity](../README.md#apiSecurity)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## DownloadUserMapping

> DownloadUserMapping(ctx, symmetrixId, nasServerId).Execute()

Get NAS Server mapping report file



### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    symmetrixId := "symmetrixId_example" // string | 
    nasServerId := "nasServerId_example" // string | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.FileApi.DownloadUserMapping(context.Background(), symmetrixId, nasServerId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `FileApi.DownloadUserMapping``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**symmetrixId** | **string** |  | 
**nasServerId** | **string** |  | 

### Other Parameters

Other parameters are passed through a pointer to a apiDownloadUserMappingRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------



### Return type

 (empty response body)

### Authorization

[apiSecurity](../README.md#apiSecurity)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## DownlodGroupNASserver

> DownlodGroupNASserver(ctx, symmetrixId, nasServerId).Execute()

Get NAS Server hosts file



### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    symmetrixId := "symmetrixId_example" // string | 
    nasServerId := "nasServerId_example" // string | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.FileApi.DownlodGroupNASserver(context.Background(), symmetrixId, nasServerId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `FileApi.DownlodGroupNASserver``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**symmetrixId** | **string** |  | 
**nasServerId** | **string** |  | 

### Other Parameters

Other parameters are passed through a pointer to a apiDownlodGroupNASserverRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------



### Return type

 (empty response body)

### Authorization

[apiSecurity](../README.md#apiSecurity)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## DownlodHomedirNASserver

> DownlodHomedirNASserver(ctx, symmetrixId, nasServerId).Execute()

Get NAS Server home dir file



### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    symmetrixId := "symmetrixId_example" // string | 
    nasServerId := "nasServerId_example" // string | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.FileApi.DownlodHomedirNASserver(context.Background(), symmetrixId, nasServerId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `FileApi.DownlodHomedirNASserver``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**symmetrixId** | **string** |  | 
**nasServerId** | **string** |  | 

### Other Parameters

Other parameters are passed through a pointer to a apiDownlodHomedirNASserverRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------



### Return type

 (empty response body)

### Authorization

[apiSecurity](../README.md#apiSecurity)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## DownlodNSSwitchNASserver

> DownlodNSSwitchNASserver(ctx, symmetrixId, nasServerId).Execute()

Get NAS Server ns switch file



### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    symmetrixId := "symmetrixId_example" // string | 
    nasServerId := "nasServerId_example" // string | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.FileApi.DownlodNSSwitchNASserver(context.Background(), symmetrixId, nasServerId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `FileApi.DownlodNSSwitchNASserver``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**symmetrixId** | **string** |  | 
**nasServerId** | **string** |  | 

### Other Parameters

Other parameters are passed through a pointer to a apiDownlodNSSwitchNASserverRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------



### Return type

 (empty response body)

### Authorization

[apiSecurity](../README.md#apiSecurity)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## DownlodNetGroupNASserver

> DownlodNetGroupNASserver(ctx, symmetrixId, nasServerId).Execute()

Get NAS Server net group file



### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    symmetrixId := "symmetrixId_example" // string | 
    nasServerId := "nasServerId_example" // string | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.FileApi.DownlodNetGroupNASserver(context.Background(), symmetrixId, nasServerId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `FileApi.DownlodNetGroupNASserver``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**symmetrixId** | **string** |  | 
**nasServerId** | **string** |  | 

### Other Parameters

Other parameters are passed through a pointer to a apiDownlodNetGroupNASserverRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------



### Return type

 (empty response body)

### Authorization

[apiSecurity](../README.md#apiSecurity)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## DownlodNtxmapNASserver

> DownlodNtxmapNASserver(ctx, symmetrixId, nasServerId).Execute()

Get NAS Server ntx map file



### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    symmetrixId := "symmetrixId_example" // string | 
    nasServerId := "nasServerId_example" // string | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.FileApi.DownlodNtxmapNASserver(context.Background(), symmetrixId, nasServerId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `FileApi.DownlodNtxmapNASserver``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**symmetrixId** | **string** |  | 
**nasServerId** | **string** |  | 

### Other Parameters

Other parameters are passed through a pointer to a apiDownlodNtxmapNASserverRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------



### Return type

 (empty response body)

### Authorization

[apiSecurity](../README.md#apiSecurity)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## FailoverReplicationSession

> FailoverReplicationSession(ctx, symmetrixId, replicationSessionId).Execute()

Failover Replication session 



### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    symmetrixId := "symmetrixId_example" // string | The ArrayId
    replicationSessionId := "replicationSessionId_example" // string | The replication_session_id

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.FileApi.FailoverReplicationSession(context.Background(), symmetrixId, replicationSessionId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `FileApi.FailoverReplicationSession``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**symmetrixId** | **string** | The ArrayId | 
**replicationSessionId** | **string** | The replication_session_id | 

### Other Parameters

Other parameters are passed through a pointer to a apiFailoverReplicationSessionRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------



### Return type

 (empty response body)

### Authorization

[apiSecurity](../README.md#apiSecurity)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## FetchCompatibleNode

> FetchCompatibleNode(ctx, symmetrixId, nasServerId).IsPrimary(isPrimary).Execute()

compatible node NASServer 



### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    symmetrixId := "symmetrixId_example" // string | The ArrayID
    nasServerId := "nasServerId_example" // string | The nas_server_id
    isPrimary := true // bool | fetch for compatible nodes for primary node (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.FileApi.FetchCompatibleNode(context.Background(), symmetrixId, nasServerId).IsPrimary(isPrimary).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `FileApi.FetchCompatibleNode``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**symmetrixId** | **string** | The ArrayID | 
**nasServerId** | **string** | The nas_server_id | 

### Other Parameters

Other parameters are passed through a pointer to a apiFetchCompatibleNodeRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


 **isPrimary** | **bool** | fetch for compatible nodes for primary node | 

### Return type

 (empty response body)

### Authorization

[apiSecurity](../README.md#apiSecurity)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetDNSService

> DnsService GetDNSService(ctx, symmetrixId, dnsServiceId).Execute()

Get DNS Service



### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    symmetrixId := "symmetrixId_example" // string | The Array ID
    dnsServiceId := "dnsServiceId_example" // string | The DNSService ID

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.FileApi.GetDNSService(context.Background(), symmetrixId, dnsServiceId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `FileApi.GetDNSService``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetDNSService`: DnsService
    fmt.Fprintf(os.Stdout, "Response from `FileApi.GetDNSService`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**symmetrixId** | **string** | The Array ID | 
**dnsServiceId** | **string** | The DNSService ID | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetDNSServiceRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------



### Return type

[**DnsService**](DnsService.md)

### Authorization

[apiSecurity](../README.md#apiSecurity)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetDNSServices

> DnsList GetDNSServices(ctx, symmetrixId).NasServerId(nasServerId).Execute()

List DNS Service



### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    symmetrixId := "symmetrixId_example" // string | The Array ID
    nasServerId := "nasServerId_example" // string | Get DNS servers where nas_server ID equals (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.FileApi.GetDNSServices(context.Background(), symmetrixId).NasServerId(nasServerId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `FileApi.GetDNSServices``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetDNSServices`: DnsList
    fmt.Fprintf(os.Stdout, "Response from `FileApi.GetDNSServices`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**symmetrixId** | **string** | The Array ID | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetDNSServicesRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **nasServerId** | **string** | Get DNS servers where nas_server ID equals | 

### Return type

[**DnsList**](DnsList.md)

### Authorization

[apiSecurity](../README.md#apiSecurity)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetDhsmServer

> DhsmServer GetDhsmServer(ctx, symmetrixId, dhsmServerId).Execute()

Get DHSMServer Configuration



### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    symmetrixId := "symmetrixId_example" // string | The ArrayID
    dhsmServerId := "dhsmServerId_example" // string | The DhsmServer unique identifier

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.FileApi.GetDhsmServer(context.Background(), symmetrixId, dhsmServerId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `FileApi.GetDhsmServer``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetDhsmServer`: DhsmServer
    fmt.Fprintf(os.Stdout, "Response from `FileApi.GetDhsmServer`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**symmetrixId** | **string** | The ArrayID | 
**dhsmServerId** | **string** | The DhsmServer unique identifier | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetDhsmServerRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------



### Return type

[**DhsmServer**](DhsmServer.md)

### Authorization

[apiSecurity](../README.md#apiSecurity)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetDpNetwork

> DpNetwork GetDpNetwork(ctx, symmetrixId, dpNetworkId).Execute()

Get Dp Network



### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    symmetrixId := "symmetrixId_example" // string | The ArrayId
    dpNetworkId := "dpNetworkId_example" // string | The dp_network_id

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.FileApi.GetDpNetwork(context.Background(), symmetrixId, dpNetworkId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `FileApi.GetDpNetwork``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetDpNetwork`: DpNetwork
    fmt.Fprintf(os.Stdout, "Response from `FileApi.GetDpNetwork`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**symmetrixId** | **string** | The ArrayId | 
**dpNetworkId** | **string** | The dp_network_id | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetDpNetworkRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------



### Return type

[**DpNetwork**](DpNetwork.md)

### Authorization

[apiSecurity](../README.md#apiSecurity)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetDpNetworks

> DpNetworkList GetDpNetworks(ctx, symmetrixId).Execute()

List Dp Network



### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    symmetrixId := "symmetrixId_example" // string | The ArrayId

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.FileApi.GetDpNetworks(context.Background(), symmetrixId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `FileApi.GetDpNetworks``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetDpNetworks`: DpNetworkList
    fmt.Fprintf(os.Stdout, "Response from `FileApi.GetDpNetworks`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**symmetrixId** | **string** | The ArrayId | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetDpNetworksRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


### Return type

[**DpNetworkList**](DpNetworkList.md)

### Authorization

[apiSecurity](../README.md#apiSecurity)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetEventPool

> EventsPool GetEventPool(ctx, symmetrixId, eventPoolId).Execute()

Get Events Pool



### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    symmetrixId := "symmetrixId_example" // string | The Array ID
    eventPoolId := "eventPoolId_example" // string | The event_pool_id

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.FileApi.GetEventPool(context.Background(), symmetrixId, eventPoolId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `FileApi.GetEventPool``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetEventPool`: EventsPool
    fmt.Fprintf(os.Stdout, "Response from `FileApi.GetEventPool`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**symmetrixId** | **string** | The Array ID | 
**eventPoolId** | **string** | The event_pool_id | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetEventPoolRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------



### Return type

[**EventsPool**](EventsPool.md)

### Authorization

[apiSecurity](../README.md#apiSecurity)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetEventPublishers

> EventsPublisherList GetEventPublishers(ctx, symmetrixId).NasServerId(nasServerId).Enable(enable).Execute()

Event Publisher



### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    symmetrixId := "symmetrixId_example" // string | The Array ID
    nasServerId := "nasServerId_example" // string | Fetches the Event publisher where The nas server Id equals (optional)
    enable := true // bool | Fetches the Event publisher where enable equal to (true/false) (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.FileApi.GetEventPublishers(context.Background(), symmetrixId).NasServerId(nasServerId).Enable(enable).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `FileApi.GetEventPublishers``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetEventPublishers`: EventsPublisherList
    fmt.Fprintf(os.Stdout, "Response from `FileApi.GetEventPublishers`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**symmetrixId** | **string** | The Array ID | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetEventPublishersRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **nasServerId** | **string** | Fetches the Event publisher where The nas server Id equals | 
 **enable** | **bool** | Fetches the Event publisher where enable equal to (true/false) | 

### Return type

[**EventsPublisherList**](EventsPublisherList.md)

### Authorization

[apiSecurity](../README.md#apiSecurity)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetEventsPostList

> EventsPoolList GetEventsPostList(ctx, symmetrixId).NasServerId(nasServerId).EventPublisherId(eventPublisherId).Execute()

List Events Pool



### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    symmetrixId := "symmetrixId_example" // string | The Array ID
    nasServerId := "nasServerId_example" // string | Fetches the Event publisher where The nas server Id equals (optional)
    eventPublisherId := "eventPublisherId_example" // string | Fetches the Event publisher where The event publishere Id equals (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.FileApi.GetEventsPostList(context.Background(), symmetrixId).NasServerId(nasServerId).EventPublisherId(eventPublisherId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `FileApi.GetEventsPostList``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetEventsPostList`: EventsPoolList
    fmt.Fprintf(os.Stdout, "Response from `FileApi.GetEventsPostList`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**symmetrixId** | **string** | The Array ID | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetEventsPostListRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **nasServerId** | **string** | Fetches the Event publisher where The nas server Id equals | 
 **eventPublisherId** | **string** | Fetches the Event publisher where The event publishere Id equals | 

### Return type

[**EventsPoolList**](EventsPoolList.md)

### Authorization

[apiSecurity](../README.md#apiSecurity)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetEventsPublisher

> EventsPublisher GetEventsPublisher(ctx, symmetrixId, eventPublisherId).Execute()

Get event publisher



### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    symmetrixId := "symmetrixId_example" // string | The Array ID
    eventPublisherId := "eventPublisherId_example" // string | The event_publisher_id

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.FileApi.GetEventsPublisher(context.Background(), symmetrixId, eventPublisherId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `FileApi.GetEventsPublisher``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetEventsPublisher`: EventsPublisher
    fmt.Fprintf(os.Stdout, "Response from `FileApi.GetEventsPublisher`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**symmetrixId** | **string** | The Array ID | 
**eventPublisherId** | **string** | The event_publisher_id | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetEventsPublisherRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------



### Return type

[**EventsPublisher**](EventsPublisher.md)

### Authorization

[apiSecurity](../README.md#apiSecurity)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetFSReplicationSession

> FsReplicationSession GetFSReplicationSession(ctx, symmetrixId, fsReplicationSessionId).Execute()

Get FS Replication session



### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    symmetrixId := "symmetrixId_example" // string | 
    fsReplicationSessionId := "fsReplicationSessionId_example" // string | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.FileApi.GetFSReplicationSession(context.Background(), symmetrixId, fsReplicationSessionId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `FileApi.GetFSReplicationSession``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetFSReplicationSession`: FsReplicationSession
    fmt.Fprintf(os.Stdout, "Response from `FileApi.GetFSReplicationSession`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**symmetrixId** | **string** |  | 
**fsReplicationSessionId** | **string** |  | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetFSReplicationSessionRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------



### Return type

[**FsReplicationSession**](FsReplicationSession.md)

### Authorization

[apiSecurity](../README.md#apiSecurity)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetFSReplicationSessions

> FsReplicationSessionList GetFSReplicationSessions(ctx, symmetrixId).Execute()

List FS Replication session



### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    symmetrixId := "symmetrixId_example" // string | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.FileApi.GetFSReplicationSessions(context.Background(), symmetrixId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `FileApi.GetFSReplicationSessions``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetFSReplicationSessions`: FsReplicationSessionList
    fmt.Fprintf(os.Stdout, "Response from `FileApi.GetFSReplicationSessions`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**symmetrixId** | **string** |  | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetFSReplicationSessionsRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


### Return type

[**FsReplicationSessionList**](FsReplicationSessionList.md)

### Authorization

[apiSecurity](../README.md#apiSecurity)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetFileInterface

> FileInterface GetFileInterface(ctx, symmetrixId, fileInterfaceId).Execute()

Get file Interface



### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    symmetrixId := "symmetrixId_example" // string | The ArrayId
    fileInterfaceId := "fileInterfaceId_example" // string | The file_interface_id

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.FileApi.GetFileInterface(context.Background(), symmetrixId, fileInterfaceId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `FileApi.GetFileInterface``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetFileInterface`: FileInterface
    fmt.Fprintf(os.Stdout, "Response from `FileApi.GetFileInterface`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**symmetrixId** | **string** | The ArrayId | 
**fileInterfaceId** | **string** | The file_interface_id | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetFileInterfaceRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------



### Return type

[**FileInterface**](FileInterface.md)

### Authorization

[apiSecurity](../README.md#apiSecurity)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetFileInterfaceList

> FileInterfaceList GetFileInterfaceList(ctx, symmetrixId).NasServerId(nasServerId).Execute()

List file Interface



### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    symmetrixId := "symmetrixId_example" // string | The ArrayId
    nasServerId := "nasServerId_example" // string | Query for file interface for nas_server

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.FileApi.GetFileInterfaceList(context.Background(), symmetrixId).NasServerId(nasServerId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `FileApi.GetFileInterfaceList``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetFileInterfaceList`: FileInterfaceList
    fmt.Fprintf(os.Stdout, "Response from `FileApi.GetFileInterfaceList`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**symmetrixId** | **string** | The ArrayId | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetFileInterfaceListRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **nasServerId** | **string** | Query for file interface for nas_server | 

### Return type

[**FileInterfaceList**](FileInterfaceList.md)

### Authorization

[apiSecurity](../README.md#apiSecurity)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetFileSystem

> FileSystem GetFileSystem(ctx, symmetrixId, fileSystemId).Execute()

Get FileSystem



### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    symmetrixId := "symmetrixId_example" // string | The array ID
    fileSystemId := "fileSystemId_example" // string | The fileSystem

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.FileApi.GetFileSystem(context.Background(), symmetrixId, fileSystemId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `FileApi.GetFileSystem``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetFileSystem`: FileSystem
    fmt.Fprintf(os.Stdout, "Response from `FileApi.GetFileSystem`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**symmetrixId** | **string** | The array ID | 
**fileSystemId** | **string** | The fileSystem | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetFileSystemRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------



### Return type

[**FileSystem**](FileSystem.md)

### Authorization

[apiSecurity](../README.md#apiSecurity)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetFileSystems

> IIterator GetFileSystems(ctx, symmetrixId).Name(name).NasServerId(nasServerId).FsType(fsType).SizeTotal(sizeTotal).SizeUsed(sizeUsed).QuotaEnabled(quotaEnabled).SmbserverEnabled(smbserverEnabled).NfsserverEnabled(nfsserverEnabled).FlrEnabled(flrEnabled).EventNotifications(eventNotifications).StorageWwn(storageWwn).FlrMode(flrMode).Execute()

List File System



### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    symmetrixId := "symmetrixId_example" // string | The array ID
    name := "name_example" // string | File systems that contains/equal name (optional)
    nasServerId := "nasServerId_example" // string | File systems that equal nas_server_id (optional)
    fsType := "fsType_example" // string | File systems that contains/equal fsType (optional)
    sizeTotal := "sizeTotal_example" // string | File systems that equal/greater equal/less than size_total (optional)
    sizeUsed := "sizeUsed_example" // string | File systems that equal/greater equal/less than size_used (optional)
    quotaEnabled := true // bool | File systems that quota enabled (true/false) (optional)
    smbserverEnabled := true // bool | File systems that smbserver enabled (true/false) (optional)
    nfsserverEnabled := true // bool | File systems that nfs server enabled (true/false) (optional)
    flrEnabled := true // bool | File systems that flr enabled (true/false) (optional)
    eventNotifications := int32(56) // int32 | File systems that event notifications equal to 0 to 3 (optional)
    storageWwn := "storageWwn_example" // string | File systems that flr mode (Enterprise/Compliance) (optional)
    flrMode := "flrMode_example" // string | File systems that flr mode (Enterprise/Compliance) (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.FileApi.GetFileSystems(context.Background(), symmetrixId).Name(name).NasServerId(nasServerId).FsType(fsType).SizeTotal(sizeTotal).SizeUsed(sizeUsed).QuotaEnabled(quotaEnabled).SmbserverEnabled(smbserverEnabled).NfsserverEnabled(nfsserverEnabled).FlrEnabled(flrEnabled).EventNotifications(eventNotifications).StorageWwn(storageWwn).FlrMode(flrMode).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `FileApi.GetFileSystems``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetFileSystems`: IIterator
    fmt.Fprintf(os.Stdout, "Response from `FileApi.GetFileSystems`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**symmetrixId** | **string** | The array ID | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetFileSystemsRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **name** | **string** | File systems that contains/equal name | 
 **nasServerId** | **string** | File systems that equal nas_server_id | 
 **fsType** | **string** | File systems that contains/equal fsType | 
 **sizeTotal** | **string** | File systems that equal/greater equal/less than size_total | 
 **sizeUsed** | **string** | File systems that equal/greater equal/less than size_used | 
 **quotaEnabled** | **bool** | File systems that quota enabled (true/false) | 
 **smbserverEnabled** | **bool** | File systems that smbserver enabled (true/false) | 
 **nfsserverEnabled** | **bool** | File systems that nfs server enabled (true/false) | 
 **flrEnabled** | **bool** | File systems that flr enabled (true/false) | 
 **eventNotifications** | **int32** | File systems that event notifications equal to 0 to 3 | 
 **storageWwn** | **string** | File systems that flr mode (Enterprise/Compliance) | 
 **flrMode** | **string** | File systems that flr mode (Enterprise/Compliance) | 

### Return type

[**IIterator**](IIterator.md)

### Authorization

[apiSecurity](../README.md#apiSecurity)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetFtpServer

> FtpServer GetFtpServer(ctx, symmetrixId, ftpServerId).Execute()

Get FTPServer



### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    symmetrixId := "symmetrixId_example" // string | The ArrayId
    ftpServerId := "ftpServerId_example" // string | The ftp server id

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.FileApi.GetFtpServer(context.Background(), symmetrixId, ftpServerId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `FileApi.GetFtpServer``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetFtpServer`: FtpServer
    fmt.Fprintf(os.Stdout, "Response from `FileApi.GetFtpServer`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**symmetrixId** | **string** | The ArrayId | 
**ftpServerId** | **string** | The ftp server id | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetFtpServerRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------



### Return type

[**FtpServer**](FtpServer.md)

### Authorization

[apiSecurity](../README.md#apiSecurity)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetFtpServers

> FtpServerList GetFtpServers(ctx, symmetrixId).NasServerId(nasServerId).Execute()

Get List FTP Server



### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    symmetrixId := "symmetrixId_example" // string | The array ID
    nasServerId := "nasServerId_example" // string | Fetch FTP Servers for nas_server_id equal (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.FileApi.GetFtpServers(context.Background(), symmetrixId).NasServerId(nasServerId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `FileApi.GetFtpServers``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetFtpServers`: FtpServerList
    fmt.Fprintf(os.Stdout, "Response from `FileApi.GetFtpServers`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**symmetrixId** | **string** | The array ID | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetFtpServersRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **nasServerId** | **string** | Fetch FTP Servers for nas_server_id equal | 

### Return type

[**FtpServerList**](FtpServerList.md)

### Authorization

[apiSecurity](../README.md#apiSecurity)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetGlobalNamespace

> UnifiedNamespaceLinkListResponse GetGlobalNamespace(ctx, symmetrixId).NasServerId(nasServerId).FileSystemId(fileSystemId).Name(name).Execute()

List GlobalNameSpace



### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    symmetrixId := "symmetrixId_example" // string | The ArrayId
    nasServerId := "nasServerId_example" // string | Queery Global Namespace by nas_server_id (optional)
    fileSystemId := "fileSystemId_example" // string | Query Global Namespace by file_system_id (optional)
    name := "name_example" // string | Query Global Namespace by name (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.FileApi.GetGlobalNamespace(context.Background(), symmetrixId).NasServerId(nasServerId).FileSystemId(fileSystemId).Name(name).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `FileApi.GetGlobalNamespace``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetGlobalNamespace`: UnifiedNamespaceLinkListResponse
    fmt.Fprintf(os.Stdout, "Response from `FileApi.GetGlobalNamespace`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**symmetrixId** | **string** | The ArrayId | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetGlobalNamespaceRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **nasServerId** | **string** | Queery Global Namespace by nas_server_id | 
 **fileSystemId** | **string** | Query Global Namespace by file_system_id | 
 **name** | **string** | Query Global Namespace by name | 

### Return type

[**UnifiedNamespaceLinkListResponse**](UnifiedNamespaceLinkListResponse.md)

### Authorization

[apiSecurity](../README.md#apiSecurity)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetGlobalNamespace1

> UnifiedNamespaceInstance GetGlobalNamespace1(ctx, symmetrixId, unifiedNamespaceId).Execute()

Get GlobalNameSpace



### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    symmetrixId := "symmetrixId_example" // string | The ArrayId
    unifiedNamespaceId := "unifiedNamespaceId_example" // string | The unified_namespace_id

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.FileApi.GetGlobalNamespace1(context.Background(), symmetrixId, unifiedNamespaceId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `FileApi.GetGlobalNamespace1``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetGlobalNamespace1`: UnifiedNamespaceInstance
    fmt.Fprintf(os.Stdout, "Response from `FileApi.GetGlobalNamespace1`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**symmetrixId** | **string** | The ArrayId | 
**unifiedNamespaceId** | **string** | The unified_namespace_id | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetGlobalNamespace1Request struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------



### Return type

[**UnifiedNamespaceInstance**](UnifiedNamespaceInstance.md)

### Authorization

[apiSecurity](../README.md#apiSecurity)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetKerberosService

> Kerberos GetKerberosService(ctx, symmetrixId, kerberosServiceId).Execute()

Get Kerberos Service



### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    symmetrixId := "symmetrixId_example" // string | The Array ID
    kerberosServiceId := "kerberosServiceId_example" // string | The kerberos service id

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.FileApi.GetKerberosService(context.Background(), symmetrixId, kerberosServiceId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `FileApi.GetKerberosService``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetKerberosService`: Kerberos
    fmt.Fprintf(os.Stdout, "Response from `FileApi.GetKerberosService`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**symmetrixId** | **string** | The Array ID | 
**kerberosServiceId** | **string** | The kerberos service id | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetKerberosServiceRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------



### Return type

[**Kerberos**](Kerberos.md)

### Authorization

[apiSecurity](../README.md#apiSecurity)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetKerberosServices

> KerberosList GetKerberosServices(ctx, symmetrixId).NasServerId(nasServerId).Execute()

List Kerberos services



### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    symmetrixId := "symmetrixId_example" // string | 
    nasServerId := "nasServerId_example" // string |  (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.FileApi.GetKerberosServices(context.Background(), symmetrixId).NasServerId(nasServerId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `FileApi.GetKerberosServices``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetKerberosServices`: KerberosList
    fmt.Fprintf(os.Stdout, "Response from `FileApi.GetKerberosServices`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**symmetrixId** | **string** |  | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetKerberosServicesRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **nasServerId** | **string** |  | 

### Return type

[**KerberosList**](KerberosList.md)

### Authorization

[apiSecurity](../README.md#apiSecurity)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetLDAPService

> LdapService GetLDAPService(ctx, symmetrixId, ldapServiceId).Execute()

Get Kerberos Service



### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    symmetrixId := "symmetrixId_example" // string | 
    ldapServiceId := "ldapServiceId_example" // string | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.FileApi.GetLDAPService(context.Background(), symmetrixId, ldapServiceId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `FileApi.GetLDAPService``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetLDAPService`: LdapService
    fmt.Fprintf(os.Stdout, "Response from `FileApi.GetLDAPService`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**symmetrixId** | **string** |  | 
**ldapServiceId** | **string** |  | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetLDAPServiceRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------



### Return type

[**LdapService**](LdapService.md)

### Authorization

[apiSecurity](../README.md#apiSecurity)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetLDAPServices

> LdapList GetLDAPServices(ctx, symmetrixId).NasServerId(nasServerId).Execute()

List Ldap Service



### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    symmetrixId := "symmetrixId_example" // string | The Array ID
    nasServerId := "nasServerId_example" // string | Fetches the Ldap service where nas server id equal (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.FileApi.GetLDAPServices(context.Background(), symmetrixId).NasServerId(nasServerId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `FileApi.GetLDAPServices``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetLDAPServices`: LdapList
    fmt.Fprintf(os.Stdout, "Response from `FileApi.GetLDAPServices`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**symmetrixId** | **string** | The Array ID | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetLDAPServicesRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **nasServerId** | **string** | Fetches the Ldap service where nas server id equal | 

### Return type

[**LdapList**](LdapList.md)

### Authorization

[apiSecurity](../README.md#apiSecurity)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetListNasServers

> NasServerListResponse GetListNasServers(ctx, symmetrixId).Name(name).RootFsWwn(rootFsWwn).ConfigFsWwn(configFsWwn).DnsServerEnable(dnsServerEnable).NisServerEnable(nisServerEnable).LdapServerEnable(ldapServerEnable).KerberosServerEnable(kerberosServerEnable).NfsServerEnable(nfsServerEnable).SmbServerEnable(smbServerEnable).DhsmServerEnable(dhsmServerEnable).VirusCheckerEnabled(virusCheckerEnabled).IsReplicationEnabled(isReplicationEnabled).Execute()

List NAS Server



### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    symmetrixId := "symmetrixId_example" // string | The array ID
    name := "name_example" // string | Nas Servers that equal or contain the specified storage Group name only. e.g. equal to \"name=nas\" or contains \"name=<like>nas\" (optional)
    rootFsWwn := "rootFsWwn_example" // string | Nas Servers filter with the parameter root_fs_wwn (optional)
    configFsWwn := "configFsWwn_example" // string | Nas Servers filter with the paramer config_fs_wwn (optional)
    dnsServerEnable := true // bool | Nas Servers that dns service enable/disable (optional)
    nisServerEnable := true // bool | Nas Servers that nis service enable/disable (optional)
    ldapServerEnable := true // bool | Nas Servers that ldap service enable/disable (optional)
    kerberosServerEnable := true // bool | Nas Servers that kerberos service enable/disable (optional)
    nfsServerEnable := true // bool | Nas Servers that nfs server enable/disable (optional)
    smbServerEnable := true // bool | Nas Servers that smb server enable (optional)
    dhsmServerEnable := true // bool | Nas Servers that dhsm server enable (optional)
    virusCheckerEnabled := true // bool | Nas Servers that virus checker enable (optional)
    isReplicationEnabled := true // bool | Nas Servers that replication enabled/disabled (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.FileApi.GetListNasServers(context.Background(), symmetrixId).Name(name).RootFsWwn(rootFsWwn).ConfigFsWwn(configFsWwn).DnsServerEnable(dnsServerEnable).NisServerEnable(nisServerEnable).LdapServerEnable(ldapServerEnable).KerberosServerEnable(kerberosServerEnable).NfsServerEnable(nfsServerEnable).SmbServerEnable(smbServerEnable).DhsmServerEnable(dhsmServerEnable).VirusCheckerEnabled(virusCheckerEnabled).IsReplicationEnabled(isReplicationEnabled).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `FileApi.GetListNasServers``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetListNasServers`: NasServerListResponse
    fmt.Fprintf(os.Stdout, "Response from `FileApi.GetListNasServers`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**symmetrixId** | **string** | The array ID | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetListNasServersRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **name** | **string** | Nas Servers that equal or contain the specified storage Group name only. e.g. equal to \&quot;name&#x3D;nas\&quot; or contains \&quot;name&#x3D;&lt;like&gt;nas\&quot; | 
 **rootFsWwn** | **string** | Nas Servers filter with the parameter root_fs_wwn | 
 **configFsWwn** | **string** | Nas Servers filter with the paramer config_fs_wwn | 
 **dnsServerEnable** | **bool** | Nas Servers that dns service enable/disable | 
 **nisServerEnable** | **bool** | Nas Servers that nis service enable/disable | 
 **ldapServerEnable** | **bool** | Nas Servers that ldap service enable/disable | 
 **kerberosServerEnable** | **bool** | Nas Servers that kerberos service enable/disable | 
 **nfsServerEnable** | **bool** | Nas Servers that nfs server enable/disable | 
 **smbServerEnable** | **bool** | Nas Servers that smb server enable | 
 **dhsmServerEnable** | **bool** | Nas Servers that dhsm server enable | 
 **virusCheckerEnabled** | **bool** | Nas Servers that virus checker enable | 
 **isReplicationEnabled** | **bool** | Nas Servers that replication enabled/disabled | 

### Return type

[**NasServerListResponse**](NasServerListResponse.md)

### Authorization

[apiSecurity](../README.md#apiSecurity)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetNDMPServer

> NdmpServer GetNDMPServer(ctx, symmetrixId, ndmpServerId).Execute()

Get Ndmp server



### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    symmetrixId := "symmetrixId_example" // string | 
    ndmpServerId := "ndmpServerId_example" // string | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.FileApi.GetNDMPServer(context.Background(), symmetrixId, ndmpServerId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `FileApi.GetNDMPServer``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetNDMPServer`: NdmpServer
    fmt.Fprintf(os.Stdout, "Response from `FileApi.GetNDMPServer`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**symmetrixId** | **string** |  | 
**ndmpServerId** | **string** |  | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetNDMPServerRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------



### Return type

[**NdmpServer**](NdmpServer.md)

### Authorization

[apiSecurity](../README.md#apiSecurity)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetNDMPServers

> NdmpServerList GetNDMPServers(ctx, symmetrixId).NasServerId(nasServerId).Execute()

List Ndmp server



### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    symmetrixId := "symmetrixId_example" // string | The ArrayId
    nasServerId := "nasServerId_example" // string | Filter NDMPServers with NDMP resource (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.FileApi.GetNDMPServers(context.Background(), symmetrixId).NasServerId(nasServerId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `FileApi.GetNDMPServers``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetNDMPServers`: NdmpServerList
    fmt.Fprintf(os.Stdout, "Response from `FileApi.GetNDMPServers`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**symmetrixId** | **string** | The ArrayId | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetNDMPServersRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **nasServerId** | **string** | Filter NDMPServers with NDMP resource | 

### Return type

[**NdmpServerList**](NdmpServerList.md)

### Authorization

[apiSecurity](../README.md#apiSecurity)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetNFSExport

> Export GetNFSExport(ctx, symmetrixId, nfsExportId).Execute()

Get NFS Export



### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    symmetrixId := "symmetrixId_example" // string | The ArrayId
    nfsExportId := "nfsExportId_example" // string | The nfs_export_id

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.FileApi.GetNFSExport(context.Background(), symmetrixId, nfsExportId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `FileApi.GetNFSExport``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetNFSExport`: Export
    fmt.Fprintf(os.Stdout, "Response from `FileApi.GetNFSExport`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**symmetrixId** | **string** | The ArrayId | 
**nfsExportId** | **string** | The nfs_export_id | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetNFSExportRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------



### Return type

[**Export**](Export.md)

### Authorization

[apiSecurity](../README.md#apiSecurity)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetNFSExports

> Export GetNFSExports(ctx, symmetrixId).Name(name).NasServer(nasServer).FileSystemId(fileSystemId).SnapshotId(snapshotId).Execute()

List NFS Export



### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    symmetrixId := "symmetrixId_example" // string | The ArrayId
    name := "name_example" // string | Query exports when nas_server equal/like
    nasServer := "nasServer_example" // string | Query exports when nas_server equal to nas_server_id (optional)
    fileSystemId := "fileSystemId_example" // string | Query exports when file_system equal (optional)
    snapshotId := "snapshotId_example" // string | Query exports when snapshot equal (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.FileApi.GetNFSExports(context.Background(), symmetrixId).Name(name).NasServer(nasServer).FileSystemId(fileSystemId).SnapshotId(snapshotId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `FileApi.GetNFSExports``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetNFSExports`: Export
    fmt.Fprintf(os.Stdout, "Response from `FileApi.GetNFSExports`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**symmetrixId** | **string** | The ArrayId | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetNFSExportsRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **name** | **string** | Query exports when nas_server equal/like | 
 **nasServer** | **string** | Query exports when nas_server equal to nas_server_id | 
 **fileSystemId** | **string** | Query exports when file_system equal | 
 **snapshotId** | **string** | Query exports when snapshot equal | 

### Return type

[**Export**](Export.md)

### Authorization

[apiSecurity](../README.md#apiSecurity)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetNFSServer

> NfsServer GetNFSServer(ctx, symmetrixId, nfsServerId).Execute()

Get NFS Server



### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    symmetrixId := "symmetrixId_example" // string | The ArrayId
    nfsServerId := "nfsServerId_example" // string | The nfs_server_id

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.FileApi.GetNFSServer(context.Background(), symmetrixId, nfsServerId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `FileApi.GetNFSServer``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetNFSServer`: NfsServer
    fmt.Fprintf(os.Stdout, "Response from `FileApi.GetNFSServer`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**symmetrixId** | **string** | The ArrayId | 
**nfsServerId** | **string** | The nfs_server_id | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetNFSServerRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------



### Return type

[**NfsServer**](NfsServer.md)

### Authorization

[apiSecurity](../README.md#apiSecurity)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetNFSServers

> NfsServerList GetNFSServers(ctx, symmetrixId).NasServerId(nasServerId).Nfsv3Enabled(nfsv3Enabled).Nfsv4Enabled(nfsv4Enabled).SecureEnabled(secureEnabled).Joined(joined).Execute()

List NFS Server



### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    symmetrixId := "symmetrixId_example" // string | The ArrayId
    nasServerId := "nasServerId_example" // string | Query NFSServer for parameter nas_server_id
    nfsv3Enabled := true // bool | Query NFSServer for parameter nfsv3_enabled
    nfsv4Enabled := true // bool | Query NFSServer for parameter nfsv4_enabled
    secureEnabled := true // bool | Query NFSServer for parameter secure_enabled
    joined := true // bool | Query NFSServer for parameter joined

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.FileApi.GetNFSServers(context.Background(), symmetrixId).NasServerId(nasServerId).Nfsv3Enabled(nfsv3Enabled).Nfsv4Enabled(nfsv4Enabled).SecureEnabled(secureEnabled).Joined(joined).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `FileApi.GetNFSServers``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetNFSServers`: NfsServerList
    fmt.Fprintf(os.Stdout, "Response from `FileApi.GetNFSServers`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**symmetrixId** | **string** | The ArrayId | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetNFSServersRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **nasServerId** | **string** | Query NFSServer for parameter nas_server_id | 
 **nfsv3Enabled** | **bool** | Query NFSServer for parameter nfsv3_enabled | 
 **nfsv4Enabled** | **bool** | Query NFSServer for parameter nfsv4_enabled | 
 **secureEnabled** | **bool** | Query NFSServer for parameter secure_enabled | 
 **joined** | **bool** | Query NFSServer for parameter joined | 

### Return type

[**NfsServerList**](NfsServerList.md)

### Authorization

[apiSecurity](../README.md#apiSecurity)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetNISService

> NisService GetNISService(ctx, symmetrixId, nisServiceId).Execute()

Get Nis Service



### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    symmetrixId := "symmetrixId_example" // string | The Array ID
    nisServiceId := "nisServiceId_example" // string | The nis service id

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.FileApi.GetNISService(context.Background(), symmetrixId, nisServiceId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `FileApi.GetNISService``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetNISService`: NisService
    fmt.Fprintf(os.Stdout, "Response from `FileApi.GetNISService`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**symmetrixId** | **string** | The Array ID | 
**nisServiceId** | **string** | The nis service id | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetNISServiceRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------



### Return type

[**NisService**](NisService.md)

### Authorization

[apiSecurity](../README.md#apiSecurity)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetNasServer

> NasServer GetNasServer(ctx, symmetrixId, nasServerId).Execute()

Get NAS Server



### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    symmetrixId := "symmetrixId_example" // string | The array ID
    nasServerId := "nasServerId_example" // string | The NASSserver ID

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.FileApi.GetNasServer(context.Background(), symmetrixId, nasServerId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `FileApi.GetNasServer``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetNasServer`: NasServer
    fmt.Fprintf(os.Stdout, "Response from `FileApi.GetNasServer`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**symmetrixId** | **string** | The array ID | 
**nasServerId** | **string** | The NASSserver ID | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetNasServerRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------



### Return type

[**NasServer**](NasServer.md)

### Authorization

[apiSecurity](../README.md#apiSecurity)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetNetworkDevice

> NetworkDevice GetNetworkDevice(ctx, symmetrixId, networkDeviceId).Execute()

Get Network Device



### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    symmetrixId := "symmetrixId_example" // string | The ArrayId
    networkDeviceId := "networkDeviceId_example" // string | The network_device_id

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.FileApi.GetNetworkDevice(context.Background(), symmetrixId, networkDeviceId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `FileApi.GetNetworkDevice``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetNetworkDevice`: NetworkDevice
    fmt.Fprintf(os.Stdout, "Response from `FileApi.GetNetworkDevice`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**symmetrixId** | **string** | The ArrayId | 
**networkDeviceId** | **string** | The network_device_id | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetNetworkDeviceRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------



### Return type

[**NetworkDevice**](NetworkDevice.md)

### Authorization

[apiSecurity](../README.md#apiSecurity)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetNetworkDevices

> NetworkDeviceListResponse GetNetworkDevices(ctx, symmetrixId).Execute()

List Network Devices



### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    symmetrixId := "symmetrixId_example" // string | The ArrayId

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.FileApi.GetNetworkDevices(context.Background(), symmetrixId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `FileApi.GetNetworkDevices``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetNetworkDevices`: NetworkDeviceListResponse
    fmt.Fprintf(os.Stdout, "Response from `FileApi.GetNetworkDevices`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**symmetrixId** | **string** | The ArrayId | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetNetworkDevicesRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


### Return type

[**NetworkDeviceListResponse**](NetworkDeviceListResponse.md)

### Authorization

[apiSecurity](../README.md#apiSecurity)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetNisServices

> NisList GetNisServices(ctx, symmetrixId).NasServer(nasServer).Execute()

List Nis Service



### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    symmetrixId := "symmetrixId_example" // string | The Array ID
    nasServer := "nasServer_example" // string | Fetch nis service for nas_server equal (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.FileApi.GetNisServices(context.Background(), symmetrixId).NasServer(nasServer).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `FileApi.GetNisServices``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetNisServices`: NisList
    fmt.Fprintf(os.Stdout, "Response from `FileApi.GetNisServices`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**symmetrixId** | **string** | The Array ID | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetNisServicesRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **nasServer** | **string** | Fetch nis service for nas_server equal | 

### Return type

[**NisList**](NisList.md)

### Authorization

[apiSecurity](../README.md#apiSecurity)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetNodeInventory

> NodeInventory GetNodeInventory(ctx, symmetrixId, nodeId).Execute()

Get Node Inventory



### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    symmetrixId := "symmetrixId_example" // string | 
    nodeId := "nodeId_example" // string | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.FileApi.GetNodeInventory(context.Background(), symmetrixId, nodeId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `FileApi.GetNodeInventory``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetNodeInventory`: NodeInventory
    fmt.Fprintf(os.Stdout, "Response from `FileApi.GetNodeInventory`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**symmetrixId** | **string** |  | 
**nodeId** | **string** |  | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetNodeInventoryRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------



### Return type

[**NodeInventory**](NodeInventory.md)

### Authorization

[apiSecurity](../README.md#apiSecurity)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetNodes

> NodeList GetNodes(ctx, symmetrixId).Execute()

List Node Inventory



### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    symmetrixId := "symmetrixId_example" // string | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.FileApi.GetNodes(context.Background(), symmetrixId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `FileApi.GetNodes``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetNodes`: NodeList
    fmt.Fprintf(os.Stdout, "Response from `FileApi.GetNodes`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**symmetrixId** | **string** |  | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetNodesRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


### Return type

[**NodeList**](NodeList.md)

### Authorization

[apiSecurity](../README.md#apiSecurity)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetRemoteSystem

> RemoteSystem GetRemoteSystem(ctx, symmetrixId, remoteSystemId).Execute()

Get Remote System



### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    symmetrixId := "symmetrixId_example" // string | The ArrayId
    remoteSystemId := "remoteSystemId_example" // string | The remote_system_id

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.FileApi.GetRemoteSystem(context.Background(), symmetrixId, remoteSystemId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `FileApi.GetRemoteSystem``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetRemoteSystem`: RemoteSystem
    fmt.Fprintf(os.Stdout, "Response from `FileApi.GetRemoteSystem`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**symmetrixId** | **string** | The ArrayId | 
**remoteSystemId** | **string** | The remote_system_id | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetRemoteSystemRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------



### Return type

[**RemoteSystem**](RemoteSystem.md)

### Authorization

[apiSecurity](../README.md#apiSecurity)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetRemoteSystems

> RemoteSystemList GetRemoteSystems(ctx, symmetrixId).Execute()

List Remote System



### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    symmetrixId := "symmetrixId_example" // string | The ArrayId

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.FileApi.GetRemoteSystems(context.Background(), symmetrixId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `FileApi.GetRemoteSystems``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetRemoteSystems`: RemoteSystemList
    fmt.Fprintf(os.Stdout, "Response from `FileApi.GetRemoteSystems`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**symmetrixId** | **string** | The ArrayId | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetRemoteSystemsRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


### Return type

[**RemoteSystemList**](RemoteSystemList.md)

### Authorization

[apiSecurity](../README.md#apiSecurity)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetReplicationSession

> ReplicationSession GetReplicationSession(ctx, symmetrixId, replicationSessionId).Execute()

Get Replication Session



### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    symmetrixId := "symmetrixId_example" // string | The ArrayId
    replicationSessionId := "replicationSessionId_example" // string | The replication_session_id

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.FileApi.GetReplicationSession(context.Background(), symmetrixId, replicationSessionId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `FileApi.GetReplicationSession``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetReplicationSession`: ReplicationSession
    fmt.Fprintf(os.Stdout, "Response from `FileApi.GetReplicationSession`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**symmetrixId** | **string** | The ArrayId | 
**replicationSessionId** | **string** | The replication_session_id | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetReplicationSessionRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------



### Return type

[**ReplicationSession**](ReplicationSession.md)

### Authorization

[apiSecurity](../README.md#apiSecurity)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetReplicationSessions

> ReplicationSessionList GetReplicationSessions(ctx, symmetrixId).NasServerId(nasServerId).Execute()

List Replication Session



### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    symmetrixId := "symmetrixId_example" // string | The ArrayId
    nasServerId := "nasServerId_example" // string | Query replications on nas_server_id (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.FileApi.GetReplicationSessions(context.Background(), symmetrixId).NasServerId(nasServerId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `FileApi.GetReplicationSessions``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetReplicationSessions`: ReplicationSessionList
    fmt.Fprintf(os.Stdout, "Response from `FileApi.GetReplicationSessions`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**symmetrixId** | **string** | The ArrayId | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetReplicationSessionsRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **nasServerId** | **string** | Query replications on nas_server_id | 

### Return type

[**ReplicationSessionList**](ReplicationSessionList.md)

### Authorization

[apiSecurity](../README.md#apiSecurity)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetRoute

> Route GetRoute(ctx, symmetrixId, routeId).Execute()

Get Interface route



### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    symmetrixId := "symmetrixId_example" // string | The ArrayId
    routeId := "routeId_example" // string | The route_id

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.FileApi.GetRoute(context.Background(), symmetrixId, routeId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `FileApi.GetRoute``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetRoute`: Route
    fmt.Fprintf(os.Stdout, "Response from `FileApi.GetRoute`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**symmetrixId** | **string** | The ArrayId | 
**routeId** | **string** | The route_id | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetRouteRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------



### Return type

[**Route**](Route.md)

### Authorization

[apiSecurity](../README.md#apiSecurity)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetRouteList

> RouteList GetRouteList(ctx, symmetrixId).NasServerId(nasServerId).Execute()

List Interface route



### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    symmetrixId := "symmetrixId_example" // string | The ArrayID
    nasServerId := "nasServerId_example" // string |  Query routes for the attribute NasServerId (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.FileApi.GetRouteList(context.Background(), symmetrixId).NasServerId(nasServerId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `FileApi.GetRouteList``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetRouteList`: RouteList
    fmt.Fprintf(os.Stdout, "Response from `FileApi.GetRouteList`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**symmetrixId** | **string** | The ArrayID | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetRouteListRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **nasServerId** | **string** |  Query routes for the attribute NasServerId | 

### Return type

[**RouteList**](RouteList.md)

### Authorization

[apiSecurity](../README.md#apiSecurity)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetSMBServer

> SmbServerInstance GetSMBServer(ctx, symmetrixId, smbServerId).Execute()

Get SMB Server



### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    symmetrixId := "symmetrixId_example" // string | The ArrayId
    smbServerId := "smbServerId_example" // string | The smb_server_id

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.FileApi.GetSMBServer(context.Background(), symmetrixId, smbServerId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `FileApi.GetSMBServer``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetSMBServer`: SmbServerInstance
    fmt.Fprintf(os.Stdout, "Response from `FileApi.GetSMBServer`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**symmetrixId** | **string** | The ArrayId | 
**smbServerId** | **string** | The smb_server_id | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetSMBServerRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------



### Return type

[**SmbServerInstance**](SmbServerInstance.md)

### Authorization

[apiSecurity](../README.md#apiSecurity)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetSMBServers

> SmbServerList GetSMBServers(ctx, symmetrixId).NasServerId(nasServerId).Execute()

List SMB Server



### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    symmetrixId := "symmetrixId_example" // string | The ArrayId
    nasServerId := "nasServerId_example" // string | Query SMBServers where nas_server equal to

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.FileApi.GetSMBServers(context.Background(), symmetrixId).NasServerId(nasServerId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `FileApi.GetSMBServers``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetSMBServers`: SmbServerList
    fmt.Fprintf(os.Stdout, "Response from `FileApi.GetSMBServers`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**symmetrixId** | **string** | The ArrayId | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetSMBServersRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **nasServerId** | **string** | Query SMBServers where nas_server equal to | 

### Return type

[**SmbServerList**](SmbServerList.md)

### Authorization

[apiSecurity](../README.md#apiSecurity)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetSMBShare

> SmbServerInstance GetSMBShare(ctx, symmetrixId, smbShareId).Execute()

Get SMB Share



### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    symmetrixId := "symmetrixId_example" // string | The ArrayId
    smbShareId := "smbShareId_example" // string | The smb_share_id

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.FileApi.GetSMBShare(context.Background(), symmetrixId, smbShareId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `FileApi.GetSMBShare``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetSMBShare`: SmbServerInstance
    fmt.Fprintf(os.Stdout, "Response from `FileApi.GetSMBShare`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**symmetrixId** | **string** | The ArrayId | 
**smbShareId** | **string** | The smb_share_id | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetSMBShareRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------



### Return type

[**SmbServerInstance**](SmbServerInstance.md)

### Authorization

[apiSecurity](../README.md#apiSecurity)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetSMBShares

> SmbShareList GetSMBShares(ctx, symmetrixId).NasServerId(nasServerId).FileSystemId(fileSystemId).SnapshotId(snapshotId).Name(name).Execute()

List SMB Share



### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    symmetrixId := "symmetrixId_example" // string | The ArrayId
    nasServerId := "nasServerId_example" // string | Query SMBShares where for nas_server_id (optional)
    fileSystemId := "fileSystemId_example" // string | Query SMBShares for filesystem id (optional)
    snapshotId := "snapshotId_example" // string | Query SMBShares for snapshot id (optional)
    name := "name_example" // string | The Query SMBShares for name equal/like (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.FileApi.GetSMBShares(context.Background(), symmetrixId).NasServerId(nasServerId).FileSystemId(fileSystemId).SnapshotId(snapshotId).Name(name).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `FileApi.GetSMBShares``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetSMBShares`: SmbShareList
    fmt.Fprintf(os.Stdout, "Response from `FileApi.GetSMBShares`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**symmetrixId** | **string** | The ArrayId | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetSMBSharesRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **nasServerId** | **string** | Query SMBShares where for nas_server_id | 
 **fileSystemId** | **string** | Query SMBShares for filesystem id | 
 **snapshotId** | **string** | Query SMBShares for snapshot id | 
 **name** | **string** | The Query SMBShares for name equal/like | 

### Return type

[**SmbShareList**](SmbShareList.md)

### Authorization

[apiSecurity](../README.md#apiSecurity)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetSchedule

> Schedule GetSchedule(ctx, symmetrixId, snapPolicyId).Execute()

Get Snap Schedule



### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    symmetrixId := "symmetrixId_example" // string | The ArrayID
    snapPolicyId := "snapPolicyId_example" // string | The Snap Policy Id

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.FileApi.GetSchedule(context.Background(), symmetrixId, snapPolicyId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `FileApi.GetSchedule``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetSchedule`: Schedule
    fmt.Fprintf(os.Stdout, "Response from `FileApi.GetSchedule`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**symmetrixId** | **string** | The ArrayID | 
**snapPolicyId** | **string** | The Snap Policy Id | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetScheduleRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------



### Return type

[**Schedule**](Schedule.md)

### Authorization

[apiSecurity](../README.md#apiSecurity)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetSchedules

> ScheduleList GetSchedules(ctx, symmetrixId).NasServerId(nasServerId).Name(name).Execute()

List Snap Schedule



### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    symmetrixId := "symmetrixId_example" // string | The ArrayID
    nasServerId := "nasServerId_example" // string | Fetch the the Schedule based nas_server_id (optional)
    name := "name_example" // string | Fetch the the Schedule based name (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.FileApi.GetSchedules(context.Background(), symmetrixId).NasServerId(nasServerId).Name(name).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `FileApi.GetSchedules``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetSchedules`: ScheduleList
    fmt.Fprintf(os.Stdout, "Response from `FileApi.GetSchedules`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**symmetrixId** | **string** | The ArrayID | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetSchedulesRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **nasServerId** | **string** | Fetch the the Schedule based nas_server_id | 
 **name** | **string** | Fetch the the Schedule based name | 

### Return type

[**ScheduleList**](ScheduleList.md)

### Authorization

[apiSecurity](../README.md#apiSecurity)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetSnapshot

> Snapshot GetSnapshot(ctx, symmetrixId, snapshotId).Execute()

Get Snapshot



### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    symmetrixId := "symmetrixId_example" // string | The ArrayId
    snapshotId := "snapshotId_example" // string | The ArrayId

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.FileApi.GetSnapshot(context.Background(), symmetrixId, snapshotId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `FileApi.GetSnapshot``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetSnapshot`: Snapshot
    fmt.Fprintf(os.Stdout, "Response from `FileApi.GetSnapshot`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**symmetrixId** | **string** | The ArrayId | 
**snapshotId** | **string** | The ArrayId | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetSnapshotRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------



### Return type

[**Snapshot**](Snapshot.md)

### Authorization

[apiSecurity](../README.md#apiSecurity)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetSnapshots

> SnapListResponse GetSnapshots(ctx, symmetrixId).FileSystemId(fileSystemId).NasServerId(nasServerId).Name(name).Execute()

List SMB Share



### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    symmetrixId := "symmetrixId_example" // string | The ArrayId
    fileSystemId := "fileSystemId_example" // string | Query Snapshots for file_system
    nasServerId := "nasServerId_example" // string | query snapshots for nas_Server
    name := "name_example" // string | query snapshots for names

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.FileApi.GetSnapshots(context.Background(), symmetrixId).FileSystemId(fileSystemId).NasServerId(nasServerId).Name(name).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `FileApi.GetSnapshots``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetSnapshots`: SnapListResponse
    fmt.Fprintf(os.Stdout, "Response from `FileApi.GetSnapshots`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**symmetrixId** | **string** | The ArrayId | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetSnapshotsRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **fileSystemId** | **string** | Query Snapshots for file_system | 
 **nasServerId** | **string** | query snapshots for nas_Server | 
 **name** | **string** | query snapshots for names | 

### Return type

[**SnapListResponse**](SnapListResponse.md)

### Authorization

[apiSecurity](../README.md#apiSecurity)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetTreeQuota

> TreeQuota GetTreeQuota(ctx, symmetrixId, fileSystemId, treeQuotaId).Execute()

Get Tree Quota by ID



### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    symmetrixId := "symmetrixId_example" // string | The ArrayId
    fileSystemId := "fileSystemId_example" // string | The file_system_id
    treeQuotaId := "treeQuotaId_example" // string | The tree_quota_id

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.FileApi.GetTreeQuota(context.Background(), symmetrixId, fileSystemId, treeQuotaId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `FileApi.GetTreeQuota``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetTreeQuota`: TreeQuota
    fmt.Fprintf(os.Stdout, "Response from `FileApi.GetTreeQuota`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**symmetrixId** | **string** | The ArrayId | 
**fileSystemId** | **string** | The file_system_id | 
**treeQuotaId** | **string** | The tree_quota_id | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetTreeQuotaRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------




### Return type

[**TreeQuota**](TreeQuota.md)

### Authorization

[apiSecurity](../README.md#apiSecurity)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetTreeQuotas

> TreeQuotaList GetTreeQuotas(ctx, symmetrixId, fileSystemId).Name(name).SizeUsed(sizeUsed).HardLimit(hardLimit).SoftLimit(softLimit).Execute()

List Tree Quota



### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    symmetrixId := "symmetrixId_example" // string | The ArrayId
    fileSystemId := "fileSystemId_example" // string | The tree_quota_id
    name := "name_example" // string | Query TreeQuota for name
    sizeUsed := int64(789) // int64 | Query TreeQuota for size_used
    hardLimit := int64(789) // int64 | Query TreeQuota for hard_limit
    softLimit := int64(789) // int64 | Query TreeQuota for soft_limit

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.FileApi.GetTreeQuotas(context.Background(), symmetrixId, fileSystemId).Name(name).SizeUsed(sizeUsed).HardLimit(hardLimit).SoftLimit(softLimit).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `FileApi.GetTreeQuotas``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetTreeQuotas`: TreeQuotaList
    fmt.Fprintf(os.Stdout, "Response from `FileApi.GetTreeQuotas`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**symmetrixId** | **string** | The ArrayId | 
**fileSystemId** | **string** | The tree_quota_id | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetTreeQuotasRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


 **name** | **string** | Query TreeQuota for name | 
 **sizeUsed** | **int64** | Query TreeQuota for size_used | 
 **hardLimit** | **int64** | Query TreeQuota for hard_limit | 
 **softLimit** | **int64** | Query TreeQuota for soft_limit | 

### Return type

[**TreeQuotaList**](TreeQuotaList.md)

### Authorization

[apiSecurity](../README.md#apiSecurity)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetUnifiedNamespace

> UnifiedNamespaceLinkListResponse GetUnifiedNamespace(ctx, symmetrixId).NasServerId(nasServerId).FileSystemId(fileSystemId).Execute()

List GlobalNameSpace



### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    symmetrixId := "symmetrixId_example" // string | The ArrayID
    nasServerId := "nasServerId_example" // string | Global Namespaces that equal nas_server_id (optional)
    fileSystemId := "fileSystemId_example" // string | Global Namespaces that equal file_system_id (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.FileApi.GetUnifiedNamespace(context.Background(), symmetrixId).NasServerId(nasServerId).FileSystemId(fileSystemId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `FileApi.GetUnifiedNamespace``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetUnifiedNamespace`: UnifiedNamespaceLinkListResponse
    fmt.Fprintf(os.Stdout, "Response from `FileApi.GetUnifiedNamespace`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**symmetrixId** | **string** | The ArrayID | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetUnifiedNamespaceRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **nasServerId** | **string** | Global Namespaces that equal nas_server_id | 
 **fileSystemId** | **string** | Global Namespaces that equal file_system_id | 

### Return type

[**UnifiedNamespaceLinkListResponse**](UnifiedNamespaceLinkListResponse.md)

### Authorization

[apiSecurity](../README.md#apiSecurity)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetUnifiedNamespace1

> UnifiedNamespaceLinkInstance GetUnifiedNamespace1(ctx, symmetrixId, globalNamespaceLinkId).Execute()

Get GlobalNameSpace Link



### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    symmetrixId := "symmetrixId_example" // string | The ArrayID
    globalNamespaceLinkId := "globalNamespaceLinkId_example" // string | The unified_namespace_link_id

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.FileApi.GetUnifiedNamespace1(context.Background(), symmetrixId, globalNamespaceLinkId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `FileApi.GetUnifiedNamespace1``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetUnifiedNamespace1`: UnifiedNamespaceLinkInstance
    fmt.Fprintf(os.Stdout, "Response from `FileApi.GetUnifiedNamespace1`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**symmetrixId** | **string** | The ArrayID | 
**globalNamespaceLinkId** | **string** | The unified_namespace_link_id | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetUnifiedNamespace1Request struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------



### Return type

[**UnifiedNamespaceLinkInstance**](UnifiedNamespaceLinkInstance.md)

### Authorization

[apiSecurity](../README.md#apiSecurity)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetUserQuota

> UserQuota GetUserQuota(ctx, symmetrixId, fileSystemId, userQuotaId).Execute()

Get User Quota



### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    symmetrixId := "symmetrixId_example" // string | The ArrayId
    fileSystemId := "fileSystemId_example" // string | The file_system_id
    userQuotaId := "userQuotaId_example" // string | The user_quota_id

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.FileApi.GetUserQuota(context.Background(), symmetrixId, fileSystemId, userQuotaId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `FileApi.GetUserQuota``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetUserQuota`: UserQuota
    fmt.Fprintf(os.Stdout, "Response from `FileApi.GetUserQuota`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**symmetrixId** | **string** | The ArrayId | 
**fileSystemId** | **string** | The file_system_id | 
**userQuotaId** | **string** | The user_quota_id | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetUserQuotaRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------




### Return type

[**UserQuota**](UserQuota.md)

### Authorization

[apiSecurity](../README.md#apiSecurity)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetUserQuotas

> Iterator GetUserQuotas(ctx, symmetrixId, fileSystemId).TreeQuotaId(treeQuotaId).HardLimit(hardLimit).SoftLimit(softLimit).SizeUsed(sizeUsed).Execute()

List Tree Quota



### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    symmetrixId := "symmetrixId_example" // string | The ArrayId
    fileSystemId := "fileSystemId_example" // string | The file_system_id
    treeQuotaId := "treeQuotaId_example" // string | Query user Quotas for tre_quota
    hardLimit := int64(789) // int64 | The Query user Quotas for hard_limit
    softLimit := int64(789) // int64 | The Query user Quotas for soft_limit
    sizeUsed := int64(789) // int64 | The Query user Quotas for size_used

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.FileApi.GetUserQuotas(context.Background(), symmetrixId, fileSystemId).TreeQuotaId(treeQuotaId).HardLimit(hardLimit).SoftLimit(softLimit).SizeUsed(sizeUsed).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `FileApi.GetUserQuotas``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetUserQuotas`: Iterator
    fmt.Fprintf(os.Stdout, "Response from `FileApi.GetUserQuotas`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**symmetrixId** | **string** | The ArrayId | 
**fileSystemId** | **string** | The file_system_id | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetUserQuotasRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


 **treeQuotaId** | **string** | Query user Quotas for tre_quota | 
 **hardLimit** | **int64** | The Query user Quotas for hard_limit | 
 **softLimit** | **int64** | The Query user Quotas for soft_limit | 
 **sizeUsed** | **int64** | The Query user Quotas for size_used | 

### Return type

[**Iterator**](Iterator.md)

### Authorization

[apiSecurity](../README.md#apiSecurity)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetVirusChecker

> VirusChecker GetVirusChecker(ctx, symmetrixId, virusCheckerId).Execute()

Get Virus checker



### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    symmetrixId := "symmetrixId_example" // string | The ArrayId
    virusCheckerId := "virusCheckerId_example" // string | The virus_checker_id

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.FileApi.GetVirusChecker(context.Background(), symmetrixId, virusCheckerId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `FileApi.GetVirusChecker``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetVirusChecker`: VirusChecker
    fmt.Fprintf(os.Stdout, "Response from `FileApi.GetVirusChecker`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**symmetrixId** | **string** | The ArrayId | 
**virusCheckerId** | **string** | The virus_checker_id | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetVirusCheckerRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------



### Return type

[**VirusChecker**](VirusChecker.md)

### Authorization

[apiSecurity](../README.md#apiSecurity)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetVirusCheckers

> VirusCheckerList GetVirusCheckers(ctx, symmetrixId).NasServerId(nasServerId).Execute()

List Virus Chcker



### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    symmetrixId := "symmetrixId_example" // string | The ArrayId
    nasServerId := "nasServerId_example" // string | Query Virus checkers for nas_server_id

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.FileApi.GetVirusCheckers(context.Background(), symmetrixId).NasServerId(nasServerId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `FileApi.GetVirusCheckers``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetVirusCheckers`: VirusCheckerList
    fmt.Fprintf(os.Stdout, "Response from `FileApi.GetVirusCheckers`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**symmetrixId** | **string** | The ArrayId | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetVirusCheckersRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **nasServerId** | **string** | Query Virus checkers for nas_server_id | 

### Return type

[**VirusCheckerList**](VirusCheckerList.md)

### Authorization

[apiSecurity](../README.md#apiSecurity)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetdhmServers

> DhsmServerListResponse GetdhmServers(ctx, symmetrixId).Execute()

List DHSMServer



### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    symmetrixId := "symmetrixId_example" // string | The ArrayID

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.FileApi.GetdhmServers(context.Background(), symmetrixId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `FileApi.GetdhmServers``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetdhmServers`: DhsmServerListResponse
    fmt.Fprintf(os.Stdout, "Response from `FileApi.GetdhmServers`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**symmetrixId** | **string** | The ArrayID | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetdhmServersRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


### Return type

[**DhsmServerListResponse**](DhsmServerListResponse.md)

### Authorization

[apiSecurity](../README.md#apiSecurity)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## JoinNFSServer

> JoinNFSServer(ctx, symmetrixId, nfsServerId).NfsServerJoinArguments(nfsServerJoinArguments).Execute()

Create NFS Server 



### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    symmetrixId := "symmetrixId_example" // string | The ArrayId
    nfsServerId := "nfsServerId_example" // string | The nfs_server_id
    nfsServerJoinArguments := *openapiclient.NewNfsServerJoinArguments("DomainUserName_example", "DomainPassword_example") // NfsServerJoinArguments | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.FileApi.JoinNFSServer(context.Background(), symmetrixId, nfsServerId).NfsServerJoinArguments(nfsServerJoinArguments).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `FileApi.JoinNFSServer``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**symmetrixId** | **string** | The ArrayId | 
**nfsServerId** | **string** | The nfs_server_id | 

### Other Parameters

Other parameters are passed through a pointer to a apiJoinNFSServerRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


 **nfsServerJoinArguments** | [**NfsServerJoinArguments**](NfsServerJoinArguments.md) |  | 

### Return type

 (empty response body)

### Authorization

[apiSecurity](../README.md#apiSecurity)

### HTTP request headers

- **Content-Type**: application/json, application/xml
- **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## JoinSMBServer

> JoinSMBServer(ctx, symmetrixId, smbServerId).SmbServerJoinArguments(smbServerJoinArguments).Execute()

Join SMB Server to active directory



### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    symmetrixId := "symmetrixId_example" // string | The ArrayId
    smbServerId := "smbServerId_example" // string | The smb_server_id
    smbServerJoinArguments := *openapiclient.NewSmbServerJoinArguments("DomainUserName_example", "DomainPassword_example") // SmbServerJoinArguments | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.FileApi.JoinSMBServer(context.Background(), symmetrixId, smbServerId).SmbServerJoinArguments(smbServerJoinArguments).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `FileApi.JoinSMBServer``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**symmetrixId** | **string** | The ArrayId | 
**smbServerId** | **string** | The smb_server_id | 

### Other Parameters

Other parameters are passed through a pointer to a apiJoinSMBServerRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


 **smbServerJoinArguments** | [**SmbServerJoinArguments**](SmbServerJoinArguments.md) |  | 

### Return type

 (empty response body)

### Authorization

[apiSecurity](../README.md#apiSecurity)

### HTTP request headers

- **Content-Type**: application/json, application/xml
- **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## ModifyBondDevice

> NetworkDevice ModifyBondDevice(ctx, symmetrixId, bondDeviceId).BondDeviceModifyArguments(bondDeviceModifyArguments).Execute()

Modify Bond Device



### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    symmetrixId := "symmetrixId_example" // string | The ArrayId
    bondDeviceId := "bondDeviceId_example" // string | The bond_device_id
    bondDeviceModifyArguments := *openapiclient.NewBondDeviceModifyArguments() // BondDeviceModifyArguments | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.FileApi.ModifyBondDevice(context.Background(), symmetrixId, bondDeviceId).BondDeviceModifyArguments(bondDeviceModifyArguments).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `FileApi.ModifyBondDevice``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `ModifyBondDevice`: NetworkDevice
    fmt.Fprintf(os.Stdout, "Response from `FileApi.ModifyBondDevice`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**symmetrixId** | **string** | The ArrayId | 
**bondDeviceId** | **string** | The bond_device_id | 

### Other Parameters

Other parameters are passed through a pointer to a apiModifyBondDeviceRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


 **bondDeviceModifyArguments** | [**BondDeviceModifyArguments**](BondDeviceModifyArguments.md) |  | 

### Return type

[**NetworkDevice**](NetworkDevice.md)

### Authorization

[apiSecurity](../README.md#apiSecurity)

### HTTP request headers

- **Content-Type**: application/json, application/xml
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## ModifyDNSService

> DnsService ModifyDNSService(ctx, symmetrixId, dnsServiceId).DnsModifyArguments(dnsModifyArguments).Execute()

Modify DNS service



### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    symmetrixId := "symmetrixId_example" // string | The Array ID
    dnsServiceId := "dnsServiceId_example" // string | The DNS service ID
    dnsModifyArguments := *openapiclient.NewDnsModifyArguments() // DnsModifyArguments | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.FileApi.ModifyDNSService(context.Background(), symmetrixId, dnsServiceId).DnsModifyArguments(dnsModifyArguments).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `FileApi.ModifyDNSService``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `ModifyDNSService`: DnsService
    fmt.Fprintf(os.Stdout, "Response from `FileApi.ModifyDNSService`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**symmetrixId** | **string** | The Array ID | 
**dnsServiceId** | **string** | The DNS service ID | 

### Other Parameters

Other parameters are passed through a pointer to a apiModifyDNSServiceRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


 **dnsModifyArguments** | [**DnsModifyArguments**](DnsModifyArguments.md) |  | 

### Return type

[**DnsService**](DnsService.md)

### Authorization

[apiSecurity](../README.md#apiSecurity)

### HTTP request headers

- **Content-Type**: application/json, application/xml
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## ModifyDhsmServer

> DhsmServer ModifyDhsmServer(ctx, symmetrixId, dhsmServerId).DhsmServerModifyArguments(dhsmServerModifyArguments).Execute()

Modify DHSMServer 



### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    symmetrixId := "symmetrixId_example" // string | The ArrayID
    dhsmServerId := "dhsmServerId_example" // string | The unique identifier of dhsm server
    dhsmServerModifyArguments := *openapiclient.NewDhsmServerModifyArguments() // DhsmServerModifyArguments | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.FileApi.ModifyDhsmServer(context.Background(), symmetrixId, dhsmServerId).DhsmServerModifyArguments(dhsmServerModifyArguments).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `FileApi.ModifyDhsmServer``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `ModifyDhsmServer`: DhsmServer
    fmt.Fprintf(os.Stdout, "Response from `FileApi.ModifyDhsmServer`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**symmetrixId** | **string** | The ArrayID | 
**dhsmServerId** | **string** | The unique identifier of dhsm server | 

### Other Parameters

Other parameters are passed through a pointer to a apiModifyDhsmServerRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


 **dhsmServerModifyArguments** | [**DhsmServerModifyArguments**](DhsmServerModifyArguments.md) |  | 

### Return type

[**DhsmServer**](DhsmServer.md)

### Authorization

[apiSecurity](../README.md#apiSecurity)

### HTTP request headers

- **Content-Type**: application/json, application/xml
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## ModifyDpNetwork

> DpNetwork ModifyDpNetwork(ctx, symmetrixId, dpNetworkId).DpNetworkModifyArguments(dpNetworkModifyArguments).Execute()

Modify Dp Network



### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    symmetrixId := "symmetrixId_example" // string | The ArrayId
    dpNetworkId := "dpNetworkId_example" // string | The dp_network_id
    dpNetworkModifyArguments := *openapiclient.NewDpNetworkModifyArguments() // DpNetworkModifyArguments | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.FileApi.ModifyDpNetwork(context.Background(), symmetrixId, dpNetworkId).DpNetworkModifyArguments(dpNetworkModifyArguments).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `FileApi.ModifyDpNetwork``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `ModifyDpNetwork`: DpNetwork
    fmt.Fprintf(os.Stdout, "Response from `FileApi.ModifyDpNetwork`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**symmetrixId** | **string** | The ArrayId | 
**dpNetworkId** | **string** | The dp_network_id | 

### Other Parameters

Other parameters are passed through a pointer to a apiModifyDpNetworkRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


 **dpNetworkModifyArguments** | [**DpNetworkModifyArguments**](DpNetworkModifyArguments.md) |  | 

### Return type

[**DpNetwork**](DpNetwork.md)

### Authorization

[apiSecurity](../README.md#apiSecurity)

### HTTP request headers

- **Content-Type**: application/json, application/xml
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## ModifyEventPool

> EventsPool ModifyEventPool(ctx, symmetrixId, eventPoolId).EventsPublisherModifyArguments(eventsPublisherModifyArguments).Execute()

Modify Events Pool



### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    symmetrixId := "symmetrixId_example" // string | The Array ID
    eventPoolId := "eventPoolId_example" // string | The event pool id
    eventsPublisherModifyArguments := *openapiclient.NewEventsPublisherModifyArguments() // EventsPublisherModifyArguments | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.FileApi.ModifyEventPool(context.Background(), symmetrixId, eventPoolId).EventsPublisherModifyArguments(eventsPublisherModifyArguments).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `FileApi.ModifyEventPool``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `ModifyEventPool`: EventsPool
    fmt.Fprintf(os.Stdout, "Response from `FileApi.ModifyEventPool`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**symmetrixId** | **string** | The Array ID | 
**eventPoolId** | **string** | The event pool id | 

### Other Parameters

Other parameters are passed through a pointer to a apiModifyEventPoolRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


 **eventsPublisherModifyArguments** | [**EventsPublisherModifyArguments**](EventsPublisherModifyArguments.md) |  | 

### Return type

[**EventsPool**](EventsPool.md)

### Authorization

[apiSecurity](../README.md#apiSecurity)

### HTTP request headers

- **Content-Type**: application/json, application/xml
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## ModifyEventPublisher

> EventsPublisher ModifyEventPublisher(ctx, symmetrixId, eventPublisherId).EventsPoolModifyArguments(eventsPoolModifyArguments).Execute()

Modify Event Publisher



### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    symmetrixId := "symmetrixId_example" // string | The Array ID
    eventPublisherId := "eventPublisherId_example" // string | The event_publisher_id
    eventsPoolModifyArguments := *openapiclient.NewEventsPoolModifyArguments() // EventsPoolModifyArguments | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.FileApi.ModifyEventPublisher(context.Background(), symmetrixId, eventPublisherId).EventsPoolModifyArguments(eventsPoolModifyArguments).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `FileApi.ModifyEventPublisher``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `ModifyEventPublisher`: EventsPublisher
    fmt.Fprintf(os.Stdout, "Response from `FileApi.ModifyEventPublisher`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**symmetrixId** | **string** | The Array ID | 
**eventPublisherId** | **string** | The event_publisher_id | 

### Other Parameters

Other parameters are passed through a pointer to a apiModifyEventPublisherRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


 **eventsPoolModifyArguments** | [**EventsPoolModifyArguments**](EventsPoolModifyArguments.md) |  | 

### Return type

[**EventsPublisher**](EventsPublisher.md)

### Authorization

[apiSecurity](../README.md#apiSecurity)

### HTTP request headers

- **Content-Type**: application/json, application/xml
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## ModifyFileInterface

> FileInterface ModifyFileInterface(ctx, symmetrixId, fileInterfaceId).FileInterfaceModifyArguments(fileInterfaceModifyArguments).Execute()

Modify file Interface



### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    symmetrixId := "symmetrixId_example" // string | The ArrayId
    fileInterfaceId := "fileInterfaceId_example" // string | The file_interface_id
    fileInterfaceModifyArguments := *openapiclient.NewFileInterfaceModifyArguments() // FileInterfaceModifyArguments | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.FileApi.ModifyFileInterface(context.Background(), symmetrixId, fileInterfaceId).FileInterfaceModifyArguments(fileInterfaceModifyArguments).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `FileApi.ModifyFileInterface``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `ModifyFileInterface`: FileInterface
    fmt.Fprintf(os.Stdout, "Response from `FileApi.ModifyFileInterface`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**symmetrixId** | **string** | The ArrayId | 
**fileInterfaceId** | **string** | The file_interface_id | 

### Other Parameters

Other parameters are passed through a pointer to a apiModifyFileInterfaceRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


 **fileInterfaceModifyArguments** | [**FileInterfaceModifyArguments**](FileInterfaceModifyArguments.md) |  | 

### Return type

[**FileInterface**](FileInterface.md)

### Authorization

[apiSecurity](../README.md#apiSecurity)

### HTTP request headers

- **Content-Type**: application/json, application/xml
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## ModifyFileSystem

> FileSystem ModifyFileSystem(ctx, symmetrixId, fileSystemId).FilesystemModifyArguments(filesystemModifyArguments).Execute()

Modify FileSystem



### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    symmetrixId := "symmetrixId_example" // string | The Array Id
    fileSystemId := "fileSystemId_example" // string | The file_system_id
    filesystemModifyArguments := *openapiclient.NewFilesystemModifyArguments() // FilesystemModifyArguments | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.FileApi.ModifyFileSystem(context.Background(), symmetrixId, fileSystemId).FilesystemModifyArguments(filesystemModifyArguments).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `FileApi.ModifyFileSystem``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `ModifyFileSystem`: FileSystem
    fmt.Fprintf(os.Stdout, "Response from `FileApi.ModifyFileSystem`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**symmetrixId** | **string** | The Array Id | 
**fileSystemId** | **string** | The file_system_id | 

### Other Parameters

Other parameters are passed through a pointer to a apiModifyFileSystemRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


 **filesystemModifyArguments** | [**FilesystemModifyArguments**](FilesystemModifyArguments.md) |  | 

### Return type

[**FileSystem**](FileSystem.md)

### Authorization

[apiSecurity](../README.md#apiSecurity)

### HTTP request headers

- **Content-Type**: application/json, application/xml
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## ModifyFtpServer

> FtpServer ModifyFtpServer(ctx, symmetrixId, ftpServerId).FtpServerModifyArguments(ftpServerModifyArguments).Execute()

Modify ftp server



### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    symmetrixId := "symmetrixId_example" // string | The array ID
    ftpServerId := "ftpServerId_example" // string | The ftp server id
    ftpServerModifyArguments := *openapiclient.NewFtpServerModifyArguments() // FtpServerModifyArguments | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.FileApi.ModifyFtpServer(context.Background(), symmetrixId, ftpServerId).FtpServerModifyArguments(ftpServerModifyArguments).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `FileApi.ModifyFtpServer``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `ModifyFtpServer`: FtpServer
    fmt.Fprintf(os.Stdout, "Response from `FileApi.ModifyFtpServer`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**symmetrixId** | **string** | The array ID | 
**ftpServerId** | **string** | The ftp server id | 

### Other Parameters

Other parameters are passed through a pointer to a apiModifyFtpServerRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


 **ftpServerModifyArguments** | [**FtpServerModifyArguments**](FtpServerModifyArguments.md) |  | 

### Return type

[**FtpServer**](FtpServer.md)

### Authorization

[apiSecurity](../README.md#apiSecurity)

### HTTP request headers

- **Content-Type**: application/json, application/xml
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## ModifyGlobalNamespace

> UnifiedNamespaceInstance ModifyGlobalNamespace(ctx, symmetrixId, unifiedNamespaceId).UnifiedNamespaceModifyArguments(unifiedNamespaceModifyArguments).Execute()

Modify GlobalNameSpace



### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    symmetrixId := "symmetrixId_example" // string | The ArrayId
    unifiedNamespaceId := "unifiedNamespaceId_example" // string | The unified_namespace_id
    unifiedNamespaceModifyArguments := *openapiclient.NewUnifiedNamespaceModifyArguments() // UnifiedNamespaceModifyArguments | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.FileApi.ModifyGlobalNamespace(context.Background(), symmetrixId, unifiedNamespaceId).UnifiedNamespaceModifyArguments(unifiedNamespaceModifyArguments).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `FileApi.ModifyGlobalNamespace``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `ModifyGlobalNamespace`: UnifiedNamespaceInstance
    fmt.Fprintf(os.Stdout, "Response from `FileApi.ModifyGlobalNamespace`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**symmetrixId** | **string** | The ArrayId | 
**unifiedNamespaceId** | **string** | The unified_namespace_id | 

### Other Parameters

Other parameters are passed through a pointer to a apiModifyGlobalNamespaceRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


 **unifiedNamespaceModifyArguments** | [**UnifiedNamespaceModifyArguments**](UnifiedNamespaceModifyArguments.md) |  | 

### Return type

[**UnifiedNamespaceInstance**](UnifiedNamespaceInstance.md)

### Authorization

[apiSecurity](../README.md#apiSecurity)

### HTTP request headers

- **Content-Type**: application/json, application/xml
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## ModifyGlobalNamespaceLink

> UnifiedNamespaceLinkInstance ModifyGlobalNamespaceLink(ctx, symmetrixId, globalNamespaceLinkId).UnifiedNamespaceLinkModifyArguments(unifiedNamespaceLinkModifyArguments).Execute()

Modify GlobalNameSpace



### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    symmetrixId := "symmetrixId_example" // string | The ArrayID
    globalNamespaceLinkId := "globalNamespaceLinkId_example" // string | The global_namespace_link_id
    unifiedNamespaceLinkModifyArguments := *openapiclient.NewUnifiedNamespaceLinkModifyArguments() // UnifiedNamespaceLinkModifyArguments | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.FileApi.ModifyGlobalNamespaceLink(context.Background(), symmetrixId, globalNamespaceLinkId).UnifiedNamespaceLinkModifyArguments(unifiedNamespaceLinkModifyArguments).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `FileApi.ModifyGlobalNamespaceLink``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `ModifyGlobalNamespaceLink`: UnifiedNamespaceLinkInstance
    fmt.Fprintf(os.Stdout, "Response from `FileApi.ModifyGlobalNamespaceLink`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**symmetrixId** | **string** | The ArrayID | 
**globalNamespaceLinkId** | **string** | The global_namespace_link_id | 

### Other Parameters

Other parameters are passed through a pointer to a apiModifyGlobalNamespaceLinkRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


 **unifiedNamespaceLinkModifyArguments** | [**UnifiedNamespaceLinkModifyArguments**](UnifiedNamespaceLinkModifyArguments.md) |  | 

### Return type

[**UnifiedNamespaceLinkInstance**](UnifiedNamespaceLinkInstance.md)

### Authorization

[apiSecurity](../README.md#apiSecurity)

### HTTP request headers

- **Content-Type**: application/json, application/xml
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## ModifyKerberosService

> Kerberos ModifyKerberosService(ctx, symmetrixId, kerberosServiceId).KerberosModifyArguments(kerberosModifyArguments).Execute()

Modify Kerberos Service



### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    symmetrixId := "symmetrixId_example" // string | The Array ID
    kerberosServiceId := "kerberosServiceId_example" // string | The kerberos service id
    kerberosModifyArguments := *openapiclient.NewKerberosModifyArguments() // KerberosModifyArguments | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.FileApi.ModifyKerberosService(context.Background(), symmetrixId, kerberosServiceId).KerberosModifyArguments(kerberosModifyArguments).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `FileApi.ModifyKerberosService``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `ModifyKerberosService`: Kerberos
    fmt.Fprintf(os.Stdout, "Response from `FileApi.ModifyKerberosService`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**symmetrixId** | **string** | The Array ID | 
**kerberosServiceId** | **string** | The kerberos service id | 

### Other Parameters

Other parameters are passed through a pointer to a apiModifyKerberosServiceRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


 **kerberosModifyArguments** | [**KerberosModifyArguments**](KerberosModifyArguments.md) |  | 

### Return type

[**Kerberos**](Kerberos.md)

### Authorization

[apiSecurity](../README.md#apiSecurity)

### HTTP request headers

- **Content-Type**: application/json, application/xml
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## ModifyLDAPService

> LdapService ModifyLDAPService(ctx, symmetrixId, ldapServiceId).LdapModifyArguments(ldapModifyArguments).Execute()

Modify Ldap Service



### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    symmetrixId := "symmetrixId_example" // string | The Array ID
    ldapServiceId := "ldapServiceId_example" // string | The ldap service id
    ldapModifyArguments := *openapiclient.NewLdapModifyArguments() // LdapModifyArguments | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.FileApi.ModifyLDAPService(context.Background(), symmetrixId, ldapServiceId).LdapModifyArguments(ldapModifyArguments).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `FileApi.ModifyLDAPService``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `ModifyLDAPService`: LdapService
    fmt.Fprintf(os.Stdout, "Response from `FileApi.ModifyLDAPService`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**symmetrixId** | **string** | The Array ID | 
**ldapServiceId** | **string** | The ldap service id | 

### Other Parameters

Other parameters are passed through a pointer to a apiModifyLDAPServiceRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


 **ldapModifyArguments** | [**LdapModifyArguments**](LdapModifyArguments.md) |  | 

### Return type

[**LdapService**](LdapService.md)

### Authorization

[apiSecurity](../README.md#apiSecurity)

### HTTP request headers

- **Content-Type**: application/json, application/xml
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## ModifyNDMPServer

> NdmpServer ModifyNDMPServer(ctx, symmetrixId, ndmpServerId).NdmpServerModifyArguments(ndmpServerModifyArguments).Execute()

Modify Ndmp server



### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    symmetrixId := "symmetrixId_example" // string | The ArrayId
    ndmpServerId := "ndmpServerId_example" // string | The ArrayId
    ndmpServerModifyArguments := *openapiclient.NewNdmpServerModifyArguments() // NdmpServerModifyArguments | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.FileApi.ModifyNDMPServer(context.Background(), symmetrixId, ndmpServerId).NdmpServerModifyArguments(ndmpServerModifyArguments).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `FileApi.ModifyNDMPServer``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `ModifyNDMPServer`: NdmpServer
    fmt.Fprintf(os.Stdout, "Response from `FileApi.ModifyNDMPServer`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**symmetrixId** | **string** | The ArrayId | 
**ndmpServerId** | **string** | The ArrayId | 

### Other Parameters

Other parameters are passed through a pointer to a apiModifyNDMPServerRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


 **ndmpServerModifyArguments** | [**NdmpServerModifyArguments**](NdmpServerModifyArguments.md) |  | 

### Return type

[**NdmpServer**](NdmpServer.md)

### Authorization

[apiSecurity](../README.md#apiSecurity)

### HTTP request headers

- **Content-Type**: application/json, application/xml
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## ModifyNFSExport

> Export ModifyNFSExport(ctx, symmetrixId, nfsExportId).ExportModifyArguments(exportModifyArguments).Execute()

Modify NFS Export



### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    symmetrixId := "symmetrixId_example" // string | The ArrayId
    nfsExportId := "nfsExportId_example" // string | The nfs_export_id
    exportModifyArguments := *openapiclient.NewExportModifyArguments() // ExportModifyArguments | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.FileApi.ModifyNFSExport(context.Background(), symmetrixId, nfsExportId).ExportModifyArguments(exportModifyArguments).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `FileApi.ModifyNFSExport``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `ModifyNFSExport`: Export
    fmt.Fprintf(os.Stdout, "Response from `FileApi.ModifyNFSExport`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**symmetrixId** | **string** | The ArrayId | 
**nfsExportId** | **string** | The nfs_export_id | 

### Other Parameters

Other parameters are passed through a pointer to a apiModifyNFSExportRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


 **exportModifyArguments** | [**ExportModifyArguments**](ExportModifyArguments.md) |  | 

### Return type

[**Export**](Export.md)

### Authorization

[apiSecurity](../README.md#apiSecurity)

### HTTP request headers

- **Content-Type**: application/json, application/xml
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## ModifyNFSServer

> NfsServer ModifyNFSServer(ctx, symmetrixId, nfsServerId).NfsServerModifyArguments(nfsServerModifyArguments).Execute()

Modify NFS Server



### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    symmetrixId := "symmetrixId_example" // string | The ArrayId
    nfsServerId := "nfsServerId_example" // string | The nfs_server_id
    nfsServerModifyArguments := *openapiclient.NewNfsServerModifyArguments() // NfsServerModifyArguments | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.FileApi.ModifyNFSServer(context.Background(), symmetrixId, nfsServerId).NfsServerModifyArguments(nfsServerModifyArguments).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `FileApi.ModifyNFSServer``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `ModifyNFSServer`: NfsServer
    fmt.Fprintf(os.Stdout, "Response from `FileApi.ModifyNFSServer`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**symmetrixId** | **string** | The ArrayId | 
**nfsServerId** | **string** | The nfs_server_id | 

### Other Parameters

Other parameters are passed through a pointer to a apiModifyNFSServerRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


 **nfsServerModifyArguments** | [**NfsServerModifyArguments**](NfsServerModifyArguments.md) |  | 

### Return type

[**NfsServer**](NfsServer.md)

### Authorization

[apiSecurity](../README.md#apiSecurity)

### HTTP request headers

- **Content-Type**: application/json, application/xml
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## ModifyNISService

> NisService ModifyNISService(ctx, symmetrixId, nisServiceId).NisModifyArguments(nisModifyArguments).Execute()

Modify Nis Service



### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    symmetrixId := "symmetrixId_example" // string | The Array ID 
    nisServiceId := "nisServiceId_example" // string | The nis service ID 
    nisModifyArguments := *openapiclient.NewNisModifyArguments() // NisModifyArguments | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.FileApi.ModifyNISService(context.Background(), symmetrixId, nisServiceId).NisModifyArguments(nisModifyArguments).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `FileApi.ModifyNISService``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `ModifyNISService`: NisService
    fmt.Fprintf(os.Stdout, "Response from `FileApi.ModifyNISService`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**symmetrixId** | **string** | The Array ID  | 
**nisServiceId** | **string** | The nis service ID  | 

### Other Parameters

Other parameters are passed through a pointer to a apiModifyNISServiceRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


 **nisModifyArguments** | [**NisModifyArguments**](NisModifyArguments.md) |  | 

### Return type

[**NisService**](NisService.md)

### Authorization

[apiSecurity](../README.md#apiSecurity)

### HTTP request headers

- **Content-Type**: application/json, application/xml
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## ModifyNasServer

> NasServer ModifyNasServer(ctx, symmetrixId, nasServerId).NasServerModifyArguments(nasServerModifyArguments).Execute()

Modify Nas server



### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    symmetrixId := "symmetrixId_example" // string | The array ID
    nasServerId := "nasServerId_example" // string | The NasServer ID
    nasServerModifyArguments := *openapiclient.NewNasServerModifyArguments() // NasServerModifyArguments | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.FileApi.ModifyNasServer(context.Background(), symmetrixId, nasServerId).NasServerModifyArguments(nasServerModifyArguments).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `FileApi.ModifyNasServer``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `ModifyNasServer`: NasServer
    fmt.Fprintf(os.Stdout, "Response from `FileApi.ModifyNasServer`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**symmetrixId** | **string** | The array ID | 
**nasServerId** | **string** | The NasServer ID | 

### Other Parameters

Other parameters are passed through a pointer to a apiModifyNasServerRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


 **nasServerModifyArguments** | [**NasServerModifyArguments**](NasServerModifyArguments.md) |  | 

### Return type

[**NasServer**](NasServer.md)

### Authorization

[apiSecurity](../README.md#apiSecurity)

### HTTP request headers

- **Content-Type**: application/json, application/xml
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## ModifyNetworkDeviceMtu

> ModifyNetworkDeviceMtu(ctx, symmetrixId).NetworkAssignSubnetArguments(networkAssignSubnetArguments).Execute()

Network Device MTU Update



### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    symmetrixId := "symmetrixId_example" // string | The ArrayId
    networkAssignSubnetArguments := *openapiclient.NewNetworkAssignSubnetArguments() // NetworkAssignSubnetArguments | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.FileApi.ModifyNetworkDeviceMtu(context.Background(), symmetrixId).NetworkAssignSubnetArguments(networkAssignSubnetArguments).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `FileApi.ModifyNetworkDeviceMtu``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**symmetrixId** | **string** | The ArrayId | 

### Other Parameters

Other parameters are passed through a pointer to a apiModifyNetworkDeviceMtuRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **networkAssignSubnetArguments** | [**NetworkAssignSubnetArguments**](NetworkAssignSubnetArguments.md) |  | 

### Return type

 (empty response body)

### Authorization

[apiSecurity](../README.md#apiSecurity)

### HTTP request headers

- **Content-Type**: application/json, application/xml
- **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## ModifyRemoteSystem

> RemoteSystem ModifyRemoteSystem(ctx, symmetrixId, remoteSystemId).RemoteSystemModifyArguments(remoteSystemModifyArguments).Execute()

Modify Remote System



### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    symmetrixId := "symmetrixId_example" // string | The ArrayId
    remoteSystemId := "remoteSystemId_example" // string | The remote_system_id
    remoteSystemModifyArguments := *openapiclient.NewRemoteSystemModifyArguments() // RemoteSystemModifyArguments | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.FileApi.ModifyRemoteSystem(context.Background(), symmetrixId, remoteSystemId).RemoteSystemModifyArguments(remoteSystemModifyArguments).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `FileApi.ModifyRemoteSystem``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `ModifyRemoteSystem`: RemoteSystem
    fmt.Fprintf(os.Stdout, "Response from `FileApi.ModifyRemoteSystem`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**symmetrixId** | **string** | The ArrayId | 
**remoteSystemId** | **string** | The remote_system_id | 

### Other Parameters

Other parameters are passed through a pointer to a apiModifyRemoteSystemRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


 **remoteSystemModifyArguments** | [**RemoteSystemModifyArguments**](RemoteSystemModifyArguments.md) |  | 

### Return type

[**RemoteSystem**](RemoteSystem.md)

### Authorization

[apiSecurity](../README.md#apiSecurity)

### HTTP request headers

- **Content-Type**: application/json, application/xml
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## ModifyRoute

> Route ModifyRoute(ctx, symmetrixId, routeId).RouteModifyArguments(routeModifyArguments).Execute()

Modify Routes



### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    symmetrixId := "symmetrixId_example" // string | The ArrayId
    routeId := "routeId_example" // string | The route_id
    routeModifyArguments := *openapiclient.NewRouteModifyArguments("Destination_example") // RouteModifyArguments | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.FileApi.ModifyRoute(context.Background(), symmetrixId, routeId).RouteModifyArguments(routeModifyArguments).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `FileApi.ModifyRoute``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `ModifyRoute`: Route
    fmt.Fprintf(os.Stdout, "Response from `FileApi.ModifyRoute`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**symmetrixId** | **string** | The ArrayId | 
**routeId** | **string** | The route_id | 

### Other Parameters

Other parameters are passed through a pointer to a apiModifyRouteRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


 **routeModifyArguments** | [**RouteModifyArguments**](RouteModifyArguments.md) |  | 

### Return type

[**Route**](Route.md)

### Authorization

[apiSecurity](../README.md#apiSecurity)

### HTTP request headers

- **Content-Type**: application/json, application/xml
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## ModifySMBServer

> SmbServerInstance ModifySMBServer(ctx, symmetrixId, smbServerId).SmbServerModifyArguments(smbServerModifyArguments).Execute()

Modify SMB Server



### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    symmetrixId := "symmetrixId_example" // string | The ArrayId
    smbServerId := "smbServerId_example" // string | The smb_server_id
    smbServerModifyArguments := *openapiclient.NewSmbServerModifyArguments() // SmbServerModifyArguments | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.FileApi.ModifySMBServer(context.Background(), symmetrixId, smbServerId).SmbServerModifyArguments(smbServerModifyArguments).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `FileApi.ModifySMBServer``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `ModifySMBServer`: SmbServerInstance
    fmt.Fprintf(os.Stdout, "Response from `FileApi.ModifySMBServer`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**symmetrixId** | **string** | The ArrayId | 
**smbServerId** | **string** | The smb_server_id | 

### Other Parameters

Other parameters are passed through a pointer to a apiModifySMBServerRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


 **smbServerModifyArguments** | [**SmbServerModifyArguments**](SmbServerModifyArguments.md) |  | 

### Return type

[**SmbServerInstance**](SmbServerInstance.md)

### Authorization

[apiSecurity](../README.md#apiSecurity)

### HTTP request headers

- **Content-Type**: application/json, application/xml
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## ModifySMBShare

> SmbShare ModifySMBShare(ctx, symmetrixId, smbShareId).SmbShareModifyArguments(smbShareModifyArguments).Execute()

Modify SMB Share



### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    symmetrixId := "symmetrixId_example" // string | The ArrayId
    smbShareId := "smbShareId_example" // string | The smb_share_id
    smbShareModifyArguments := *openapiclient.NewSmbShareModifyArguments() // SmbShareModifyArguments | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.FileApi.ModifySMBShare(context.Background(), symmetrixId, smbShareId).SmbShareModifyArguments(smbShareModifyArguments).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `FileApi.ModifySMBShare``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `ModifySMBShare`: SmbShare
    fmt.Fprintf(os.Stdout, "Response from `FileApi.ModifySMBShare`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**symmetrixId** | **string** | The ArrayId | 
**smbShareId** | **string** | The smb_share_id | 

### Other Parameters

Other parameters are passed through a pointer to a apiModifySMBShareRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


 **smbShareModifyArguments** | [**SmbShareModifyArguments**](SmbShareModifyArguments.md) |  | 

### Return type

[**SmbShare**](SmbShare.md)

### Authorization

[apiSecurity](../README.md#apiSecurity)

### HTTP request headers

- **Content-Type**: application/json, application/xml
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## ModifySchedule

> Schedule ModifySchedule(ctx, symmetrixId, snapPolicyId).ScheduleModifyArguments(scheduleModifyArguments).Execute()

Modify Snap Schedule



### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    symmetrixId := "symmetrixId_example" // string | The ArrayID
    snapPolicyId := "snapPolicyId_example" // string | The Snap Policy Id
    scheduleModifyArguments := *openapiclient.NewScheduleModifyArguments(int32(123)) // ScheduleModifyArguments | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.FileApi.ModifySchedule(context.Background(), symmetrixId, snapPolicyId).ScheduleModifyArguments(scheduleModifyArguments).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `FileApi.ModifySchedule``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `ModifySchedule`: Schedule
    fmt.Fprintf(os.Stdout, "Response from `FileApi.ModifySchedule`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**symmetrixId** | **string** | The ArrayID | 
**snapPolicyId** | **string** | The Snap Policy Id | 

### Other Parameters

Other parameters are passed through a pointer to a apiModifyScheduleRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


 **scheduleModifyArguments** | [**ScheduleModifyArguments**](ScheduleModifyArguments.md) |  | 

### Return type

[**Schedule**](Schedule.md)

### Authorization

[apiSecurity](../README.md#apiSecurity)

### HTTP request headers

- **Content-Type**: application/json, application/xml
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## ModifySnapshot

> Snapshot ModifySnapshot(ctx, symmetrixId, snapshotId).SnapModifyArguments(snapModifyArguments).Execute()

Modify Snapshot



### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    symmetrixId := "symmetrixId_example" // string | The ArrayId
    snapshotId := "snapshotId_example" // string | The snapshot_id
    snapModifyArguments := *openapiclient.NewSnapModifyArguments() // SnapModifyArguments | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.FileApi.ModifySnapshot(context.Background(), symmetrixId, snapshotId).SnapModifyArguments(snapModifyArguments).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `FileApi.ModifySnapshot``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `ModifySnapshot`: Snapshot
    fmt.Fprintf(os.Stdout, "Response from `FileApi.ModifySnapshot`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**symmetrixId** | **string** | The ArrayId | 
**snapshotId** | **string** | The snapshot_id | 

### Other Parameters

Other parameters are passed through a pointer to a apiModifySnapshotRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


 **snapModifyArguments** | [**SnapModifyArguments**](SnapModifyArguments.md) |  | 

### Return type

[**Snapshot**](Snapshot.md)

### Authorization

[apiSecurity](../README.md#apiSecurity)

### HTTP request headers

- **Content-Type**: application/json, application/xml
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## ModifySubnet

> NetworkDevice ModifySubnet(ctx, symmetrixId).NetworkAssignSubnetArguments(networkAssignSubnetArguments).Execute()

Modify subnet 



### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    symmetrixId := "symmetrixId_example" // string | The ArrayId
    networkAssignSubnetArguments := *openapiclient.NewNetworkAssignSubnetArguments() // NetworkAssignSubnetArguments | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.FileApi.ModifySubnet(context.Background(), symmetrixId).NetworkAssignSubnetArguments(networkAssignSubnetArguments).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `FileApi.ModifySubnet``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `ModifySubnet`: NetworkDevice
    fmt.Fprintf(os.Stdout, "Response from `FileApi.ModifySubnet`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**symmetrixId** | **string** | The ArrayId | 

### Other Parameters

Other parameters are passed through a pointer to a apiModifySubnetRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **networkAssignSubnetArguments** | [**NetworkAssignSubnetArguments**](NetworkAssignSubnetArguments.md) |  | 

### Return type

[**NetworkDevice**](NetworkDevice.md)

### Authorization

[apiSecurity](../README.md#apiSecurity)

### HTTP request headers

- **Content-Type**: application/json, application/xml
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## ModifySubnet1

> NetworkAssignSubnetArguments ModifySubnet1(ctx, symmetrixId).ModifyNetwork(modifyNetwork).Execute()

display Network Device 



### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    symmetrixId := "symmetrixId_example" // string | The ArrayId
    modifyNetwork := *openapiclient.NewModifyNetwork([]openapiclient.NetworkDevice{*openapiclient.NewNetworkDevice()}) // ModifyNetwork | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.FileApi.ModifySubnet1(context.Background(), symmetrixId).ModifyNetwork(modifyNetwork).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `FileApi.ModifySubnet1``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `ModifySubnet1`: NetworkAssignSubnetArguments
    fmt.Fprintf(os.Stdout, "Response from `FileApi.ModifySubnet1`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**symmetrixId** | **string** | The ArrayId | 

### Other Parameters

Other parameters are passed through a pointer to a apiModifySubnet1Request struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **modifyNetwork** | [**ModifyNetwork**](ModifyNetwork.md) |  | 

### Return type

[**NetworkAssignSubnetArguments**](NetworkAssignSubnetArguments.md)

### Authorization

[apiSecurity](../README.md#apiSecurity)

### HTTP request headers

- **Content-Type**: application/json, application/xml
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## ModifyTreeQuota

> TreeQuota ModifyTreeQuota(ctx, symmetrixId, fileSystemId, treeQuotaId).TreeQuotaModifyArguments(treeQuotaModifyArguments).Execute()

Modify Tree Quota



### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    symmetrixId := "symmetrixId_example" // string | The ArrayId
    fileSystemId := "fileSystemId_example" // string | The file_system_id
    treeQuotaId := "treeQuotaId_example" // string | The tree_quota_id
    treeQuotaModifyArguments := *openapiclient.NewTreeQuotaModifyArguments() // TreeQuotaModifyArguments | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.FileApi.ModifyTreeQuota(context.Background(), symmetrixId, fileSystemId, treeQuotaId).TreeQuotaModifyArguments(treeQuotaModifyArguments).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `FileApi.ModifyTreeQuota``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `ModifyTreeQuota`: TreeQuota
    fmt.Fprintf(os.Stdout, "Response from `FileApi.ModifyTreeQuota`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**symmetrixId** | **string** | The ArrayId | 
**fileSystemId** | **string** | The file_system_id | 
**treeQuotaId** | **string** | The tree_quota_id | 

### Other Parameters

Other parameters are passed through a pointer to a apiModifyTreeQuotaRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------



 **treeQuotaModifyArguments** | [**TreeQuotaModifyArguments**](TreeQuotaModifyArguments.md) |  | 

### Return type

[**TreeQuota**](TreeQuota.md)

### Authorization

[apiSecurity](../README.md#apiSecurity)

### HTTP request headers

- **Content-Type**: application/json, application/xml
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## ModifyUserQuota

> UserQuota ModifyUserQuota(ctx, symmetrixId, fileSystemId, userQuotaId).UserQuotaModifyArguments(userQuotaModifyArguments).Execute()

Modify User Quota



### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    symmetrixId := "symmetrixId_example" // string | The ArrayId
    fileSystemId := "fileSystemId_example" // string | The file_system_id
    userQuotaId := "userQuotaId_example" // string | The user_quota_id
    userQuotaModifyArguments := *openapiclient.NewUserQuotaModifyArguments() // UserQuotaModifyArguments | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.FileApi.ModifyUserQuota(context.Background(), symmetrixId, fileSystemId, userQuotaId).UserQuotaModifyArguments(userQuotaModifyArguments).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `FileApi.ModifyUserQuota``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `ModifyUserQuota`: UserQuota
    fmt.Fprintf(os.Stdout, "Response from `FileApi.ModifyUserQuota`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**symmetrixId** | **string** | The ArrayId | 
**fileSystemId** | **string** | The file_system_id | 
**userQuotaId** | **string** | The user_quota_id | 

### Other Parameters

Other parameters are passed through a pointer to a apiModifyUserQuotaRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------



 **userQuotaModifyArguments** | [**UserQuotaModifyArguments**](UserQuotaModifyArguments.md) |  | 

### Return type

[**UserQuota**](UserQuota.md)

### Authorization

[apiSecurity](../README.md#apiSecurity)

### HTTP request headers

- **Content-Type**: application/json, application/xml
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## ModifyVirusChecker

> VirusChecker ModifyVirusChecker(ctx, symmetrixId, virusCheckerId).VirusCheckerModifyArguments(virusCheckerModifyArguments).Execute()

Modify Virus checker



### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    symmetrixId := "symmetrixId_example" // string | The ArrayId
    virusCheckerId := "virusCheckerId_example" // string | The virus_checker_id
    virusCheckerModifyArguments := *openapiclient.NewVirusCheckerModifyArguments() // VirusCheckerModifyArguments | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.FileApi.ModifyVirusChecker(context.Background(), symmetrixId, virusCheckerId).VirusCheckerModifyArguments(virusCheckerModifyArguments).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `FileApi.ModifyVirusChecker``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `ModifyVirusChecker`: VirusChecker
    fmt.Fprintf(os.Stdout, "Response from `FileApi.ModifyVirusChecker`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**symmetrixId** | **string** | The ArrayId | 
**virusCheckerId** | **string** | The virus_checker_id | 

### Other Parameters

Other parameters are passed through a pointer to a apiModifyVirusCheckerRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


 **virusCheckerModifyArguments** | [**VirusCheckerModifyArguments**](VirusCheckerModifyArguments.md) |  | 

### Return type

[**VirusChecker**](VirusChecker.md)

### Authorization

[apiSecurity](../README.md#apiSecurity)

### HTTP request headers

- **Content-Type**: application/json, application/xml
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## PingNasServer

> Ping PingNasServer(ctx, symmetrixId, nasServerId).NasServerPingArguments(nasServerPingArguments).Execute()

Create NASServer Ping request 



### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    symmetrixId := "symmetrixId_example" // string | 
    nasServerId := "nasServerId_example" // string | 
    nasServerPingArguments := *openapiclient.NewNasServerPingArguments() // NasServerPingArguments | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.FileApi.PingNasServer(context.Background(), symmetrixId, nasServerId).NasServerPingArguments(nasServerPingArguments).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `FileApi.PingNasServer``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `PingNasServer`: Ping
    fmt.Fprintf(os.Stdout, "Response from `FileApi.PingNasServer`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**symmetrixId** | **string** |  | 
**nasServerId** | **string** |  | 

### Other Parameters

Other parameters are passed through a pointer to a apiPingNasServerRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


 **nasServerPingArguments** | [**NasServerPingArguments**](NasServerPingArguments.md) |  | 

### Return type

[**Ping**](Ping.md)

### Authorization

[apiSecurity](../README.md#apiSecurity)

### HTTP request headers

- **Content-Type**: application/json, application/xml
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## RefreshQuotas

> RefreshQuotas(ctx, symmetrixId, fileSystemId).Execute()

refresh quotas FileSystem  



### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    symmetrixId := "symmetrixId_example" // string | The Array ID
    fileSystemId := "fileSystemId_example" // string | The file_system_id

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.FileApi.RefreshQuotas(context.Background(), symmetrixId, fileSystemId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `FileApi.RefreshQuotas``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**symmetrixId** | **string** | The Array ID | 
**fileSystemId** | **string** | The file_system_id | 

### Other Parameters

Other parameters are passed through a pointer to a apiRefreshQuotasRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------



### Return type

 (empty response body)

### Authorization

[apiSecurity](../README.md#apiSecurity)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## RefreshTreeQuota

> RefreshTreeQuota(ctx, symmetrixId, fileSystemId, treeQuotaId).Execute()

Refresh Tree Quota



### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    symmetrixId := "symmetrixId_example" // string | The ArrayId
    fileSystemId := "fileSystemId_example" // string | The file_system_id
    treeQuotaId := "treeQuotaId_example" // string | The tree_quota_id

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.FileApi.RefreshTreeQuota(context.Background(), symmetrixId, fileSystemId, treeQuotaId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `FileApi.RefreshTreeQuota``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**symmetrixId** | **string** | The ArrayId | 
**fileSystemId** | **string** | The file_system_id | 
**treeQuotaId** | **string** | The tree_quota_id | 

### Other Parameters

Other parameters are passed through a pointer to a apiRefreshTreeQuotaRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------




### Return type

 (empty response body)

### Authorization

[apiSecurity](../README.md#apiSecurity)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## RefreshUserQuota

> RefreshUserQuota(ctx, symmetrixId, fileSystemId, userQuotaId).Execute()

Modify User Quota



### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    symmetrixId := "symmetrixId_example" // string | The ArrayId
    fileSystemId := "fileSystemId_example" // string | The ArrayId
    userQuotaId := "userQuotaId_example" // string | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.FileApi.RefreshUserQuota(context.Background(), symmetrixId, fileSystemId, userQuotaId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `FileApi.RefreshUserQuota``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**symmetrixId** | **string** | The ArrayId | 
**fileSystemId** | **string** | The ArrayId | 
**userQuotaId** | **string** |  | 

### Other Parameters

Other parameters are passed through a pointer to a apiRefreshUserQuotaRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------




### Return type

 (empty response body)

### Authorization

[apiSecurity](../README.md#apiSecurity)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## RestoreAccessGlobalNamespace

> RestoreAccessGlobalNamespace(ctx, symmetrixId, unifiedNamespaceId).Execute()

restore access GlobalNameSpace



### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    symmetrixId := "symmetrixId_example" // string | The ArrayId
    unifiedNamespaceId := "unifiedNamespaceId_example" // string | The unified_namespace_id

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.FileApi.RestoreAccessGlobalNamespace(context.Background(), symmetrixId, unifiedNamespaceId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `FileApi.RestoreAccessGlobalNamespace``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**symmetrixId** | **string** | The ArrayId | 
**unifiedNamespaceId** | **string** | The unified_namespace_id | 

### Other Parameters

Other parameters are passed through a pointer to a apiRestoreAccessGlobalNamespaceRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------



### Return type

 (empty response body)

### Authorization

[apiSecurity](../README.md#apiSecurity)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## ReverseReplicationSession

> ReverseReplicationSession(ctx, symmetrixId, replicationSessionId).Execute()

Reverse Replication session 



### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    symmetrixId := "symmetrixId_example" // string | The ArrayId
    replicationSessionId := "replicationSessionId_example" // string | The replication_session_id

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.FileApi.ReverseReplicationSession(context.Background(), symmetrixId, replicationSessionId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `FileApi.ReverseReplicationSession``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**symmetrixId** | **string** | The ArrayId | 
**replicationSessionId** | **string** | The replication_session_id | 

### Other Parameters

Other parameters are passed through a pointer to a apiReverseReplicationSessionRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------



### Return type

 (empty response body)

### Authorization

[apiSecurity](../README.md#apiSecurity)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## SetBackupNode

> SetBackupNode(ctx, symmetrixId, nasServerId).NodeDeviceArguments(nodeDeviceArguments).Execute()

Set Backup node 



### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    symmetrixId := "symmetrixId_example" // string | 
    nasServerId := "nasServerId_example" // string | 
    nodeDeviceArguments := *openapiclient.NewNodeDeviceArguments() // NodeDeviceArguments | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.FileApi.SetBackupNode(context.Background(), symmetrixId, nasServerId).NodeDeviceArguments(nodeDeviceArguments).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `FileApi.SetBackupNode``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**symmetrixId** | **string** |  | 
**nasServerId** | **string** |  | 

### Other Parameters

Other parameters are passed through a pointer to a apiSetBackupNodeRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


 **nodeDeviceArguments** | [**NodeDeviceArguments**](NodeDeviceArguments.md) |  | 

### Return type

 (empty response body)

### Authorization

[apiSecurity](../README.md#apiSecurity)

### HTTP request headers

- **Content-Type**: application/json, application/xml
- **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## SetPrimaryNode

> SetPrimaryNode(ctx, symmetrixId, nasServerId).NodeDeviceArguments(nodeDeviceArguments).Execute()

Set Primary node 



### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    symmetrixId := "symmetrixId_example" // string | 
    nasServerId := "nasServerId_example" // string | 
    nodeDeviceArguments := *openapiclient.NewNodeDeviceArguments() // NodeDeviceArguments | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.FileApi.SetPrimaryNode(context.Background(), symmetrixId, nasServerId).NodeDeviceArguments(nodeDeviceArguments).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `FileApi.SetPrimaryNode``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**symmetrixId** | **string** |  | 
**nasServerId** | **string** |  | 

### Other Parameters

Other parameters are passed through a pointer to a apiSetPrimaryNodeRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


 **nodeDeviceArguments** | [**NodeDeviceArguments**](NodeDeviceArguments.md) |  | 

### Return type

 (empty response body)

### Authorization

[apiSecurity](../README.md#apiSecurity)

### HTTP request headers

- **Content-Type**: application/json, application/xml
- **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## SetQuotaConfig

> SetQuotaConfig(ctx, symmetrixId, fileSystemId).SetFilesystemQuotasArguments(setFilesystemQuotasArguments).Execute()

Quota setting FileSystem  



### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    symmetrixId := "symmetrixId_example" // string | The file_system_id
    fileSystemId := "fileSystemId_example" // string | The file_system_id
    setFilesystemQuotasArguments := *openapiclient.NewSetFilesystemQuotasArguments() // SetFilesystemQuotasArguments | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.FileApi.SetQuotaConfig(context.Background(), symmetrixId, fileSystemId).SetFilesystemQuotasArguments(setFilesystemQuotasArguments).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `FileApi.SetQuotaConfig``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**symmetrixId** | **string** | The file_system_id | 
**fileSystemId** | **string** | The file_system_id | 

### Other Parameters

Other parameters are passed through a pointer to a apiSetQuotaConfigRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


 **setFilesystemQuotasArguments** | [**SetFilesystemQuotasArguments**](SetFilesystemQuotasArguments.md) |  | 

### Return type

 (empty response body)

### Authorization

[apiSecurity](../README.md#apiSecurity)

### HTTP request headers

- **Content-Type**: application/json, application/xml
- **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## SnapShotClone

> Snapshot SnapShotClone(ctx, symmetrixId, snapshotId).SnapCloneArguments(snapCloneArguments).Execute()

Create Snapshot 



### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    symmetrixId := "symmetrixId_example" // string | The ArrayId
    snapshotId := "snapshotId_example" // string | The snapshot_id
    snapCloneArguments := *openapiclient.NewSnapCloneArguments() // SnapCloneArguments | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.FileApi.SnapShotClone(context.Background(), symmetrixId, snapshotId).SnapCloneArguments(snapCloneArguments).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `FileApi.SnapShotClone``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `SnapShotClone`: Snapshot
    fmt.Fprintf(os.Stdout, "Response from `FileApi.SnapShotClone`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**symmetrixId** | **string** | The ArrayId | 
**snapshotId** | **string** | The snapshot_id | 

### Other Parameters

Other parameters are passed through a pointer to a apiSnapShotCloneRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


 **snapCloneArguments** | [**SnapCloneArguments**](SnapCloneArguments.md) |  | 

### Return type

[**Snapshot**](Snapshot.md)

### Authorization

[apiSecurity](../README.md#apiSecurity)

### HTTP request headers

- **Content-Type**: application/json, application/xml
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## SnapshotRefresh

> SnapshotRefresh(ctx, symmetrixId, snapshotId).Execute()

Delete Snapshot



### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    symmetrixId := "symmetrixId_example" // string | The ArrayId
    snapshotId := "snapshotId_example" // string | The snapshot_id

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.FileApi.SnapshotRefresh(context.Background(), symmetrixId, snapshotId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `FileApi.SnapshotRefresh``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**symmetrixId** | **string** | The ArrayId | 
**snapshotId** | **string** | The snapshot_id | 

### Other Parameters

Other parameters are passed through a pointer to a apiSnapshotRefreshRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------



### Return type

 (empty response body)

### Authorization

[apiSecurity](../README.md#apiSecurity)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## SnapshotRestore

> SnapshotRestore(ctx, symmetrixId, snapshotId).SnapRestoreArgument(snapRestoreArgument).Execute()

Create Snapshot 



### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    symmetrixId := "symmetrixId_example" // string | The ArrayId
    snapshotId := "snapshotId_example" // string | The snapshot_id
    snapRestoreArgument := *openapiclient.NewSnapRestoreArgument() // SnapRestoreArgument | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.FileApi.SnapshotRestore(context.Background(), symmetrixId, snapshotId).SnapRestoreArgument(snapRestoreArgument).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `FileApi.SnapshotRestore``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**symmetrixId** | **string** | The ArrayId | 
**snapshotId** | **string** | The snapshot_id | 

### Other Parameters

Other parameters are passed through a pointer to a apiSnapshotRestoreRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


 **snapRestoreArgument** | [**SnapRestoreArgument**](SnapRestoreArgument.md) |  | 

### Return type

 (empty response body)

### Authorization

[apiSecurity](../README.md#apiSecurity)

### HTTP request headers

- **Content-Type**: application/json, application/xml
- **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## StartReplicationSession

> StartReplicationSession(ctx, symmetrixId, replicationSessionId).ReplicationSessionStartArguments(replicationSessionStartArguments).Execute()

Start Replication session 



### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    symmetrixId := "symmetrixId_example" // string | The ArrayId
    replicationSessionId := "replicationSessionId_example" // string | The replication_session_id
    replicationSessionStartArguments := *openapiclient.NewReplicationSessionStartArguments() // ReplicationSessionStartArguments | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.FileApi.StartReplicationSession(context.Background(), symmetrixId, replicationSessionId).ReplicationSessionStartArguments(replicationSessionStartArguments).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `FileApi.StartReplicationSession``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**symmetrixId** | **string** | The ArrayId | 
**replicationSessionId** | **string** | The replication_session_id | 

### Other Parameters

Other parameters are passed through a pointer to a apiStartReplicationSessionRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


 **replicationSessionStartArguments** | [**ReplicationSessionStartArguments**](ReplicationSessionStartArguments.md) |  | 

### Return type

 (empty response body)

### Authorization

[apiSecurity](../README.md#apiSecurity)

### HTTP request headers

- **Content-Type**: application/json, application/xml
- **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## StopReplicationSession

> StopReplicationSession(ctx, symmetrixId, replicationSessionId).Execute()

Stop Replication session 



### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    symmetrixId := "symmetrixId_example" // string | The ArrayId
    replicationSessionId := "replicationSessionId_example" // string | The replication_session_id

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.FileApi.StopReplicationSession(context.Background(), symmetrixId, replicationSessionId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `FileApi.StopReplicationSession``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**symmetrixId** | **string** | The ArrayId | 
**replicationSessionId** | **string** | The replication_session_id | 

### Other Parameters

Other parameters are passed through a pointer to a apiStopReplicationSessionRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------



### Return type

 (empty response body)

### Authorization

[apiSecurity](../README.md#apiSecurity)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## SwapNodesNasServer

> SwapNodesNasServer(ctx, symmetrixId, nasServerId).Execute()

Set swap node 



### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    symmetrixId := "symmetrixId_example" // string | 
    nasServerId := "nasServerId_example" // string | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.FileApi.SwapNodesNasServer(context.Background(), symmetrixId, nasServerId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `FileApi.SwapNodesNasServer``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**symmetrixId** | **string** |  | 
**nasServerId** | **string** |  | 

### Other Parameters

Other parameters are passed through a pointer to a apiSwapNodesNasServerRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------



### Return type

 (empty response body)

### Authorization

[apiSecurity](../README.md#apiSecurity)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## SwitchOverReplicationSession

> SwitchOverReplicationSession(ctx, symmetrixId, replicationSessionId).Execute()

Switchover Replication session 



### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    symmetrixId := "symmetrixId_example" // string | The ArrayId
    replicationSessionId := "replicationSessionId_example" // string | The replication_session_id

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.FileApi.SwitchOverReplicationSession(context.Background(), symmetrixId, replicationSessionId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `FileApi.SwitchOverReplicationSession``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**symmetrixId** | **string** | The ArrayId | 
**replicationSessionId** | **string** | The replication_session_id | 

### Other Parameters

Other parameters are passed through a pointer to a apiSwitchOverReplicationSessionRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------



### Return type

 (empty response body)

### Authorization

[apiSecurity](../README.md#apiSecurity)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## TestRemoteSystem

> TestRemoteSystem(ctx, symmetrixId, remoteSystemId).RemoteSystemTestArguments(remoteSystemTestArguments).Execute()

Test Remote System



### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    symmetrixId := "symmetrixId_example" // string | 
    remoteSystemId := "remoteSystemId_example" // string | 
    remoteSystemTestArguments := *openapiclient.NewRemoteSystemTestArguments("NasServer_example", []openapiclient.RemoteNode{*openapiclient.NewRemoteNode()}) // RemoteSystemTestArguments | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.FileApi.TestRemoteSystem(context.Background(), symmetrixId, remoteSystemId).RemoteSystemTestArguments(remoteSystemTestArguments).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `FileApi.TestRemoteSystem``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**symmetrixId** | **string** |  | 
**remoteSystemId** | **string** |  | 

### Other Parameters

Other parameters are passed through a pointer to a apiTestRemoteSystemRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


 **remoteSystemTestArguments** | [**RemoteSystemTestArguments**](RemoteSystemTestArguments.md) |  | 

### Return type

 (empty response body)

### Authorization

[apiSecurity](../README.md#apiSecurity)

### HTTP request headers

- **Content-Type**: application/json, application/xml
- **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UnJoinSMBServer

> UnJoinSMBServer(ctx, symmetrixId, smbServerId).SmbServerUnjoinArguments(smbServerUnjoinArguments).Execute()

unjoin SMB Server to active directory



### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    symmetrixId := "symmetrixId_example" // string | 
    smbServerId := "smbServerId_example" // string | 
    smbServerUnjoinArguments := *openapiclient.NewSmbServerUnjoinArguments("DomainUserName_example", "DomainPassword_example") // SmbServerUnjoinArguments | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.FileApi.UnJoinSMBServer(context.Background(), symmetrixId, smbServerId).SmbServerUnjoinArguments(smbServerUnjoinArguments).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `FileApi.UnJoinSMBServer``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**symmetrixId** | **string** |  | 
**smbServerId** | **string** |  | 

### Other Parameters

Other parameters are passed through a pointer to a apiUnJoinSMBServerRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


 **smbServerUnjoinArguments** | [**SmbServerUnjoinArguments**](SmbServerUnjoinArguments.md) |  | 

### Return type

 (empty response body)

### Authorization

[apiSecurity](../README.md#apiSecurity)

### HTTP request headers

- **Content-Type**: application/json, application/xml
- **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UnjoinNFSServer

> UnjoinNFSServer(ctx, symmetrixId, nfsServerId).NfsServerUnjoinArguments(nfsServerUnjoinArguments).Execute()

Create NFS Server 



### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    symmetrixId := "symmetrixId_example" // string | The ArrayId
    nfsServerId := "nfsServerId_example" // string | The nfs_server_id
    nfsServerUnjoinArguments := *openapiclient.NewNfsServerUnjoinArguments() // NfsServerUnjoinArguments | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.FileApi.UnjoinNFSServer(context.Background(), symmetrixId, nfsServerId).NfsServerUnjoinArguments(nfsServerUnjoinArguments).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `FileApi.UnjoinNFSServer``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**symmetrixId** | **string** | The ArrayId | 
**nfsServerId** | **string** | The nfs_server_id | 

### Other Parameters

Other parameters are passed through a pointer to a apiUnjoinNFSServerRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


 **nfsServerUnjoinArguments** | [**NfsServerUnjoinArguments**](NfsServerUnjoinArguments.md) |  | 

### Return type

 (empty response body)

### Authorization

[apiSecurity](../README.md#apiSecurity)

### HTTP request headers

- **Content-Type**: application/json, application/xml
- **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdateReplicationSession

> UpdateReplicationSession(ctx, symmetrixId, replicationSessionId).Execute()

Update Replication session 



### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    symmetrixId := "symmetrixId_example" // string | The ArrayId
    replicationSessionId := "replicationSessionId_example" // string | The replication_session_id

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.FileApi.UpdateReplicationSession(context.Background(), symmetrixId, replicationSessionId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `FileApi.UpdateReplicationSession``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**symmetrixId** | **string** | The ArrayId | 
**replicationSessionId** | **string** | The replication_session_id | 

### Other Parameters

Other parameters are passed through a pointer to a apiUpdateReplicationSessionRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------



### Return type

 (empty response body)

### Authorization

[apiSecurity](../README.md#apiSecurity)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UploadCertificateLDAPService

> UploadCertificateLDAPService(ctx, symmetrixId, ldapServiceId).Execute()

upload Ldap Service certification



### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    symmetrixId := "symmetrixId_example" // string | The Array ID
    ldapServiceId := "ldapServiceId_example" // string | The ldap_service_id

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.FileApi.UploadCertificateLDAPService(context.Background(), symmetrixId, ldapServiceId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `FileApi.UploadCertificateLDAPService``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**symmetrixId** | **string** | The Array ID | 
**ldapServiceId** | **string** | The ldap_service_id | 

### Other Parameters

Other parameters are passed through a pointer to a apiUploadCertificateLDAPServiceRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------



### Return type

 (empty response body)

### Authorization

[apiSecurity](../README.md#apiSecurity)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UploadConfigLDAPService

> UploadConfigLDAPService(ctx, symmetrixId, ldapServiceId).Execute()

Modify Ldap Service



### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    symmetrixId := "symmetrixId_example" // string | 
    ldapServiceId := "ldapServiceId_example" // string | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.FileApi.UploadConfigLDAPService(context.Background(), symmetrixId, ldapServiceId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `FileApi.UploadConfigLDAPService``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**symmetrixId** | **string** |  | 
**ldapServiceId** | **string** |  | 

### Other Parameters

Other parameters are passed through a pointer to a apiUploadConfigLDAPServiceRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------



### Return type

 (empty response body)

### Authorization

[apiSecurity](../README.md#apiSecurity)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UploadConfigVirusChecker

> UploadConfigVirusChecker(ctx, symmetrixId, virusCheckerId).Execute()

upload Virtus checker config



### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    symmetrixId := "symmetrixId_example" // string | The ArrayId
    virusCheckerId := "virusCheckerId_example" // string | The virus_checker_id

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.FileApi.UploadConfigVirusChecker(context.Background(), symmetrixId, virusCheckerId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `FileApi.UploadConfigVirusChecker``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**symmetrixId** | **string** | The ArrayId | 
**virusCheckerId** | **string** | The virus_checker_id | 

### Other Parameters

Other parameters are passed through a pointer to a apiUploadConfigVirusCheckerRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------



### Return type

 (empty response body)

### Authorization

[apiSecurity](../README.md#apiSecurity)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UploadGroupNasServer

> UploadGroupNasServer(ctx, symmetrixId, nasServerId).Execute()

NASServer upload group 



### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    symmetrixId := "symmetrixId_example" // string | 
    nasServerId := "nasServerId_example" // string | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.FileApi.UploadGroupNasServer(context.Background(), symmetrixId, nasServerId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `FileApi.UploadGroupNasServer``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**symmetrixId** | **string** |  | 
**nasServerId** | **string** |  | 

### Other Parameters

Other parameters are passed through a pointer to a apiUploadGroupNasServerRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------



### Return type

 (empty response body)

### Authorization

[apiSecurity](../README.md#apiSecurity)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UploadHomedirNasServer

> UploadHomedirNasServer(ctx, symmetrixId, nasServerId).Execute()

Create NASServer upload home dir 



### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    symmetrixId := "symmetrixId_example" // string | 
    nasServerId := "nasServerId_example" // string | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.FileApi.UploadHomedirNasServer(context.Background(), symmetrixId, nasServerId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `FileApi.UploadHomedirNasServer``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**symmetrixId** | **string** |  | 
**nasServerId** | **string** |  | 

### Other Parameters

Other parameters are passed through a pointer to a apiUploadHomedirNasServerRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------



### Return type

 (empty response body)

### Authorization

[apiSecurity](../README.md#apiSecurity)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UploadKeytabKerberosService

> UploadKeytabKerberosService(ctx, symmetrixId, kerberosServiceId).Execute()

Upload Kerberos Service



### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    symmetrixId := "symmetrixId_example" // string | 
    kerberosServiceId := "kerberosServiceId_example" // string | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.FileApi.UploadKeytabKerberosService(context.Background(), symmetrixId, kerberosServiceId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `FileApi.UploadKeytabKerberosService``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**symmetrixId** | **string** |  | 
**kerberosServiceId** | **string** |  | 

### Other Parameters

Other parameters are passed through a pointer to a apiUploadKeytabKerberosServiceRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------



### Return type

 (empty response body)

### Authorization

[apiSecurity](../README.md#apiSecurity)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UploadNSSwitchNasServer

> UploadNSSwitchNasServer(ctx, symmetrixId, nasServerId).Execute()

Create NASServer ns_switch hosts 



### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    symmetrixId := "symmetrixId_example" // string | 
    nasServerId := "nasServerId_example" // string | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.FileApi.UploadNSSwitchNasServer(context.Background(), symmetrixId, nasServerId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `FileApi.UploadNSSwitchNasServer``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**symmetrixId** | **string** |  | 
**nasServerId** | **string** |  | 

### Other Parameters

Other parameters are passed through a pointer to a apiUploadNSSwitchNasServerRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------



### Return type

 (empty response body)

### Authorization

[apiSecurity](../README.md#apiSecurity)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UploadNetGroupNasServer

> UploadNetGroupNasServer(ctx, symmetrixId, nasServerId).Execute()

Create NASServer upload net group 



### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    symmetrixId := "symmetrixId_example" // string | 
    nasServerId := "nasServerId_example" // string | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.FileApi.UploadNetGroupNasServer(context.Background(), symmetrixId, nasServerId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `FileApi.UploadNetGroupNasServer``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**symmetrixId** | **string** |  | 
**nasServerId** | **string** |  | 

### Other Parameters

Other parameters are passed through a pointer to a apiUploadNetGroupNasServerRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------



### Return type

 (empty response body)

### Authorization

[apiSecurity](../README.md#apiSecurity)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UploadNtxmapNasServer

> UploadNtxmapNasServer(ctx, symmetrixId, nasServerId).Execute()

Create NASServer upload ntx map 



### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    symmetrixId := "symmetrixId_example" // string | 
    nasServerId := "nasServerId_example" // string | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.FileApi.UploadNtxmapNasServer(context.Background(), symmetrixId, nasServerId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `FileApi.UploadNtxmapNasServer``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**symmetrixId** | **string** |  | 
**nasServerId** | **string** |  | 

### Other Parameters

Other parameters are passed through a pointer to a apiUploadNtxmapNasServerRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------



### Return type

 (empty response body)

### Authorization

[apiSecurity](../README.md#apiSecurity)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UploadPasswdNasServer

> UploadPasswdNasServer(ctx, symmetrixId, nasServerId).Parts(parts).Preamble(preamble).Execute()

Create NASServer Passwd upload 



### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    symmetrixId := "symmetrixId_example" // string | 
    nasServerId := "nasServerId_example" // string | 
    parts := []openapiclient.InputPart{*openapiclient.NewInputPart()} // []InputPart |  (optional)
    preamble := "preamble_example" // string |  (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.FileApi.UploadPasswdNasServer(context.Background(), symmetrixId, nasServerId).Parts(parts).Preamble(preamble).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `FileApi.UploadPasswdNasServer``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**symmetrixId** | **string** |  | 
**nasServerId** | **string** |  | 

### Other Parameters

Other parameters are passed through a pointer to a apiUploadPasswdNasServerRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


 **parts** | [**[]InputPart**](InputPart.md) |  | 
 **preamble** | **string** |  | 

### Return type

 (empty response body)

### Authorization

[apiSecurity](../README.md#apiSecurity)

### HTTP request headers

- **Content-Type**: multipart/form-data
- **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UploadhostsNasServer

> UploadhostsNasServer(ctx, symmetrixId, nasServerId).Execute()

Create NASServer upload hosts 



### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    symmetrixId := "symmetrixId_example" // string | 
    nasServerId := "nasServerId_example" // string | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.FileApi.UploadhostsNasServer(context.Background(), symmetrixId, nasServerId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `FileApi.UploadhostsNasServer``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**symmetrixId** | **string** |  | 
**nasServerId** | **string** |  | 

### Other Parameters

Other parameters are passed through a pointer to a apiUploadhostsNasServerRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------



### Return type

 (empty response body)

### Authorization

[apiSecurity](../README.md#apiSecurity)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UserMapping

> UserMapping(ctx, symmetrixId, nasServerId).Execute()

NASServer user mapping 



### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    symmetrixId := "symmetrixId_example" // string | 
    nasServerId := "nasServerId_example" // string | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.FileApi.UserMapping(context.Background(), symmetrixId, nasServerId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `FileApi.UserMapping``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**symmetrixId** | **string** |  | 
**nasServerId** | **string** |  | 

### Other Parameters

Other parameters are passed through a pointer to a apiUserMappingRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------



### Return type

 (empty response body)

### Authorization

[apiSecurity](../README.md#apiSecurity)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)

