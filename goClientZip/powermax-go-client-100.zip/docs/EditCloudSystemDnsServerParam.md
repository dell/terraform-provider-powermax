# EditCloudSystemDnsServerParam

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ExecutionOption** | Pointer to **string** |  | [optional] [default to "SYNCHRONOUS"]
**EditCloudSystemDnsServerAction** | [**EditCloudSystemDnsServerActionParam**](EditCloudSystemDnsServerActionParam.md) |  | 

## Methods

### NewEditCloudSystemDnsServerParam

`func NewEditCloudSystemDnsServerParam(editCloudSystemDnsServerAction EditCloudSystemDnsServerActionParam, ) *EditCloudSystemDnsServerParam`

NewEditCloudSystemDnsServerParam instantiates a new EditCloudSystemDnsServerParam object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewEditCloudSystemDnsServerParamWithDefaults

`func NewEditCloudSystemDnsServerParamWithDefaults() *EditCloudSystemDnsServerParam`

NewEditCloudSystemDnsServerParamWithDefaults instantiates a new EditCloudSystemDnsServerParam object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetExecutionOption

`func (o *EditCloudSystemDnsServerParam) GetExecutionOption() string`

GetExecutionOption returns the ExecutionOption field if non-nil, zero value otherwise.

### GetExecutionOptionOk

`func (o *EditCloudSystemDnsServerParam) GetExecutionOptionOk() (*string, bool)`

GetExecutionOptionOk returns a tuple with the ExecutionOption field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetExecutionOption

`func (o *EditCloudSystemDnsServerParam) SetExecutionOption(v string)`

SetExecutionOption sets ExecutionOption field to given value.

### HasExecutionOption

`func (o *EditCloudSystemDnsServerParam) HasExecutionOption() bool`

HasExecutionOption returns a boolean if a field has been set.

### GetEditCloudSystemDnsServerAction

`func (o *EditCloudSystemDnsServerParam) GetEditCloudSystemDnsServerAction() EditCloudSystemDnsServerActionParam`

GetEditCloudSystemDnsServerAction returns the EditCloudSystemDnsServerAction field if non-nil, zero value otherwise.

### GetEditCloudSystemDnsServerActionOk

`func (o *EditCloudSystemDnsServerParam) GetEditCloudSystemDnsServerActionOk() (*EditCloudSystemDnsServerActionParam, bool)`

GetEditCloudSystemDnsServerActionOk returns a tuple with the EditCloudSystemDnsServerAction field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetEditCloudSystemDnsServerAction

`func (o *EditCloudSystemDnsServerParam) SetEditCloudSystemDnsServerAction(v EditCloudSystemDnsServerActionParam)`

SetEditCloudSystemDnsServerAction sets EditCloudSystemDnsServerAction field to given value.



[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


