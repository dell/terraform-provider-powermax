# EditSnapshotPoliciesParam

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ResumeSnapshotPolicyParam** | Pointer to [**ResumeSnapshotPolicyParam**](ResumeSnapshotPolicyParam.md) |  | [optional] 
**SuspendSnapshotPolicyParam** | Pointer to [**SuspendSnapshotPolicyParam**](SuspendSnapshotPolicyParam.md) |  | [optional] 
**DisassociateSnapshotPolicyParam** | Pointer to [**DisassociateSnapshotPolicyParam**](DisassociateSnapshotPolicyParam.md) |  | [optional] 
**AssociateSnapshotPolicyParam** | Pointer to [**AssociateSnapshotPolicyParam**](AssociateSnapshotPolicyParam.md) |  | [optional] 

## Methods

### NewEditSnapshotPoliciesParam

`func NewEditSnapshotPoliciesParam() *EditSnapshotPoliciesParam`

NewEditSnapshotPoliciesParam instantiates a new EditSnapshotPoliciesParam object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewEditSnapshotPoliciesParamWithDefaults

`func NewEditSnapshotPoliciesParamWithDefaults() *EditSnapshotPoliciesParam`

NewEditSnapshotPoliciesParamWithDefaults instantiates a new EditSnapshotPoliciesParam object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetResumeSnapshotPolicyParam

`func (o *EditSnapshotPoliciesParam) GetResumeSnapshotPolicyParam() ResumeSnapshotPolicyParam`

GetResumeSnapshotPolicyParam returns the ResumeSnapshotPolicyParam field if non-nil, zero value otherwise.

### GetResumeSnapshotPolicyParamOk

`func (o *EditSnapshotPoliciesParam) GetResumeSnapshotPolicyParamOk() (*ResumeSnapshotPolicyParam, bool)`

GetResumeSnapshotPolicyParamOk returns a tuple with the ResumeSnapshotPolicyParam field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetResumeSnapshotPolicyParam

`func (o *EditSnapshotPoliciesParam) SetResumeSnapshotPolicyParam(v ResumeSnapshotPolicyParam)`

SetResumeSnapshotPolicyParam sets ResumeSnapshotPolicyParam field to given value.

### HasResumeSnapshotPolicyParam

`func (o *EditSnapshotPoliciesParam) HasResumeSnapshotPolicyParam() bool`

HasResumeSnapshotPolicyParam returns a boolean if a field has been set.

### GetSuspendSnapshotPolicyParam

`func (o *EditSnapshotPoliciesParam) GetSuspendSnapshotPolicyParam() SuspendSnapshotPolicyParam`

GetSuspendSnapshotPolicyParam returns the SuspendSnapshotPolicyParam field if non-nil, zero value otherwise.

### GetSuspendSnapshotPolicyParamOk

`func (o *EditSnapshotPoliciesParam) GetSuspendSnapshotPolicyParamOk() (*SuspendSnapshotPolicyParam, bool)`

GetSuspendSnapshotPolicyParamOk returns a tuple with the SuspendSnapshotPolicyParam field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetSuspendSnapshotPolicyParam

`func (o *EditSnapshotPoliciesParam) SetSuspendSnapshotPolicyParam(v SuspendSnapshotPolicyParam)`

SetSuspendSnapshotPolicyParam sets SuspendSnapshotPolicyParam field to given value.

### HasSuspendSnapshotPolicyParam

`func (o *EditSnapshotPoliciesParam) HasSuspendSnapshotPolicyParam() bool`

HasSuspendSnapshotPolicyParam returns a boolean if a field has been set.

### GetDisassociateSnapshotPolicyParam

`func (o *EditSnapshotPoliciesParam) GetDisassociateSnapshotPolicyParam() DisassociateSnapshotPolicyParam`

GetDisassociateSnapshotPolicyParam returns the DisassociateSnapshotPolicyParam field if non-nil, zero value otherwise.

### GetDisassociateSnapshotPolicyParamOk

`func (o *EditSnapshotPoliciesParam) GetDisassociateSnapshotPolicyParamOk() (*DisassociateSnapshotPolicyParam, bool)`

GetDisassociateSnapshotPolicyParamOk returns a tuple with the DisassociateSnapshotPolicyParam field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetDisassociateSnapshotPolicyParam

`func (o *EditSnapshotPoliciesParam) SetDisassociateSnapshotPolicyParam(v DisassociateSnapshotPolicyParam)`

SetDisassociateSnapshotPolicyParam sets DisassociateSnapshotPolicyParam field to given value.

### HasDisassociateSnapshotPolicyParam

`func (o *EditSnapshotPoliciesParam) HasDisassociateSnapshotPolicyParam() bool`

HasDisassociateSnapshotPolicyParam returns a boolean if a field has been set.

### GetAssociateSnapshotPolicyParam

`func (o *EditSnapshotPoliciesParam) GetAssociateSnapshotPolicyParam() AssociateSnapshotPolicyParam`

GetAssociateSnapshotPolicyParam returns the AssociateSnapshotPolicyParam field if non-nil, zero value otherwise.

### GetAssociateSnapshotPolicyParamOk

`func (o *EditSnapshotPoliciesParam) GetAssociateSnapshotPolicyParamOk() (*AssociateSnapshotPolicyParam, bool)`

GetAssociateSnapshotPolicyParamOk returns a tuple with the AssociateSnapshotPolicyParam field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetAssociateSnapshotPolicyParam

`func (o *EditSnapshotPoliciesParam) SetAssociateSnapshotPolicyParam(v AssociateSnapshotPolicyParam)`

SetAssociateSnapshotPolicyParam sets AssociateSnapshotPolicyParam field to given value.

### HasAssociateSnapshotPolicyParam

`func (o *EditSnapshotPoliciesParam) HasAssociateSnapshotPolicyParam() bool`

HasAssociateSnapshotPolicyParam returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


