# EditCloudSystemTeamParam

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ExecutionOption** | Pointer to **string** |  | [optional] [default to "SYNCHRONOUS"]
**EditCloudSystemTeamAction** | [**EditCloudSystemTeamActionParam**](EditCloudSystemTeamActionParam.md) |  | 

## Methods

### NewEditCloudSystemTeamParam

`func NewEditCloudSystemTeamParam(editCloudSystemTeamAction EditCloudSystemTeamActionParam, ) *EditCloudSystemTeamParam`

NewEditCloudSystemTeamParam instantiates a new EditCloudSystemTeamParam object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewEditCloudSystemTeamParamWithDefaults

`func NewEditCloudSystemTeamParamWithDefaults() *EditCloudSystemTeamParam`

NewEditCloudSystemTeamParamWithDefaults instantiates a new EditCloudSystemTeamParam object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetExecutionOption

`func (o *EditCloudSystemTeamParam) GetExecutionOption() string`

GetExecutionOption returns the ExecutionOption field if non-nil, zero value otherwise.

### GetExecutionOptionOk

`func (o *EditCloudSystemTeamParam) GetExecutionOptionOk() (*string, bool)`

GetExecutionOptionOk returns a tuple with the ExecutionOption field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetExecutionOption

`func (o *EditCloudSystemTeamParam) SetExecutionOption(v string)`

SetExecutionOption sets ExecutionOption field to given value.

### HasExecutionOption

`func (o *EditCloudSystemTeamParam) HasExecutionOption() bool`

HasExecutionOption returns a boolean if a field has been set.

### GetEditCloudSystemTeamAction

`func (o *EditCloudSystemTeamParam) GetEditCloudSystemTeamAction() EditCloudSystemTeamActionParam`

GetEditCloudSystemTeamAction returns the EditCloudSystemTeamAction field if non-nil, zero value otherwise.

### GetEditCloudSystemTeamActionOk

`func (o *EditCloudSystemTeamParam) GetEditCloudSystemTeamActionOk() (*EditCloudSystemTeamActionParam, bool)`

GetEditCloudSystemTeamActionOk returns a tuple with the EditCloudSystemTeamAction field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetEditCloudSystemTeamAction

`func (o *EditCloudSystemTeamParam) SetEditCloudSystemTeamAction(v EditCloudSystemTeamActionParam)`

SetEditCloudSystemTeamAction sets EditCloudSystemTeamAction field to given value.



[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


