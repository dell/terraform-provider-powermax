# FtpServer

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Id** | Pointer to **string** |                          Identifier of the FTP server                      | [optional] 
**NasServer** | Pointer to **string** |                          Identifier of the FTP server                      | [optional] 
**FtpEnabled** | Pointer to **bool** |                          Indicates whether the FTP server is enabled on the NAS server specified in the nasServer attribute. Values are:                         - true - FTP server is enabled on the specified NAS server.                         - false - FTP server is disabled on the specified NAS server.                      | [optional] 
**SftpEnabled** | Pointer to **bool** |                          Indicates whether the SFTP server is enabled on the NAS server specified in the nasServer attribute. Values are:                         - true - SFTP server is enabled on the specified NAS server.                         - false - SFTP server is disabled on the specified NAS server.                      | [optional] 
**SmbAuthenticationEnabled** | Pointer to **bool** |                          Indicates whether FTP and SFTP clients can be authenticated using a SMB user name.                         These user names are defined in a Windows domain controller, and their formats are \&quot;user(at)domain\&quot; or domain(slash)user.                         Values are:                         - true - SMB user names are accepted for authentication.                         - false - SMB user names are not accepted for authentication.                      | [optional] 
**UnixAuthentication** | Pointer to **bool** |                          Indicates whether FTP and SFTP clients can be authenticated using a Unix user name.                         Unix user names are defined in LDAP or NIS servers or in local passwd file.                         Values are:                         - true - Unix user names are accepted for authentication.                         - false - Unix user names are not accepted for authentication.                      | [optional] 
**AnonymousAuthentication** | Pointer to **bool** |                          Indicates whether FTP clients can be authenticated anonymously.                         Values are:                         - true - Anonymous user name is accepted.                         - false - Anonymous user name is not accepted.                      | [optional] 
**HomedirLimit** | Pointer to **bool** |                          Indicates whether an FTP or SFTP user access is limited to his home directory. Values are:                         - true - An FTP or SFTP user can access his or her own home directory only.                         - false - FTP and SFTP users can access any NAS server directory, according to NAS server permissions.                      | [optional] 
**DefaultHomedir** | Pointer to **string** |                          (Applies when the value of HomedirLimit is false.)                         Default directory of FTP and SFTP clients who have a home directory that is not defined or accessible.                         This parameter is an absolute path relative to the root of the NAS server.                      | [optional] 
**WelcomeMsg** | Pointer to **string** |                          Welcome message displayed on the console of FTP and SFTP clients before their authentication.                      | [optional] 
**MessageOfTheDay** | Pointer to **string** |                          Message of the day displayed on the console of FTP clients after their authentication.                       | [optional] 
**AuditEnabled** | Pointer to **bool** |                          Indicates whether the activity of FTP and SFTP clients is tracked in audit files. Values are:                         - true - FTP/SFTP activity is tracked.                         - false - FTP/SFTP activity is not tracked.                      | [optional] 
**AuditDir** | Pointer to **string** |                          (Applies when the value of AuditEnabled is true.)                         Directory of FTP/SFTP audit files.                         This parameter is an absolute path relative to the root of the NAS server.                         This directory cannot be located on the root file system.                      | [optional] 
**AuditMaxSize** | Pointer to **int32** |                          (Applies when the value of AuditEnabled is true.)                         Maximum size of FTP/SFTP audit files, in bytes.                         The maximum value for this setting is 1GB if the audit directory belongs to a user file system of the NAS server.                         If it belongs to the config file system, the maximum value is 1MB.                         The minimum value is 8kB on any file system.                         When the audit file size reaches this value, the file is closed and renamed with an index. A new audit file is then created (files rotation).                         Up to 4 renamed audit files are kept. the oldest files are deleted.                      | [optional] 
**HostsList** | Pointer to **[]string** |                          Allowed or denied hosts, depending on the value of the AllowHosts attribute.                         A host is defined using its IP address.                         Subnets using CIDR notation are also supported.                         - If allowed hosts exist, only those hosts and no others can connect to the NAS server through FTP or SFTP.                         - If denied hosts exist, they always have access denied to the NAS server through FTP or SFTP.                         - If the list is empty, there is no restriction to NAS server access through FTP or SFTP based on the host IP.                      | [optional] 
**UsersList** | Pointer to **[]string** |                          Allowed or denied users, depending on the value of the AllowUsers attribute.                         - If allowed users exist, only those users and no others can connect to the NAS server through FTP or SFTP.                         - If denied users exist, they have always access denied to the NAS server through FTP or SFTP.                         - If the list is empty, there is no restriction to the NAS server access through FTP or SFTP based on the user name.                      | [optional] 
**GroupsList** | Pointer to **[]string** |                          Allowed or denied user groups, depending on the value of the AllowGroups attribute.                         - If allowed groups exist, only users who are members of these groups and no others can connect to the NAS server through FTP or SFTP.                         - If denied groups exist, all users who are members of those groups have always access denied to the NAS server through FTP or SFTP.                         - If the list is empty, there is no restriction to the NAS server access through FTP or SFTP based on the user group.                      | [optional] 
**AllowHosts** | Pointer to **bool** |                          Indicates whether the hostsList attribute contains allowed or denied hosts. Values are:                         true - hostsList contains allowed hosts.                         false - hostsList contains denied hosts.                         Note the hostsList must be empty to be able to change the value of this property.                      | [optional] 
**AllowUsers** | Pointer to **bool** |                          Indicates whether the usersList attribute contains allowed or denied users. Values are:                         - true - usersList contains allowed users.                         - false - usersList contains denied users.                         Note the usersList must be empty to be able to change the value of this property.                      | [optional] 
**AllowGroups** | Pointer to **bool** |                          Indicates whether the groupsList attribute contains allowed or denied user groups. Values are:                         - true - groupsList contains allowed user groups.                         - false - groupsList contains denied user groups.                         Note the groupsList must be empty to be able to change the value of this property.                      | [optional] 
**Health** | Pointer to [**Health**](Health.md) |  | [optional] 

## Methods

### NewFtpServer

`func NewFtpServer() *FtpServer`

NewFtpServer instantiates a new FtpServer object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewFtpServerWithDefaults

`func NewFtpServerWithDefaults() *FtpServer`

NewFtpServerWithDefaults instantiates a new FtpServer object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetId

`func (o *FtpServer) GetId() string`

GetId returns the Id field if non-nil, zero value otherwise.

### GetIdOk

`func (o *FtpServer) GetIdOk() (*string, bool)`

GetIdOk returns a tuple with the Id field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetId

`func (o *FtpServer) SetId(v string)`

SetId sets Id field to given value.

### HasId

`func (o *FtpServer) HasId() bool`

HasId returns a boolean if a field has been set.

### GetNasServer

`func (o *FtpServer) GetNasServer() string`

GetNasServer returns the NasServer field if non-nil, zero value otherwise.

### GetNasServerOk

`func (o *FtpServer) GetNasServerOk() (*string, bool)`

GetNasServerOk returns a tuple with the NasServer field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetNasServer

`func (o *FtpServer) SetNasServer(v string)`

SetNasServer sets NasServer field to given value.

### HasNasServer

`func (o *FtpServer) HasNasServer() bool`

HasNasServer returns a boolean if a field has been set.

### GetFtpEnabled

`func (o *FtpServer) GetFtpEnabled() bool`

GetFtpEnabled returns the FtpEnabled field if non-nil, zero value otherwise.

### GetFtpEnabledOk

`func (o *FtpServer) GetFtpEnabledOk() (*bool, bool)`

GetFtpEnabledOk returns a tuple with the FtpEnabled field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetFtpEnabled

`func (o *FtpServer) SetFtpEnabled(v bool)`

SetFtpEnabled sets FtpEnabled field to given value.

### HasFtpEnabled

`func (o *FtpServer) HasFtpEnabled() bool`

HasFtpEnabled returns a boolean if a field has been set.

### GetSftpEnabled

`func (o *FtpServer) GetSftpEnabled() bool`

GetSftpEnabled returns the SftpEnabled field if non-nil, zero value otherwise.

### GetSftpEnabledOk

`func (o *FtpServer) GetSftpEnabledOk() (*bool, bool)`

GetSftpEnabledOk returns a tuple with the SftpEnabled field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetSftpEnabled

`func (o *FtpServer) SetSftpEnabled(v bool)`

SetSftpEnabled sets SftpEnabled field to given value.

### HasSftpEnabled

`func (o *FtpServer) HasSftpEnabled() bool`

HasSftpEnabled returns a boolean if a field has been set.

### GetSmbAuthenticationEnabled

`func (o *FtpServer) GetSmbAuthenticationEnabled() bool`

GetSmbAuthenticationEnabled returns the SmbAuthenticationEnabled field if non-nil, zero value otherwise.

### GetSmbAuthenticationEnabledOk

`func (o *FtpServer) GetSmbAuthenticationEnabledOk() (*bool, bool)`

GetSmbAuthenticationEnabledOk returns a tuple with the SmbAuthenticationEnabled field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetSmbAuthenticationEnabled

`func (o *FtpServer) SetSmbAuthenticationEnabled(v bool)`

SetSmbAuthenticationEnabled sets SmbAuthenticationEnabled field to given value.

### HasSmbAuthenticationEnabled

`func (o *FtpServer) HasSmbAuthenticationEnabled() bool`

HasSmbAuthenticationEnabled returns a boolean if a field has been set.

### GetUnixAuthentication

`func (o *FtpServer) GetUnixAuthentication() bool`

GetUnixAuthentication returns the UnixAuthentication field if non-nil, zero value otherwise.

### GetUnixAuthenticationOk

`func (o *FtpServer) GetUnixAuthenticationOk() (*bool, bool)`

GetUnixAuthenticationOk returns a tuple with the UnixAuthentication field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetUnixAuthentication

`func (o *FtpServer) SetUnixAuthentication(v bool)`

SetUnixAuthentication sets UnixAuthentication field to given value.

### HasUnixAuthentication

`func (o *FtpServer) HasUnixAuthentication() bool`

HasUnixAuthentication returns a boolean if a field has been set.

### GetAnonymousAuthentication

`func (o *FtpServer) GetAnonymousAuthentication() bool`

GetAnonymousAuthentication returns the AnonymousAuthentication field if non-nil, zero value otherwise.

### GetAnonymousAuthenticationOk

`func (o *FtpServer) GetAnonymousAuthenticationOk() (*bool, bool)`

GetAnonymousAuthenticationOk returns a tuple with the AnonymousAuthentication field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetAnonymousAuthentication

`func (o *FtpServer) SetAnonymousAuthentication(v bool)`

SetAnonymousAuthentication sets AnonymousAuthentication field to given value.

### HasAnonymousAuthentication

`func (o *FtpServer) HasAnonymousAuthentication() bool`

HasAnonymousAuthentication returns a boolean if a field has been set.

### GetHomedirLimit

`func (o *FtpServer) GetHomedirLimit() bool`

GetHomedirLimit returns the HomedirLimit field if non-nil, zero value otherwise.

### GetHomedirLimitOk

`func (o *FtpServer) GetHomedirLimitOk() (*bool, bool)`

GetHomedirLimitOk returns a tuple with the HomedirLimit field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetHomedirLimit

`func (o *FtpServer) SetHomedirLimit(v bool)`

SetHomedirLimit sets HomedirLimit field to given value.

### HasHomedirLimit

`func (o *FtpServer) HasHomedirLimit() bool`

HasHomedirLimit returns a boolean if a field has been set.

### GetDefaultHomedir

`func (o *FtpServer) GetDefaultHomedir() string`

GetDefaultHomedir returns the DefaultHomedir field if non-nil, zero value otherwise.

### GetDefaultHomedirOk

`func (o *FtpServer) GetDefaultHomedirOk() (*string, bool)`

GetDefaultHomedirOk returns a tuple with the DefaultHomedir field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetDefaultHomedir

`func (o *FtpServer) SetDefaultHomedir(v string)`

SetDefaultHomedir sets DefaultHomedir field to given value.

### HasDefaultHomedir

`func (o *FtpServer) HasDefaultHomedir() bool`

HasDefaultHomedir returns a boolean if a field has been set.

### GetWelcomeMsg

`func (o *FtpServer) GetWelcomeMsg() string`

GetWelcomeMsg returns the WelcomeMsg field if non-nil, zero value otherwise.

### GetWelcomeMsgOk

`func (o *FtpServer) GetWelcomeMsgOk() (*string, bool)`

GetWelcomeMsgOk returns a tuple with the WelcomeMsg field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetWelcomeMsg

`func (o *FtpServer) SetWelcomeMsg(v string)`

SetWelcomeMsg sets WelcomeMsg field to given value.

### HasWelcomeMsg

`func (o *FtpServer) HasWelcomeMsg() bool`

HasWelcomeMsg returns a boolean if a field has been set.

### GetMessageOfTheDay

`func (o *FtpServer) GetMessageOfTheDay() string`

GetMessageOfTheDay returns the MessageOfTheDay field if non-nil, zero value otherwise.

### GetMessageOfTheDayOk

`func (o *FtpServer) GetMessageOfTheDayOk() (*string, bool)`

GetMessageOfTheDayOk returns a tuple with the MessageOfTheDay field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetMessageOfTheDay

`func (o *FtpServer) SetMessageOfTheDay(v string)`

SetMessageOfTheDay sets MessageOfTheDay field to given value.

### HasMessageOfTheDay

`func (o *FtpServer) HasMessageOfTheDay() bool`

HasMessageOfTheDay returns a boolean if a field has been set.

### GetAuditEnabled

`func (o *FtpServer) GetAuditEnabled() bool`

GetAuditEnabled returns the AuditEnabled field if non-nil, zero value otherwise.

### GetAuditEnabledOk

`func (o *FtpServer) GetAuditEnabledOk() (*bool, bool)`

GetAuditEnabledOk returns a tuple with the AuditEnabled field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetAuditEnabled

`func (o *FtpServer) SetAuditEnabled(v bool)`

SetAuditEnabled sets AuditEnabled field to given value.

### HasAuditEnabled

`func (o *FtpServer) HasAuditEnabled() bool`

HasAuditEnabled returns a boolean if a field has been set.

### GetAuditDir

`func (o *FtpServer) GetAuditDir() string`

GetAuditDir returns the AuditDir field if non-nil, zero value otherwise.

### GetAuditDirOk

`func (o *FtpServer) GetAuditDirOk() (*string, bool)`

GetAuditDirOk returns a tuple with the AuditDir field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetAuditDir

`func (o *FtpServer) SetAuditDir(v string)`

SetAuditDir sets AuditDir field to given value.

### HasAuditDir

`func (o *FtpServer) HasAuditDir() bool`

HasAuditDir returns a boolean if a field has been set.

### GetAuditMaxSize

`func (o *FtpServer) GetAuditMaxSize() int32`

GetAuditMaxSize returns the AuditMaxSize field if non-nil, zero value otherwise.

### GetAuditMaxSizeOk

`func (o *FtpServer) GetAuditMaxSizeOk() (*int32, bool)`

GetAuditMaxSizeOk returns a tuple with the AuditMaxSize field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetAuditMaxSize

`func (o *FtpServer) SetAuditMaxSize(v int32)`

SetAuditMaxSize sets AuditMaxSize field to given value.

### HasAuditMaxSize

`func (o *FtpServer) HasAuditMaxSize() bool`

HasAuditMaxSize returns a boolean if a field has been set.

### GetHostsList

`func (o *FtpServer) GetHostsList() []string`

GetHostsList returns the HostsList field if non-nil, zero value otherwise.

### GetHostsListOk

`func (o *FtpServer) GetHostsListOk() (*[]string, bool)`

GetHostsListOk returns a tuple with the HostsList field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetHostsList

`func (o *FtpServer) SetHostsList(v []string)`

SetHostsList sets HostsList field to given value.

### HasHostsList

`func (o *FtpServer) HasHostsList() bool`

HasHostsList returns a boolean if a field has been set.

### GetUsersList

`func (o *FtpServer) GetUsersList() []string`

GetUsersList returns the UsersList field if non-nil, zero value otherwise.

### GetUsersListOk

`func (o *FtpServer) GetUsersListOk() (*[]string, bool)`

GetUsersListOk returns a tuple with the UsersList field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetUsersList

`func (o *FtpServer) SetUsersList(v []string)`

SetUsersList sets UsersList field to given value.

### HasUsersList

`func (o *FtpServer) HasUsersList() bool`

HasUsersList returns a boolean if a field has been set.

### GetGroupsList

`func (o *FtpServer) GetGroupsList() []string`

GetGroupsList returns the GroupsList field if non-nil, zero value otherwise.

### GetGroupsListOk

`func (o *FtpServer) GetGroupsListOk() (*[]string, bool)`

GetGroupsListOk returns a tuple with the GroupsList field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetGroupsList

`func (o *FtpServer) SetGroupsList(v []string)`

SetGroupsList sets GroupsList field to given value.

### HasGroupsList

`func (o *FtpServer) HasGroupsList() bool`

HasGroupsList returns a boolean if a field has been set.

### GetAllowHosts

`func (o *FtpServer) GetAllowHosts() bool`

GetAllowHosts returns the AllowHosts field if non-nil, zero value otherwise.

### GetAllowHostsOk

`func (o *FtpServer) GetAllowHostsOk() (*bool, bool)`

GetAllowHostsOk returns a tuple with the AllowHosts field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetAllowHosts

`func (o *FtpServer) SetAllowHosts(v bool)`

SetAllowHosts sets AllowHosts field to given value.

### HasAllowHosts

`func (o *FtpServer) HasAllowHosts() bool`

HasAllowHosts returns a boolean if a field has been set.

### GetAllowUsers

`func (o *FtpServer) GetAllowUsers() bool`

GetAllowUsers returns the AllowUsers field if non-nil, zero value otherwise.

### GetAllowUsersOk

`func (o *FtpServer) GetAllowUsersOk() (*bool, bool)`

GetAllowUsersOk returns a tuple with the AllowUsers field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetAllowUsers

`func (o *FtpServer) SetAllowUsers(v bool)`

SetAllowUsers sets AllowUsers field to given value.

### HasAllowUsers

`func (o *FtpServer) HasAllowUsers() bool`

HasAllowUsers returns a boolean if a field has been set.

### GetAllowGroups

`func (o *FtpServer) GetAllowGroups() bool`

GetAllowGroups returns the AllowGroups field if non-nil, zero value otherwise.

### GetAllowGroupsOk

`func (o *FtpServer) GetAllowGroupsOk() (*bool, bool)`

GetAllowGroupsOk returns a tuple with the AllowGroups field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetAllowGroups

`func (o *FtpServer) SetAllowGroups(v bool)`

SetAllowGroups sets AllowGroups field to given value.

### HasAllowGroups

`func (o *FtpServer) HasAllowGroups() bool`

HasAllowGroups returns a boolean if a field has been set.

### GetHealth

`func (o *FtpServer) GetHealth() Health`

GetHealth returns the Health field if non-nil, zero value otherwise.

### GetHealthOk

`func (o *FtpServer) GetHealthOk() (*Health, bool)`

GetHealthOk returns a tuple with the Health field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetHealth

`func (o *FtpServer) SetHealth(v Health)`

SetHealth sets Health field to given value.

### HasHealth

`func (o *FtpServer) HasHealth() bool`

HasHealth returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


