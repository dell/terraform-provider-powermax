# CreateCloudSnapshotParam

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ExecutionOption** | Pointer to **string** |  | [optional] [default to "SYNCHRONOUS"]
**CloudProviderId** | **string** | The name of the cloud provider where the snapshot shot will reside. | 
**SnapshotName** | **string** | The name of the new snapshot. | 
**ExpiryTimeDays** | Pointer to **int32** | The time that the snapshot generation is to live for in Days . | [optional] 

## Methods

### NewCreateCloudSnapshotParam

`func NewCreateCloudSnapshotParam(cloudProviderId string, snapshotName string, ) *CreateCloudSnapshotParam`

NewCreateCloudSnapshotParam instantiates a new CreateCloudSnapshotParam object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewCreateCloudSnapshotParamWithDefaults

`func NewCreateCloudSnapshotParamWithDefaults() *CreateCloudSnapshotParam`

NewCreateCloudSnapshotParamWithDefaults instantiates a new CreateCloudSnapshotParam object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetExecutionOption

`func (o *CreateCloudSnapshotParam) GetExecutionOption() string`

GetExecutionOption returns the ExecutionOption field if non-nil, zero value otherwise.

### GetExecutionOptionOk

`func (o *CreateCloudSnapshotParam) GetExecutionOptionOk() (*string, bool)`

GetExecutionOptionOk returns a tuple with the ExecutionOption field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetExecutionOption

`func (o *CreateCloudSnapshotParam) SetExecutionOption(v string)`

SetExecutionOption sets ExecutionOption field to given value.

### HasExecutionOption

`func (o *CreateCloudSnapshotParam) HasExecutionOption() bool`

HasExecutionOption returns a boolean if a field has been set.

### GetCloudProviderId

`func (o *CreateCloudSnapshotParam) GetCloudProviderId() string`

GetCloudProviderId returns the CloudProviderId field if non-nil, zero value otherwise.

### GetCloudProviderIdOk

`func (o *CreateCloudSnapshotParam) GetCloudProviderIdOk() (*string, bool)`

GetCloudProviderIdOk returns a tuple with the CloudProviderId field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetCloudProviderId

`func (o *CreateCloudSnapshotParam) SetCloudProviderId(v string)`

SetCloudProviderId sets CloudProviderId field to given value.


### GetSnapshotName

`func (o *CreateCloudSnapshotParam) GetSnapshotName() string`

GetSnapshotName returns the SnapshotName field if non-nil, zero value otherwise.

### GetSnapshotNameOk

`func (o *CreateCloudSnapshotParam) GetSnapshotNameOk() (*string, bool)`

GetSnapshotNameOk returns a tuple with the SnapshotName field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetSnapshotName

`func (o *CreateCloudSnapshotParam) SetSnapshotName(v string)`

SetSnapshotName sets SnapshotName field to given value.


### GetExpiryTimeDays

`func (o *CreateCloudSnapshotParam) GetExpiryTimeDays() int32`

GetExpiryTimeDays returns the ExpiryTimeDays field if non-nil, zero value otherwise.

### GetExpiryTimeDaysOk

`func (o *CreateCloudSnapshotParam) GetExpiryTimeDaysOk() (*int32, bool)`

GetExpiryTimeDaysOk returns a tuple with the ExpiryTimeDays field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetExpiryTimeDays

`func (o *CreateCloudSnapshotParam) SetExpiryTimeDays(v int32)`

SetExpiryTimeDays sets ExpiryTimeDays field to given value.

### HasExpiryTimeDays

`func (o *CreateCloudSnapshotParam) HasExpiryTimeDays() bool`

HasExpiryTimeDays returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


