# EditSloParam

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ExecutionOption** | Pointer to **string** |  | [optional] [default to "SYNCHRONOUS"]
**EditSloActionParam** | [**EditSloActionParam**](EditSloActionParam.md) |  | 

## Methods

### NewEditSloParam

`func NewEditSloParam(editSloActionParam EditSloActionParam, ) *EditSloParam`

NewEditSloParam instantiates a new EditSloParam object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewEditSloParamWithDefaults

`func NewEditSloParamWithDefaults() *EditSloParam`

NewEditSloParamWithDefaults instantiates a new EditSloParam object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetExecutionOption

`func (o *EditSloParam) GetExecutionOption() string`

GetExecutionOption returns the ExecutionOption field if non-nil, zero value otherwise.

### GetExecutionOptionOk

`func (o *EditSloParam) GetExecutionOptionOk() (*string, bool)`

GetExecutionOptionOk returns a tuple with the ExecutionOption field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetExecutionOption

`func (o *EditSloParam) SetExecutionOption(v string)`

SetExecutionOption sets ExecutionOption field to given value.

### HasExecutionOption

`func (o *EditSloParam) HasExecutionOption() bool`

HasExecutionOption returns a boolean if a field has been set.

### GetEditSloActionParam

`func (o *EditSloParam) GetEditSloActionParam() EditSloActionParam`

GetEditSloActionParam returns the EditSloActionParam field if non-nil, zero value otherwise.

### GetEditSloActionParamOk

`func (o *EditSloParam) GetEditSloActionParamOk() (*EditSloActionParam, bool)`

GetEditSloActionParamOk returns a tuple with the EditSloActionParam field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetEditSloActionParam

`func (o *EditSloParam) SetEditSloActionParam(v EditSloActionParam)`

SetEditSloActionParam sets EditSloActionParam field to given value.



[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


