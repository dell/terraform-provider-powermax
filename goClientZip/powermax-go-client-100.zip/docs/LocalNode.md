# LocalNode

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**NodeId** | Pointer to **int32** |                          Internal ID of the node starting at 1.                      | [optional] 
**NodeUuid** | Pointer to **string** |                          Global ID of the node.                      | [optional] 

## Methods

### NewLocalNode

`func NewLocalNode() *LocalNode`

NewLocalNode instantiates a new LocalNode object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewLocalNodeWithDefaults

`func NewLocalNodeWithDefaults() *LocalNode`

NewLocalNodeWithDefaults instantiates a new LocalNode object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetNodeId

`func (o *LocalNode) GetNodeId() int32`

GetNodeId returns the NodeId field if non-nil, zero value otherwise.

### GetNodeIdOk

`func (o *LocalNode) GetNodeIdOk() (*int32, bool)`

GetNodeIdOk returns a tuple with the NodeId field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetNodeId

`func (o *LocalNode) SetNodeId(v int32)`

SetNodeId sets NodeId field to given value.

### HasNodeId

`func (o *LocalNode) HasNodeId() bool`

HasNodeId returns a boolean if a field has been set.

### GetNodeUuid

`func (o *LocalNode) GetNodeUuid() string`

GetNodeUuid returns the NodeUuid field if non-nil, zero value otherwise.

### GetNodeUuidOk

`func (o *LocalNode) GetNodeUuidOk() (*string, bool)`

GetNodeUuidOk returns a tuple with the NodeUuid field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetNodeUuid

`func (o *LocalNode) SetNodeUuid(v string)`

SetNodeUuid sets NodeUuid field to given value.

### HasNodeUuid

`func (o *LocalNode) HasNodeUuid() bool`

HasNodeUuid returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


