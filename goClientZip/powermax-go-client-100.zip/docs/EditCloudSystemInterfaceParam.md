# EditCloudSystemInterfaceParam

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ExecutionOption** | Pointer to **string** |  | [optional] [default to "SYNCHRONOUS"]
**EditCloudSystemInterfaceAction** | [**EditCloudSystemInterfaceActionParam**](EditCloudSystemInterfaceActionParam.md) |  | 

## Methods

### NewEditCloudSystemInterfaceParam

`func NewEditCloudSystemInterfaceParam(editCloudSystemInterfaceAction EditCloudSystemInterfaceActionParam, ) *EditCloudSystemInterfaceParam`

NewEditCloudSystemInterfaceParam instantiates a new EditCloudSystemInterfaceParam object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewEditCloudSystemInterfaceParamWithDefaults

`func NewEditCloudSystemInterfaceParamWithDefaults() *EditCloudSystemInterfaceParam`

NewEditCloudSystemInterfaceParamWithDefaults instantiates a new EditCloudSystemInterfaceParam object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetExecutionOption

`func (o *EditCloudSystemInterfaceParam) GetExecutionOption() string`

GetExecutionOption returns the ExecutionOption field if non-nil, zero value otherwise.

### GetExecutionOptionOk

`func (o *EditCloudSystemInterfaceParam) GetExecutionOptionOk() (*string, bool)`

GetExecutionOptionOk returns a tuple with the ExecutionOption field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetExecutionOption

`func (o *EditCloudSystemInterfaceParam) SetExecutionOption(v string)`

SetExecutionOption sets ExecutionOption field to given value.

### HasExecutionOption

`func (o *EditCloudSystemInterfaceParam) HasExecutionOption() bool`

HasExecutionOption returns a boolean if a field has been set.

### GetEditCloudSystemInterfaceAction

`func (o *EditCloudSystemInterfaceParam) GetEditCloudSystemInterfaceAction() EditCloudSystemInterfaceActionParam`

GetEditCloudSystemInterfaceAction returns the EditCloudSystemInterfaceAction field if non-nil, zero value otherwise.

### GetEditCloudSystemInterfaceActionOk

`func (o *EditCloudSystemInterfaceParam) GetEditCloudSystemInterfaceActionOk() (*EditCloudSystemInterfaceActionParam, bool)`

GetEditCloudSystemInterfaceActionOk returns a tuple with the EditCloudSystemInterfaceAction field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetEditCloudSystemInterfaceAction

`func (o *EditCloudSystemInterfaceParam) SetEditCloudSystemInterfaceAction(v EditCloudSystemInterfaceActionParam)`

SetEditCloudSystemInterfaceAction sets EditCloudSystemInterfaceAction field to given value.



[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


