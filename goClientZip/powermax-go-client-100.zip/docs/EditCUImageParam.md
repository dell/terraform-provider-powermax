# EditCUImageParam

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ExecutionOption** | Pointer to **string** |  | [optional] [default to "SYNCHRONOUS"]
**EditCUImageActionParam** | [**EditCUImageActionParam**](EditCUImageActionParam.md) |  | 

## Methods

### NewEditCUImageParam

`func NewEditCUImageParam(editCUImageActionParam EditCUImageActionParam, ) *EditCUImageParam`

NewEditCUImageParam instantiates a new EditCUImageParam object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewEditCUImageParamWithDefaults

`func NewEditCUImageParamWithDefaults() *EditCUImageParam`

NewEditCUImageParamWithDefaults instantiates a new EditCUImageParam object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetExecutionOption

`func (o *EditCUImageParam) GetExecutionOption() string`

GetExecutionOption returns the ExecutionOption field if non-nil, zero value otherwise.

### GetExecutionOptionOk

`func (o *EditCUImageParam) GetExecutionOptionOk() (*string, bool)`

GetExecutionOptionOk returns a tuple with the ExecutionOption field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetExecutionOption

`func (o *EditCUImageParam) SetExecutionOption(v string)`

SetExecutionOption sets ExecutionOption field to given value.

### HasExecutionOption

`func (o *EditCUImageParam) HasExecutionOption() bool`

HasExecutionOption returns a boolean if a field has been set.

### GetEditCUImageActionParam

`func (o *EditCUImageParam) GetEditCUImageActionParam() EditCUImageActionParam`

GetEditCUImageActionParam returns the EditCUImageActionParam field if non-nil, zero value otherwise.

### GetEditCUImageActionParamOk

`func (o *EditCUImageParam) GetEditCUImageActionParamOk() (*EditCUImageActionParam, bool)`

GetEditCUImageActionParamOk returns a tuple with the EditCUImageActionParam field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetEditCUImageActionParam

`func (o *EditCUImageParam) SetEditCUImageActionParam(v EditCUImageActionParam)`

SetEditCUImageActionParam sets EditCUImageActionParam field to given value.



[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


