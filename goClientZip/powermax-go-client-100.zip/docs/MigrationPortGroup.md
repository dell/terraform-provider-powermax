# MigrationPortGroup

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Name** | Pointer to **string** | The name of the Masking View | [optional] 
**Invalid** | Pointer to **bool** | Flag to indicate if the entity is invalid | [optional] 
**ChildInvalid** | Pointer to **bool** | Flag to indicate if a child entity is valid | [optional] 
**Missing** | Pointer to **bool** | Flag to indicate if the entity is missing | [optional] 
**Ports** | Pointer to [**[]MigrationPort**](MigrationPort.md) | Collection of Port Groups that are part of the Masking View | [optional] 

## Methods

### NewMigrationPortGroup

`func NewMigrationPortGroup() *MigrationPortGroup`

NewMigrationPortGroup instantiates a new MigrationPortGroup object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewMigrationPortGroupWithDefaults

`func NewMigrationPortGroupWithDefaults() *MigrationPortGroup`

NewMigrationPortGroupWithDefaults instantiates a new MigrationPortGroup object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetName

`func (o *MigrationPortGroup) GetName() string`

GetName returns the Name field if non-nil, zero value otherwise.

### GetNameOk

`func (o *MigrationPortGroup) GetNameOk() (*string, bool)`

GetNameOk returns a tuple with the Name field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetName

`func (o *MigrationPortGroup) SetName(v string)`

SetName sets Name field to given value.

### HasName

`func (o *MigrationPortGroup) HasName() bool`

HasName returns a boolean if a field has been set.

### GetInvalid

`func (o *MigrationPortGroup) GetInvalid() bool`

GetInvalid returns the Invalid field if non-nil, zero value otherwise.

### GetInvalidOk

`func (o *MigrationPortGroup) GetInvalidOk() (*bool, bool)`

GetInvalidOk returns a tuple with the Invalid field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetInvalid

`func (o *MigrationPortGroup) SetInvalid(v bool)`

SetInvalid sets Invalid field to given value.

### HasInvalid

`func (o *MigrationPortGroup) HasInvalid() bool`

HasInvalid returns a boolean if a field has been set.

### GetChildInvalid

`func (o *MigrationPortGroup) GetChildInvalid() bool`

GetChildInvalid returns the ChildInvalid field if non-nil, zero value otherwise.

### GetChildInvalidOk

`func (o *MigrationPortGroup) GetChildInvalidOk() (*bool, bool)`

GetChildInvalidOk returns a tuple with the ChildInvalid field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetChildInvalid

`func (o *MigrationPortGroup) SetChildInvalid(v bool)`

SetChildInvalid sets ChildInvalid field to given value.

### HasChildInvalid

`func (o *MigrationPortGroup) HasChildInvalid() bool`

HasChildInvalid returns a boolean if a field has been set.

### GetMissing

`func (o *MigrationPortGroup) GetMissing() bool`

GetMissing returns the Missing field if non-nil, zero value otherwise.

### GetMissingOk

`func (o *MigrationPortGroup) GetMissingOk() (*bool, bool)`

GetMissingOk returns a tuple with the Missing field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetMissing

`func (o *MigrationPortGroup) SetMissing(v bool)`

SetMissing sets Missing field to given value.

### HasMissing

`func (o *MigrationPortGroup) HasMissing() bool`

HasMissing returns a boolean if a field has been set.

### GetPorts

`func (o *MigrationPortGroup) GetPorts() []MigrationPort`

GetPorts returns the Ports field if non-nil, zero value otherwise.

### GetPortsOk

`func (o *MigrationPortGroup) GetPortsOk() (*[]MigrationPort, bool)`

GetPortsOk returns a tuple with the Ports field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetPorts

`func (o *MigrationPortGroup) SetPorts(v []MigrationPort)`

SetPorts sets Ports field to given value.

### HasPorts

`func (o *MigrationPortGroup) HasPorts() bool`

HasPorts returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


