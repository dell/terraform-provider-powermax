# EditCloudJobParam

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ExecutionOption** | Pointer to **string** |  | [optional] [default to "SYNCHRONOUS"]
**Action** | **string** | The action to be performed.   Enumeration values: * **pause** - Pause a Cloud Job * **resume** - Resume a Cloud Job * **cancel** - Cancel a Cloud Job  | 

## Methods

### NewEditCloudJobParam

`func NewEditCloudJobParam(action string, ) *EditCloudJobParam`

NewEditCloudJobParam instantiates a new EditCloudJobParam object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewEditCloudJobParamWithDefaults

`func NewEditCloudJobParamWithDefaults() *EditCloudJobParam`

NewEditCloudJobParamWithDefaults instantiates a new EditCloudJobParam object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetExecutionOption

`func (o *EditCloudJobParam) GetExecutionOption() string`

GetExecutionOption returns the ExecutionOption field if non-nil, zero value otherwise.

### GetExecutionOptionOk

`func (o *EditCloudJobParam) GetExecutionOptionOk() (*string, bool)`

GetExecutionOptionOk returns a tuple with the ExecutionOption field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetExecutionOption

`func (o *EditCloudJobParam) SetExecutionOption(v string)`

SetExecutionOption sets ExecutionOption field to given value.

### HasExecutionOption

`func (o *EditCloudJobParam) HasExecutionOption() bool`

HasExecutionOption returns a boolean if a field has been set.

### GetAction

`func (o *EditCloudJobParam) GetAction() string`

GetAction returns the Action field if non-nil, zero value otherwise.

### GetActionOk

`func (o *EditCloudJobParam) GetActionOk() (*string, bool)`

GetActionOk returns a tuple with the Action field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetAction

`func (o *EditCloudJobParam) SetAction(v string)`

SetAction sets Action field to given value.



[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


