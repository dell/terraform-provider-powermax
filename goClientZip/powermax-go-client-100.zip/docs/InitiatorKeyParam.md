# InitiatorKeyParam

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**SymmetrixId** | **string** | &lt;p&gt;The Symmetrix array ID.&lt;/p&gt; | 
**StartDate** | **int64** | &lt;p&gt;Starting date in millisecond.&lt;/p&gt; | 
**EndDate** | **int64** | &lt;p&gt;Ending date in millisecond..&lt;/p&gt; | 

## Methods

### NewInitiatorKeyParam

`func NewInitiatorKeyParam(symmetrixId string, startDate int64, endDate int64, ) *InitiatorKeyParam`

NewInitiatorKeyParam instantiates a new InitiatorKeyParam object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewInitiatorKeyParamWithDefaults

`func NewInitiatorKeyParamWithDefaults() *InitiatorKeyParam`

NewInitiatorKeyParamWithDefaults instantiates a new InitiatorKeyParam object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetSymmetrixId

`func (o *InitiatorKeyParam) GetSymmetrixId() string`

GetSymmetrixId returns the SymmetrixId field if non-nil, zero value otherwise.

### GetSymmetrixIdOk

`func (o *InitiatorKeyParam) GetSymmetrixIdOk() (*string, bool)`

GetSymmetrixIdOk returns a tuple with the SymmetrixId field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetSymmetrixId

`func (o *InitiatorKeyParam) SetSymmetrixId(v string)`

SetSymmetrixId sets SymmetrixId field to given value.


### GetStartDate

`func (o *InitiatorKeyParam) GetStartDate() int64`

GetStartDate returns the StartDate field if non-nil, zero value otherwise.

### GetStartDateOk

`func (o *InitiatorKeyParam) GetStartDateOk() (*int64, bool)`

GetStartDateOk returns a tuple with the StartDate field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetStartDate

`func (o *InitiatorKeyParam) SetStartDate(v int64)`

SetStartDate sets StartDate field to given value.


### GetEndDate

`func (o *InitiatorKeyParam) GetEndDate() int64`

GetEndDate returns the EndDate field if non-nil, zero value otherwise.

### GetEndDateOk

`func (o *InitiatorKeyParam) GetEndDateOk() (*int64, bool)`

GetEndDateOk returns a tuple with the EndDate field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetEndDate

`func (o *InitiatorKeyParam) SetEndDate(v int64)`

SetEndDate sets EndDate field to given value.



[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


