# MigrationDevicePair

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**SrcVolumeName** | **string** | The name of the Source Volume | 
**InvalidSrc** | **bool** | Flag to indicate if the source device is invalid | 
**MissingSrc** | **bool** | Flag to indicate if the source device is missing | 
**TgtVolumeName** | **string** | The name of the Target Volume | 
**InvalidTgt** | **bool** | Flag to indicate if the target device is invalid | 
**MissingTgt** | **bool** | Flag to indicate if the target device is missing | 

## Methods

### NewMigrationDevicePair

`func NewMigrationDevicePair(srcVolumeName string, invalidSrc bool, missingSrc bool, tgtVolumeName string, invalidTgt bool, missingTgt bool, ) *MigrationDevicePair`

NewMigrationDevicePair instantiates a new MigrationDevicePair object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewMigrationDevicePairWithDefaults

`func NewMigrationDevicePairWithDefaults() *MigrationDevicePair`

NewMigrationDevicePairWithDefaults instantiates a new MigrationDevicePair object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetSrcVolumeName

`func (o *MigrationDevicePair) GetSrcVolumeName() string`

GetSrcVolumeName returns the SrcVolumeName field if non-nil, zero value otherwise.

### GetSrcVolumeNameOk

`func (o *MigrationDevicePair) GetSrcVolumeNameOk() (*string, bool)`

GetSrcVolumeNameOk returns a tuple with the SrcVolumeName field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetSrcVolumeName

`func (o *MigrationDevicePair) SetSrcVolumeName(v string)`

SetSrcVolumeName sets SrcVolumeName field to given value.


### GetInvalidSrc

`func (o *MigrationDevicePair) GetInvalidSrc() bool`

GetInvalidSrc returns the InvalidSrc field if non-nil, zero value otherwise.

### GetInvalidSrcOk

`func (o *MigrationDevicePair) GetInvalidSrcOk() (*bool, bool)`

GetInvalidSrcOk returns a tuple with the InvalidSrc field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetInvalidSrc

`func (o *MigrationDevicePair) SetInvalidSrc(v bool)`

SetInvalidSrc sets InvalidSrc field to given value.


### GetMissingSrc

`func (o *MigrationDevicePair) GetMissingSrc() bool`

GetMissingSrc returns the MissingSrc field if non-nil, zero value otherwise.

### GetMissingSrcOk

`func (o *MigrationDevicePair) GetMissingSrcOk() (*bool, bool)`

GetMissingSrcOk returns a tuple with the MissingSrc field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetMissingSrc

`func (o *MigrationDevicePair) SetMissingSrc(v bool)`

SetMissingSrc sets MissingSrc field to given value.


### GetTgtVolumeName

`func (o *MigrationDevicePair) GetTgtVolumeName() string`

GetTgtVolumeName returns the TgtVolumeName field if non-nil, zero value otherwise.

### GetTgtVolumeNameOk

`func (o *MigrationDevicePair) GetTgtVolumeNameOk() (*string, bool)`

GetTgtVolumeNameOk returns a tuple with the TgtVolumeName field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetTgtVolumeName

`func (o *MigrationDevicePair) SetTgtVolumeName(v string)`

SetTgtVolumeName sets TgtVolumeName field to given value.


### GetInvalidTgt

`func (o *MigrationDevicePair) GetInvalidTgt() bool`

GetInvalidTgt returns the InvalidTgt field if non-nil, zero value otherwise.

### GetInvalidTgtOk

`func (o *MigrationDevicePair) GetInvalidTgtOk() (*bool, bool)`

GetInvalidTgtOk returns a tuple with the InvalidTgt field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetInvalidTgt

`func (o *MigrationDevicePair) SetInvalidTgt(v bool)`

SetInvalidTgt sets InvalidTgt field to given value.


### GetMissingTgt

`func (o *MigrationDevicePair) GetMissingTgt() bool`

GetMissingTgt returns the MissingTgt field if non-nil, zero value otherwise.

### GetMissingTgtOk

`func (o *MigrationDevicePair) GetMissingTgtOk() (*bool, bool)`

GetMissingTgtOk returns a tuple with the MissingTgt field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetMissingTgt

`func (o *MigrationDevicePair) SetMissingTgt(v bool)`

SetMissingTgt sets MissingTgt field to given value.



[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


