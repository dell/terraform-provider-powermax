# Esrs

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**UnisphereRegistered** | **bool** | unisphere_registered | 
**UnisphereIpAddress** | **string** | unisphere_ip_address | 
**GatewayUrl** | **string** | gateway_url | 
**SerialNumber** | **string** | serial_number | 
**Model** | **string** | model | 

## Methods

### NewEsrs

`func NewEsrs(unisphereRegistered bool, unisphereIpAddress string, gatewayUrl string, serialNumber string, model string, ) *Esrs`

NewEsrs instantiates a new Esrs object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewEsrsWithDefaults

`func NewEsrsWithDefaults() *Esrs`

NewEsrsWithDefaults instantiates a new Esrs object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetUnisphereRegistered

`func (o *Esrs) GetUnisphereRegistered() bool`

GetUnisphereRegistered returns the UnisphereRegistered field if non-nil, zero value otherwise.

### GetUnisphereRegisteredOk

`func (o *Esrs) GetUnisphereRegisteredOk() (*bool, bool)`

GetUnisphereRegisteredOk returns a tuple with the UnisphereRegistered field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetUnisphereRegistered

`func (o *Esrs) SetUnisphereRegistered(v bool)`

SetUnisphereRegistered sets UnisphereRegistered field to given value.


### GetUnisphereIpAddress

`func (o *Esrs) GetUnisphereIpAddress() string`

GetUnisphereIpAddress returns the UnisphereIpAddress field if non-nil, zero value otherwise.

### GetUnisphereIpAddressOk

`func (o *Esrs) GetUnisphereIpAddressOk() (*string, bool)`

GetUnisphereIpAddressOk returns a tuple with the UnisphereIpAddress field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetUnisphereIpAddress

`func (o *Esrs) SetUnisphereIpAddress(v string)`

SetUnisphereIpAddress sets UnisphereIpAddress field to given value.


### GetGatewayUrl

`func (o *Esrs) GetGatewayUrl() string`

GetGatewayUrl returns the GatewayUrl field if non-nil, zero value otherwise.

### GetGatewayUrlOk

`func (o *Esrs) GetGatewayUrlOk() (*string, bool)`

GetGatewayUrlOk returns a tuple with the GatewayUrl field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetGatewayUrl

`func (o *Esrs) SetGatewayUrl(v string)`

SetGatewayUrl sets GatewayUrl field to given value.


### GetSerialNumber

`func (o *Esrs) GetSerialNumber() string`

GetSerialNumber returns the SerialNumber field if non-nil, zero value otherwise.

### GetSerialNumberOk

`func (o *Esrs) GetSerialNumberOk() (*string, bool)`

GetSerialNumberOk returns a tuple with the SerialNumber field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetSerialNumber

`func (o *Esrs) SetSerialNumber(v string)`

SetSerialNumber sets SerialNumber field to given value.


### GetModel

`func (o *Esrs) GetModel() string`

GetModel returns the Model field if non-nil, zero value otherwise.

### GetModelOk

`func (o *Esrs) GetModelOk() (*string, bool)`

GetModelOk returns a tuple with the Model field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetModel

`func (o *Esrs) SetModel(v string)`

SetModel sets Model field to given value.



[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


