# BePortKeyResult

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**BePortInfo** | Pointer to [**[]BePortInfo**](BePortInfo.md) | bePortInfo | [optional] 

## Methods

### NewBePortKeyResult

`func NewBePortKeyResult() *BePortKeyResult`

NewBePortKeyResult instantiates a new BePortKeyResult object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewBePortKeyResultWithDefaults

`func NewBePortKeyResultWithDefaults() *BePortKeyResult`

NewBePortKeyResultWithDefaults instantiates a new BePortKeyResult object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetBePortInfo

`func (o *BePortKeyResult) GetBePortInfo() []BePortInfo`

GetBePortInfo returns the BePortInfo field if non-nil, zero value otherwise.

### GetBePortInfoOk

`func (o *BePortKeyResult) GetBePortInfoOk() (*[]BePortInfo, bool)`

GetBePortInfoOk returns a tuple with the BePortInfo field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetBePortInfo

`func (o *BePortKeyResult) SetBePortInfo(v []BePortInfo)`

SetBePortInfo sets BePortInfo field to given value.

### HasBePortInfo

`func (o *BePortKeyResult) HasBePortInfo() bool`

HasBePortInfo returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


