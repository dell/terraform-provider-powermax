# MetroDREnvRestoreParam

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Metro** | Pointer to **bool** | Indicates that the command is targeted at the SRDF/Metro session. | [optional] 
**Dr** | Pointer to **bool** | Indicates that the command is targeted at the DR session. | [optional] 
**Force** | Pointer to **bool** | Attempts to force the operation even though one or more volumes may not be in the normal, expected state(s) for the                                 specified                                 operation. | [optional] 
**Symforce** | Pointer to **bool** | Requests the System force operation be executed when normally it is rejected. Use extreme caution when using                                 this                                 option.                                  CAUTION: Use care when applying symforce, as data could be lost or corrupted. Use of this option is not recommended,                                 except in                                 an emergency.                                  NOTE: To enable symforce, a parameter called SYMAPI_ALLOW_RDF_SYMFORCE in the options file must be set to TRUE and                                 restart the                                 Unisphere server to pick up the change.                                  When used with symforce, a split command executes on an SRDF pair, even when the pair is sync in progress or restore in                                 progress.                                 During the execution of an establish or restore command, -symforce prohibits the verification of valid tracks on the                                 device at                                 the source. | [optional] 

## Methods

### NewMetroDREnvRestoreParam

`func NewMetroDREnvRestoreParam() *MetroDREnvRestoreParam`

NewMetroDREnvRestoreParam instantiates a new MetroDREnvRestoreParam object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewMetroDREnvRestoreParamWithDefaults

`func NewMetroDREnvRestoreParamWithDefaults() *MetroDREnvRestoreParam`

NewMetroDREnvRestoreParamWithDefaults instantiates a new MetroDREnvRestoreParam object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetMetro

`func (o *MetroDREnvRestoreParam) GetMetro() bool`

GetMetro returns the Metro field if non-nil, zero value otherwise.

### GetMetroOk

`func (o *MetroDREnvRestoreParam) GetMetroOk() (*bool, bool)`

GetMetroOk returns a tuple with the Metro field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetMetro

`func (o *MetroDREnvRestoreParam) SetMetro(v bool)`

SetMetro sets Metro field to given value.

### HasMetro

`func (o *MetroDREnvRestoreParam) HasMetro() bool`

HasMetro returns a boolean if a field has been set.

### GetDr

`func (o *MetroDREnvRestoreParam) GetDr() bool`

GetDr returns the Dr field if non-nil, zero value otherwise.

### GetDrOk

`func (o *MetroDREnvRestoreParam) GetDrOk() (*bool, bool)`

GetDrOk returns a tuple with the Dr field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetDr

`func (o *MetroDREnvRestoreParam) SetDr(v bool)`

SetDr sets Dr field to given value.

### HasDr

`func (o *MetroDREnvRestoreParam) HasDr() bool`

HasDr returns a boolean if a field has been set.

### GetForce

`func (o *MetroDREnvRestoreParam) GetForce() bool`

GetForce returns the Force field if non-nil, zero value otherwise.

### GetForceOk

`func (o *MetroDREnvRestoreParam) GetForceOk() (*bool, bool)`

GetForceOk returns a tuple with the Force field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetForce

`func (o *MetroDREnvRestoreParam) SetForce(v bool)`

SetForce sets Force field to given value.

### HasForce

`func (o *MetroDREnvRestoreParam) HasForce() bool`

HasForce returns a boolean if a field has been set.

### GetSymforce

`func (o *MetroDREnvRestoreParam) GetSymforce() bool`

GetSymforce returns the Symforce field if non-nil, zero value otherwise.

### GetSymforceOk

`func (o *MetroDREnvRestoreParam) GetSymforceOk() (*bool, bool)`

GetSymforceOk returns a tuple with the Symforce field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetSymforce

`func (o *MetroDREnvRestoreParam) SetSymforce(v bool)`

SetSymforce sets Symforce field to given value.

### HasSymforce

`func (o *MetroDREnvRestoreParam) HasSymforce() bool`

HasSymforce returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


