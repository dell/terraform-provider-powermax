# DiskGroupKeyResult

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**DiskGroupInfo** | Pointer to [**[]DiskGroupInfo**](DiskGroupInfo.md) | diskGroupInfo | [optional] 

## Methods

### NewDiskGroupKeyResult

`func NewDiskGroupKeyResult() *DiskGroupKeyResult`

NewDiskGroupKeyResult instantiates a new DiskGroupKeyResult object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewDiskGroupKeyResultWithDefaults

`func NewDiskGroupKeyResultWithDefaults() *DiskGroupKeyResult`

NewDiskGroupKeyResultWithDefaults instantiates a new DiskGroupKeyResult object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetDiskGroupInfo

`func (o *DiskGroupKeyResult) GetDiskGroupInfo() []DiskGroupInfo`

GetDiskGroupInfo returns the DiskGroupInfo field if non-nil, zero value otherwise.

### GetDiskGroupInfoOk

`func (o *DiskGroupKeyResult) GetDiskGroupInfoOk() (*[]DiskGroupInfo, bool)`

GetDiskGroupInfoOk returns a tuple with the DiskGroupInfo field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetDiskGroupInfo

`func (o *DiskGroupKeyResult) SetDiskGroupInfo(v []DiskGroupInfo)`

SetDiskGroupInfo sets DiskGroupInfo field to given value.

### HasDiskGroupInfo

`func (o *DiskGroupKeyResult) HasDiskGroupInfo() bool`

HasDiskGroupInfo returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


