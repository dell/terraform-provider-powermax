# ListHostResult

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**HostId** | Pointer to **[]string** | ID/name of the host | [optional] 

## Methods

### NewListHostResult

`func NewListHostResult() *ListHostResult`

NewListHostResult instantiates a new ListHostResult object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewListHostResultWithDefaults

`func NewListHostResultWithDefaults() *ListHostResult`

NewListHostResultWithDefaults instantiates a new ListHostResult object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetHostId

`func (o *ListHostResult) GetHostId() []string`

GetHostId returns the HostId field if non-nil, zero value otherwise.

### GetHostIdOk

`func (o *ListHostResult) GetHostIdOk() (*[]string, bool)`

GetHostIdOk returns a tuple with the HostId field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetHostId

`func (o *ListHostResult) SetHostId(v []string)`

SetHostId sets HostId field to given value.

### HasHostId

`func (o *ListHostResult) HasHostId() bool`

HasHostId returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


