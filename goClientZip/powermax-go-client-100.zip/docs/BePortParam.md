# BePortParam

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**StartDate** | **int64** | Starting date in millisecond. | 
**EndDate** | **int64** | Ending date in millisecond. | 
**SymmetrixId** | **string** | The Symmetrix array ID. | 
**DirectorId** | **string** | BE Director ID | 
**PortId** | **string** | BE Port ID | 
**DataFormat** | Pointer to **string** | &lt;p&gt;Data Format (Average or Maximum).&lt;/p&gt;   Enumeration values: * **Average** * **Maximum**  | [optional] 
**Metrics** | **[]string** | metrics   Enumeration values: * **Reads** - Areaddatatransferbetweenthedirectorandthecache.AnIOmayrequiremultiplerequestsdependingonIOsize,alignmentorboth.TherequestsrateshouldbeeitherequaltoorgreaterthantheIOrate. * **Writes** - Awritedatatransferbetweenthedirectorandthecache.AnIOmayrequiremultiplerequestsdependingonIOsize,alignmentorboth.TherequestsrateshouldbeeitherequaltoorgreaterthantheIOrate. * **IOs** - An IO command to the disk. * **MBRead** - The reads per second in MBs. * **MBWritten** - The writes per second in MBs. * **MBs** - The total IO (reads and writes) per second in MBs. * **AvgIOSize** - The average IO size served by the port * **SpeedGBs** - The number of gigabits moving through the port  per second. * **MaxSpeedGBs** - The max number of gigabits moving through the port  per second. * **PercentBusy** - The percent of time the port is busy.  | 

## Methods

### NewBePortParam

`func NewBePortParam(startDate int64, endDate int64, symmetrixId string, directorId string, portId string, metrics []string, ) *BePortParam`

NewBePortParam instantiates a new BePortParam object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewBePortParamWithDefaults

`func NewBePortParamWithDefaults() *BePortParam`

NewBePortParamWithDefaults instantiates a new BePortParam object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetStartDate

`func (o *BePortParam) GetStartDate() int64`

GetStartDate returns the StartDate field if non-nil, zero value otherwise.

### GetStartDateOk

`func (o *BePortParam) GetStartDateOk() (*int64, bool)`

GetStartDateOk returns a tuple with the StartDate field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetStartDate

`func (o *BePortParam) SetStartDate(v int64)`

SetStartDate sets StartDate field to given value.


### GetEndDate

`func (o *BePortParam) GetEndDate() int64`

GetEndDate returns the EndDate field if non-nil, zero value otherwise.

### GetEndDateOk

`func (o *BePortParam) GetEndDateOk() (*int64, bool)`

GetEndDateOk returns a tuple with the EndDate field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetEndDate

`func (o *BePortParam) SetEndDate(v int64)`

SetEndDate sets EndDate field to given value.


### GetSymmetrixId

`func (o *BePortParam) GetSymmetrixId() string`

GetSymmetrixId returns the SymmetrixId field if non-nil, zero value otherwise.

### GetSymmetrixIdOk

`func (o *BePortParam) GetSymmetrixIdOk() (*string, bool)`

GetSymmetrixIdOk returns a tuple with the SymmetrixId field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetSymmetrixId

`func (o *BePortParam) SetSymmetrixId(v string)`

SetSymmetrixId sets SymmetrixId field to given value.


### GetDirectorId

`func (o *BePortParam) GetDirectorId() string`

GetDirectorId returns the DirectorId field if non-nil, zero value otherwise.

### GetDirectorIdOk

`func (o *BePortParam) GetDirectorIdOk() (*string, bool)`

GetDirectorIdOk returns a tuple with the DirectorId field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetDirectorId

`func (o *BePortParam) SetDirectorId(v string)`

SetDirectorId sets DirectorId field to given value.


### GetPortId

`func (o *BePortParam) GetPortId() string`

GetPortId returns the PortId field if non-nil, zero value otherwise.

### GetPortIdOk

`func (o *BePortParam) GetPortIdOk() (*string, bool)`

GetPortIdOk returns a tuple with the PortId field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetPortId

`func (o *BePortParam) SetPortId(v string)`

SetPortId sets PortId field to given value.


### GetDataFormat

`func (o *BePortParam) GetDataFormat() string`

GetDataFormat returns the DataFormat field if non-nil, zero value otherwise.

### GetDataFormatOk

`func (o *BePortParam) GetDataFormatOk() (*string, bool)`

GetDataFormatOk returns a tuple with the DataFormat field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetDataFormat

`func (o *BePortParam) SetDataFormat(v string)`

SetDataFormat sets DataFormat field to given value.

### HasDataFormat

`func (o *BePortParam) HasDataFormat() bool`

HasDataFormat returns a boolean if a field has been set.

### GetMetrics

`func (o *BePortParam) GetMetrics() []string`

GetMetrics returns the Metrics field if non-nil, zero value otherwise.

### GetMetricsOk

`func (o *BePortParam) GetMetricsOk() (*[]string, bool)`

GetMetricsOk returns a tuple with the Metrics field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetMetrics

`func (o *BePortParam) SetMetrics(v []string)`

SetMetrics sets Metrics field to given value.



[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


