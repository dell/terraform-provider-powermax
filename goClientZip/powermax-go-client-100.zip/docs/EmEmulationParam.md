# EmEmulationParam

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**StartDate** | **int64** | Starting date in millisecond. | 
**EndDate** | **int64** | Ending date in millisecond. | 
**SystemId** | **string** | &lt;p&gt;The Symmetrix array ID.&lt;/p&gt; | 
**EmEmulationId** | **string** | emEmulationId | 
**DataFormat** | Pointer to **string** | &lt;p&gt;Data Format (Average or Maximum).&lt;/p&gt;   Enumeration values: * **Average** * **Maximum**  | [optional] 
**Metrics** | **[]string** | metrics   Enumeration values: * **TotalWorkTime** - Total Work Time. * **PercentBusy** - % Busy  | 

## Methods

### NewEmEmulationParam

`func NewEmEmulationParam(startDate int64, endDate int64, systemId string, emEmulationId string, metrics []string, ) *EmEmulationParam`

NewEmEmulationParam instantiates a new EmEmulationParam object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewEmEmulationParamWithDefaults

`func NewEmEmulationParamWithDefaults() *EmEmulationParam`

NewEmEmulationParamWithDefaults instantiates a new EmEmulationParam object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetStartDate

`func (o *EmEmulationParam) GetStartDate() int64`

GetStartDate returns the StartDate field if non-nil, zero value otherwise.

### GetStartDateOk

`func (o *EmEmulationParam) GetStartDateOk() (*int64, bool)`

GetStartDateOk returns a tuple with the StartDate field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetStartDate

`func (o *EmEmulationParam) SetStartDate(v int64)`

SetStartDate sets StartDate field to given value.


### GetEndDate

`func (o *EmEmulationParam) GetEndDate() int64`

GetEndDate returns the EndDate field if non-nil, zero value otherwise.

### GetEndDateOk

`func (o *EmEmulationParam) GetEndDateOk() (*int64, bool)`

GetEndDateOk returns a tuple with the EndDate field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetEndDate

`func (o *EmEmulationParam) SetEndDate(v int64)`

SetEndDate sets EndDate field to given value.


### GetSystemId

`func (o *EmEmulationParam) GetSystemId() string`

GetSystemId returns the SystemId field if non-nil, zero value otherwise.

### GetSystemIdOk

`func (o *EmEmulationParam) GetSystemIdOk() (*string, bool)`

GetSystemIdOk returns a tuple with the SystemId field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetSystemId

`func (o *EmEmulationParam) SetSystemId(v string)`

SetSystemId sets SystemId field to given value.


### GetEmEmulationId

`func (o *EmEmulationParam) GetEmEmulationId() string`

GetEmEmulationId returns the EmEmulationId field if non-nil, zero value otherwise.

### GetEmEmulationIdOk

`func (o *EmEmulationParam) GetEmEmulationIdOk() (*string, bool)`

GetEmEmulationIdOk returns a tuple with the EmEmulationId field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetEmEmulationId

`func (o *EmEmulationParam) SetEmEmulationId(v string)`

SetEmEmulationId sets EmEmulationId field to given value.


### GetDataFormat

`func (o *EmEmulationParam) GetDataFormat() string`

GetDataFormat returns the DataFormat field if non-nil, zero value otherwise.

### GetDataFormatOk

`func (o *EmEmulationParam) GetDataFormatOk() (*string, bool)`

GetDataFormatOk returns a tuple with the DataFormat field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetDataFormat

`func (o *EmEmulationParam) SetDataFormat(v string)`

SetDataFormat sets DataFormat field to given value.

### HasDataFormat

`func (o *EmEmulationParam) HasDataFormat() bool`

HasDataFormat returns a boolean if a field has been set.

### GetMetrics

`func (o *EmEmulationParam) GetMetrics() []string`

GetMetrics returns the Metrics field if non-nil, zero value otherwise.

### GetMetricsOk

`func (o *EmEmulationParam) GetMetricsOk() (*[]string, bool)`

GetMetricsOk returns a tuple with the Metrics field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetMetrics

`func (o *EmEmulationParam) SetMetrics(v []string)`

SetMetrics sets Metrics field to given value.



[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


