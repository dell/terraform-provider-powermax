# CloudJobInfo

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**CloudJobId** | **string** | The ID of the Cloud Job | 
**CloudSnapshotId** | Pointer to **string** | The id of the Cloud Snapshot | [optional] 
**StartDateMilliseconds** | Pointer to **int64** | The Cloud Job Start Date in milliseconds from Epoch | [optional] 
**StartDate** | Pointer to **string** | The Cloud Job Start Date | [optional] 
**CompletedDateMilliseconds** | Pointer to **int64** | The Cloud Job Completed Date in milliseconds from Epoch | [optional] 
**CompletedDate** | Pointer to **string** | The Cloud Job Completed Date | [optional] 

## Methods

### NewCloudJobInfo

`func NewCloudJobInfo(cloudJobId string, ) *CloudJobInfo`

NewCloudJobInfo instantiates a new CloudJobInfo object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewCloudJobInfoWithDefaults

`func NewCloudJobInfoWithDefaults() *CloudJobInfo`

NewCloudJobInfoWithDefaults instantiates a new CloudJobInfo object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetCloudJobId

`func (o *CloudJobInfo) GetCloudJobId() string`

GetCloudJobId returns the CloudJobId field if non-nil, zero value otherwise.

### GetCloudJobIdOk

`func (o *CloudJobInfo) GetCloudJobIdOk() (*string, bool)`

GetCloudJobIdOk returns a tuple with the CloudJobId field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetCloudJobId

`func (o *CloudJobInfo) SetCloudJobId(v string)`

SetCloudJobId sets CloudJobId field to given value.


### GetCloudSnapshotId

`func (o *CloudJobInfo) GetCloudSnapshotId() string`

GetCloudSnapshotId returns the CloudSnapshotId field if non-nil, zero value otherwise.

### GetCloudSnapshotIdOk

`func (o *CloudJobInfo) GetCloudSnapshotIdOk() (*string, bool)`

GetCloudSnapshotIdOk returns a tuple with the CloudSnapshotId field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetCloudSnapshotId

`func (o *CloudJobInfo) SetCloudSnapshotId(v string)`

SetCloudSnapshotId sets CloudSnapshotId field to given value.

### HasCloudSnapshotId

`func (o *CloudJobInfo) HasCloudSnapshotId() bool`

HasCloudSnapshotId returns a boolean if a field has been set.

### GetStartDateMilliseconds

`func (o *CloudJobInfo) GetStartDateMilliseconds() int64`

GetStartDateMilliseconds returns the StartDateMilliseconds field if non-nil, zero value otherwise.

### GetStartDateMillisecondsOk

`func (o *CloudJobInfo) GetStartDateMillisecondsOk() (*int64, bool)`

GetStartDateMillisecondsOk returns a tuple with the StartDateMilliseconds field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetStartDateMilliseconds

`func (o *CloudJobInfo) SetStartDateMilliseconds(v int64)`

SetStartDateMilliseconds sets StartDateMilliseconds field to given value.

### HasStartDateMilliseconds

`func (o *CloudJobInfo) HasStartDateMilliseconds() bool`

HasStartDateMilliseconds returns a boolean if a field has been set.

### GetStartDate

`func (o *CloudJobInfo) GetStartDate() string`

GetStartDate returns the StartDate field if non-nil, zero value otherwise.

### GetStartDateOk

`func (o *CloudJobInfo) GetStartDateOk() (*string, bool)`

GetStartDateOk returns a tuple with the StartDate field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetStartDate

`func (o *CloudJobInfo) SetStartDate(v string)`

SetStartDate sets StartDate field to given value.

### HasStartDate

`func (o *CloudJobInfo) HasStartDate() bool`

HasStartDate returns a boolean if a field has been set.

### GetCompletedDateMilliseconds

`func (o *CloudJobInfo) GetCompletedDateMilliseconds() int64`

GetCompletedDateMilliseconds returns the CompletedDateMilliseconds field if non-nil, zero value otherwise.

### GetCompletedDateMillisecondsOk

`func (o *CloudJobInfo) GetCompletedDateMillisecondsOk() (*int64, bool)`

GetCompletedDateMillisecondsOk returns a tuple with the CompletedDateMilliseconds field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetCompletedDateMilliseconds

`func (o *CloudJobInfo) SetCompletedDateMilliseconds(v int64)`

SetCompletedDateMilliseconds sets CompletedDateMilliseconds field to given value.

### HasCompletedDateMilliseconds

`func (o *CloudJobInfo) HasCompletedDateMilliseconds() bool`

HasCompletedDateMilliseconds returns a boolean if a field has been set.

### GetCompletedDate

`func (o *CloudJobInfo) GetCompletedDate() string`

GetCompletedDate returns the CompletedDate field if non-nil, zero value otherwise.

### GetCompletedDateOk

`func (o *CloudJobInfo) GetCompletedDateOk() (*string, bool)`

GetCompletedDateOk returns a tuple with the CompletedDate field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetCompletedDate

`func (o *CloudJobInfo) SetCompletedDate(v string)`

SetCompletedDate sets CompletedDate field to given value.

### HasCompletedDate

`func (o *CloudJobInfo) HasCompletedDate() bool`

HasCompletedDate returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


