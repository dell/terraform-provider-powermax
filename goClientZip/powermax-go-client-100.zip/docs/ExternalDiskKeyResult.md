# ExternalDiskKeyResult

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ExternalDiskInfo** | Pointer to [**[]ExternalDiskInfo**](ExternalDiskInfo.md) | externalDiskInfo | [optional] 

## Methods

### NewExternalDiskKeyResult

`func NewExternalDiskKeyResult() *ExternalDiskKeyResult`

NewExternalDiskKeyResult instantiates a new ExternalDiskKeyResult object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewExternalDiskKeyResultWithDefaults

`func NewExternalDiskKeyResultWithDefaults() *ExternalDiskKeyResult`

NewExternalDiskKeyResultWithDefaults instantiates a new ExternalDiskKeyResult object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetExternalDiskInfo

`func (o *ExternalDiskKeyResult) GetExternalDiskInfo() []ExternalDiskInfo`

GetExternalDiskInfo returns the ExternalDiskInfo field if non-nil, zero value otherwise.

### GetExternalDiskInfoOk

`func (o *ExternalDiskKeyResult) GetExternalDiskInfoOk() (*[]ExternalDiskInfo, bool)`

GetExternalDiskInfoOk returns a tuple with the ExternalDiskInfo field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetExternalDiskInfo

`func (o *ExternalDiskKeyResult) SetExternalDiskInfo(v []ExternalDiskInfo)`

SetExternalDiskInfo sets ExternalDiskInfo field to given value.

### HasExternalDiskInfo

`func (o *ExternalDiskKeyResult) HasExternalDiskInfo() bool`

HasExternalDiskInfo returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


