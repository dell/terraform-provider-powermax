# MetroDrTriangle

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**MetroR1VolumeName** | **string** | The name of the volume in the R1 role of the Metro session | 
**MetroR2VolumeName** | **string** | The name of the volume in the R2 role of the Metro session | 
**DrVolumeName** | **string** | The name of the volume in the DR role | 
**MetroR1R2Paired** | Pointer to **bool** | Are the R1 and R2 volumes paired in the Metro session | [optional] 
**MetroR1DrPaired** | Pointer to **bool** | Are the metro R1 and DR volumes paired in the environment | [optional] 
**MetroR2DrPaired** | Pointer to **bool** | Are the metro R2 and DR volumes paired in the environment | [optional] 
**MetroR1Mapped** | Pointer to **bool** | Is the metro R1 volume mapped | [optional] 
**MetroR2Mapped** | Pointer to **bool** | Is the metro R2 volume mapped | [optional] 
**DrMapped** | Pointer to **bool** | Is the DR volume mapped | [optional] 

## Methods

### NewMetroDrTriangle

`func NewMetroDrTriangle(metroR1VolumeName string, metroR2VolumeName string, drVolumeName string, ) *MetroDrTriangle`

NewMetroDrTriangle instantiates a new MetroDrTriangle object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewMetroDrTriangleWithDefaults

`func NewMetroDrTriangleWithDefaults() *MetroDrTriangle`

NewMetroDrTriangleWithDefaults instantiates a new MetroDrTriangle object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetMetroR1VolumeName

`func (o *MetroDrTriangle) GetMetroR1VolumeName() string`

GetMetroR1VolumeName returns the MetroR1VolumeName field if non-nil, zero value otherwise.

### GetMetroR1VolumeNameOk

`func (o *MetroDrTriangle) GetMetroR1VolumeNameOk() (*string, bool)`

GetMetroR1VolumeNameOk returns a tuple with the MetroR1VolumeName field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetMetroR1VolumeName

`func (o *MetroDrTriangle) SetMetroR1VolumeName(v string)`

SetMetroR1VolumeName sets MetroR1VolumeName field to given value.


### GetMetroR2VolumeName

`func (o *MetroDrTriangle) GetMetroR2VolumeName() string`

GetMetroR2VolumeName returns the MetroR2VolumeName field if non-nil, zero value otherwise.

### GetMetroR2VolumeNameOk

`func (o *MetroDrTriangle) GetMetroR2VolumeNameOk() (*string, bool)`

GetMetroR2VolumeNameOk returns a tuple with the MetroR2VolumeName field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetMetroR2VolumeName

`func (o *MetroDrTriangle) SetMetroR2VolumeName(v string)`

SetMetroR2VolumeName sets MetroR2VolumeName field to given value.


### GetDrVolumeName

`func (o *MetroDrTriangle) GetDrVolumeName() string`

GetDrVolumeName returns the DrVolumeName field if non-nil, zero value otherwise.

### GetDrVolumeNameOk

`func (o *MetroDrTriangle) GetDrVolumeNameOk() (*string, bool)`

GetDrVolumeNameOk returns a tuple with the DrVolumeName field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetDrVolumeName

`func (o *MetroDrTriangle) SetDrVolumeName(v string)`

SetDrVolumeName sets DrVolumeName field to given value.


### GetMetroR1R2Paired

`func (o *MetroDrTriangle) GetMetroR1R2Paired() bool`

GetMetroR1R2Paired returns the MetroR1R2Paired field if non-nil, zero value otherwise.

### GetMetroR1R2PairedOk

`func (o *MetroDrTriangle) GetMetroR1R2PairedOk() (*bool, bool)`

GetMetroR1R2PairedOk returns a tuple with the MetroR1R2Paired field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetMetroR1R2Paired

`func (o *MetroDrTriangle) SetMetroR1R2Paired(v bool)`

SetMetroR1R2Paired sets MetroR1R2Paired field to given value.

### HasMetroR1R2Paired

`func (o *MetroDrTriangle) HasMetroR1R2Paired() bool`

HasMetroR1R2Paired returns a boolean if a field has been set.

### GetMetroR1DrPaired

`func (o *MetroDrTriangle) GetMetroR1DrPaired() bool`

GetMetroR1DrPaired returns the MetroR1DrPaired field if non-nil, zero value otherwise.

### GetMetroR1DrPairedOk

`func (o *MetroDrTriangle) GetMetroR1DrPairedOk() (*bool, bool)`

GetMetroR1DrPairedOk returns a tuple with the MetroR1DrPaired field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetMetroR1DrPaired

`func (o *MetroDrTriangle) SetMetroR1DrPaired(v bool)`

SetMetroR1DrPaired sets MetroR1DrPaired field to given value.

### HasMetroR1DrPaired

`func (o *MetroDrTriangle) HasMetroR1DrPaired() bool`

HasMetroR1DrPaired returns a boolean if a field has been set.

### GetMetroR2DrPaired

`func (o *MetroDrTriangle) GetMetroR2DrPaired() bool`

GetMetroR2DrPaired returns the MetroR2DrPaired field if non-nil, zero value otherwise.

### GetMetroR2DrPairedOk

`func (o *MetroDrTriangle) GetMetroR2DrPairedOk() (*bool, bool)`

GetMetroR2DrPairedOk returns a tuple with the MetroR2DrPaired field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetMetroR2DrPaired

`func (o *MetroDrTriangle) SetMetroR2DrPaired(v bool)`

SetMetroR2DrPaired sets MetroR2DrPaired field to given value.

### HasMetroR2DrPaired

`func (o *MetroDrTriangle) HasMetroR2DrPaired() bool`

HasMetroR2DrPaired returns a boolean if a field has been set.

### GetMetroR1Mapped

`func (o *MetroDrTriangle) GetMetroR1Mapped() bool`

GetMetroR1Mapped returns the MetroR1Mapped field if non-nil, zero value otherwise.

### GetMetroR1MappedOk

`func (o *MetroDrTriangle) GetMetroR1MappedOk() (*bool, bool)`

GetMetroR1MappedOk returns a tuple with the MetroR1Mapped field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetMetroR1Mapped

`func (o *MetroDrTriangle) SetMetroR1Mapped(v bool)`

SetMetroR1Mapped sets MetroR1Mapped field to given value.

### HasMetroR1Mapped

`func (o *MetroDrTriangle) HasMetroR1Mapped() bool`

HasMetroR1Mapped returns a boolean if a field has been set.

### GetMetroR2Mapped

`func (o *MetroDrTriangle) GetMetroR2Mapped() bool`

GetMetroR2Mapped returns the MetroR2Mapped field if non-nil, zero value otherwise.

### GetMetroR2MappedOk

`func (o *MetroDrTriangle) GetMetroR2MappedOk() (*bool, bool)`

GetMetroR2MappedOk returns a tuple with the MetroR2Mapped field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetMetroR2Mapped

`func (o *MetroDrTriangle) SetMetroR2Mapped(v bool)`

SetMetroR2Mapped sets MetroR2Mapped field to given value.

### HasMetroR2Mapped

`func (o *MetroDrTriangle) HasMetroR2Mapped() bool`

HasMetroR2Mapped returns a boolean if a field has been set.

### GetDrMapped

`func (o *MetroDrTriangle) GetDrMapped() bool`

GetDrMapped returns the DrMapped field if non-nil, zero value otherwise.

### GetDrMappedOk

`func (o *MetroDrTriangle) GetDrMappedOk() (*bool, bool)`

GetDrMappedOk returns a tuple with the DrMapped field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetDrMapped

`func (o *MetroDrTriangle) SetDrMapped(v bool)`

SetDrMapped sets DrMapped field to given value.

### HasDrMapped

`func (o *MetroDrTriangle) HasDrMapped() bool`

HasDrMapped returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


