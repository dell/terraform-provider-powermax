# FiconEmulationKeyParam

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**SymmetrixId** | **string** | &lt;p&gt;The Symmetrix array ID.&lt;/p&gt; | 

## Methods

### NewFiconEmulationKeyParam

`func NewFiconEmulationKeyParam(symmetrixId string, ) *FiconEmulationKeyParam`

NewFiconEmulationKeyParam instantiates a new FiconEmulationKeyParam object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewFiconEmulationKeyParamWithDefaults

`func NewFiconEmulationKeyParamWithDefaults() *FiconEmulationKeyParam`

NewFiconEmulationKeyParamWithDefaults instantiates a new FiconEmulationKeyParam object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetSymmetrixId

`func (o *FiconEmulationKeyParam) GetSymmetrixId() string`

GetSymmetrixId returns the SymmetrixId field if non-nil, zero value otherwise.

### GetSymmetrixIdOk

`func (o *FiconEmulationKeyParam) GetSymmetrixIdOk() (*string, bool)`

GetSymmetrixIdOk returns a tuple with the SymmetrixId field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetSymmetrixId

`func (o *FiconEmulationKeyParam) SetSymmetrixId(v string)`

SetSymmetrixId sets SymmetrixId field to given value.



[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


