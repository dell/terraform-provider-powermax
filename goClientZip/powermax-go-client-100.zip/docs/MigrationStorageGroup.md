# MigrationStorageGroup

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**SourceArray** | Pointer to **string** | The name of the source System. | [optional] 
**TargetArray** | Pointer to **string** | The name of the target System. | [optional] 
**StorageGroup** | Pointer to **string** | The name of the Storage Group involved in the migration. | [optional] 
**State** | Pointer to **string** | The state of the migration session | [optional] 
**TotalCapacity** | Pointer to **float64** | This is the total amount of data, in GB, to be migrated. | [optional] 
**RemainingCapacity** | Pointer to **float64** | The capacity, in GB, that remains to be synchronized in the migrating state and cutover-syncing states. The value 0 will be                         returned for                         all other states. | [optional] 
**DevicePairs** | Pointer to [**[]MigrationDevicePair**](MigrationDevicePair.md) | The Migration Device Pairs in the Storage Group | [optional] 
**SourceMaskingView** | Pointer to [**[]MigrationMaskingView**](MigrationMaskingView.md) | The source Masking View for the Storage Group | [optional] 
**TargetMaskingView** | Pointer to [**[]MigrationMaskingView**](MigrationMaskingView.md) | The target Masking View for the Storage Group. These are not populated when target side masking views haven&#39;t yet been created. | [optional] 
**TargetInitiatorGroup** | Pointer to [**[]MigrationInitiatorGroup**](MigrationInitiatorGroup.md) | The target initiator groups for the Storage Group migration. These are populated when they&#39;re not in a masking view related to                         the migration. | [optional] 
**TargetPortGroup** | Pointer to [**[]MigrationPortGroup**](MigrationPortGroup.md) | The target port groups for the Storage Group migration. These are populated when they&#39;re not in a masking view related to the                         migration. | [optional] 
**Offline** | Pointer to **bool** | Set when the migration is a minimally disruptive migration | [optional] 
**Type** | **string** | Indicator of the Migration type | 

## Methods

### NewMigrationStorageGroup

`func NewMigrationStorageGroup(type_ string, ) *MigrationStorageGroup`

NewMigrationStorageGroup instantiates a new MigrationStorageGroup object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewMigrationStorageGroupWithDefaults

`func NewMigrationStorageGroupWithDefaults() *MigrationStorageGroup`

NewMigrationStorageGroupWithDefaults instantiates a new MigrationStorageGroup object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetSourceArray

`func (o *MigrationStorageGroup) GetSourceArray() string`

GetSourceArray returns the SourceArray field if non-nil, zero value otherwise.

### GetSourceArrayOk

`func (o *MigrationStorageGroup) GetSourceArrayOk() (*string, bool)`

GetSourceArrayOk returns a tuple with the SourceArray field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetSourceArray

`func (o *MigrationStorageGroup) SetSourceArray(v string)`

SetSourceArray sets SourceArray field to given value.

### HasSourceArray

`func (o *MigrationStorageGroup) HasSourceArray() bool`

HasSourceArray returns a boolean if a field has been set.

### GetTargetArray

`func (o *MigrationStorageGroup) GetTargetArray() string`

GetTargetArray returns the TargetArray field if non-nil, zero value otherwise.

### GetTargetArrayOk

`func (o *MigrationStorageGroup) GetTargetArrayOk() (*string, bool)`

GetTargetArrayOk returns a tuple with the TargetArray field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetTargetArray

`func (o *MigrationStorageGroup) SetTargetArray(v string)`

SetTargetArray sets TargetArray field to given value.

### HasTargetArray

`func (o *MigrationStorageGroup) HasTargetArray() bool`

HasTargetArray returns a boolean if a field has been set.

### GetStorageGroup

`func (o *MigrationStorageGroup) GetStorageGroup() string`

GetStorageGroup returns the StorageGroup field if non-nil, zero value otherwise.

### GetStorageGroupOk

`func (o *MigrationStorageGroup) GetStorageGroupOk() (*string, bool)`

GetStorageGroupOk returns a tuple with the StorageGroup field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetStorageGroup

`func (o *MigrationStorageGroup) SetStorageGroup(v string)`

SetStorageGroup sets StorageGroup field to given value.

### HasStorageGroup

`func (o *MigrationStorageGroup) HasStorageGroup() bool`

HasStorageGroup returns a boolean if a field has been set.

### GetState

`func (o *MigrationStorageGroup) GetState() string`

GetState returns the State field if non-nil, zero value otherwise.

### GetStateOk

`func (o *MigrationStorageGroup) GetStateOk() (*string, bool)`

GetStateOk returns a tuple with the State field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetState

`func (o *MigrationStorageGroup) SetState(v string)`

SetState sets State field to given value.

### HasState

`func (o *MigrationStorageGroup) HasState() bool`

HasState returns a boolean if a field has been set.

### GetTotalCapacity

`func (o *MigrationStorageGroup) GetTotalCapacity() float64`

GetTotalCapacity returns the TotalCapacity field if non-nil, zero value otherwise.

### GetTotalCapacityOk

`func (o *MigrationStorageGroup) GetTotalCapacityOk() (*float64, bool)`

GetTotalCapacityOk returns a tuple with the TotalCapacity field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetTotalCapacity

`func (o *MigrationStorageGroup) SetTotalCapacity(v float64)`

SetTotalCapacity sets TotalCapacity field to given value.

### HasTotalCapacity

`func (o *MigrationStorageGroup) HasTotalCapacity() bool`

HasTotalCapacity returns a boolean if a field has been set.

### GetRemainingCapacity

`func (o *MigrationStorageGroup) GetRemainingCapacity() float64`

GetRemainingCapacity returns the RemainingCapacity field if non-nil, zero value otherwise.

### GetRemainingCapacityOk

`func (o *MigrationStorageGroup) GetRemainingCapacityOk() (*float64, bool)`

GetRemainingCapacityOk returns a tuple with the RemainingCapacity field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetRemainingCapacity

`func (o *MigrationStorageGroup) SetRemainingCapacity(v float64)`

SetRemainingCapacity sets RemainingCapacity field to given value.

### HasRemainingCapacity

`func (o *MigrationStorageGroup) HasRemainingCapacity() bool`

HasRemainingCapacity returns a boolean if a field has been set.

### GetDevicePairs

`func (o *MigrationStorageGroup) GetDevicePairs() []MigrationDevicePair`

GetDevicePairs returns the DevicePairs field if non-nil, zero value otherwise.

### GetDevicePairsOk

`func (o *MigrationStorageGroup) GetDevicePairsOk() (*[]MigrationDevicePair, bool)`

GetDevicePairsOk returns a tuple with the DevicePairs field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetDevicePairs

`func (o *MigrationStorageGroup) SetDevicePairs(v []MigrationDevicePair)`

SetDevicePairs sets DevicePairs field to given value.

### HasDevicePairs

`func (o *MigrationStorageGroup) HasDevicePairs() bool`

HasDevicePairs returns a boolean if a field has been set.

### GetSourceMaskingView

`func (o *MigrationStorageGroup) GetSourceMaskingView() []MigrationMaskingView`

GetSourceMaskingView returns the SourceMaskingView field if non-nil, zero value otherwise.

### GetSourceMaskingViewOk

`func (o *MigrationStorageGroup) GetSourceMaskingViewOk() (*[]MigrationMaskingView, bool)`

GetSourceMaskingViewOk returns a tuple with the SourceMaskingView field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetSourceMaskingView

`func (o *MigrationStorageGroup) SetSourceMaskingView(v []MigrationMaskingView)`

SetSourceMaskingView sets SourceMaskingView field to given value.

### HasSourceMaskingView

`func (o *MigrationStorageGroup) HasSourceMaskingView() bool`

HasSourceMaskingView returns a boolean if a field has been set.

### GetTargetMaskingView

`func (o *MigrationStorageGroup) GetTargetMaskingView() []MigrationMaskingView`

GetTargetMaskingView returns the TargetMaskingView field if non-nil, zero value otherwise.

### GetTargetMaskingViewOk

`func (o *MigrationStorageGroup) GetTargetMaskingViewOk() (*[]MigrationMaskingView, bool)`

GetTargetMaskingViewOk returns a tuple with the TargetMaskingView field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetTargetMaskingView

`func (o *MigrationStorageGroup) SetTargetMaskingView(v []MigrationMaskingView)`

SetTargetMaskingView sets TargetMaskingView field to given value.

### HasTargetMaskingView

`func (o *MigrationStorageGroup) HasTargetMaskingView() bool`

HasTargetMaskingView returns a boolean if a field has been set.

### GetTargetInitiatorGroup

`func (o *MigrationStorageGroup) GetTargetInitiatorGroup() []MigrationInitiatorGroup`

GetTargetInitiatorGroup returns the TargetInitiatorGroup field if non-nil, zero value otherwise.

### GetTargetInitiatorGroupOk

`func (o *MigrationStorageGroup) GetTargetInitiatorGroupOk() (*[]MigrationInitiatorGroup, bool)`

GetTargetInitiatorGroupOk returns a tuple with the TargetInitiatorGroup field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetTargetInitiatorGroup

`func (o *MigrationStorageGroup) SetTargetInitiatorGroup(v []MigrationInitiatorGroup)`

SetTargetInitiatorGroup sets TargetInitiatorGroup field to given value.

### HasTargetInitiatorGroup

`func (o *MigrationStorageGroup) HasTargetInitiatorGroup() bool`

HasTargetInitiatorGroup returns a boolean if a field has been set.

### GetTargetPortGroup

`func (o *MigrationStorageGroup) GetTargetPortGroup() []MigrationPortGroup`

GetTargetPortGroup returns the TargetPortGroup field if non-nil, zero value otherwise.

### GetTargetPortGroupOk

`func (o *MigrationStorageGroup) GetTargetPortGroupOk() (*[]MigrationPortGroup, bool)`

GetTargetPortGroupOk returns a tuple with the TargetPortGroup field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetTargetPortGroup

`func (o *MigrationStorageGroup) SetTargetPortGroup(v []MigrationPortGroup)`

SetTargetPortGroup sets TargetPortGroup field to given value.

### HasTargetPortGroup

`func (o *MigrationStorageGroup) HasTargetPortGroup() bool`

HasTargetPortGroup returns a boolean if a field has been set.

### GetOffline

`func (o *MigrationStorageGroup) GetOffline() bool`

GetOffline returns the Offline field if non-nil, zero value otherwise.

### GetOfflineOk

`func (o *MigrationStorageGroup) GetOfflineOk() (*bool, bool)`

GetOfflineOk returns a tuple with the Offline field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetOffline

`func (o *MigrationStorageGroup) SetOffline(v bool)`

SetOffline sets Offline field to given value.

### HasOffline

`func (o *MigrationStorageGroup) HasOffline() bool`

HasOffline returns a boolean if a field has been set.

### GetType

`func (o *MigrationStorageGroup) GetType() string`

GetType returns the Type field if non-nil, zero value otherwise.

### GetTypeOk

`func (o *MigrationStorageGroup) GetTypeOk() (*string, bool)`

GetTypeOk returns a tuple with the Type field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetType

`func (o *MigrationStorageGroup) SetType(v string)`

SetType sets Type field to given value.



[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


