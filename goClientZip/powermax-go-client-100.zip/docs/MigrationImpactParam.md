# MigrationImpactParam

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**SourceSymmetrixId** | **string** | Source Array ID for storage group to be migrated. | 
**SourceStorageGroupId** | **string** | Storage group to be migrated. | 

## Methods

### NewMigrationImpactParam

`func NewMigrationImpactParam(sourceSymmetrixId string, sourceStorageGroupId string, ) *MigrationImpactParam`

NewMigrationImpactParam instantiates a new MigrationImpactParam object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewMigrationImpactParamWithDefaults

`func NewMigrationImpactParamWithDefaults() *MigrationImpactParam`

NewMigrationImpactParamWithDefaults instantiates a new MigrationImpactParam object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetSourceSymmetrixId

`func (o *MigrationImpactParam) GetSourceSymmetrixId() string`

GetSourceSymmetrixId returns the SourceSymmetrixId field if non-nil, zero value otherwise.

### GetSourceSymmetrixIdOk

`func (o *MigrationImpactParam) GetSourceSymmetrixIdOk() (*string, bool)`

GetSourceSymmetrixIdOk returns a tuple with the SourceSymmetrixId field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetSourceSymmetrixId

`func (o *MigrationImpactParam) SetSourceSymmetrixId(v string)`

SetSourceSymmetrixId sets SourceSymmetrixId field to given value.


### GetSourceStorageGroupId

`func (o *MigrationImpactParam) GetSourceStorageGroupId() string`

GetSourceStorageGroupId returns the SourceStorageGroupId field if non-nil, zero value otherwise.

### GetSourceStorageGroupIdOk

`func (o *MigrationImpactParam) GetSourceStorageGroupIdOk() (*string, bool)`

GetSourceStorageGroupIdOk returns a tuple with the SourceStorageGroupId field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetSourceStorageGroupId

`func (o *MigrationImpactParam) SetSourceStorageGroupId(v string)`

SetSourceStorageGroupId sets SourceStorageGroupId field to given value.



[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


