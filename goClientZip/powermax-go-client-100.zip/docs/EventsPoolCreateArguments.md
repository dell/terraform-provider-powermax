# EventsPoolCreateArguments

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Name** | **string** |  Name of the eventspool | 
**EventsPublisher** | **string** |  Unique identifier Event Publisher  | 
**EventsPublisherServers** | **[]string** |                          Network identifier of the File Event Service servers. (fully qualified domain name or ip addresses).                         You can set at max 5 File Event Service Servers per Events Pool.                      | 
**PreEvents** | [**PreEventsList**](PreEventsList.md) |  | 
**PostEvents** | Pointer to [**PostEventsList**](PostEventsList.md) |  | [optional] 
**PostErrorEvents** | Pointer to [**PostErrorEventsList**](PostErrorEventsList.md) |  | [optional] 

## Methods

### NewEventsPoolCreateArguments

`func NewEventsPoolCreateArguments(name string, eventsPublisher string, eventsPublisherServers []string, preEvents PreEventsList, ) *EventsPoolCreateArguments`

NewEventsPoolCreateArguments instantiates a new EventsPoolCreateArguments object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewEventsPoolCreateArgumentsWithDefaults

`func NewEventsPoolCreateArgumentsWithDefaults() *EventsPoolCreateArguments`

NewEventsPoolCreateArgumentsWithDefaults instantiates a new EventsPoolCreateArguments object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetName

`func (o *EventsPoolCreateArguments) GetName() string`

GetName returns the Name field if non-nil, zero value otherwise.

### GetNameOk

`func (o *EventsPoolCreateArguments) GetNameOk() (*string, bool)`

GetNameOk returns a tuple with the Name field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetName

`func (o *EventsPoolCreateArguments) SetName(v string)`

SetName sets Name field to given value.


### GetEventsPublisher

`func (o *EventsPoolCreateArguments) GetEventsPublisher() string`

GetEventsPublisher returns the EventsPublisher field if non-nil, zero value otherwise.

### GetEventsPublisherOk

`func (o *EventsPoolCreateArguments) GetEventsPublisherOk() (*string, bool)`

GetEventsPublisherOk returns a tuple with the EventsPublisher field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetEventsPublisher

`func (o *EventsPoolCreateArguments) SetEventsPublisher(v string)`

SetEventsPublisher sets EventsPublisher field to given value.


### GetEventsPublisherServers

`func (o *EventsPoolCreateArguments) GetEventsPublisherServers() []string`

GetEventsPublisherServers returns the EventsPublisherServers field if non-nil, zero value otherwise.

### GetEventsPublisherServersOk

`func (o *EventsPoolCreateArguments) GetEventsPublisherServersOk() (*[]string, bool)`

GetEventsPublisherServersOk returns a tuple with the EventsPublisherServers field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetEventsPublisherServers

`func (o *EventsPoolCreateArguments) SetEventsPublisherServers(v []string)`

SetEventsPublisherServers sets EventsPublisherServers field to given value.


### GetPreEvents

`func (o *EventsPoolCreateArguments) GetPreEvents() PreEventsList`

GetPreEvents returns the PreEvents field if non-nil, zero value otherwise.

### GetPreEventsOk

`func (o *EventsPoolCreateArguments) GetPreEventsOk() (*PreEventsList, bool)`

GetPreEventsOk returns a tuple with the PreEvents field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetPreEvents

`func (o *EventsPoolCreateArguments) SetPreEvents(v PreEventsList)`

SetPreEvents sets PreEvents field to given value.


### GetPostEvents

`func (o *EventsPoolCreateArguments) GetPostEvents() PostEventsList`

GetPostEvents returns the PostEvents field if non-nil, zero value otherwise.

### GetPostEventsOk

`func (o *EventsPoolCreateArguments) GetPostEventsOk() (*PostEventsList, bool)`

GetPostEventsOk returns a tuple with the PostEvents field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetPostEvents

`func (o *EventsPoolCreateArguments) SetPostEvents(v PostEventsList)`

SetPostEvents sets PostEvents field to given value.

### HasPostEvents

`func (o *EventsPoolCreateArguments) HasPostEvents() bool`

HasPostEvents returns a boolean if a field has been set.

### GetPostErrorEvents

`func (o *EventsPoolCreateArguments) GetPostErrorEvents() PostErrorEventsList`

GetPostErrorEvents returns the PostErrorEvents field if non-nil, zero value otherwise.

### GetPostErrorEventsOk

`func (o *EventsPoolCreateArguments) GetPostErrorEventsOk() (*PostErrorEventsList, bool)`

GetPostErrorEventsOk returns a tuple with the PostErrorEvents field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetPostErrorEvents

`func (o *EventsPoolCreateArguments) SetPostErrorEvents(v PostErrorEventsList)`

SetPostErrorEvents sets PostErrorEvents field to given value.

### HasPostErrorEvents

`func (o *EventsPoolCreateArguments) HasPostErrorEvents() bool`

HasPostErrorEvents returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


