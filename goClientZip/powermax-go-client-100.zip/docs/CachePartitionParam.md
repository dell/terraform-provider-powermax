# CachePartitionParam

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**StartDate** | **int64** | Starting date in millisecond. | 
**EndDate** | **int64** | Ending date in millisecond. | 
**SymmetrixId** | **string** | &lt;p&gt;The Symmetrix array ID.&lt;/p&gt; | 
**CachePartitionId** | **string** | cachePartitionId | 
**DataFormat** | Pointer to **string** | &lt;p&gt;Data Format (Average or Maximum).&lt;/p&gt;   Enumeration values: * **Average** * **Maximum**  | [optional] 
**Metrics** | **[]string** | metrics   Enumeration values: * **WPCount** - A sampled value at the time of data collection. * **SystemMaxWPLimit** - The percent of the target % at which writes are delayed The range is from 40% to 80%. If the target is 30% and the write pending limit is 80%, then the actual limit is 24% of the cache. * **PercentTargetCache** - The percent of total cache allocated to this partition; cannot be less than 10% or larger than 90% and the sum of all targets must be equal to 100%. * **PercentMinCache** - The partition will not go below this allocation (from 0% to target %). * **PercentMaxCache** - The maximum slot allocation for a partition (from target % to 100%). * **CacheSlotsUsed** - The number of partition fall throughs under 8 seconds. A slot in this age range was removed or recycled as a new slot for other data. * **DonationTime** - The length of time a cache slot must age before being available for donation. * **PercentCacheUsed** - The percent of cache that is used. * **PercentWPUtilization** - Calculated value: (WP Count / (total slots * % Cache Used / 100) * 100) * **RemoteWPCount** - The number of writes pending for a remote system. * **LocalWPCount** - The calculation of the total writes pending minus the remote writes pending. * **HostIOs** - The number of host IOs per second. * **HostMBs** - The number of host MBs per second. * **PercentHit** - The percent of IOs that were immediately satisfied. * **AcquiredSlotCount** - Acquired Slot Count. * **AgeNonWPSlots** - Age Non WP Slots. * **AvgAgeGivenDestage** - Avg Age Given Destage. * **AvgAgeOfWriteToNonWPSlots** - Avg Age of Write to Non WP Slot. * **CacheAgeGT_10_Min** - Cache Age GT 10 Min. * **CacheAgeGT_1_Hour** - Cache Age GT 1 hour. * **CacheAgeGT_1_Min** - Cache Age GT 1 Min. * **CacheHitAges_1** - Cache Hit Ages 1. * **CacheHitAges_2** - Cache Hit Ages 2. * **CacheHitAges_3** - Cache Hit Ages 3. * **CacheHitAges_4** - Cache Hit Ages 4. * **CacheHitAges_5** - Cache Hit Ages 5. * **CacheHitAges_6** - Cache Hit Ages 6. * **CacheHitAges_7** - Cache Hit Ages 7. * **CacheHitAges_8** - Cache Hit Ages 8. * **CacheSlotAges_1** - Cache Slot Ages 1. * **CacheSlotAges_2** - Cache Slot Ages 2. * **CacheSlotAges_3** - Cache Slot Ages 3. * **CacheSlotAges_4** - Cache Slot Ages 4. * **CacheSlotAges_5** - Cache Slot Ages 5. * **CacheSlotAges_6** - Cache Slot Ages 6. * **CacheSlotAges_7** - Cache Slot Ages 7. * **CacheSlotAges_8** - Cache Slot Ages 8. * **DestageSlotAge** - Destage Slot Age. * **DestagedSlotCount** - Destaged Slot Count. * **DonationGiveCount** - Donation Give Count. * **DonationTakeCount** - Donation Take Count. * **TotalReplaceSlots** - Total Replace Slots. * **WritesToAllNonWPSlots** - Writes to All Non WP Slots. * **WritesToYoungNonWPSlots** - Writes to Young Non WP Slots. * **WPUsedCapacity** - WP Used Capacity * **LocalWPUsedCapacity** - Local WP Used Capacity * **RemoteWPUsedCapacity** - Remote WP Used Capacity * **ACQUIRE_SLOT_COUNT** - The number of cache partition slots acquired from other cache. * **AVG_AGE_GIVEN_DESTAGE** - Calculated value: (destage slot age) / (destaged slot count). * **AVG_AGE_WRITE_TO_NON_WP_SLOT** - Calculated value: (age non WP slots) / ((writes to all non WP slots) - (writes to young non WP slots)) * **AGE_NON_WP_SLOT** - The average time accumulated for non WP cache slots. * **CACHE_AGE_GT_1_HR** - The average fall-through-time w/ 1:08:16 second decay. Decay is a moving average, where the decay time is the \&quot;average time\&quot; average. * **CACHE_AGE_GT_1_MIN** - The average fall-through-time w/ 64 second decay. Decay is a moving average, where the decay time is the \&quot;average time\&quot; average. * **CACHE_AGE_GT_10_MIN** - The average fall-through-time w/ 8:32 second decay. Decay is a moving average, where the decay time is the \&quot;average time\&quot; average. * **CACHE_HIT_AGE_1** - The number of partition read hits under 4 seconds. A slot in this age range satisfied a host read request (cache hit) and was promoted to age zero. * **CACHE_HIT_AGE_2** - The number of partition read hits under 4 seconds. A slot in this age range satisfied a host read request (cache hit) and was promoted to age zero. * **CACHE_HIT_AGE_3** - The number of partition read hits under 4 seconds. A slot in this age range satisfied a host read request (cache hit) and was promoted to age zero. * **CACHE_HIT_AGE_4** - The number of partition read hits under 4 seconds. A slot in this age range satisfied a host read request (cache hit) and was promoted to age zero. * **CACHE_HIT_AGE_5** - The number of partition read hits under 4 seconds. A slot in this age range satisfied a host read request (cache hit) and was promoted to age zero. * **CACHE_HIT_AGE_6** - The number of partition read hits under 4 seconds. A slot in this age range satisfied a host read request (cache hit) and was promoted to age zero. * **CACHE_HIT_AGE_7** - The number of partition read hits under 4 seconds. A slot in this age range satisfied a host read request (cache hit) and was promoted to age zero. * **CACHE_HIT_AGE_8** - The number of partition read hits under 4 seconds. A slot in this age range satisfied a host read request (cache hit) and was promoted to age zero. * **CACHE_SLOT_AGE_1** - The number of partition read hits under 4 seconds. A slot in this age range satisfied a host read request (cache hit) and was promoted to age zero. * **CACHE_SLOT_AGE_2** - The number of partition fall throughs under 8 seconds. A slot in this age range was removed or recycled as a new slot for other data. * **CACHE_SLOT_AGE_3** - The number of partition fall throughs under 8 seconds. A slot in this age range was removed or recycled as a new slot for other data. * **CACHE_SLOT_AGE_4** - The number of partition fall throughs under 8 seconds. A slot in this age range was removed or recycled as a new slot for other data. * **CACHE_SLOT_AGE_5** - The number of partition fall throughs under 8 seconds. A slot in this age range was removed or recycled as a new slot for other data. * **CACHE_SLOT_AGE_6** - The number of partition fall throughs under 8 seconds. A slot in this age range was removed or recycled as a new slot for other data. * **CACHE_SLOT_AGE_7** - The number of partition fall throughs under 8 seconds. A slot in this age range was removed or recycled as a new slot for other data. * **CACHE_SLOT_AGE_8** - The number of partition fall throughs under 8 seconds. A slot in this age range was removed or recycled as a new slot for other data. * **CACHE_SLOT_USED** - The number of partition fall throughs under 8 seconds. A slot in this age range was removed or recycled as a new slot for other data. * **DESTAGE_SLOT_AGE** - The average time accumulated for destaged cache slots. * **DESTAGE_SLOT_COUNT** - The number of cache slots destaged. * **DONATION_GIVE_COUNT** - The amount of cache donated from other cache. * **DONATION_TAKE_COUNT** - The amount of cache donated to other cache. * **DONATION_TIME** - The length of time a cache slot must age before being available for donation. * **IO_RATE** - The number of host IOs per second. * **LOCAL_WP** - The calculation of the total writes pending minus the remote writes pending. * **MAX_CACHE_PERCENT** - The maximum slot allocation for a partition (from target % to 100%). * **MIN_CACHE_PERCENT** - The partition will not go below this allocation (from 0% to target %). * **MB_RATE** - The number of host MBs per second. * **PERCENT_BUSY** - Calculated value: (WP Count / (total slots * % Cache Used / 100) * 100) * **PERCENT_HIT** - The percent of IOs that were immediately satisfied. * **REMOTE_WP** - The number of writes pending for a remote system. * **SIZE** - The percent of cache that is used. * **TARGET_CACHE_PERCENT** - The percent of total cache allocated to this partition; cannot be less than 10% or larger than 90% and the sum of all targets must be equal to 100%. * **TOTAL_REPLACE_SLOTS** - The partition fall-through-time events (FT). * **WP** - A sampled value at the time of data collection. * **WP_LIMIT** - The percent of the target % at which writes are delayed The range is from 40% to 80%. If the target is 30% and the write pending limit is 80%, then the actual limit is 24% of the cache. * **WRITES_TO_ALL_NON_WP_SLOT** - The number of writes to all non WP cache slots that were 4 seconds or older. * **WRITES_TO_YOUNG_NON_WP_SLOT** - The number of writes to cache slots that were less than four seconds old.  | 

## Methods

### NewCachePartitionParam

`func NewCachePartitionParam(startDate int64, endDate int64, symmetrixId string, cachePartitionId string, metrics []string, ) *CachePartitionParam`

NewCachePartitionParam instantiates a new CachePartitionParam object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewCachePartitionParamWithDefaults

`func NewCachePartitionParamWithDefaults() *CachePartitionParam`

NewCachePartitionParamWithDefaults instantiates a new CachePartitionParam object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetStartDate

`func (o *CachePartitionParam) GetStartDate() int64`

GetStartDate returns the StartDate field if non-nil, zero value otherwise.

### GetStartDateOk

`func (o *CachePartitionParam) GetStartDateOk() (*int64, bool)`

GetStartDateOk returns a tuple with the StartDate field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetStartDate

`func (o *CachePartitionParam) SetStartDate(v int64)`

SetStartDate sets StartDate field to given value.


### GetEndDate

`func (o *CachePartitionParam) GetEndDate() int64`

GetEndDate returns the EndDate field if non-nil, zero value otherwise.

### GetEndDateOk

`func (o *CachePartitionParam) GetEndDateOk() (*int64, bool)`

GetEndDateOk returns a tuple with the EndDate field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetEndDate

`func (o *CachePartitionParam) SetEndDate(v int64)`

SetEndDate sets EndDate field to given value.


### GetSymmetrixId

`func (o *CachePartitionParam) GetSymmetrixId() string`

GetSymmetrixId returns the SymmetrixId field if non-nil, zero value otherwise.

### GetSymmetrixIdOk

`func (o *CachePartitionParam) GetSymmetrixIdOk() (*string, bool)`

GetSymmetrixIdOk returns a tuple with the SymmetrixId field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetSymmetrixId

`func (o *CachePartitionParam) SetSymmetrixId(v string)`

SetSymmetrixId sets SymmetrixId field to given value.


### GetCachePartitionId

`func (o *CachePartitionParam) GetCachePartitionId() string`

GetCachePartitionId returns the CachePartitionId field if non-nil, zero value otherwise.

### GetCachePartitionIdOk

`func (o *CachePartitionParam) GetCachePartitionIdOk() (*string, bool)`

GetCachePartitionIdOk returns a tuple with the CachePartitionId field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetCachePartitionId

`func (o *CachePartitionParam) SetCachePartitionId(v string)`

SetCachePartitionId sets CachePartitionId field to given value.


### GetDataFormat

`func (o *CachePartitionParam) GetDataFormat() string`

GetDataFormat returns the DataFormat field if non-nil, zero value otherwise.

### GetDataFormatOk

`func (o *CachePartitionParam) GetDataFormatOk() (*string, bool)`

GetDataFormatOk returns a tuple with the DataFormat field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetDataFormat

`func (o *CachePartitionParam) SetDataFormat(v string)`

SetDataFormat sets DataFormat field to given value.

### HasDataFormat

`func (o *CachePartitionParam) HasDataFormat() bool`

HasDataFormat returns a boolean if a field has been set.

### GetMetrics

`func (o *CachePartitionParam) GetMetrics() []string`

GetMetrics returns the Metrics field if non-nil, zero value otherwise.

### GetMetricsOk

`func (o *CachePartitionParam) GetMetricsOk() (*[]string, bool)`

GetMetricsOk returns a tuple with the Metrics field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetMetrics

`func (o *CachePartitionParam) SetMetrics(v []string)`

SetMetrics sets Metrics field to given value.



[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


