# ListPowerPathHostResult

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**PowerPathHostId** | Pointer to **[]string** | The PowerPath Host Name | [optional] 

## Methods

### NewListPowerPathHostResult

`func NewListPowerPathHostResult() *ListPowerPathHostResult`

NewListPowerPathHostResult instantiates a new ListPowerPathHostResult object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewListPowerPathHostResultWithDefaults

`func NewListPowerPathHostResultWithDefaults() *ListPowerPathHostResult`

NewListPowerPathHostResultWithDefaults instantiates a new ListPowerPathHostResult object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetPowerPathHostId

`func (o *ListPowerPathHostResult) GetPowerPathHostId() []string`

GetPowerPathHostId returns the PowerPathHostId field if non-nil, zero value otherwise.

### GetPowerPathHostIdOk

`func (o *ListPowerPathHostResult) GetPowerPathHostIdOk() (*[]string, bool)`

GetPowerPathHostIdOk returns a tuple with the PowerPathHostId field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetPowerPathHostId

`func (o *ListPowerPathHostResult) SetPowerPathHostId(v []string)`

SetPowerPathHostId sets PowerPathHostId field to given value.

### HasPowerPathHostId

`func (o *ListPowerPathHostResult) HasPowerPathHostId() bool`

HasPowerPathHostId returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


