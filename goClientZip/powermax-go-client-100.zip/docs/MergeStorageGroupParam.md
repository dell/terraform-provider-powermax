# MergeStorageGroupParam

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**StorageGroupId** | **string** | Standalone storage group name. | 

## Methods

### NewMergeStorageGroupParam

`func NewMergeStorageGroupParam(storageGroupId string, ) *MergeStorageGroupParam`

NewMergeStorageGroupParam instantiates a new MergeStorageGroupParam object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewMergeStorageGroupParamWithDefaults

`func NewMergeStorageGroupParamWithDefaults() *MergeStorageGroupParam`

NewMergeStorageGroupParamWithDefaults instantiates a new MergeStorageGroupParam object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetStorageGroupId

`func (o *MergeStorageGroupParam) GetStorageGroupId() string`

GetStorageGroupId returns the StorageGroupId field if non-nil, zero value otherwise.

### GetStorageGroupIdOk

`func (o *MergeStorageGroupParam) GetStorageGroupIdOk() (*string, bool)`

GetStorageGroupIdOk returns a tuple with the StorageGroupId field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetStorageGroupId

`func (o *MergeStorageGroupParam) SetStorageGroupId(v string)`

SetStorageGroupId sets StorageGroupId field to given value.



[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


