# EffectiveCapacityUsage

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**SnapshotUsedTb** | Pointer to **float64** | Snapshot Used capacity in TB | [optional] 
**UserUsedTb** | Pointer to **float64** | User Used capacity in TB | [optional] 
**FreeTb** | Pointer to **float64** | Free capacity in TB | [optional] 

## Methods

### NewEffectiveCapacityUsage

`func NewEffectiveCapacityUsage() *EffectiveCapacityUsage`

NewEffectiveCapacityUsage instantiates a new EffectiveCapacityUsage object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewEffectiveCapacityUsageWithDefaults

`func NewEffectiveCapacityUsageWithDefaults() *EffectiveCapacityUsage`

NewEffectiveCapacityUsageWithDefaults instantiates a new EffectiveCapacityUsage object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetSnapshotUsedTb

`func (o *EffectiveCapacityUsage) GetSnapshotUsedTb() float64`

GetSnapshotUsedTb returns the SnapshotUsedTb field if non-nil, zero value otherwise.

### GetSnapshotUsedTbOk

`func (o *EffectiveCapacityUsage) GetSnapshotUsedTbOk() (*float64, bool)`

GetSnapshotUsedTbOk returns a tuple with the SnapshotUsedTb field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetSnapshotUsedTb

`func (o *EffectiveCapacityUsage) SetSnapshotUsedTb(v float64)`

SetSnapshotUsedTb sets SnapshotUsedTb field to given value.

### HasSnapshotUsedTb

`func (o *EffectiveCapacityUsage) HasSnapshotUsedTb() bool`

HasSnapshotUsedTb returns a boolean if a field has been set.

### GetUserUsedTb

`func (o *EffectiveCapacityUsage) GetUserUsedTb() float64`

GetUserUsedTb returns the UserUsedTb field if non-nil, zero value otherwise.

### GetUserUsedTbOk

`func (o *EffectiveCapacityUsage) GetUserUsedTbOk() (*float64, bool)`

GetUserUsedTbOk returns a tuple with the UserUsedTb field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetUserUsedTb

`func (o *EffectiveCapacityUsage) SetUserUsedTb(v float64)`

SetUserUsedTb sets UserUsedTb field to given value.

### HasUserUsedTb

`func (o *EffectiveCapacityUsage) HasUserUsedTb() bool`

HasUserUsedTb returns a boolean if a field has been set.

### GetFreeTb

`func (o *EffectiveCapacityUsage) GetFreeTb() float64`

GetFreeTb returns the FreeTb field if non-nil, zero value otherwise.

### GetFreeTbOk

`func (o *EffectiveCapacityUsage) GetFreeTbOk() (*float64, bool)`

GetFreeTbOk returns a tuple with the FreeTb field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetFreeTb

`func (o *EffectiveCapacityUsage) SetFreeTb(v float64)`

SetFreeTb sets FreeTb field to given value.

### HasFreeTb

`func (o *EffectiveCapacityUsage) HasFreeTb() bool`

HasFreeTb returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


