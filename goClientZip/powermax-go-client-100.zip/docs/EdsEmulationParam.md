# EdsEmulationParam

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**StartDate** | **int64** | Starting date in millisecond. | 
**EndDate** | **int64** | Ending date in millisecond. | 
**SymmetrixId** | **string** | &lt;p&gt;The Symmetrix array ID.&lt;/p&gt; | 
**EdsEmulationId** | **string** | edsEmulationId | 
**DataFormat** | Pointer to **string** | &lt;p&gt;Data Format (Average or Maximum).&lt;/p&gt;   Enumeration values: * **Average** * **Maximum**  | [optional] 
**Metrics** | **[]string** | metrics   Enumeration values: * **EmulationTime** -  * **IOMachineTime** -  * **LPIOMachineTime** -  * **HousekeepingTime** -  * **LrepControlTime** -  * **VpTime** -  * **CopyScannerTime** -  * **PyramidTime** -  * **ScanTime** -  * **SnowSpilloverTime** -  * **RemoteReplicationTime** -  * **SyscallsTime** -  * **WatchdogTime** -  * **AllocationSplitTime** -  * **FsmTime** -  * **SymmkTotalTime** -  * **SymmkIdleTime** -  * **TotalWorkTime** - Total Work Time. * **PercentBusy** - % Busy  | 

## Methods

### NewEdsEmulationParam

`func NewEdsEmulationParam(startDate int64, endDate int64, symmetrixId string, edsEmulationId string, metrics []string, ) *EdsEmulationParam`

NewEdsEmulationParam instantiates a new EdsEmulationParam object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewEdsEmulationParamWithDefaults

`func NewEdsEmulationParamWithDefaults() *EdsEmulationParam`

NewEdsEmulationParamWithDefaults instantiates a new EdsEmulationParam object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetStartDate

`func (o *EdsEmulationParam) GetStartDate() int64`

GetStartDate returns the StartDate field if non-nil, zero value otherwise.

### GetStartDateOk

`func (o *EdsEmulationParam) GetStartDateOk() (*int64, bool)`

GetStartDateOk returns a tuple with the StartDate field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetStartDate

`func (o *EdsEmulationParam) SetStartDate(v int64)`

SetStartDate sets StartDate field to given value.


### GetEndDate

`func (o *EdsEmulationParam) GetEndDate() int64`

GetEndDate returns the EndDate field if non-nil, zero value otherwise.

### GetEndDateOk

`func (o *EdsEmulationParam) GetEndDateOk() (*int64, bool)`

GetEndDateOk returns a tuple with the EndDate field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetEndDate

`func (o *EdsEmulationParam) SetEndDate(v int64)`

SetEndDate sets EndDate field to given value.


### GetSymmetrixId

`func (o *EdsEmulationParam) GetSymmetrixId() string`

GetSymmetrixId returns the SymmetrixId field if non-nil, zero value otherwise.

### GetSymmetrixIdOk

`func (o *EdsEmulationParam) GetSymmetrixIdOk() (*string, bool)`

GetSymmetrixIdOk returns a tuple with the SymmetrixId field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetSymmetrixId

`func (o *EdsEmulationParam) SetSymmetrixId(v string)`

SetSymmetrixId sets SymmetrixId field to given value.


### GetEdsEmulationId

`func (o *EdsEmulationParam) GetEdsEmulationId() string`

GetEdsEmulationId returns the EdsEmulationId field if non-nil, zero value otherwise.

### GetEdsEmulationIdOk

`func (o *EdsEmulationParam) GetEdsEmulationIdOk() (*string, bool)`

GetEdsEmulationIdOk returns a tuple with the EdsEmulationId field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetEdsEmulationId

`func (o *EdsEmulationParam) SetEdsEmulationId(v string)`

SetEdsEmulationId sets EdsEmulationId field to given value.


### GetDataFormat

`func (o *EdsEmulationParam) GetDataFormat() string`

GetDataFormat returns the DataFormat field if non-nil, zero value otherwise.

### GetDataFormatOk

`func (o *EdsEmulationParam) GetDataFormatOk() (*string, bool)`

GetDataFormatOk returns a tuple with the DataFormat field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetDataFormat

`func (o *EdsEmulationParam) SetDataFormat(v string)`

SetDataFormat sets DataFormat field to given value.

### HasDataFormat

`func (o *EdsEmulationParam) HasDataFormat() bool`

HasDataFormat returns a boolean if a field has been set.

### GetMetrics

`func (o *EdsEmulationParam) GetMetrics() []string`

GetMetrics returns the Metrics field if non-nil, zero value otherwise.

### GetMetricsOk

`func (o *EdsEmulationParam) GetMetricsOk() (*[]string, bool)`

GetMetricsOk returns a tuple with the Metrics field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetMetrics

`func (o *EdsEmulationParam) SetMetrics(v []string)`

SetMetrics sets Metrics field to given value.



[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


