# KerberosCreateArguments

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**NasServer** | **string** |                          Id of associated Nas Server instance that uses this Kerberos object. Only one Kerberos object per Nas Server is supported.                      | 
**Realm** | **string** |                          Realm name of the Kerberos Service                      | 
**KdcNames** | **[]string** |                          Fully Qualified domain names of the Kerberos Key Distribution Center (KDC) servers.                      | 
**PortNumber** | Pointer to **int32** |                          KDC servers TCP port. Default: 88.                      | [optional] 

## Methods

### NewKerberosCreateArguments

`func NewKerberosCreateArguments(nasServer string, realm string, kdcNames []string, ) *KerberosCreateArguments`

NewKerberosCreateArguments instantiates a new KerberosCreateArguments object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewKerberosCreateArgumentsWithDefaults

`func NewKerberosCreateArgumentsWithDefaults() *KerberosCreateArguments`

NewKerberosCreateArgumentsWithDefaults instantiates a new KerberosCreateArguments object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetNasServer

`func (o *KerberosCreateArguments) GetNasServer() string`

GetNasServer returns the NasServer field if non-nil, zero value otherwise.

### GetNasServerOk

`func (o *KerberosCreateArguments) GetNasServerOk() (*string, bool)`

GetNasServerOk returns a tuple with the NasServer field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetNasServer

`func (o *KerberosCreateArguments) SetNasServer(v string)`

SetNasServer sets NasServer field to given value.


### GetRealm

`func (o *KerberosCreateArguments) GetRealm() string`

GetRealm returns the Realm field if non-nil, zero value otherwise.

### GetRealmOk

`func (o *KerberosCreateArguments) GetRealmOk() (*string, bool)`

GetRealmOk returns a tuple with the Realm field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetRealm

`func (o *KerberosCreateArguments) SetRealm(v string)`

SetRealm sets Realm field to given value.


### GetKdcNames

`func (o *KerberosCreateArguments) GetKdcNames() []string`

GetKdcNames returns the KdcNames field if non-nil, zero value otherwise.

### GetKdcNamesOk

`func (o *KerberosCreateArguments) GetKdcNamesOk() (*[]string, bool)`

GetKdcNamesOk returns a tuple with the KdcNames field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetKdcNames

`func (o *KerberosCreateArguments) SetKdcNames(v []string)`

SetKdcNames sets KdcNames field to given value.


### GetPortNumber

`func (o *KerberosCreateArguments) GetPortNumber() int32`

GetPortNumber returns the PortNumber field if non-nil, zero value otherwise.

### GetPortNumberOk

`func (o *KerberosCreateArguments) GetPortNumberOk() (*int32, bool)`

GetPortNumberOk returns a tuple with the PortNumber field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetPortNumber

`func (o *KerberosCreateArguments) SetPortNumber(v int32)`

SetPortNumber sets PortNumber field to given value.

### HasPortNumber

`func (o *KerberosCreateArguments) HasPortNumber() bool`

HasPortNumber returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


