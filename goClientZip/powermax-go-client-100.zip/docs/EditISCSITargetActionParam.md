# EditISCSITargetActionParam

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**DetachIPInterfaceParam** | Pointer to [**DetachIPInterfaceParam**](DetachIPInterfaceParam.md) |  | [optional] 
**AttachIPInterfaceParam** | Pointer to [**AttachIPInterfaceParam**](AttachIPInterfaceParam.md) |  | [optional] 
**ModifyPortFlagsParam** | Pointer to [**ModifyPortFlagsParam**](ModifyPortFlagsParam.md) |  | [optional] 
**ModifyISCSITargetParam** | Pointer to [**ModifyISCSITargetParam**](ModifyISCSITargetParam.md) |  | [optional] 
**RenameISCSITargetParam** | Pointer to [**RenameISCSITargetParam**](RenameISCSITargetParam.md) |  | [optional] 

## Methods

### NewEditISCSITargetActionParam

`func NewEditISCSITargetActionParam() *EditISCSITargetActionParam`

NewEditISCSITargetActionParam instantiates a new EditISCSITargetActionParam object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewEditISCSITargetActionParamWithDefaults

`func NewEditISCSITargetActionParamWithDefaults() *EditISCSITargetActionParam`

NewEditISCSITargetActionParamWithDefaults instantiates a new EditISCSITargetActionParam object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetDetachIPInterfaceParam

`func (o *EditISCSITargetActionParam) GetDetachIPInterfaceParam() DetachIPInterfaceParam`

GetDetachIPInterfaceParam returns the DetachIPInterfaceParam field if non-nil, zero value otherwise.

### GetDetachIPInterfaceParamOk

`func (o *EditISCSITargetActionParam) GetDetachIPInterfaceParamOk() (*DetachIPInterfaceParam, bool)`

GetDetachIPInterfaceParamOk returns a tuple with the DetachIPInterfaceParam field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetDetachIPInterfaceParam

`func (o *EditISCSITargetActionParam) SetDetachIPInterfaceParam(v DetachIPInterfaceParam)`

SetDetachIPInterfaceParam sets DetachIPInterfaceParam field to given value.

### HasDetachIPInterfaceParam

`func (o *EditISCSITargetActionParam) HasDetachIPInterfaceParam() bool`

HasDetachIPInterfaceParam returns a boolean if a field has been set.

### GetAttachIPInterfaceParam

`func (o *EditISCSITargetActionParam) GetAttachIPInterfaceParam() AttachIPInterfaceParam`

GetAttachIPInterfaceParam returns the AttachIPInterfaceParam field if non-nil, zero value otherwise.

### GetAttachIPInterfaceParamOk

`func (o *EditISCSITargetActionParam) GetAttachIPInterfaceParamOk() (*AttachIPInterfaceParam, bool)`

GetAttachIPInterfaceParamOk returns a tuple with the AttachIPInterfaceParam field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetAttachIPInterfaceParam

`func (o *EditISCSITargetActionParam) SetAttachIPInterfaceParam(v AttachIPInterfaceParam)`

SetAttachIPInterfaceParam sets AttachIPInterfaceParam field to given value.

### HasAttachIPInterfaceParam

`func (o *EditISCSITargetActionParam) HasAttachIPInterfaceParam() bool`

HasAttachIPInterfaceParam returns a boolean if a field has been set.

### GetModifyPortFlagsParam

`func (o *EditISCSITargetActionParam) GetModifyPortFlagsParam() ModifyPortFlagsParam`

GetModifyPortFlagsParam returns the ModifyPortFlagsParam field if non-nil, zero value otherwise.

### GetModifyPortFlagsParamOk

`func (o *EditISCSITargetActionParam) GetModifyPortFlagsParamOk() (*ModifyPortFlagsParam, bool)`

GetModifyPortFlagsParamOk returns a tuple with the ModifyPortFlagsParam field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetModifyPortFlagsParam

`func (o *EditISCSITargetActionParam) SetModifyPortFlagsParam(v ModifyPortFlagsParam)`

SetModifyPortFlagsParam sets ModifyPortFlagsParam field to given value.

### HasModifyPortFlagsParam

`func (o *EditISCSITargetActionParam) HasModifyPortFlagsParam() bool`

HasModifyPortFlagsParam returns a boolean if a field has been set.

### GetModifyISCSITargetParam

`func (o *EditISCSITargetActionParam) GetModifyISCSITargetParam() ModifyISCSITargetParam`

GetModifyISCSITargetParam returns the ModifyISCSITargetParam field if non-nil, zero value otherwise.

### GetModifyISCSITargetParamOk

`func (o *EditISCSITargetActionParam) GetModifyISCSITargetParamOk() (*ModifyISCSITargetParam, bool)`

GetModifyISCSITargetParamOk returns a tuple with the ModifyISCSITargetParam field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetModifyISCSITargetParam

`func (o *EditISCSITargetActionParam) SetModifyISCSITargetParam(v ModifyISCSITargetParam)`

SetModifyISCSITargetParam sets ModifyISCSITargetParam field to given value.

### HasModifyISCSITargetParam

`func (o *EditISCSITargetActionParam) HasModifyISCSITargetParam() bool`

HasModifyISCSITargetParam returns a boolean if a field has been set.

### GetRenameISCSITargetParam

`func (o *EditISCSITargetActionParam) GetRenameISCSITargetParam() RenameISCSITargetParam`

GetRenameISCSITargetParam returns the RenameISCSITargetParam field if non-nil, zero value otherwise.

### GetRenameISCSITargetParamOk

`func (o *EditISCSITargetActionParam) GetRenameISCSITargetParamOk() (*RenameISCSITargetParam, bool)`

GetRenameISCSITargetParamOk returns a tuple with the RenameISCSITargetParam field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetRenameISCSITargetParam

`func (o *EditISCSITargetActionParam) SetRenameISCSITargetParam(v RenameISCSITargetParam)`

SetRenameISCSITargetParam sets RenameISCSITargetParam field to given value.

### HasRenameISCSITargetParam

`func (o *EditISCSITargetActionParam) HasRenameISCSITargetParam() bool`

HasRenameISCSITargetParam returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


