# Job

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**JobId** | **string** | &lt;p&gt;Unique identifier for the job&lt;/p&gt; | 
**Name** | Pointer to **string** | &lt;p&gt;Name of the job&lt;/p&gt; | [optional] 
**SymmetrixId** | Pointer to **string** | &lt;p&gt;Job System ID&lt;/p&gt; | [optional] 
**Status** | **string** | &lt;p&gt;Job execution status&lt;/p&gt;   Enumeration values: * **UNSCHEDULED** -                          Execution time for the job has not been specified                      * **SCHEDULED** -                          Execution time for the job has been specified                      * **RUNNING** -                          The job is currently being executed                      * **SUCCEEDED** -                          The job has been executed successfuly                      * **FAILED** -                          Job execution has failed                      * **ABORTED** -                          Job execution has been aborted                      * **UNKNOWN** -                          The job status is currently unknown                      * **VALIDATING** -                          The job is currently being validated                      * **VALIDATED** -                          Job validation has been completed successfuly                      * **VALIDATE_FAILED** -                          Job validation has failed                      * **INVALID** -                          The specified job is not valid and cannot be executed                      * **RETRIEVING_PICTURE**  | 
**Username** | **string** | &lt;p&gt;Username that have created the job&lt;/p&gt; | 
**LastModifiedDate** | **string** | &lt;p&gt;Date at which the job was last modified&lt;/p&gt; | 
**LastModifiedDateMilliseconds** | Pointer to **int64** | &lt;p&gt;Date at which the job was last modified in miliseconds&lt;/p&gt; | [optional] 
**ScheduledDate** | Pointer to **string** | &lt;p&gt;Execution date for which the job has been scheduled&lt;/p&gt; | [optional] 
**ScheduledDateMilliseconds** | Pointer to **int64** | &lt;p&gt;Execution date for which the job has been scheduled in miliseconds&lt;/p&gt; | [optional] 
**CompletedDate** | Pointer to **string** | &lt;p&gt;Date at which the job execution has been completed&lt;/p&gt; | [optional] 
**CompletedDateMilliseconds** | Pointer to **int64** | &lt;p&gt;Date at which the job execution has been completed in miliseconds&lt;/p&gt; | [optional] 
**Task** | Pointer to [**[]Task**](Task.md) | task | [optional] 
**ResourceLink** | Pointer to **string** | &lt;p&gt;REST endpoint for which the job has been triggered&lt;/p&gt; | [optional] 
**Result** | Pointer to **string** | &lt;p&gt;Detailed job result status description&lt;/p&gt; | [optional] 
**Links** | Pointer to [**[]UriLink**](UriLink.md) | &lt;p&gt;URI links&lt;/p&gt; | [optional] 

## Methods

### NewJob

`func NewJob(jobId string, status string, username string, lastModifiedDate string, ) *Job`

NewJob instantiates a new Job object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewJobWithDefaults

`func NewJobWithDefaults() *Job`

NewJobWithDefaults instantiates a new Job object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetJobId

`func (o *Job) GetJobId() string`

GetJobId returns the JobId field if non-nil, zero value otherwise.

### GetJobIdOk

`func (o *Job) GetJobIdOk() (*string, bool)`

GetJobIdOk returns a tuple with the JobId field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetJobId

`func (o *Job) SetJobId(v string)`

SetJobId sets JobId field to given value.


### GetName

`func (o *Job) GetName() string`

GetName returns the Name field if non-nil, zero value otherwise.

### GetNameOk

`func (o *Job) GetNameOk() (*string, bool)`

GetNameOk returns a tuple with the Name field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetName

`func (o *Job) SetName(v string)`

SetName sets Name field to given value.

### HasName

`func (o *Job) HasName() bool`

HasName returns a boolean if a field has been set.

### GetSymmetrixId

`func (o *Job) GetSymmetrixId() string`

GetSymmetrixId returns the SymmetrixId field if non-nil, zero value otherwise.

### GetSymmetrixIdOk

`func (o *Job) GetSymmetrixIdOk() (*string, bool)`

GetSymmetrixIdOk returns a tuple with the SymmetrixId field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetSymmetrixId

`func (o *Job) SetSymmetrixId(v string)`

SetSymmetrixId sets SymmetrixId field to given value.

### HasSymmetrixId

`func (o *Job) HasSymmetrixId() bool`

HasSymmetrixId returns a boolean if a field has been set.

### GetStatus

`func (o *Job) GetStatus() string`

GetStatus returns the Status field if non-nil, zero value otherwise.

### GetStatusOk

`func (o *Job) GetStatusOk() (*string, bool)`

GetStatusOk returns a tuple with the Status field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetStatus

`func (o *Job) SetStatus(v string)`

SetStatus sets Status field to given value.


### GetUsername

`func (o *Job) GetUsername() string`

GetUsername returns the Username field if non-nil, zero value otherwise.

### GetUsernameOk

`func (o *Job) GetUsernameOk() (*string, bool)`

GetUsernameOk returns a tuple with the Username field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetUsername

`func (o *Job) SetUsername(v string)`

SetUsername sets Username field to given value.


### GetLastModifiedDate

`func (o *Job) GetLastModifiedDate() string`

GetLastModifiedDate returns the LastModifiedDate field if non-nil, zero value otherwise.

### GetLastModifiedDateOk

`func (o *Job) GetLastModifiedDateOk() (*string, bool)`

GetLastModifiedDateOk returns a tuple with the LastModifiedDate field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetLastModifiedDate

`func (o *Job) SetLastModifiedDate(v string)`

SetLastModifiedDate sets LastModifiedDate field to given value.


### GetLastModifiedDateMilliseconds

`func (o *Job) GetLastModifiedDateMilliseconds() int64`

GetLastModifiedDateMilliseconds returns the LastModifiedDateMilliseconds field if non-nil, zero value otherwise.

### GetLastModifiedDateMillisecondsOk

`func (o *Job) GetLastModifiedDateMillisecondsOk() (*int64, bool)`

GetLastModifiedDateMillisecondsOk returns a tuple with the LastModifiedDateMilliseconds field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetLastModifiedDateMilliseconds

`func (o *Job) SetLastModifiedDateMilliseconds(v int64)`

SetLastModifiedDateMilliseconds sets LastModifiedDateMilliseconds field to given value.

### HasLastModifiedDateMilliseconds

`func (o *Job) HasLastModifiedDateMilliseconds() bool`

HasLastModifiedDateMilliseconds returns a boolean if a field has been set.

### GetScheduledDate

`func (o *Job) GetScheduledDate() string`

GetScheduledDate returns the ScheduledDate field if non-nil, zero value otherwise.

### GetScheduledDateOk

`func (o *Job) GetScheduledDateOk() (*string, bool)`

GetScheduledDateOk returns a tuple with the ScheduledDate field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetScheduledDate

`func (o *Job) SetScheduledDate(v string)`

SetScheduledDate sets ScheduledDate field to given value.

### HasScheduledDate

`func (o *Job) HasScheduledDate() bool`

HasScheduledDate returns a boolean if a field has been set.

### GetScheduledDateMilliseconds

`func (o *Job) GetScheduledDateMilliseconds() int64`

GetScheduledDateMilliseconds returns the ScheduledDateMilliseconds field if non-nil, zero value otherwise.

### GetScheduledDateMillisecondsOk

`func (o *Job) GetScheduledDateMillisecondsOk() (*int64, bool)`

GetScheduledDateMillisecondsOk returns a tuple with the ScheduledDateMilliseconds field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetScheduledDateMilliseconds

`func (o *Job) SetScheduledDateMilliseconds(v int64)`

SetScheduledDateMilliseconds sets ScheduledDateMilliseconds field to given value.

### HasScheduledDateMilliseconds

`func (o *Job) HasScheduledDateMilliseconds() bool`

HasScheduledDateMilliseconds returns a boolean if a field has been set.

### GetCompletedDate

`func (o *Job) GetCompletedDate() string`

GetCompletedDate returns the CompletedDate field if non-nil, zero value otherwise.

### GetCompletedDateOk

`func (o *Job) GetCompletedDateOk() (*string, bool)`

GetCompletedDateOk returns a tuple with the CompletedDate field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetCompletedDate

`func (o *Job) SetCompletedDate(v string)`

SetCompletedDate sets CompletedDate field to given value.

### HasCompletedDate

`func (o *Job) HasCompletedDate() bool`

HasCompletedDate returns a boolean if a field has been set.

### GetCompletedDateMilliseconds

`func (o *Job) GetCompletedDateMilliseconds() int64`

GetCompletedDateMilliseconds returns the CompletedDateMilliseconds field if non-nil, zero value otherwise.

### GetCompletedDateMillisecondsOk

`func (o *Job) GetCompletedDateMillisecondsOk() (*int64, bool)`

GetCompletedDateMillisecondsOk returns a tuple with the CompletedDateMilliseconds field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetCompletedDateMilliseconds

`func (o *Job) SetCompletedDateMilliseconds(v int64)`

SetCompletedDateMilliseconds sets CompletedDateMilliseconds field to given value.

### HasCompletedDateMilliseconds

`func (o *Job) HasCompletedDateMilliseconds() bool`

HasCompletedDateMilliseconds returns a boolean if a field has been set.

### GetTask

`func (o *Job) GetTask() []Task`

GetTask returns the Task field if non-nil, zero value otherwise.

### GetTaskOk

`func (o *Job) GetTaskOk() (*[]Task, bool)`

GetTaskOk returns a tuple with the Task field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetTask

`func (o *Job) SetTask(v []Task)`

SetTask sets Task field to given value.

### HasTask

`func (o *Job) HasTask() bool`

HasTask returns a boolean if a field has been set.

### GetResourceLink

`func (o *Job) GetResourceLink() string`

GetResourceLink returns the ResourceLink field if non-nil, zero value otherwise.

### GetResourceLinkOk

`func (o *Job) GetResourceLinkOk() (*string, bool)`

GetResourceLinkOk returns a tuple with the ResourceLink field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetResourceLink

`func (o *Job) SetResourceLink(v string)`

SetResourceLink sets ResourceLink field to given value.

### HasResourceLink

`func (o *Job) HasResourceLink() bool`

HasResourceLink returns a boolean if a field has been set.

### GetResult

`func (o *Job) GetResult() string`

GetResult returns the Result field if non-nil, zero value otherwise.

### GetResultOk

`func (o *Job) GetResultOk() (*string, bool)`

GetResultOk returns a tuple with the Result field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetResult

`func (o *Job) SetResult(v string)`

SetResult sets Result field to given value.

### HasResult

`func (o *Job) HasResult() bool`

HasResult returns a boolean if a field has been set.

### GetLinks

`func (o *Job) GetLinks() []UriLink`

GetLinks returns the Links field if non-nil, zero value otherwise.

### GetLinksOk

`func (o *Job) GetLinksOk() (*[]UriLink, bool)`

GetLinksOk returns a tuple with the Links field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetLinks

`func (o *Job) SetLinks(v []UriLink)`

SetLinks sets Links field to given value.

### HasLinks

`func (o *Job) HasLinks() bool`

HasLinks returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


