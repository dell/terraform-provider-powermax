# AcknowledgedInfo

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**AcknowledgedUser** | Pointer to **string** | acknowledged_user | [optional] 
**AcknowledgedDate** | Pointer to **string** | acknowledged_date | [optional] 

## Methods

### NewAcknowledgedInfo

`func NewAcknowledgedInfo() *AcknowledgedInfo`

NewAcknowledgedInfo instantiates a new AcknowledgedInfo object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewAcknowledgedInfoWithDefaults

`func NewAcknowledgedInfoWithDefaults() *AcknowledgedInfo`

NewAcknowledgedInfoWithDefaults instantiates a new AcknowledgedInfo object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetAcknowledgedUser

`func (o *AcknowledgedInfo) GetAcknowledgedUser() string`

GetAcknowledgedUser returns the AcknowledgedUser field if non-nil, zero value otherwise.

### GetAcknowledgedUserOk

`func (o *AcknowledgedInfo) GetAcknowledgedUserOk() (*string, bool)`

GetAcknowledgedUserOk returns a tuple with the AcknowledgedUser field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetAcknowledgedUser

`func (o *AcknowledgedInfo) SetAcknowledgedUser(v string)`

SetAcknowledgedUser sets AcknowledgedUser field to given value.

### HasAcknowledgedUser

`func (o *AcknowledgedInfo) HasAcknowledgedUser() bool`

HasAcknowledgedUser returns a boolean if a field has been set.

### GetAcknowledgedDate

`func (o *AcknowledgedInfo) GetAcknowledgedDate() string`

GetAcknowledgedDate returns the AcknowledgedDate field if non-nil, zero value otherwise.

### GetAcknowledgedDateOk

`func (o *AcknowledgedInfo) GetAcknowledgedDateOk() (*string, bool)`

GetAcknowledgedDateOk returns a tuple with the AcknowledgedDate field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetAcknowledgedDate

`func (o *AcknowledgedInfo) SetAcknowledgedDate(v string)`

SetAcknowledgedDate sets AcknowledgedDate field to given value.

### HasAcknowledgedDate

`func (o *AcknowledgedInfo) HasAcknowledgedDate() bool`

HasAcknowledgedDate returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


