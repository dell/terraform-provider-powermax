# Initiator

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**InitiatorId** | **string** | ID of the initiator | 
**SymmetrixPortKey** | Pointer to [**[]SymmetrixPortKey**](SymmetrixPortKey.md) | symmetrixPortKey | [optional] 
**Alias** | Pointer to **string** | Initiator alias | [optional] 
**Type** | Pointer to **string** | Initiator type | [optional] 
**Fcid** | Pointer to **string** | FCID associated with the initiator | [optional] 
**FcidValue** | Pointer to **string** | FCID value of the initiator | [optional] 
**FcidLockdown** | Pointer to **string** | FCID lockdown of the initiator | [optional] 
**IpAddress** | Pointer to **string** | IP address of the initiator | [optional] 
**LoggedIn** | Pointer to **bool** | States whether the initiator is logged in | [optional] 
**OnFabric** | Pointer to **bool** | States whether the initiator is on fabric | [optional] 
**FabricName** | Pointer to **string** | Fabric associated with the initiator | [optional] 
**PortFlagsOverride** | Pointer to **bool** | Flags that are overridden on the initiator | [optional] 
**EnabledFlags** | Pointer to **string** | Enabled flags on the initiator | [optional] 
**DisabledFlags** | Pointer to **string** | Disabled flags on the initiator | [optional] 
**FlagsInEffect** | Pointer to **string** | Initiator flags in effect | [optional] 
**NumOfVols** | Pointer to **int32** | Number of volumes associated with the initiator | [optional] 
**Host** | Pointer to **string** | Host associated with the initiator | [optional] 
**NumOfHostGroups** | Pointer to **int32** | Number of host groups associated with the initiator | [optional] 
**HostGroup** | Pointer to **[]string** | Host groups associated with the initiator | [optional] 
**NumOfMaskingViews** | Pointer to **int32** | Number of masking views associated with the initiator | [optional] 
**Maskingview** | Pointer to **[]string** | Masking views associated with the initiator | [optional] 
**Powerpathhosts** | Pointer to **[]string** | The PowerPath hosts associated with the initiator | [optional] 
**NumOfPowerpathHosts** | Pointer to **int64** | Number of PowerPath hosts associated with the initiator | [optional] 
**HostId** | Pointer to **string** | Host ID associated with the NQN initiator | [optional] 

## Methods

### NewInitiator

`func NewInitiator(initiatorId string, ) *Initiator`

NewInitiator instantiates a new Initiator object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewInitiatorWithDefaults

`func NewInitiatorWithDefaults() *Initiator`

NewInitiatorWithDefaults instantiates a new Initiator object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetInitiatorId

`func (o *Initiator) GetInitiatorId() string`

GetInitiatorId returns the InitiatorId field if non-nil, zero value otherwise.

### GetInitiatorIdOk

`func (o *Initiator) GetInitiatorIdOk() (*string, bool)`

GetInitiatorIdOk returns a tuple with the InitiatorId field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetInitiatorId

`func (o *Initiator) SetInitiatorId(v string)`

SetInitiatorId sets InitiatorId field to given value.


### GetSymmetrixPortKey

`func (o *Initiator) GetSymmetrixPortKey() []SymmetrixPortKey`

GetSymmetrixPortKey returns the SymmetrixPortKey field if non-nil, zero value otherwise.

### GetSymmetrixPortKeyOk

`func (o *Initiator) GetSymmetrixPortKeyOk() (*[]SymmetrixPortKey, bool)`

GetSymmetrixPortKeyOk returns a tuple with the SymmetrixPortKey field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetSymmetrixPortKey

`func (o *Initiator) SetSymmetrixPortKey(v []SymmetrixPortKey)`

SetSymmetrixPortKey sets SymmetrixPortKey field to given value.

### HasSymmetrixPortKey

`func (o *Initiator) HasSymmetrixPortKey() bool`

HasSymmetrixPortKey returns a boolean if a field has been set.

### GetAlias

`func (o *Initiator) GetAlias() string`

GetAlias returns the Alias field if non-nil, zero value otherwise.

### GetAliasOk

`func (o *Initiator) GetAliasOk() (*string, bool)`

GetAliasOk returns a tuple with the Alias field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetAlias

`func (o *Initiator) SetAlias(v string)`

SetAlias sets Alias field to given value.

### HasAlias

`func (o *Initiator) HasAlias() bool`

HasAlias returns a boolean if a field has been set.

### GetType

`func (o *Initiator) GetType() string`

GetType returns the Type field if non-nil, zero value otherwise.

### GetTypeOk

`func (o *Initiator) GetTypeOk() (*string, bool)`

GetTypeOk returns a tuple with the Type field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetType

`func (o *Initiator) SetType(v string)`

SetType sets Type field to given value.

### HasType

`func (o *Initiator) HasType() bool`

HasType returns a boolean if a field has been set.

### GetFcid

`func (o *Initiator) GetFcid() string`

GetFcid returns the Fcid field if non-nil, zero value otherwise.

### GetFcidOk

`func (o *Initiator) GetFcidOk() (*string, bool)`

GetFcidOk returns a tuple with the Fcid field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetFcid

`func (o *Initiator) SetFcid(v string)`

SetFcid sets Fcid field to given value.

### HasFcid

`func (o *Initiator) HasFcid() bool`

HasFcid returns a boolean if a field has been set.

### GetFcidValue

`func (o *Initiator) GetFcidValue() string`

GetFcidValue returns the FcidValue field if non-nil, zero value otherwise.

### GetFcidValueOk

`func (o *Initiator) GetFcidValueOk() (*string, bool)`

GetFcidValueOk returns a tuple with the FcidValue field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetFcidValue

`func (o *Initiator) SetFcidValue(v string)`

SetFcidValue sets FcidValue field to given value.

### HasFcidValue

`func (o *Initiator) HasFcidValue() bool`

HasFcidValue returns a boolean if a field has been set.

### GetFcidLockdown

`func (o *Initiator) GetFcidLockdown() string`

GetFcidLockdown returns the FcidLockdown field if non-nil, zero value otherwise.

### GetFcidLockdownOk

`func (o *Initiator) GetFcidLockdownOk() (*string, bool)`

GetFcidLockdownOk returns a tuple with the FcidLockdown field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetFcidLockdown

`func (o *Initiator) SetFcidLockdown(v string)`

SetFcidLockdown sets FcidLockdown field to given value.

### HasFcidLockdown

`func (o *Initiator) HasFcidLockdown() bool`

HasFcidLockdown returns a boolean if a field has been set.

### GetIpAddress

`func (o *Initiator) GetIpAddress() string`

GetIpAddress returns the IpAddress field if non-nil, zero value otherwise.

### GetIpAddressOk

`func (o *Initiator) GetIpAddressOk() (*string, bool)`

GetIpAddressOk returns a tuple with the IpAddress field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetIpAddress

`func (o *Initiator) SetIpAddress(v string)`

SetIpAddress sets IpAddress field to given value.

### HasIpAddress

`func (o *Initiator) HasIpAddress() bool`

HasIpAddress returns a boolean if a field has been set.

### GetLoggedIn

`func (o *Initiator) GetLoggedIn() bool`

GetLoggedIn returns the LoggedIn field if non-nil, zero value otherwise.

### GetLoggedInOk

`func (o *Initiator) GetLoggedInOk() (*bool, bool)`

GetLoggedInOk returns a tuple with the LoggedIn field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetLoggedIn

`func (o *Initiator) SetLoggedIn(v bool)`

SetLoggedIn sets LoggedIn field to given value.

### HasLoggedIn

`func (o *Initiator) HasLoggedIn() bool`

HasLoggedIn returns a boolean if a field has been set.

### GetOnFabric

`func (o *Initiator) GetOnFabric() bool`

GetOnFabric returns the OnFabric field if non-nil, zero value otherwise.

### GetOnFabricOk

`func (o *Initiator) GetOnFabricOk() (*bool, bool)`

GetOnFabricOk returns a tuple with the OnFabric field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetOnFabric

`func (o *Initiator) SetOnFabric(v bool)`

SetOnFabric sets OnFabric field to given value.

### HasOnFabric

`func (o *Initiator) HasOnFabric() bool`

HasOnFabric returns a boolean if a field has been set.

### GetFabricName

`func (o *Initiator) GetFabricName() string`

GetFabricName returns the FabricName field if non-nil, zero value otherwise.

### GetFabricNameOk

`func (o *Initiator) GetFabricNameOk() (*string, bool)`

GetFabricNameOk returns a tuple with the FabricName field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetFabricName

`func (o *Initiator) SetFabricName(v string)`

SetFabricName sets FabricName field to given value.

### HasFabricName

`func (o *Initiator) HasFabricName() bool`

HasFabricName returns a boolean if a field has been set.

### GetPortFlagsOverride

`func (o *Initiator) GetPortFlagsOverride() bool`

GetPortFlagsOverride returns the PortFlagsOverride field if non-nil, zero value otherwise.

### GetPortFlagsOverrideOk

`func (o *Initiator) GetPortFlagsOverrideOk() (*bool, bool)`

GetPortFlagsOverrideOk returns a tuple with the PortFlagsOverride field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetPortFlagsOverride

`func (o *Initiator) SetPortFlagsOverride(v bool)`

SetPortFlagsOverride sets PortFlagsOverride field to given value.

### HasPortFlagsOverride

`func (o *Initiator) HasPortFlagsOverride() bool`

HasPortFlagsOverride returns a boolean if a field has been set.

### GetEnabledFlags

`func (o *Initiator) GetEnabledFlags() string`

GetEnabledFlags returns the EnabledFlags field if non-nil, zero value otherwise.

### GetEnabledFlagsOk

`func (o *Initiator) GetEnabledFlagsOk() (*string, bool)`

GetEnabledFlagsOk returns a tuple with the EnabledFlags field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetEnabledFlags

`func (o *Initiator) SetEnabledFlags(v string)`

SetEnabledFlags sets EnabledFlags field to given value.

### HasEnabledFlags

`func (o *Initiator) HasEnabledFlags() bool`

HasEnabledFlags returns a boolean if a field has been set.

### GetDisabledFlags

`func (o *Initiator) GetDisabledFlags() string`

GetDisabledFlags returns the DisabledFlags field if non-nil, zero value otherwise.

### GetDisabledFlagsOk

`func (o *Initiator) GetDisabledFlagsOk() (*string, bool)`

GetDisabledFlagsOk returns a tuple with the DisabledFlags field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetDisabledFlags

`func (o *Initiator) SetDisabledFlags(v string)`

SetDisabledFlags sets DisabledFlags field to given value.

### HasDisabledFlags

`func (o *Initiator) HasDisabledFlags() bool`

HasDisabledFlags returns a boolean if a field has been set.

### GetFlagsInEffect

`func (o *Initiator) GetFlagsInEffect() string`

GetFlagsInEffect returns the FlagsInEffect field if non-nil, zero value otherwise.

### GetFlagsInEffectOk

`func (o *Initiator) GetFlagsInEffectOk() (*string, bool)`

GetFlagsInEffectOk returns a tuple with the FlagsInEffect field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetFlagsInEffect

`func (o *Initiator) SetFlagsInEffect(v string)`

SetFlagsInEffect sets FlagsInEffect field to given value.

### HasFlagsInEffect

`func (o *Initiator) HasFlagsInEffect() bool`

HasFlagsInEffect returns a boolean if a field has been set.

### GetNumOfVols

`func (o *Initiator) GetNumOfVols() int32`

GetNumOfVols returns the NumOfVols field if non-nil, zero value otherwise.

### GetNumOfVolsOk

`func (o *Initiator) GetNumOfVolsOk() (*int32, bool)`

GetNumOfVolsOk returns a tuple with the NumOfVols field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetNumOfVols

`func (o *Initiator) SetNumOfVols(v int32)`

SetNumOfVols sets NumOfVols field to given value.

### HasNumOfVols

`func (o *Initiator) HasNumOfVols() bool`

HasNumOfVols returns a boolean if a field has been set.

### GetHost

`func (o *Initiator) GetHost() string`

GetHost returns the Host field if non-nil, zero value otherwise.

### GetHostOk

`func (o *Initiator) GetHostOk() (*string, bool)`

GetHostOk returns a tuple with the Host field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetHost

`func (o *Initiator) SetHost(v string)`

SetHost sets Host field to given value.

### HasHost

`func (o *Initiator) HasHost() bool`

HasHost returns a boolean if a field has been set.

### GetNumOfHostGroups

`func (o *Initiator) GetNumOfHostGroups() int32`

GetNumOfHostGroups returns the NumOfHostGroups field if non-nil, zero value otherwise.

### GetNumOfHostGroupsOk

`func (o *Initiator) GetNumOfHostGroupsOk() (*int32, bool)`

GetNumOfHostGroupsOk returns a tuple with the NumOfHostGroups field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetNumOfHostGroups

`func (o *Initiator) SetNumOfHostGroups(v int32)`

SetNumOfHostGroups sets NumOfHostGroups field to given value.

### HasNumOfHostGroups

`func (o *Initiator) HasNumOfHostGroups() bool`

HasNumOfHostGroups returns a boolean if a field has been set.

### GetHostGroup

`func (o *Initiator) GetHostGroup() []string`

GetHostGroup returns the HostGroup field if non-nil, zero value otherwise.

### GetHostGroupOk

`func (o *Initiator) GetHostGroupOk() (*[]string, bool)`

GetHostGroupOk returns a tuple with the HostGroup field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetHostGroup

`func (o *Initiator) SetHostGroup(v []string)`

SetHostGroup sets HostGroup field to given value.

### HasHostGroup

`func (o *Initiator) HasHostGroup() bool`

HasHostGroup returns a boolean if a field has been set.

### GetNumOfMaskingViews

`func (o *Initiator) GetNumOfMaskingViews() int32`

GetNumOfMaskingViews returns the NumOfMaskingViews field if non-nil, zero value otherwise.

### GetNumOfMaskingViewsOk

`func (o *Initiator) GetNumOfMaskingViewsOk() (*int32, bool)`

GetNumOfMaskingViewsOk returns a tuple with the NumOfMaskingViews field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetNumOfMaskingViews

`func (o *Initiator) SetNumOfMaskingViews(v int32)`

SetNumOfMaskingViews sets NumOfMaskingViews field to given value.

### HasNumOfMaskingViews

`func (o *Initiator) HasNumOfMaskingViews() bool`

HasNumOfMaskingViews returns a boolean if a field has been set.

### GetMaskingview

`func (o *Initiator) GetMaskingview() []string`

GetMaskingview returns the Maskingview field if non-nil, zero value otherwise.

### GetMaskingviewOk

`func (o *Initiator) GetMaskingviewOk() (*[]string, bool)`

GetMaskingviewOk returns a tuple with the Maskingview field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetMaskingview

`func (o *Initiator) SetMaskingview(v []string)`

SetMaskingview sets Maskingview field to given value.

### HasMaskingview

`func (o *Initiator) HasMaskingview() bool`

HasMaskingview returns a boolean if a field has been set.

### GetPowerpathhosts

`func (o *Initiator) GetPowerpathhosts() []string`

GetPowerpathhosts returns the Powerpathhosts field if non-nil, zero value otherwise.

### GetPowerpathhostsOk

`func (o *Initiator) GetPowerpathhostsOk() (*[]string, bool)`

GetPowerpathhostsOk returns a tuple with the Powerpathhosts field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetPowerpathhosts

`func (o *Initiator) SetPowerpathhosts(v []string)`

SetPowerpathhosts sets Powerpathhosts field to given value.

### HasPowerpathhosts

`func (o *Initiator) HasPowerpathhosts() bool`

HasPowerpathhosts returns a boolean if a field has been set.

### GetNumOfPowerpathHosts

`func (o *Initiator) GetNumOfPowerpathHosts() int64`

GetNumOfPowerpathHosts returns the NumOfPowerpathHosts field if non-nil, zero value otherwise.

### GetNumOfPowerpathHostsOk

`func (o *Initiator) GetNumOfPowerpathHostsOk() (*int64, bool)`

GetNumOfPowerpathHostsOk returns a tuple with the NumOfPowerpathHosts field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetNumOfPowerpathHosts

`func (o *Initiator) SetNumOfPowerpathHosts(v int64)`

SetNumOfPowerpathHosts sets NumOfPowerpathHosts field to given value.

### HasNumOfPowerpathHosts

`func (o *Initiator) HasNumOfPowerpathHosts() bool`

HasNumOfPowerpathHosts returns a boolean if a field has been set.

### GetHostId

`func (o *Initiator) GetHostId() string`

GetHostId returns the HostId field if non-nil, zero value otherwise.

### GetHostIdOk

`func (o *Initiator) GetHostIdOk() (*string, bool)`

GetHostIdOk returns a tuple with the HostId field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetHostId

`func (o *Initiator) SetHostId(v string)`

SetHostId sets HostId field to given value.

### HasHostId

`func (o *Initiator) HasHostId() bool`

HasHostId returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


