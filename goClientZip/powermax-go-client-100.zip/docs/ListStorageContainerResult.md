# ListStorageContainerResult

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**StorageContainerId** | Pointer to **[]string** | The Storage Container Id. | [optional] 

## Methods

### NewListStorageContainerResult

`func NewListStorageContainerResult() *ListStorageContainerResult`

NewListStorageContainerResult instantiates a new ListStorageContainerResult object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewListStorageContainerResultWithDefaults

`func NewListStorageContainerResultWithDefaults() *ListStorageContainerResult`

NewListStorageContainerResultWithDefaults instantiates a new ListStorageContainerResult object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetStorageContainerId

`func (o *ListStorageContainerResult) GetStorageContainerId() []string`

GetStorageContainerId returns the StorageContainerId field if non-nil, zero value otherwise.

### GetStorageContainerIdOk

`func (o *ListStorageContainerResult) GetStorageContainerIdOk() (*[]string, bool)`

GetStorageContainerIdOk returns a tuple with the StorageContainerId field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetStorageContainerId

`func (o *ListStorageContainerResult) SetStorageContainerId(v []string)`

SetStorageContainerId sets StorageContainerId field to given value.

### HasStorageContainerId

`func (o *ListStorageContainerResult) HasStorageContainerId() bool`

HasStorageContainerId returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


