# CloudSystem

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**State** | Pointer to **string** | The Cloud System State | [optional] 
**StateType** | Pointer to **string** | The Cloud System State Type | [optional] 
**Info** | Pointer to **string** | A description of the The Cloud System State | [optional] 
**NumOfCloudProviders** | Pointer to **int32** | The Total Number of Cloud Providers associated with the Cloud System | [optional] 
**NumOfCloudSnapshots** | Pointer to **int32** | The Total Number of Cloud Snapshots associated with the Cloud System | [optional] 
**NumOfCloudStorageGroups** | Pointer to **int32** | The total number of Cloud Storage Groups associated with the Cloud System | [optional] 

## Methods

### NewCloudSystem

`func NewCloudSystem() *CloudSystem`

NewCloudSystem instantiates a new CloudSystem object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewCloudSystemWithDefaults

`func NewCloudSystemWithDefaults() *CloudSystem`

NewCloudSystemWithDefaults instantiates a new CloudSystem object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetState

`func (o *CloudSystem) GetState() string`

GetState returns the State field if non-nil, zero value otherwise.

### GetStateOk

`func (o *CloudSystem) GetStateOk() (*string, bool)`

GetStateOk returns a tuple with the State field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetState

`func (o *CloudSystem) SetState(v string)`

SetState sets State field to given value.

### HasState

`func (o *CloudSystem) HasState() bool`

HasState returns a boolean if a field has been set.

### GetStateType

`func (o *CloudSystem) GetStateType() string`

GetStateType returns the StateType field if non-nil, zero value otherwise.

### GetStateTypeOk

`func (o *CloudSystem) GetStateTypeOk() (*string, bool)`

GetStateTypeOk returns a tuple with the StateType field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetStateType

`func (o *CloudSystem) SetStateType(v string)`

SetStateType sets StateType field to given value.

### HasStateType

`func (o *CloudSystem) HasStateType() bool`

HasStateType returns a boolean if a field has been set.

### GetInfo

`func (o *CloudSystem) GetInfo() string`

GetInfo returns the Info field if non-nil, zero value otherwise.

### GetInfoOk

`func (o *CloudSystem) GetInfoOk() (*string, bool)`

GetInfoOk returns a tuple with the Info field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetInfo

`func (o *CloudSystem) SetInfo(v string)`

SetInfo sets Info field to given value.

### HasInfo

`func (o *CloudSystem) HasInfo() bool`

HasInfo returns a boolean if a field has been set.

### GetNumOfCloudProviders

`func (o *CloudSystem) GetNumOfCloudProviders() int32`

GetNumOfCloudProviders returns the NumOfCloudProviders field if non-nil, zero value otherwise.

### GetNumOfCloudProvidersOk

`func (o *CloudSystem) GetNumOfCloudProvidersOk() (*int32, bool)`

GetNumOfCloudProvidersOk returns a tuple with the NumOfCloudProviders field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetNumOfCloudProviders

`func (o *CloudSystem) SetNumOfCloudProviders(v int32)`

SetNumOfCloudProviders sets NumOfCloudProviders field to given value.

### HasNumOfCloudProviders

`func (o *CloudSystem) HasNumOfCloudProviders() bool`

HasNumOfCloudProviders returns a boolean if a field has been set.

### GetNumOfCloudSnapshots

`func (o *CloudSystem) GetNumOfCloudSnapshots() int32`

GetNumOfCloudSnapshots returns the NumOfCloudSnapshots field if non-nil, zero value otherwise.

### GetNumOfCloudSnapshotsOk

`func (o *CloudSystem) GetNumOfCloudSnapshotsOk() (*int32, bool)`

GetNumOfCloudSnapshotsOk returns a tuple with the NumOfCloudSnapshots field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetNumOfCloudSnapshots

`func (o *CloudSystem) SetNumOfCloudSnapshots(v int32)`

SetNumOfCloudSnapshots sets NumOfCloudSnapshots field to given value.

### HasNumOfCloudSnapshots

`func (o *CloudSystem) HasNumOfCloudSnapshots() bool`

HasNumOfCloudSnapshots returns a boolean if a field has been set.

### GetNumOfCloudStorageGroups

`func (o *CloudSystem) GetNumOfCloudStorageGroups() int32`

GetNumOfCloudStorageGroups returns the NumOfCloudStorageGroups field if non-nil, zero value otherwise.

### GetNumOfCloudStorageGroupsOk

`func (o *CloudSystem) GetNumOfCloudStorageGroupsOk() (*int32, bool)`

GetNumOfCloudStorageGroupsOk returns a tuple with the NumOfCloudStorageGroups field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetNumOfCloudStorageGroups

`func (o *CloudSystem) SetNumOfCloudStorageGroups(v int32)`

SetNumOfCloudStorageGroups sets NumOfCloudStorageGroups field to given value.

### HasNumOfCloudStorageGroups

`func (o *CloudSystem) HasNumOfCloudStorageGroups() bool`

HasNumOfCloudStorageGroups returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


