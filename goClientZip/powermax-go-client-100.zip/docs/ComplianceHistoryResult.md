# ComplianceHistoryResult

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**SloCompliance** | [**[]SloCompliance**](SloCompliance.md) | sloCompliance | 

## Methods

### NewComplianceHistoryResult

`func NewComplianceHistoryResult(sloCompliance []SloCompliance, ) *ComplianceHistoryResult`

NewComplianceHistoryResult instantiates a new ComplianceHistoryResult object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewComplianceHistoryResultWithDefaults

`func NewComplianceHistoryResultWithDefaults() *ComplianceHistoryResult`

NewComplianceHistoryResultWithDefaults instantiates a new ComplianceHistoryResult object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetSloCompliance

`func (o *ComplianceHistoryResult) GetSloCompliance() []SloCompliance`

GetSloCompliance returns the SloCompliance field if non-nil, zero value otherwise.

### GetSloComplianceOk

`func (o *ComplianceHistoryResult) GetSloComplianceOk() (*[]SloCompliance, bool)`

GetSloComplianceOk returns a tuple with the SloCompliance field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetSloCompliance

`func (o *ComplianceHistoryResult) SetSloCompliance(v []SloCompliance)`

SetSloCompliance sets SloCompliance field to given value.



[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


