# AddVasaProviderParam

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ExecutionOption** | Pointer to **string** |  | [optional] [default to "SYNCHRONOUS"]
**Ipaddress** | **string** | ipaddress | 

## Methods

### NewAddVasaProviderParam

`func NewAddVasaProviderParam(ipaddress string, ) *AddVasaProviderParam`

NewAddVasaProviderParam instantiates a new AddVasaProviderParam object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewAddVasaProviderParamWithDefaults

`func NewAddVasaProviderParamWithDefaults() *AddVasaProviderParam`

NewAddVasaProviderParamWithDefaults instantiates a new AddVasaProviderParam object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetExecutionOption

`func (o *AddVasaProviderParam) GetExecutionOption() string`

GetExecutionOption returns the ExecutionOption field if non-nil, zero value otherwise.

### GetExecutionOptionOk

`func (o *AddVasaProviderParam) GetExecutionOptionOk() (*string, bool)`

GetExecutionOptionOk returns a tuple with the ExecutionOption field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetExecutionOption

`func (o *AddVasaProviderParam) SetExecutionOption(v string)`

SetExecutionOption sets ExecutionOption field to given value.

### HasExecutionOption

`func (o *AddVasaProviderParam) HasExecutionOption() bool`

HasExecutionOption returns a boolean if a field has been set.

### GetIpaddress

`func (o *AddVasaProviderParam) GetIpaddress() string`

GetIpaddress returns the Ipaddress field if non-nil, zero value otherwise.

### GetIpaddressOk

`func (o *AddVasaProviderParam) GetIpaddressOk() (*string, bool)`

GetIpaddressOk returns a tuple with the Ipaddress field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetIpaddress

`func (o *AddVasaProviderParam) SetIpaddress(v string)`

SetIpaddress sets Ipaddress field to given value.



[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


