# ExternalDirectorKeyResult

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ExternalDirectorInfo** | Pointer to [**[]ExternalDirectorInfo**](ExternalDirectorInfo.md) | externalDirectorInfo | [optional] 

## Methods

### NewExternalDirectorKeyResult

`func NewExternalDirectorKeyResult() *ExternalDirectorKeyResult`

NewExternalDirectorKeyResult instantiates a new ExternalDirectorKeyResult object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewExternalDirectorKeyResultWithDefaults

`func NewExternalDirectorKeyResultWithDefaults() *ExternalDirectorKeyResult`

NewExternalDirectorKeyResultWithDefaults instantiates a new ExternalDirectorKeyResult object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetExternalDirectorInfo

`func (o *ExternalDirectorKeyResult) GetExternalDirectorInfo() []ExternalDirectorInfo`

GetExternalDirectorInfo returns the ExternalDirectorInfo field if non-nil, zero value otherwise.

### GetExternalDirectorInfoOk

`func (o *ExternalDirectorKeyResult) GetExternalDirectorInfoOk() (*[]ExternalDirectorInfo, bool)`

GetExternalDirectorInfoOk returns a tuple with the ExternalDirectorInfo field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetExternalDirectorInfo

`func (o *ExternalDirectorKeyResult) SetExternalDirectorInfo(v []ExternalDirectorInfo)`

SetExternalDirectorInfo sets ExternalDirectorInfo field to given value.

### HasExternalDirectorInfo

`func (o *ExternalDirectorKeyResult) HasExternalDirectorInfo() bool`

HasExternalDirectorInfo returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


