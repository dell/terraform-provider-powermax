# EmEmulationInfo

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**FirstAvailableDate** | Pointer to **int64** |  | [optional] 
**LastAvailableDate** | Pointer to **int64** |  | [optional] 
**EmEmulationId** | **string** | emEmulationId | 

## Methods

### NewEmEmulationInfo

`func NewEmEmulationInfo(emEmulationId string, ) *EmEmulationInfo`

NewEmEmulationInfo instantiates a new EmEmulationInfo object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewEmEmulationInfoWithDefaults

`func NewEmEmulationInfoWithDefaults() *EmEmulationInfo`

NewEmEmulationInfoWithDefaults instantiates a new EmEmulationInfo object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetFirstAvailableDate

`func (o *EmEmulationInfo) GetFirstAvailableDate() int64`

GetFirstAvailableDate returns the FirstAvailableDate field if non-nil, zero value otherwise.

### GetFirstAvailableDateOk

`func (o *EmEmulationInfo) GetFirstAvailableDateOk() (*int64, bool)`

GetFirstAvailableDateOk returns a tuple with the FirstAvailableDate field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetFirstAvailableDate

`func (o *EmEmulationInfo) SetFirstAvailableDate(v int64)`

SetFirstAvailableDate sets FirstAvailableDate field to given value.

### HasFirstAvailableDate

`func (o *EmEmulationInfo) HasFirstAvailableDate() bool`

HasFirstAvailableDate returns a boolean if a field has been set.

### GetLastAvailableDate

`func (o *EmEmulationInfo) GetLastAvailableDate() int64`

GetLastAvailableDate returns the LastAvailableDate field if non-nil, zero value otherwise.

### GetLastAvailableDateOk

`func (o *EmEmulationInfo) GetLastAvailableDateOk() (*int64, bool)`

GetLastAvailableDateOk returns a tuple with the LastAvailableDate field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetLastAvailableDate

`func (o *EmEmulationInfo) SetLastAvailableDate(v int64)`

SetLastAvailableDate sets LastAvailableDate field to given value.

### HasLastAvailableDate

`func (o *EmEmulationInfo) HasLastAvailableDate() bool`

HasLastAvailableDate returns a boolean if a field has been set.

### GetEmEmulationId

`func (o *EmEmulationInfo) GetEmEmulationId() string`

GetEmEmulationId returns the EmEmulationId field if non-nil, zero value otherwise.

### GetEmEmulationIdOk

`func (o *EmEmulationInfo) GetEmEmulationIdOk() (*string, bool)`

GetEmEmulationIdOk returns a tuple with the EmEmulationId field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetEmEmulationId

`func (o *EmEmulationInfo) SetEmEmulationId(v string)`

SetEmEmulationId sets EmEmulationId field to given value.



[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


