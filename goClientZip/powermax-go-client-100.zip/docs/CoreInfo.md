# CoreInfo

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**FirstAvailableDate** | Pointer to **int64** |  | [optional] 
**LastAvailableDate** | Pointer to **int64** |  | [optional] 
**CoreId** | **string** | coreId | 

## Methods

### NewCoreInfo

`func NewCoreInfo(coreId string, ) *CoreInfo`

NewCoreInfo instantiates a new CoreInfo object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewCoreInfoWithDefaults

`func NewCoreInfoWithDefaults() *CoreInfo`

NewCoreInfoWithDefaults instantiates a new CoreInfo object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetFirstAvailableDate

`func (o *CoreInfo) GetFirstAvailableDate() int64`

GetFirstAvailableDate returns the FirstAvailableDate field if non-nil, zero value otherwise.

### GetFirstAvailableDateOk

`func (o *CoreInfo) GetFirstAvailableDateOk() (*int64, bool)`

GetFirstAvailableDateOk returns a tuple with the FirstAvailableDate field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetFirstAvailableDate

`func (o *CoreInfo) SetFirstAvailableDate(v int64)`

SetFirstAvailableDate sets FirstAvailableDate field to given value.

### HasFirstAvailableDate

`func (o *CoreInfo) HasFirstAvailableDate() bool`

HasFirstAvailableDate returns a boolean if a field has been set.

### GetLastAvailableDate

`func (o *CoreInfo) GetLastAvailableDate() int64`

GetLastAvailableDate returns the LastAvailableDate field if non-nil, zero value otherwise.

### GetLastAvailableDateOk

`func (o *CoreInfo) GetLastAvailableDateOk() (*int64, bool)`

GetLastAvailableDateOk returns a tuple with the LastAvailableDate field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetLastAvailableDate

`func (o *CoreInfo) SetLastAvailableDate(v int64)`

SetLastAvailableDate sets LastAvailableDate field to given value.

### HasLastAvailableDate

`func (o *CoreInfo) HasLastAvailableDate() bool`

HasLastAvailableDate returns a boolean if a field has been set.

### GetCoreId

`func (o *CoreInfo) GetCoreId() string`

GetCoreId returns the CoreId field if non-nil, zero value otherwise.

### GetCoreIdOk

`func (o *CoreInfo) GetCoreIdOk() (*string, bool)`

GetCoreIdOk returns a tuple with the CoreId field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetCoreId

`func (o *CoreInfo) SetCoreId(v string)`

SetCoreId sets CoreId field to given value.



[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


