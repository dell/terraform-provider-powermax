# AutoHostGroupParam

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ExecutionOption** | Pointer to **string** |  | [optional] [default to "SYNCHRONOUS"]
**HostGroupId** | Pointer to **string** | Host group name. If not specified, it will be generated from storage group name. | [optional] 
**CopyHostKey** | Pointer to [**CopyHostKey**](CopyHostKey.md) |  | [optional] 
**InitiatorIds** | Pointer to **[]string** | ID/name of the initiator. | [optional] 

## Methods

### NewAutoHostGroupParam

`func NewAutoHostGroupParam() *AutoHostGroupParam`

NewAutoHostGroupParam instantiates a new AutoHostGroupParam object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewAutoHostGroupParamWithDefaults

`func NewAutoHostGroupParamWithDefaults() *AutoHostGroupParam`

NewAutoHostGroupParamWithDefaults instantiates a new AutoHostGroupParam object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetExecutionOption

`func (o *AutoHostGroupParam) GetExecutionOption() string`

GetExecutionOption returns the ExecutionOption field if non-nil, zero value otherwise.

### GetExecutionOptionOk

`func (o *AutoHostGroupParam) GetExecutionOptionOk() (*string, bool)`

GetExecutionOptionOk returns a tuple with the ExecutionOption field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetExecutionOption

`func (o *AutoHostGroupParam) SetExecutionOption(v string)`

SetExecutionOption sets ExecutionOption field to given value.

### HasExecutionOption

`func (o *AutoHostGroupParam) HasExecutionOption() bool`

HasExecutionOption returns a boolean if a field has been set.

### GetHostGroupId

`func (o *AutoHostGroupParam) GetHostGroupId() string`

GetHostGroupId returns the HostGroupId field if non-nil, zero value otherwise.

### GetHostGroupIdOk

`func (o *AutoHostGroupParam) GetHostGroupIdOk() (*string, bool)`

GetHostGroupIdOk returns a tuple with the HostGroupId field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetHostGroupId

`func (o *AutoHostGroupParam) SetHostGroupId(v string)`

SetHostGroupId sets HostGroupId field to given value.

### HasHostGroupId

`func (o *AutoHostGroupParam) HasHostGroupId() bool`

HasHostGroupId returns a boolean if a field has been set.

### GetCopyHostKey

`func (o *AutoHostGroupParam) GetCopyHostKey() CopyHostKey`

GetCopyHostKey returns the CopyHostKey field if non-nil, zero value otherwise.

### GetCopyHostKeyOk

`func (o *AutoHostGroupParam) GetCopyHostKeyOk() (*CopyHostKey, bool)`

GetCopyHostKeyOk returns a tuple with the CopyHostKey field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetCopyHostKey

`func (o *AutoHostGroupParam) SetCopyHostKey(v CopyHostKey)`

SetCopyHostKey sets CopyHostKey field to given value.

### HasCopyHostKey

`func (o *AutoHostGroupParam) HasCopyHostKey() bool`

HasCopyHostKey returns a boolean if a field has been set.

### GetInitiatorIds

`func (o *AutoHostGroupParam) GetInitiatorIds() []string`

GetInitiatorIds returns the InitiatorIds field if non-nil, zero value otherwise.

### GetInitiatorIdsOk

`func (o *AutoHostGroupParam) GetInitiatorIdsOk() (*[]string, bool)`

GetInitiatorIdsOk returns a tuple with the InitiatorIds field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetInitiatorIds

`func (o *AutoHostGroupParam) SetInitiatorIds(v []string)`

SetInitiatorIds sets InitiatorIds field to given value.

### HasInitiatorIds

`func (o *AutoHostGroupParam) HasInitiatorIds() bool`

HasInitiatorIds returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


