# EditCloudSystemNetworkingActionParam

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**EditBandwidthLimit** | Pointer to [**EditBandwidthLimitParam**](EditBandwidthLimitParam.md) |  | [optional] 

## Methods

### NewEditCloudSystemNetworkingActionParam

`func NewEditCloudSystemNetworkingActionParam() *EditCloudSystemNetworkingActionParam`

NewEditCloudSystemNetworkingActionParam instantiates a new EditCloudSystemNetworkingActionParam object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewEditCloudSystemNetworkingActionParamWithDefaults

`func NewEditCloudSystemNetworkingActionParamWithDefaults() *EditCloudSystemNetworkingActionParam`

NewEditCloudSystemNetworkingActionParamWithDefaults instantiates a new EditCloudSystemNetworkingActionParam object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetEditBandwidthLimit

`func (o *EditCloudSystemNetworkingActionParam) GetEditBandwidthLimit() EditBandwidthLimitParam`

GetEditBandwidthLimit returns the EditBandwidthLimit field if non-nil, zero value otherwise.

### GetEditBandwidthLimitOk

`func (o *EditCloudSystemNetworkingActionParam) GetEditBandwidthLimitOk() (*EditBandwidthLimitParam, bool)`

GetEditBandwidthLimitOk returns a tuple with the EditBandwidthLimit field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetEditBandwidthLimit

`func (o *EditCloudSystemNetworkingActionParam) SetEditBandwidthLimit(v EditBandwidthLimitParam)`

SetEditBandwidthLimit sets EditBandwidthLimit field to given value.

### HasEditBandwidthLimit

`func (o *EditCloudSystemNetworkingActionParam) HasEditBandwidthLimit() bool`

HasEditBandwidthLimit returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


