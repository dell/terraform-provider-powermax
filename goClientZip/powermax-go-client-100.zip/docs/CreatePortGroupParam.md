# CreatePortGroupParam

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ExecutionOption** | Pointer to **string** |  | [optional] [default to "SYNCHRONOUS"]
**PortGroupId** | **string** | The name of the port group | 
**SymmetrixPortKey** | Pointer to [**[]SymmetrixPortKey**](SymmetrixPortKey.md) | symmetrixPortKey | [optional] 
**PortGroupProtocol** | Pointer to **string** | port_Group_Protocol   Enumeration values: * **SCSI_FC** * **iSCSI** * **NVMe_FC** * **NVMe_TCP**  | [optional] 

## Methods

### NewCreatePortGroupParam

`func NewCreatePortGroupParam(portGroupId string, ) *CreatePortGroupParam`

NewCreatePortGroupParam instantiates a new CreatePortGroupParam object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewCreatePortGroupParamWithDefaults

`func NewCreatePortGroupParamWithDefaults() *CreatePortGroupParam`

NewCreatePortGroupParamWithDefaults instantiates a new CreatePortGroupParam object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetExecutionOption

`func (o *CreatePortGroupParam) GetExecutionOption() string`

GetExecutionOption returns the ExecutionOption field if non-nil, zero value otherwise.

### GetExecutionOptionOk

`func (o *CreatePortGroupParam) GetExecutionOptionOk() (*string, bool)`

GetExecutionOptionOk returns a tuple with the ExecutionOption field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetExecutionOption

`func (o *CreatePortGroupParam) SetExecutionOption(v string)`

SetExecutionOption sets ExecutionOption field to given value.

### HasExecutionOption

`func (o *CreatePortGroupParam) HasExecutionOption() bool`

HasExecutionOption returns a boolean if a field has been set.

### GetPortGroupId

`func (o *CreatePortGroupParam) GetPortGroupId() string`

GetPortGroupId returns the PortGroupId field if non-nil, zero value otherwise.

### GetPortGroupIdOk

`func (o *CreatePortGroupParam) GetPortGroupIdOk() (*string, bool)`

GetPortGroupIdOk returns a tuple with the PortGroupId field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetPortGroupId

`func (o *CreatePortGroupParam) SetPortGroupId(v string)`

SetPortGroupId sets PortGroupId field to given value.


### GetSymmetrixPortKey

`func (o *CreatePortGroupParam) GetSymmetrixPortKey() []SymmetrixPortKey`

GetSymmetrixPortKey returns the SymmetrixPortKey field if non-nil, zero value otherwise.

### GetSymmetrixPortKeyOk

`func (o *CreatePortGroupParam) GetSymmetrixPortKeyOk() (*[]SymmetrixPortKey, bool)`

GetSymmetrixPortKeyOk returns a tuple with the SymmetrixPortKey field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetSymmetrixPortKey

`func (o *CreatePortGroupParam) SetSymmetrixPortKey(v []SymmetrixPortKey)`

SetSymmetrixPortKey sets SymmetrixPortKey field to given value.

### HasSymmetrixPortKey

`func (o *CreatePortGroupParam) HasSymmetrixPortKey() bool`

HasSymmetrixPortKey returns a boolean if a field has been set.

### GetPortGroupProtocol

`func (o *CreatePortGroupParam) GetPortGroupProtocol() string`

GetPortGroupProtocol returns the PortGroupProtocol field if non-nil, zero value otherwise.

### GetPortGroupProtocolOk

`func (o *CreatePortGroupParam) GetPortGroupProtocolOk() (*string, bool)`

GetPortGroupProtocolOk returns a tuple with the PortGroupProtocol field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetPortGroupProtocol

`func (o *CreatePortGroupParam) SetPortGroupProtocol(v string)`

SetPortGroupProtocol sets PortGroupProtocol field to given value.

### HasPortGroupProtocol

`func (o *CreatePortGroupParam) HasPortGroupProtocol() bool`

HasPortGroupProtocol returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


