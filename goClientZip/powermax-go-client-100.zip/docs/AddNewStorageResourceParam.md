# AddNewStorageResourceParam

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**StorageResourceParam** | Pointer to [**[]VvolStorageResourceParam**](VvolStorageResourceParam.md) | storageResourceParam | [optional] 

## Methods

### NewAddNewStorageResourceParam

`func NewAddNewStorageResourceParam() *AddNewStorageResourceParam`

NewAddNewStorageResourceParam instantiates a new AddNewStorageResourceParam object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewAddNewStorageResourceParamWithDefaults

`func NewAddNewStorageResourceParamWithDefaults() *AddNewStorageResourceParam`

NewAddNewStorageResourceParamWithDefaults instantiates a new AddNewStorageResourceParam object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetStorageResourceParam

`func (o *AddNewStorageResourceParam) GetStorageResourceParam() []VvolStorageResourceParam`

GetStorageResourceParam returns the StorageResourceParam field if non-nil, zero value otherwise.

### GetStorageResourceParamOk

`func (o *AddNewStorageResourceParam) GetStorageResourceParamOk() (*[]VvolStorageResourceParam, bool)`

GetStorageResourceParamOk returns a tuple with the StorageResourceParam field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetStorageResourceParam

`func (o *AddNewStorageResourceParam) SetStorageResourceParam(v []VvolStorageResourceParam)`

SetStorageResourceParam sets StorageResourceParam field to given value.

### HasStorageResourceParam

`func (o *AddNewStorageResourceParam) HasStorageResourceParam() bool`

HasStorageResourceParam returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


