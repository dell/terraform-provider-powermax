# EndpointKeyParam

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**SystemId** | **string** | systemId | 

## Methods

### NewEndpointKeyParam

`func NewEndpointKeyParam(systemId string, ) *EndpointKeyParam`

NewEndpointKeyParam instantiates a new EndpointKeyParam object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewEndpointKeyParamWithDefaults

`func NewEndpointKeyParamWithDefaults() *EndpointKeyParam`

NewEndpointKeyParamWithDefaults instantiates a new EndpointKeyParam object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetSystemId

`func (o *EndpointKeyParam) GetSystemId() string`

GetSystemId returns the SystemId field if non-nil, zero value otherwise.

### GetSystemIdOk

`func (o *EndpointKeyParam) GetSystemIdOk() (*string, bool)`

GetSystemIdOk returns a tuple with the SystemId field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetSystemId

`func (o *EndpointKeyParam) SetSystemId(v string)`

SetSystemId sets SystemId field to given value.



[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


