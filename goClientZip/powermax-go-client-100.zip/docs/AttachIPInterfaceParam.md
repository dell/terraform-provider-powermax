# AttachIPInterfaceParam

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**IpInterfaceParam** | Pointer to [**[]IpInterfaceParam**](IpInterfaceParam.md) | ipInterfaceParam | [optional] 

## Methods

### NewAttachIPInterfaceParam

`func NewAttachIPInterfaceParam() *AttachIPInterfaceParam`

NewAttachIPInterfaceParam instantiates a new AttachIPInterfaceParam object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewAttachIPInterfaceParamWithDefaults

`func NewAttachIPInterfaceParamWithDefaults() *AttachIPInterfaceParam`

NewAttachIPInterfaceParamWithDefaults instantiates a new AttachIPInterfaceParam object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetIpInterfaceParam

`func (o *AttachIPInterfaceParam) GetIpInterfaceParam() []IpInterfaceParam`

GetIpInterfaceParam returns the IpInterfaceParam field if non-nil, zero value otherwise.

### GetIpInterfaceParamOk

`func (o *AttachIPInterfaceParam) GetIpInterfaceParamOk() (*[]IpInterfaceParam, bool)`

GetIpInterfaceParamOk returns a tuple with the IpInterfaceParam field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetIpInterfaceParam

`func (o *AttachIPInterfaceParam) SetIpInterfaceParam(v []IpInterfaceParam)`

SetIpInterfaceParam sets IpInterfaceParam field to given value.

### HasIpInterfaceParam

`func (o *AttachIPInterfaceParam) HasIpInterfaceParam() bool`

HasIpInterfaceParam returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


