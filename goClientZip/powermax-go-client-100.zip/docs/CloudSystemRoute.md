# CloudSystemRoute

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**RouteId** | **string** | The ID of the Cloud System Route | 
**DestinationIpAddress** | Pointer to **string** | The destination IP Address of the Cloud System Route | [optional] 
**Prefix** | Pointer to **string** | The Netmask Prefix Number of the Cloud System Route | [optional] 
**GatewayIpAddress** | Pointer to **string** | The Gateway IP Address of the Cloud System Route | [optional] 
**InterfaceId** | Pointer to **string** | The ID of the Interface associated with the Cloud System Route | [optional] 

## Methods

### NewCloudSystemRoute

`func NewCloudSystemRoute(routeId string, ) *CloudSystemRoute`

NewCloudSystemRoute instantiates a new CloudSystemRoute object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewCloudSystemRouteWithDefaults

`func NewCloudSystemRouteWithDefaults() *CloudSystemRoute`

NewCloudSystemRouteWithDefaults instantiates a new CloudSystemRoute object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetRouteId

`func (o *CloudSystemRoute) GetRouteId() string`

GetRouteId returns the RouteId field if non-nil, zero value otherwise.

### GetRouteIdOk

`func (o *CloudSystemRoute) GetRouteIdOk() (*string, bool)`

GetRouteIdOk returns a tuple with the RouteId field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetRouteId

`func (o *CloudSystemRoute) SetRouteId(v string)`

SetRouteId sets RouteId field to given value.


### GetDestinationIpAddress

`func (o *CloudSystemRoute) GetDestinationIpAddress() string`

GetDestinationIpAddress returns the DestinationIpAddress field if non-nil, zero value otherwise.

### GetDestinationIpAddressOk

`func (o *CloudSystemRoute) GetDestinationIpAddressOk() (*string, bool)`

GetDestinationIpAddressOk returns a tuple with the DestinationIpAddress field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetDestinationIpAddress

`func (o *CloudSystemRoute) SetDestinationIpAddress(v string)`

SetDestinationIpAddress sets DestinationIpAddress field to given value.

### HasDestinationIpAddress

`func (o *CloudSystemRoute) HasDestinationIpAddress() bool`

HasDestinationIpAddress returns a boolean if a field has been set.

### GetPrefix

`func (o *CloudSystemRoute) GetPrefix() string`

GetPrefix returns the Prefix field if non-nil, zero value otherwise.

### GetPrefixOk

`func (o *CloudSystemRoute) GetPrefixOk() (*string, bool)`

GetPrefixOk returns a tuple with the Prefix field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetPrefix

`func (o *CloudSystemRoute) SetPrefix(v string)`

SetPrefix sets Prefix field to given value.

### HasPrefix

`func (o *CloudSystemRoute) HasPrefix() bool`

HasPrefix returns a boolean if a field has been set.

### GetGatewayIpAddress

`func (o *CloudSystemRoute) GetGatewayIpAddress() string`

GetGatewayIpAddress returns the GatewayIpAddress field if non-nil, zero value otherwise.

### GetGatewayIpAddressOk

`func (o *CloudSystemRoute) GetGatewayIpAddressOk() (*string, bool)`

GetGatewayIpAddressOk returns a tuple with the GatewayIpAddress field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetGatewayIpAddress

`func (o *CloudSystemRoute) SetGatewayIpAddress(v string)`

SetGatewayIpAddress sets GatewayIpAddress field to given value.

### HasGatewayIpAddress

`func (o *CloudSystemRoute) HasGatewayIpAddress() bool`

HasGatewayIpAddress returns a boolean if a field has been set.

### GetInterfaceId

`func (o *CloudSystemRoute) GetInterfaceId() string`

GetInterfaceId returns the InterfaceId field if non-nil, zero value otherwise.

### GetInterfaceIdOk

`func (o *CloudSystemRoute) GetInterfaceIdOk() (*string, bool)`

GetInterfaceIdOk returns a tuple with the InterfaceId field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetInterfaceId

`func (o *CloudSystemRoute) SetInterfaceId(v string)`

SetInterfaceId sets InterfaceId field to given value.

### HasInterfaceId

`func (o *CloudSystemRoute) HasInterfaceId() bool`

HasInterfaceId returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


