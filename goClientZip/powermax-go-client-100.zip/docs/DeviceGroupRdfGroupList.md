# DeviceGroupRdfGroupList

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**RdfgNumbers** | Pointer to **[]int64** | The local SRDF Group numbers for the Device Group standard devices | [optional] 
**BcvRdfgNumbers** | Pointer to **[]int64** | The local SRDF Group numbers for the Device Group BCV devices | [optional] 

## Methods

### NewDeviceGroupRdfGroupList

`func NewDeviceGroupRdfGroupList() *DeviceGroupRdfGroupList`

NewDeviceGroupRdfGroupList instantiates a new DeviceGroupRdfGroupList object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewDeviceGroupRdfGroupListWithDefaults

`func NewDeviceGroupRdfGroupListWithDefaults() *DeviceGroupRdfGroupList`

NewDeviceGroupRdfGroupListWithDefaults instantiates a new DeviceGroupRdfGroupList object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetRdfgNumbers

`func (o *DeviceGroupRdfGroupList) GetRdfgNumbers() []int64`

GetRdfgNumbers returns the RdfgNumbers field if non-nil, zero value otherwise.

### GetRdfgNumbersOk

`func (o *DeviceGroupRdfGroupList) GetRdfgNumbersOk() (*[]int64, bool)`

GetRdfgNumbersOk returns a tuple with the RdfgNumbers field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetRdfgNumbers

`func (o *DeviceGroupRdfGroupList) SetRdfgNumbers(v []int64)`

SetRdfgNumbers sets RdfgNumbers field to given value.

### HasRdfgNumbers

`func (o *DeviceGroupRdfGroupList) HasRdfgNumbers() bool`

HasRdfgNumbers returns a boolean if a field has been set.

### GetBcvRdfgNumbers

`func (o *DeviceGroupRdfGroupList) GetBcvRdfgNumbers() []int64`

GetBcvRdfgNumbers returns the BcvRdfgNumbers field if non-nil, zero value otherwise.

### GetBcvRdfgNumbersOk

`func (o *DeviceGroupRdfGroupList) GetBcvRdfgNumbersOk() (*[]int64, bool)`

GetBcvRdfgNumbersOk returns a tuple with the BcvRdfgNumbers field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetBcvRdfgNumbers

`func (o *DeviceGroupRdfGroupList) SetBcvRdfgNumbers(v []int64)`

SetBcvRdfgNumbers sets BcvRdfgNumbers field to given value.

### HasBcvRdfgNumbers

`func (o *DeviceGroupRdfGroupList) HasBcvRdfgNumbers() bool`

HasBcvRdfgNumbers returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


