# Metrics200ResponseMediaType

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Type** | Pointer to **string** |  | [optional] 
**Subtype** | Pointer to **string** |  | [optional] 
**Parameters** | Pointer to **map[string]string** |  | [optional] 
**WildcardSubtype** | Pointer to **bool** |  | [optional] 
**WildcardType** | Pointer to **bool** |  | [optional] 

## Methods

### NewMetrics200ResponseMediaType

`func NewMetrics200ResponseMediaType() *Metrics200ResponseMediaType`

NewMetrics200ResponseMediaType instantiates a new Metrics200ResponseMediaType object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewMetrics200ResponseMediaTypeWithDefaults

`func NewMetrics200ResponseMediaTypeWithDefaults() *Metrics200ResponseMediaType`

NewMetrics200ResponseMediaTypeWithDefaults instantiates a new Metrics200ResponseMediaType object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetType

`func (o *Metrics200ResponseMediaType) GetType() string`

GetType returns the Type field if non-nil, zero value otherwise.

### GetTypeOk

`func (o *Metrics200ResponseMediaType) GetTypeOk() (*string, bool)`

GetTypeOk returns a tuple with the Type field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetType

`func (o *Metrics200ResponseMediaType) SetType(v string)`

SetType sets Type field to given value.

### HasType

`func (o *Metrics200ResponseMediaType) HasType() bool`

HasType returns a boolean if a field has been set.

### GetSubtype

`func (o *Metrics200ResponseMediaType) GetSubtype() string`

GetSubtype returns the Subtype field if non-nil, zero value otherwise.

### GetSubtypeOk

`func (o *Metrics200ResponseMediaType) GetSubtypeOk() (*string, bool)`

GetSubtypeOk returns a tuple with the Subtype field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetSubtype

`func (o *Metrics200ResponseMediaType) SetSubtype(v string)`

SetSubtype sets Subtype field to given value.

### HasSubtype

`func (o *Metrics200ResponseMediaType) HasSubtype() bool`

HasSubtype returns a boolean if a field has been set.

### GetParameters

`func (o *Metrics200ResponseMediaType) GetParameters() map[string]string`

GetParameters returns the Parameters field if non-nil, zero value otherwise.

### GetParametersOk

`func (o *Metrics200ResponseMediaType) GetParametersOk() (*map[string]string, bool)`

GetParametersOk returns a tuple with the Parameters field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetParameters

`func (o *Metrics200ResponseMediaType) SetParameters(v map[string]string)`

SetParameters sets Parameters field to given value.

### HasParameters

`func (o *Metrics200ResponseMediaType) HasParameters() bool`

HasParameters returns a boolean if a field has been set.

### GetWildcardSubtype

`func (o *Metrics200ResponseMediaType) GetWildcardSubtype() bool`

GetWildcardSubtype returns the WildcardSubtype field if non-nil, zero value otherwise.

### GetWildcardSubtypeOk

`func (o *Metrics200ResponseMediaType) GetWildcardSubtypeOk() (*bool, bool)`

GetWildcardSubtypeOk returns a tuple with the WildcardSubtype field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetWildcardSubtype

`func (o *Metrics200ResponseMediaType) SetWildcardSubtype(v bool)`

SetWildcardSubtype sets WildcardSubtype field to given value.

### HasWildcardSubtype

`func (o *Metrics200ResponseMediaType) HasWildcardSubtype() bool`

HasWildcardSubtype returns a boolean if a field has been set.

### GetWildcardType

`func (o *Metrics200ResponseMediaType) GetWildcardType() bool`

GetWildcardType returns the WildcardType field if non-nil, zero value otherwise.

### GetWildcardTypeOk

`func (o *Metrics200ResponseMediaType) GetWildcardTypeOk() (*bool, bool)`

GetWildcardTypeOk returns a tuple with the WildcardType field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetWildcardType

`func (o *Metrics200ResponseMediaType) SetWildcardType(v bool)`

SetWildcardType sets WildcardType field to given value.

### HasWildcardType

`func (o *Metrics200ResponseMediaType) HasWildcardType() bool`

HasWildcardType returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


