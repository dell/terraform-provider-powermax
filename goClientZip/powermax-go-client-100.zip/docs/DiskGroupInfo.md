# DiskGroupInfo

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**FirstAvailableDate** | Pointer to **int64** |  | [optional] 
**LastAvailableDate** | Pointer to **int64** |  | [optional] 
**DiskGroupId** | **string** | diskGroupId | 

## Methods

### NewDiskGroupInfo

`func NewDiskGroupInfo(diskGroupId string, ) *DiskGroupInfo`

NewDiskGroupInfo instantiates a new DiskGroupInfo object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewDiskGroupInfoWithDefaults

`func NewDiskGroupInfoWithDefaults() *DiskGroupInfo`

NewDiskGroupInfoWithDefaults instantiates a new DiskGroupInfo object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetFirstAvailableDate

`func (o *DiskGroupInfo) GetFirstAvailableDate() int64`

GetFirstAvailableDate returns the FirstAvailableDate field if non-nil, zero value otherwise.

### GetFirstAvailableDateOk

`func (o *DiskGroupInfo) GetFirstAvailableDateOk() (*int64, bool)`

GetFirstAvailableDateOk returns a tuple with the FirstAvailableDate field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetFirstAvailableDate

`func (o *DiskGroupInfo) SetFirstAvailableDate(v int64)`

SetFirstAvailableDate sets FirstAvailableDate field to given value.

### HasFirstAvailableDate

`func (o *DiskGroupInfo) HasFirstAvailableDate() bool`

HasFirstAvailableDate returns a boolean if a field has been set.

### GetLastAvailableDate

`func (o *DiskGroupInfo) GetLastAvailableDate() int64`

GetLastAvailableDate returns the LastAvailableDate field if non-nil, zero value otherwise.

### GetLastAvailableDateOk

`func (o *DiskGroupInfo) GetLastAvailableDateOk() (*int64, bool)`

GetLastAvailableDateOk returns a tuple with the LastAvailableDate field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetLastAvailableDate

`func (o *DiskGroupInfo) SetLastAvailableDate(v int64)`

SetLastAvailableDate sets LastAvailableDate field to given value.

### HasLastAvailableDate

`func (o *DiskGroupInfo) HasLastAvailableDate() bool`

HasLastAvailableDate returns a boolean if a field has been set.

### GetDiskGroupId

`func (o *DiskGroupInfo) GetDiskGroupId() string`

GetDiskGroupId returns the DiskGroupId field if non-nil, zero value otherwise.

### GetDiskGroupIdOk

`func (o *DiskGroupInfo) GetDiskGroupIdOk() (*string, bool)`

GetDiskGroupIdOk returns a tuple with the DiskGroupId field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetDiskGroupId

`func (o *DiskGroupInfo) SetDiskGroupId(v string)`

SetDiskGroupId sets DiskGroupId field to given value.



[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


