# AllVolumeParam

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**VolumeAttribute** | [**VolumeAttribute**](VolumeAttribute.md) |  | 
**RdfGroupNumber** | Pointer to **int64** | Rdf Group Number for the device. | [optional] 

## Methods

### NewAllVolumeParam

`func NewAllVolumeParam(volumeAttribute VolumeAttribute, ) *AllVolumeParam`

NewAllVolumeParam instantiates a new AllVolumeParam object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewAllVolumeParamWithDefaults

`func NewAllVolumeParamWithDefaults() *AllVolumeParam`

NewAllVolumeParamWithDefaults instantiates a new AllVolumeParam object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetVolumeAttribute

`func (o *AllVolumeParam) GetVolumeAttribute() VolumeAttribute`

GetVolumeAttribute returns the VolumeAttribute field if non-nil, zero value otherwise.

### GetVolumeAttributeOk

`func (o *AllVolumeParam) GetVolumeAttributeOk() (*VolumeAttribute, bool)`

GetVolumeAttributeOk returns a tuple with the VolumeAttribute field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetVolumeAttribute

`func (o *AllVolumeParam) SetVolumeAttribute(v VolumeAttribute)`

SetVolumeAttribute sets VolumeAttribute field to given value.


### GetRdfGroupNumber

`func (o *AllVolumeParam) GetRdfGroupNumber() int64`

GetRdfGroupNumber returns the RdfGroupNumber field if non-nil, zero value otherwise.

### GetRdfGroupNumberOk

`func (o *AllVolumeParam) GetRdfGroupNumberOk() (*int64, bool)`

GetRdfGroupNumberOk returns a tuple with the RdfGroupNumber field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetRdfGroupNumber

`func (o *AllVolumeParam) SetRdfGroupNumber(v int64)`

SetRdfGroupNumber sets RdfGroupNumber field to given value.

### HasRdfGroupNumber

`func (o *AllVolumeParam) HasRdfGroupNumber() bool`

HasRdfGroupNumber returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


