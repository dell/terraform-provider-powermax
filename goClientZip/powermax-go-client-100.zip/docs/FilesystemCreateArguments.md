# FilesystemCreateArguments

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Name** | **string** |                          Name of the filesystem                      | 
**NasServer** | **string** |                          Object ID of the NAS server for the filesystem                      | 
**Description** | Pointer to **string** |                          Filesystem description                      | [optional] 
**SizeTotal** | **int64** |                          Size, in MiB, that the system presents to the host or end user.                      | 
**FsType** | Pointer to **string** |                          - 1: filesystem                         - 2: VMWare file system                        Enumeration values: * **General** * **VMWare**  | [optional] [default to "General"]
**AccessPolicy** | Pointer to **string** |                          File system or protocol snap security access policies.                         - 0: Native Security.                         - 1: UNIX Security.                         - 2: Windows Security.                        Enumeration values: * **Native** * **UNIX** * **Windows**  | [optional] [default to "Native"]
**LockingPolicy** | Pointer to **string** |                          File system or protocol snap locking policies. These policy choices control whether the NFSv4 range locks must be honored. Because NFSv3 is advisory by design, this policy allows specifying whether the NFSv4 locking feature behaves like NFSv3 (advisory mode) in order to be backward compatible with applications expecting an advisory locking scheme.                         - 0: Advisory - No lock checking for NFS and honor SMB lock range only for SMB.                         - 1: Mandatory - Honor SMB and NFS lock range.                        Enumeration values: * **Advisory** * **Mandatory**  | [optional] [default to "Advisory"]
**FolderRenamePolicy** | Pointer to **string** |                          File system or protocol snap folder rename policies. These policy choices control whether directory can be renamed from NFS or SMB clients if at least one file is opened in the directory or in one of its child directories.                         - 0: SMB_Rename_Forbidden - A directory rename from the SMB protocol will be denied if at least one file is opened in the directory or in one of its child directories.                         - 1: All_Rename_Forbidden - Any directory rename request will be denied regardless of the protocol used, if at least one file is opened in the directory or in one of its child directories.                         - 2: All_Rename_Allowed - All protocols are allowed to rename directories without any restrictions.                        Enumeration values: * **SMB_Rename_Forbidden** * **All_Rename_Forbidden** * **All_Rename_Allowed**  | [optional] [default to "SMB_Rename_Forbidden"]
**EventNotifications** | Pointer to **string** |                          State of the event notification services for file system or protocol snap.                         - 0 : off                         - 1 : smb only notifications                         - 2 : nfs only notifications                         - 3 : smb and nfs notifications                        Enumeration values: * **off** * **SMB** * **NFS** * **SMB_NFS**  | [optional] [default to "off"]
**ServiceLevel** | Pointer to **string** |                          Service Level Object                        Enumeration values: * **Optimized** * **Bronze** * **Silver** * **Gold** * **Diamond** * **Platinum**  | [optional] [default to "Optimized"]
**DataReduction** | Pointer to **bool** |                          Platform attribute                         - true if data reduction enabled                         - false if data reduction disabled                      | [optional] [default to false]
**SmbSyncWrites** | Pointer to **bool** |                          Indicates whether the synchronous writes option is enabled on the file system. Values are:                         - true - Synchronous writes option is enabled on the file system.                         - false - Synchronous writes option is disabled on the file system.                      | [optional] 
**SmbNoNotify** | Pointer to **bool** |                          Indicates whether notifications of changes to directory file structure are enabled.                         - true - Notifications are enabled.                         - false - Notifications are disabled.                      | [optional] 
**SmbOpLocks** | Pointer to **bool** |                          Indicates whether opportunistic file locking is enabled on the file system. Values are:                         - true - Opportunistic file locking is enabled on the file system.                         - false - Opportunistic file locking is disabled on the file system.                      | [optional] 
**SmbNotifyOnAccess** | Pointer to **bool** |                          Indicates whether notifications on file access are enabled on the file system. Values are:                         - true - Notifications on file access are enabled on the file system.                         - false - Notifications on file access are disabled on the file system.                      | [optional] 
**SmbNotifyOnWrite** | Pointer to **bool** |                          Indicates whether notifications on file writes are enabled on the file system. Values are:                         - true - Notifications on file writes are enabled on the file system.                         - false - Notifications on file writes are disabled on the file system.                      | [optional] 
**SmbNotifyOnChangeDirDepth** | Pointer to **int32** |                          Lowest directory level to which the enabled notifications apply, if any.                      | [optional] 
**AsyncMtime** | Pointer to **bool** |                          Indicates whether asynchronous MTIME is enabled on the file system. Values are:                         - true - asynchronous MTIME is enabled on the file system.                         - false - asynchronous MTIME is disabled on the file system.                      | [optional] 
**HostIosize** | Pointer to **int32** |                          Typical size of writes from the server or other computer using the file system or LUN to the storage system. This setting is used to match the storage block size to the I/O of the primary application using the storage, which can optimize performance. Choose one of the suggested applications if you are using one of them, or check the setup guide or performance tuning information for the primary application, or stay with default 8K size for general use.  For create operation applies only to vmware datastore fstype filesystems:                         - 8192: General_8K - Host I/O size is 8K for general purpose                         - 16384: General_16K - Host I/O size is 16K for general purpose                         - 32768: General_32K - Host I/O size is 32K for general purpose                         - 65536: General_64K - Host I/O size is 64K for general purpose                      | [optional] [default to 8192]
**FlrMode** | Pointer to **string** |                          The FLR type of the file system. This setting is significant only if flrEnabled is true.                        Enumeration values: * **None** * **Enterprise** * **Compliance**  | [optional] [default to "None"]
**FlrMinRet** | Pointer to **string** |                          The shortest retention period for which files on an FLR-enabled file system can be locked and protected from deletion. This value must be less than or equal to the maximum retention period. Any attempt to lock a file for less than the minimum retention period results in the file being locked until the current system time plus the minimum retention period is reached.                         Format [Y|M|D] (example 5Y for 5 years), specify Y for years, M for months, D for days, or the keyword infinite. Setting infinite means that the files can never be deleted.  This attribute should be set only for FLR enabled filesystems.                      | [optional] 
**FlrDefRet** | Pointer to **string** |                          The default retention period that is used in an FLR-enabled file system when a file is locked and a retention period is not specified. This value must be greater than or equal to the minimum retention period, and less than or equal to the maximum retention period.                         Format [Y|M|D] (example 5Y for 5 years).  Specify Y for years, M for months, D for days, or infinite. The default value for the default retention period is infinite for Enterprise FLR mode, and 1 year for Compliance FLR mode.  This attribute should be set only for FLR enabled filesystems.                      | [optional] 
**FlrMaxRet** | Pointer to **string** |                          The longest retention period for which files on an FLR-enabled file system can be locked and protected from deletion. Any attempt to lock a file for more than this maximum retention period results in the file being locked until the current system time plus the maximum retention period is reached. Specify Y for years, M for months, D for days, or infinite. setting infinite means that the files can never be deleted.  This attribute should be set only for FLR enabled filesystems.                      | [optional] 
**FlrEnabled** | Pointer to **bool** |                          Indicates whether File Level Retention feature is to enabled on the Filesystem                      | [optional] 
**InfoThreshold** | Pointer to **int32** |                              The info threshold will trigger info event if the file system used space exceeds this threshold. Default value is 0 (disabled).                      | [optional] 
**HighThreshold** | Pointer to **int32** |                          The high threshold will trigger info event if the file system used space exceeds this threshold. Default value is 75%. (set to 0 to disable)                      | [optional] 
**WarningThreshold** | Pointer to **int32** |                          The warning threshold will trigger alert event if the file system used space exceeds this threshold. Default value is 95%. (set to 0 to disable)                      | [optional] 

## Methods

### NewFilesystemCreateArguments

`func NewFilesystemCreateArguments(name string, nasServer string, sizeTotal int64, ) *FilesystemCreateArguments`

NewFilesystemCreateArguments instantiates a new FilesystemCreateArguments object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewFilesystemCreateArgumentsWithDefaults

`func NewFilesystemCreateArgumentsWithDefaults() *FilesystemCreateArguments`

NewFilesystemCreateArgumentsWithDefaults instantiates a new FilesystemCreateArguments object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetName

`func (o *FilesystemCreateArguments) GetName() string`

GetName returns the Name field if non-nil, zero value otherwise.

### GetNameOk

`func (o *FilesystemCreateArguments) GetNameOk() (*string, bool)`

GetNameOk returns a tuple with the Name field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetName

`func (o *FilesystemCreateArguments) SetName(v string)`

SetName sets Name field to given value.


### GetNasServer

`func (o *FilesystemCreateArguments) GetNasServer() string`

GetNasServer returns the NasServer field if non-nil, zero value otherwise.

### GetNasServerOk

`func (o *FilesystemCreateArguments) GetNasServerOk() (*string, bool)`

GetNasServerOk returns a tuple with the NasServer field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetNasServer

`func (o *FilesystemCreateArguments) SetNasServer(v string)`

SetNasServer sets NasServer field to given value.


### GetDescription

`func (o *FilesystemCreateArguments) GetDescription() string`

GetDescription returns the Description field if non-nil, zero value otherwise.

### GetDescriptionOk

`func (o *FilesystemCreateArguments) GetDescriptionOk() (*string, bool)`

GetDescriptionOk returns a tuple with the Description field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetDescription

`func (o *FilesystemCreateArguments) SetDescription(v string)`

SetDescription sets Description field to given value.

### HasDescription

`func (o *FilesystemCreateArguments) HasDescription() bool`

HasDescription returns a boolean if a field has been set.

### GetSizeTotal

`func (o *FilesystemCreateArguments) GetSizeTotal() int64`

GetSizeTotal returns the SizeTotal field if non-nil, zero value otherwise.

### GetSizeTotalOk

`func (o *FilesystemCreateArguments) GetSizeTotalOk() (*int64, bool)`

GetSizeTotalOk returns a tuple with the SizeTotal field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetSizeTotal

`func (o *FilesystemCreateArguments) SetSizeTotal(v int64)`

SetSizeTotal sets SizeTotal field to given value.


### GetFsType

`func (o *FilesystemCreateArguments) GetFsType() string`

GetFsType returns the FsType field if non-nil, zero value otherwise.

### GetFsTypeOk

`func (o *FilesystemCreateArguments) GetFsTypeOk() (*string, bool)`

GetFsTypeOk returns a tuple with the FsType field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetFsType

`func (o *FilesystemCreateArguments) SetFsType(v string)`

SetFsType sets FsType field to given value.

### HasFsType

`func (o *FilesystemCreateArguments) HasFsType() bool`

HasFsType returns a boolean if a field has been set.

### GetAccessPolicy

`func (o *FilesystemCreateArguments) GetAccessPolicy() string`

GetAccessPolicy returns the AccessPolicy field if non-nil, zero value otherwise.

### GetAccessPolicyOk

`func (o *FilesystemCreateArguments) GetAccessPolicyOk() (*string, bool)`

GetAccessPolicyOk returns a tuple with the AccessPolicy field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetAccessPolicy

`func (o *FilesystemCreateArguments) SetAccessPolicy(v string)`

SetAccessPolicy sets AccessPolicy field to given value.

### HasAccessPolicy

`func (o *FilesystemCreateArguments) HasAccessPolicy() bool`

HasAccessPolicy returns a boolean if a field has been set.

### GetLockingPolicy

`func (o *FilesystemCreateArguments) GetLockingPolicy() string`

GetLockingPolicy returns the LockingPolicy field if non-nil, zero value otherwise.

### GetLockingPolicyOk

`func (o *FilesystemCreateArguments) GetLockingPolicyOk() (*string, bool)`

GetLockingPolicyOk returns a tuple with the LockingPolicy field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetLockingPolicy

`func (o *FilesystemCreateArguments) SetLockingPolicy(v string)`

SetLockingPolicy sets LockingPolicy field to given value.

### HasLockingPolicy

`func (o *FilesystemCreateArguments) HasLockingPolicy() bool`

HasLockingPolicy returns a boolean if a field has been set.

### GetFolderRenamePolicy

`func (o *FilesystemCreateArguments) GetFolderRenamePolicy() string`

GetFolderRenamePolicy returns the FolderRenamePolicy field if non-nil, zero value otherwise.

### GetFolderRenamePolicyOk

`func (o *FilesystemCreateArguments) GetFolderRenamePolicyOk() (*string, bool)`

GetFolderRenamePolicyOk returns a tuple with the FolderRenamePolicy field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetFolderRenamePolicy

`func (o *FilesystemCreateArguments) SetFolderRenamePolicy(v string)`

SetFolderRenamePolicy sets FolderRenamePolicy field to given value.

### HasFolderRenamePolicy

`func (o *FilesystemCreateArguments) HasFolderRenamePolicy() bool`

HasFolderRenamePolicy returns a boolean if a field has been set.

### GetEventNotifications

`func (o *FilesystemCreateArguments) GetEventNotifications() string`

GetEventNotifications returns the EventNotifications field if non-nil, zero value otherwise.

### GetEventNotificationsOk

`func (o *FilesystemCreateArguments) GetEventNotificationsOk() (*string, bool)`

GetEventNotificationsOk returns a tuple with the EventNotifications field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetEventNotifications

`func (o *FilesystemCreateArguments) SetEventNotifications(v string)`

SetEventNotifications sets EventNotifications field to given value.

### HasEventNotifications

`func (o *FilesystemCreateArguments) HasEventNotifications() bool`

HasEventNotifications returns a boolean if a field has been set.

### GetServiceLevel

`func (o *FilesystemCreateArguments) GetServiceLevel() string`

GetServiceLevel returns the ServiceLevel field if non-nil, zero value otherwise.

### GetServiceLevelOk

`func (o *FilesystemCreateArguments) GetServiceLevelOk() (*string, bool)`

GetServiceLevelOk returns a tuple with the ServiceLevel field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetServiceLevel

`func (o *FilesystemCreateArguments) SetServiceLevel(v string)`

SetServiceLevel sets ServiceLevel field to given value.

### HasServiceLevel

`func (o *FilesystemCreateArguments) HasServiceLevel() bool`

HasServiceLevel returns a boolean if a field has been set.

### GetDataReduction

`func (o *FilesystemCreateArguments) GetDataReduction() bool`

GetDataReduction returns the DataReduction field if non-nil, zero value otherwise.

### GetDataReductionOk

`func (o *FilesystemCreateArguments) GetDataReductionOk() (*bool, bool)`

GetDataReductionOk returns a tuple with the DataReduction field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetDataReduction

`func (o *FilesystemCreateArguments) SetDataReduction(v bool)`

SetDataReduction sets DataReduction field to given value.

### HasDataReduction

`func (o *FilesystemCreateArguments) HasDataReduction() bool`

HasDataReduction returns a boolean if a field has been set.

### GetSmbSyncWrites

`func (o *FilesystemCreateArguments) GetSmbSyncWrites() bool`

GetSmbSyncWrites returns the SmbSyncWrites field if non-nil, zero value otherwise.

### GetSmbSyncWritesOk

`func (o *FilesystemCreateArguments) GetSmbSyncWritesOk() (*bool, bool)`

GetSmbSyncWritesOk returns a tuple with the SmbSyncWrites field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetSmbSyncWrites

`func (o *FilesystemCreateArguments) SetSmbSyncWrites(v bool)`

SetSmbSyncWrites sets SmbSyncWrites field to given value.

### HasSmbSyncWrites

`func (o *FilesystemCreateArguments) HasSmbSyncWrites() bool`

HasSmbSyncWrites returns a boolean if a field has been set.

### GetSmbNoNotify

`func (o *FilesystemCreateArguments) GetSmbNoNotify() bool`

GetSmbNoNotify returns the SmbNoNotify field if non-nil, zero value otherwise.

### GetSmbNoNotifyOk

`func (o *FilesystemCreateArguments) GetSmbNoNotifyOk() (*bool, bool)`

GetSmbNoNotifyOk returns a tuple with the SmbNoNotify field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetSmbNoNotify

`func (o *FilesystemCreateArguments) SetSmbNoNotify(v bool)`

SetSmbNoNotify sets SmbNoNotify field to given value.

### HasSmbNoNotify

`func (o *FilesystemCreateArguments) HasSmbNoNotify() bool`

HasSmbNoNotify returns a boolean if a field has been set.

### GetSmbOpLocks

`func (o *FilesystemCreateArguments) GetSmbOpLocks() bool`

GetSmbOpLocks returns the SmbOpLocks field if non-nil, zero value otherwise.

### GetSmbOpLocksOk

`func (o *FilesystemCreateArguments) GetSmbOpLocksOk() (*bool, bool)`

GetSmbOpLocksOk returns a tuple with the SmbOpLocks field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetSmbOpLocks

`func (o *FilesystemCreateArguments) SetSmbOpLocks(v bool)`

SetSmbOpLocks sets SmbOpLocks field to given value.

### HasSmbOpLocks

`func (o *FilesystemCreateArguments) HasSmbOpLocks() bool`

HasSmbOpLocks returns a boolean if a field has been set.

### GetSmbNotifyOnAccess

`func (o *FilesystemCreateArguments) GetSmbNotifyOnAccess() bool`

GetSmbNotifyOnAccess returns the SmbNotifyOnAccess field if non-nil, zero value otherwise.

### GetSmbNotifyOnAccessOk

`func (o *FilesystemCreateArguments) GetSmbNotifyOnAccessOk() (*bool, bool)`

GetSmbNotifyOnAccessOk returns a tuple with the SmbNotifyOnAccess field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetSmbNotifyOnAccess

`func (o *FilesystemCreateArguments) SetSmbNotifyOnAccess(v bool)`

SetSmbNotifyOnAccess sets SmbNotifyOnAccess field to given value.

### HasSmbNotifyOnAccess

`func (o *FilesystemCreateArguments) HasSmbNotifyOnAccess() bool`

HasSmbNotifyOnAccess returns a boolean if a field has been set.

### GetSmbNotifyOnWrite

`func (o *FilesystemCreateArguments) GetSmbNotifyOnWrite() bool`

GetSmbNotifyOnWrite returns the SmbNotifyOnWrite field if non-nil, zero value otherwise.

### GetSmbNotifyOnWriteOk

`func (o *FilesystemCreateArguments) GetSmbNotifyOnWriteOk() (*bool, bool)`

GetSmbNotifyOnWriteOk returns a tuple with the SmbNotifyOnWrite field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetSmbNotifyOnWrite

`func (o *FilesystemCreateArguments) SetSmbNotifyOnWrite(v bool)`

SetSmbNotifyOnWrite sets SmbNotifyOnWrite field to given value.

### HasSmbNotifyOnWrite

`func (o *FilesystemCreateArguments) HasSmbNotifyOnWrite() bool`

HasSmbNotifyOnWrite returns a boolean if a field has been set.

### GetSmbNotifyOnChangeDirDepth

`func (o *FilesystemCreateArguments) GetSmbNotifyOnChangeDirDepth() int32`

GetSmbNotifyOnChangeDirDepth returns the SmbNotifyOnChangeDirDepth field if non-nil, zero value otherwise.

### GetSmbNotifyOnChangeDirDepthOk

`func (o *FilesystemCreateArguments) GetSmbNotifyOnChangeDirDepthOk() (*int32, bool)`

GetSmbNotifyOnChangeDirDepthOk returns a tuple with the SmbNotifyOnChangeDirDepth field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetSmbNotifyOnChangeDirDepth

`func (o *FilesystemCreateArguments) SetSmbNotifyOnChangeDirDepth(v int32)`

SetSmbNotifyOnChangeDirDepth sets SmbNotifyOnChangeDirDepth field to given value.

### HasSmbNotifyOnChangeDirDepth

`func (o *FilesystemCreateArguments) HasSmbNotifyOnChangeDirDepth() bool`

HasSmbNotifyOnChangeDirDepth returns a boolean if a field has been set.

### GetAsyncMtime

`func (o *FilesystemCreateArguments) GetAsyncMtime() bool`

GetAsyncMtime returns the AsyncMtime field if non-nil, zero value otherwise.

### GetAsyncMtimeOk

`func (o *FilesystemCreateArguments) GetAsyncMtimeOk() (*bool, bool)`

GetAsyncMtimeOk returns a tuple with the AsyncMtime field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetAsyncMtime

`func (o *FilesystemCreateArguments) SetAsyncMtime(v bool)`

SetAsyncMtime sets AsyncMtime field to given value.

### HasAsyncMtime

`func (o *FilesystemCreateArguments) HasAsyncMtime() bool`

HasAsyncMtime returns a boolean if a field has been set.

### GetHostIosize

`func (o *FilesystemCreateArguments) GetHostIosize() int32`

GetHostIosize returns the HostIosize field if non-nil, zero value otherwise.

### GetHostIosizeOk

`func (o *FilesystemCreateArguments) GetHostIosizeOk() (*int32, bool)`

GetHostIosizeOk returns a tuple with the HostIosize field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetHostIosize

`func (o *FilesystemCreateArguments) SetHostIosize(v int32)`

SetHostIosize sets HostIosize field to given value.

### HasHostIosize

`func (o *FilesystemCreateArguments) HasHostIosize() bool`

HasHostIosize returns a boolean if a field has been set.

### GetFlrMode

`func (o *FilesystemCreateArguments) GetFlrMode() string`

GetFlrMode returns the FlrMode field if non-nil, zero value otherwise.

### GetFlrModeOk

`func (o *FilesystemCreateArguments) GetFlrModeOk() (*string, bool)`

GetFlrModeOk returns a tuple with the FlrMode field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetFlrMode

`func (o *FilesystemCreateArguments) SetFlrMode(v string)`

SetFlrMode sets FlrMode field to given value.

### HasFlrMode

`func (o *FilesystemCreateArguments) HasFlrMode() bool`

HasFlrMode returns a boolean if a field has been set.

### GetFlrMinRet

`func (o *FilesystemCreateArguments) GetFlrMinRet() string`

GetFlrMinRet returns the FlrMinRet field if non-nil, zero value otherwise.

### GetFlrMinRetOk

`func (o *FilesystemCreateArguments) GetFlrMinRetOk() (*string, bool)`

GetFlrMinRetOk returns a tuple with the FlrMinRet field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetFlrMinRet

`func (o *FilesystemCreateArguments) SetFlrMinRet(v string)`

SetFlrMinRet sets FlrMinRet field to given value.

### HasFlrMinRet

`func (o *FilesystemCreateArguments) HasFlrMinRet() bool`

HasFlrMinRet returns a boolean if a field has been set.

### GetFlrDefRet

`func (o *FilesystemCreateArguments) GetFlrDefRet() string`

GetFlrDefRet returns the FlrDefRet field if non-nil, zero value otherwise.

### GetFlrDefRetOk

`func (o *FilesystemCreateArguments) GetFlrDefRetOk() (*string, bool)`

GetFlrDefRetOk returns a tuple with the FlrDefRet field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetFlrDefRet

`func (o *FilesystemCreateArguments) SetFlrDefRet(v string)`

SetFlrDefRet sets FlrDefRet field to given value.

### HasFlrDefRet

`func (o *FilesystemCreateArguments) HasFlrDefRet() bool`

HasFlrDefRet returns a boolean if a field has been set.

### GetFlrMaxRet

`func (o *FilesystemCreateArguments) GetFlrMaxRet() string`

GetFlrMaxRet returns the FlrMaxRet field if non-nil, zero value otherwise.

### GetFlrMaxRetOk

`func (o *FilesystemCreateArguments) GetFlrMaxRetOk() (*string, bool)`

GetFlrMaxRetOk returns a tuple with the FlrMaxRet field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetFlrMaxRet

`func (o *FilesystemCreateArguments) SetFlrMaxRet(v string)`

SetFlrMaxRet sets FlrMaxRet field to given value.

### HasFlrMaxRet

`func (o *FilesystemCreateArguments) HasFlrMaxRet() bool`

HasFlrMaxRet returns a boolean if a field has been set.

### GetFlrEnabled

`func (o *FilesystemCreateArguments) GetFlrEnabled() bool`

GetFlrEnabled returns the FlrEnabled field if non-nil, zero value otherwise.

### GetFlrEnabledOk

`func (o *FilesystemCreateArguments) GetFlrEnabledOk() (*bool, bool)`

GetFlrEnabledOk returns a tuple with the FlrEnabled field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetFlrEnabled

`func (o *FilesystemCreateArguments) SetFlrEnabled(v bool)`

SetFlrEnabled sets FlrEnabled field to given value.

### HasFlrEnabled

`func (o *FilesystemCreateArguments) HasFlrEnabled() bool`

HasFlrEnabled returns a boolean if a field has been set.

### GetInfoThreshold

`func (o *FilesystemCreateArguments) GetInfoThreshold() int32`

GetInfoThreshold returns the InfoThreshold field if non-nil, zero value otherwise.

### GetInfoThresholdOk

`func (o *FilesystemCreateArguments) GetInfoThresholdOk() (*int32, bool)`

GetInfoThresholdOk returns a tuple with the InfoThreshold field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetInfoThreshold

`func (o *FilesystemCreateArguments) SetInfoThreshold(v int32)`

SetInfoThreshold sets InfoThreshold field to given value.

### HasInfoThreshold

`func (o *FilesystemCreateArguments) HasInfoThreshold() bool`

HasInfoThreshold returns a boolean if a field has been set.

### GetHighThreshold

`func (o *FilesystemCreateArguments) GetHighThreshold() int32`

GetHighThreshold returns the HighThreshold field if non-nil, zero value otherwise.

### GetHighThresholdOk

`func (o *FilesystemCreateArguments) GetHighThresholdOk() (*int32, bool)`

GetHighThresholdOk returns a tuple with the HighThreshold field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetHighThreshold

`func (o *FilesystemCreateArguments) SetHighThreshold(v int32)`

SetHighThreshold sets HighThreshold field to given value.

### HasHighThreshold

`func (o *FilesystemCreateArguments) HasHighThreshold() bool`

HasHighThreshold returns a boolean if a field has been set.

### GetWarningThreshold

`func (o *FilesystemCreateArguments) GetWarningThreshold() int32`

GetWarningThreshold returns the WarningThreshold field if non-nil, zero value otherwise.

### GetWarningThresholdOk

`func (o *FilesystemCreateArguments) GetWarningThresholdOk() (*int32, bool)`

GetWarningThresholdOk returns a tuple with the WarningThreshold field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetWarningThreshold

`func (o *FilesystemCreateArguments) SetWarningThreshold(v int32)`

SetWarningThreshold sets WarningThreshold field to given value.

### HasWarningThreshold

`func (o *FilesystemCreateArguments) HasWarningThreshold() bool`

HasWarningThreshold returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


