# EditInterfaceIpSettingsParam

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**IpAddress** | **string** | The new IP Address of the NIC Team | 
**Prefix** | **int32** | The new Netmask Prefix Number of the NIC Team | 

## Methods

### NewEditInterfaceIpSettingsParam

`func NewEditInterfaceIpSettingsParam(ipAddress string, prefix int32, ) *EditInterfaceIpSettingsParam`

NewEditInterfaceIpSettingsParam instantiates a new EditInterfaceIpSettingsParam object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewEditInterfaceIpSettingsParamWithDefaults

`func NewEditInterfaceIpSettingsParamWithDefaults() *EditInterfaceIpSettingsParam`

NewEditInterfaceIpSettingsParamWithDefaults instantiates a new EditInterfaceIpSettingsParam object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetIpAddress

`func (o *EditInterfaceIpSettingsParam) GetIpAddress() string`

GetIpAddress returns the IpAddress field if non-nil, zero value otherwise.

### GetIpAddressOk

`func (o *EditInterfaceIpSettingsParam) GetIpAddressOk() (*string, bool)`

GetIpAddressOk returns a tuple with the IpAddress field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetIpAddress

`func (o *EditInterfaceIpSettingsParam) SetIpAddress(v string)`

SetIpAddress sets IpAddress field to given value.


### GetPrefix

`func (o *EditInterfaceIpSettingsParam) GetPrefix() int32`

GetPrefix returns the Prefix field if non-nil, zero value otherwise.

### GetPrefixOk

`func (o *EditInterfaceIpSettingsParam) GetPrefixOk() (*int32, bool)`

GetPrefixOk returns a tuple with the Prefix field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetPrefix

`func (o *EditInterfaceIpSettingsParam) SetPrefix(v int32)`

SetPrefix sets Prefix field to given value.



[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


