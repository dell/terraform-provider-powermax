# AddHostParam

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Host** | Pointer to **[]string** | IDs/Names of existing host to be added to host group | [optional] 
**NewHosts** | Pointer to [**[]CreateHostParam**](CreateHostParam.md) | New host objects to be added to host group | [optional] 

## Methods

### NewAddHostParam

`func NewAddHostParam() *AddHostParam`

NewAddHostParam instantiates a new AddHostParam object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewAddHostParamWithDefaults

`func NewAddHostParamWithDefaults() *AddHostParam`

NewAddHostParamWithDefaults instantiates a new AddHostParam object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetHost

`func (o *AddHostParam) GetHost() []string`

GetHost returns the Host field if non-nil, zero value otherwise.

### GetHostOk

`func (o *AddHostParam) GetHostOk() (*[]string, bool)`

GetHostOk returns a tuple with the Host field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetHost

`func (o *AddHostParam) SetHost(v []string)`

SetHost sets Host field to given value.

### HasHost

`func (o *AddHostParam) HasHost() bool`

HasHost returns a boolean if a field has been set.

### GetNewHosts

`func (o *AddHostParam) GetNewHosts() []CreateHostParam`

GetNewHosts returns the NewHosts field if non-nil, zero value otherwise.

### GetNewHostsOk

`func (o *AddHostParam) GetNewHostsOk() (*[]CreateHostParam, bool)`

GetNewHostsOk returns a tuple with the NewHosts field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetNewHosts

`func (o *AddHostParam) SetNewHosts(v []CreateHostParam)`

SetNewHosts sets NewHosts field to given value.

### HasNewHosts

`func (o *AddHostParam) HasNewHosts() bool`

HasNewHosts returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


