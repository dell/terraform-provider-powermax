# DaysToFullObjectResultType

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ProjectionDaysToFull** | Pointer to **float32** | ProjectionDaysToFull | [optional] 
**PercentUsedCapacity** | Pointer to **float64** | PercentUsedCapacity | [optional] 
**TotalPoolCapacityGB** | Pointer to **float64** | TotalPoolCapacityGB | [optional] 
**InstanceId** | Pointer to **string** | instanceId | [optional] 

## Methods

### NewDaysToFullObjectResultType

`func NewDaysToFullObjectResultType() *DaysToFullObjectResultType`

NewDaysToFullObjectResultType instantiates a new DaysToFullObjectResultType object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewDaysToFullObjectResultTypeWithDefaults

`func NewDaysToFullObjectResultTypeWithDefaults() *DaysToFullObjectResultType`

NewDaysToFullObjectResultTypeWithDefaults instantiates a new DaysToFullObjectResultType object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetProjectionDaysToFull

`func (o *DaysToFullObjectResultType) GetProjectionDaysToFull() float32`

GetProjectionDaysToFull returns the ProjectionDaysToFull field if non-nil, zero value otherwise.

### GetProjectionDaysToFullOk

`func (o *DaysToFullObjectResultType) GetProjectionDaysToFullOk() (*float32, bool)`

GetProjectionDaysToFullOk returns a tuple with the ProjectionDaysToFull field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetProjectionDaysToFull

`func (o *DaysToFullObjectResultType) SetProjectionDaysToFull(v float32)`

SetProjectionDaysToFull sets ProjectionDaysToFull field to given value.

### HasProjectionDaysToFull

`func (o *DaysToFullObjectResultType) HasProjectionDaysToFull() bool`

HasProjectionDaysToFull returns a boolean if a field has been set.

### GetPercentUsedCapacity

`func (o *DaysToFullObjectResultType) GetPercentUsedCapacity() float64`

GetPercentUsedCapacity returns the PercentUsedCapacity field if non-nil, zero value otherwise.

### GetPercentUsedCapacityOk

`func (o *DaysToFullObjectResultType) GetPercentUsedCapacityOk() (*float64, bool)`

GetPercentUsedCapacityOk returns a tuple with the PercentUsedCapacity field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetPercentUsedCapacity

`func (o *DaysToFullObjectResultType) SetPercentUsedCapacity(v float64)`

SetPercentUsedCapacity sets PercentUsedCapacity field to given value.

### HasPercentUsedCapacity

`func (o *DaysToFullObjectResultType) HasPercentUsedCapacity() bool`

HasPercentUsedCapacity returns a boolean if a field has been set.

### GetTotalPoolCapacityGB

`func (o *DaysToFullObjectResultType) GetTotalPoolCapacityGB() float64`

GetTotalPoolCapacityGB returns the TotalPoolCapacityGB field if non-nil, zero value otherwise.

### GetTotalPoolCapacityGBOk

`func (o *DaysToFullObjectResultType) GetTotalPoolCapacityGBOk() (*float64, bool)`

GetTotalPoolCapacityGBOk returns a tuple with the TotalPoolCapacityGB field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetTotalPoolCapacityGB

`func (o *DaysToFullObjectResultType) SetTotalPoolCapacityGB(v float64)`

SetTotalPoolCapacityGB sets TotalPoolCapacityGB field to given value.

### HasTotalPoolCapacityGB

`func (o *DaysToFullObjectResultType) HasTotalPoolCapacityGB() bool`

HasTotalPoolCapacityGB returns a boolean if a field has been set.

### GetInstanceId

`func (o *DaysToFullObjectResultType) GetInstanceId() string`

GetInstanceId returns the InstanceId field if non-nil, zero value otherwise.

### GetInstanceIdOk

`func (o *DaysToFullObjectResultType) GetInstanceIdOk() (*string, bool)`

GetInstanceIdOk returns a tuple with the InstanceId field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetInstanceId

`func (o *DaysToFullObjectResultType) SetInstanceId(v string)`

SetInstanceId sets InstanceId field to given value.

### HasInstanceId

`func (o *DaysToFullObjectResultType) HasInstanceId() bool`

HasInstanceId returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


