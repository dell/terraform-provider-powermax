# FileSystem

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Id** | Pointer to **string** |                          Object Id of the filesystem                      | [optional] 
**ParentOid** | Pointer to **string** |                          The object id of the parent of this filesystem (only applies to clones).  If the filesystem is not a clone this will contain the null GUID 00000000-0000-0000-0000-000000000000.                      | [optional] 
**Name** | Pointer to **string** |                          Name of the filesystem                      | [optional] 
**StorageWwn** | Pointer to **string** |                          WWN of the storage containing the filesystem                      | [optional] 
**ExportFsid** | Pointer to **string** |                          The id used by network protocols for access to filesystem                      | [optional] 
**Description** | Pointer to **string** |                          Filesystem description                      | [optional] 
**SizeTotal** | Pointer to **int64** |                          Size, in MiB, that the system presents to the host or end user.                      | [optional] 
**SizeUsed** | Pointer to **int64** |                          Size used, in MiB, for the data and metadata of the file system.                      | [optional] 
**Health** | Pointer to [**Health**](Health.md) |  | [optional] 
**ReadOnly** | Pointer to **bool** |                          Indicates whether the file system is read-only. Values are:                         - true - File system is read-only.                         - false - File system is read-write.                      | [optional] 
**FsType** | Pointer to **string** |                          - 1: filesystem                         - 2: VMWare file system                        Enumeration values: * **General** * **VMWare**  | [optional] [default to "General"]
**MountState** | Pointer to **string** | mount_State   Enumeration values: * **Destination mode unmounted** * **Recovery required** * **Service unmounted** * **Not mapped (protocol snap)** * **Standby** * **Ready but unmounted (I/O Error)** * **Mounted** * **Replication Skip Mount** * **Unknown**  | [optional] 
**AccessPolicy** | Pointer to **string** |                          File system or protocol snap security access policies.                         - 0: Native Security.                         - 1: UNIX Security.                         - 2: Windows Security.                        Enumeration values: * **Native** * **UNIX** * **Windows**  | [optional] [default to "Native"]
**LockingPolicy** | Pointer to **string** |                          File system or protocol snap locking policies. These policy choices control whether the NFSv4 range locks must be honored. Because NFSv3 is advisory by design, this policy allows specifying whether the NFSv4 locking feature behaves like NFSv3 (advisory mode) in order to be backward compatible with applications expecting an advisory locking scheme.                         - 0: Advisory - No lock checking for NFS and honor SMB lock range only for SMB.                         - 1: Mandatory - Honor SMB and NFS lock range.                        Enumeration values: * **Advisory** * **Mandatory**  | [optional] [default to "Advisory"]
**FolderRenamePolicy** | Pointer to **string** |                          File system or protocol snap folder rename policies. These policy choices control whether directory can be renamed from NFS or SMB clients if at least one file is opened in the directory or in one of its child directories.                         - 0: SMB_Rename_Forbidden - A directory rename from the SMB protocol will be denied if at least one file is opened in the directory or in one of its child directories.                         - 1: All_Rename_Forbidden - Any directory rename request will be denied regardless of the protocol used, if at least one file is opened in the directory or in one of its child directories.                         - 2: All_Rename_Allowed - All protocols are allowed to rename directories without any restrictions.                        Enumeration values: * **SMB_Rename_Forbidden** * **All_Rename_Forbidden** * **All_Rename_Allowed**  | [optional] [default to "SMB_Rename_Forbidden"]
**HostIoblockSize** | Pointer to **int64** |                          File system data block size (in KiB).                      | [optional] 
**NasServer** | Pointer to **string** |                          Id of the NAS Server on which the file system is mounted                      | [optional] 
**SmbSyncWrites** | Pointer to **bool** |                          Indicates whether the synchronous writes option is enabled on the file system. Values are:                         - true - Synchronous writes option is enabled on the file system.                         - false - Synchronous writes option is disabled on the file system.                      | [optional] 
**SmbOpLocks** | Pointer to **bool** |                          Indicates whether opportunistic file locking is enabled on the file system. Values are:                         - true - Opportunistic file locking is enabled on the file system.                         - false - Opportunistic file locking is disabled on the file system.                      | [optional] 
**SmbNoNotify** | Pointer to **bool** |                          Indicates whether notifications of changes to directory file structure are enabled.                         - true - Notifications are enabled.                         - false - Notifications are disabled.                      | [optional] 
**SmbNotifyOnAccess** | Pointer to **bool** |                          Indicates whether notifications on file access are enabled on the file system. Values are:                         - true - Notifications on file access are enabled on the file system.                         - false - Notifications on file access are disabled on the file system.                      | [optional] 
**SmbNotifyOnWrite** | Pointer to **bool** |                          Indicates whether notifications on file writes are enabled on the file system. Values are:                         - true - Notifications on file writes are enabled on the file system.                         - false - Notifications on file writes are disabled on the file system.                      | [optional] 
**SmbNotifyOnChangeDirDepth** | Pointer to **int32** |                          Lowest directory level to which the enabled notifications apply, if any.                      | [optional] 
**AsyncMtime** | Pointer to **bool** |                          Indicates whether asynchronous MTIME is enabled on the file system. Values are:                         - true - asynchronous MTIME is enabled on the file system.                         - false - asynchronous MTIME is disabled on the file system.                      | [optional] 
**OpaqueMountOptions** | Pointer to **string** |                          Engineering only mount options                      | [optional] 
**FlrMode** | Pointer to **string** |                          The FLR type of the file system. This setting is significant only if flrEnabled is true.                        Enumeration values: * **None** * **Enterprise** * **Compliance**  | [optional] [default to "None"]
**FlrMinRet** | Pointer to **string** |                          The shortest retention period for which files on an FLR-enabled file system can be locked and protected from deletion. This value must be less than or equal to the maximum retention period. Any attempt to lock a file for less than the minimum retention period results in the file being locked until the current system time plus the minimum retention period is reached. The default value for the minimum retention period is 1 day.                         Format [Y|M|D] (example 5Y for 5 years), specify Y for years, M for months, D for days, or the keyword infinite. Setting infinite means that the files can never be deleted.  This setting is significant only if flrEnabled is true.                      | [optional] 
**FlrDefRet** | Pointer to **string** |                          The default retention period that is used in an FLR-enabled file system when a file is locked and a retention period is not specified. This value must be greater than or equal to the minimum retention period, and less than or equal to the maximum retention period.                         Format [Y|M|D] (example 5Y for 5 years).  Specify Y for years, M for months, D for days, or infinite. The default value for the default retention period is infinite, which means that the files can never be deleted.  This setting is significant only if flrEnabled is true.                      | [optional] 
**FlrMaxRet** | Pointer to **string** |                          The longest retention period for which files on an FLR-enabled file system can be locked and protected from deletion. Any attempt to lock a file for more than this maximum retention period results in the file being locked until the current system time plus the maximum retention period is reached. Specify Y for years, M for months, D for days, or infinite. The default value for the maximum retention period is infinite, which means that the files can never be deleted. This setting is significant only if flrEnabled is true.                      | [optional] 
**FlrAutoLock** | Pointer to **bool** |                          Indicates whether to automatically lock files in an FLR-enabled file system.  When true files are locked automatically after modification based on the flrPolicyInterval interval.  When enabled, auto-locked files are set with the default retention period value. Values:                         - true - automatic lock is enabled on the file system.                         - false - automatic lock is disabled on the file system.                         This setting is significant only if flrEnabled is true.                      | [optional] 
**FlrAutoDelete** | Pointer to **bool** |                          Indicates whether locked files will be automatically delete from an FLR-enabled file system once their retention periods have expired. Values:                         - true - automatic delete is enabled on the file system                         - false - automatic delete is disabled on the file system.                         This setting is significant only if flrEnabled is true.                      | [optional] 
**FlrPolicyInterval** | Pointer to **int32** |                          Indicates how long to wait (in seconds) after files are modified before the files are automatically locked. The default value is 3600 seconds (1 hour). This setting is significant only if flrEnabled is true.                      | [optional] 
**FlrEnabled** | Pointer to **bool** |                          Indicates whether File Level Retention feature is enabled on the Filesystem.                      | [optional] 
**FlrClockTime** | Pointer to **string** |                          Per file system clock used to track the retention date. It is initialized when an FLR-enabled file system is first mounted on a NAS Server. It does not advance when a file system is not mounted.  Format is RFC3339 and precision is in seconds (ie: YYYY-MM-DDTHH:MM:SS.000Z). This setting is significant only if flrEnabled is true.                      | [optional] 
**FlrMaxRetentionDate** | Pointer to **string** |                          Maximum date and time that has been set on any locked file in an FLR-enabled file system, which means that the file system itself will be protected until this date and time.  This value is compared to the FLR Clock Time to determine whether the date and time have passed.  Value is the string infinite if the maximum locked date is infinite, or a specific time in the RFC3339 format with precision in seconds (ie: YYYY-MM-DDTHH:MM:SS.000Z). This setting is significant only if flrEnabled is true.                      | [optional] 
**FlrHasProtectedFiles** | Pointer to **bool** |                          Indicates whether FLR file system has protected files.                      | [optional] 
**QuotaConfig** | Pointer to [**QuotaConfig**](QuotaConfig.md) |  | [optional] 
**SnapPolicyList** | Pointer to **[]string** |                          List of the IDs of all snap policies that this file system is attached to                      | [optional] 
**EventNotifications** | Pointer to **string** |                          State of the event notification services for file system or protocol snap.                         - 0 : off                         - 1 : smb only notifications                         - 2 : nfs only notifications                         - 3 : smb and nfs notifications                        Enumeration values: * **off** * **SMB** * **NFS** * **SMB_NFS**  | [optional] [default to "off"]
**InfoThreshold** | Pointer to **int32** |                          The info threshold will trigger info event if the file system used space exceeds this threshold. Default value is 0 (disabled).                      | [optional] 
**HighThreshold** | Pointer to **int32** |                          The high threshold will trigger info event if the file system used space exceeds this threshold. Default value is 75%. (set to 0 to disable)                      | [optional] 
**WarningThreshold** | Pointer to **int32** |                          The warning threshold will trigger alert event if the file system used space exceeds this threshold. Default value is 95%. (set to 0 to disable)                      | [optional] 
**ServiceLevel** | Pointer to **string** |                          Service Level Object                      | [optional] 
**DataReduction** | Pointer to **bool** |                          Platform attribute                         - true if data reduction enabled                         - false if data reduction disabled                      | [optional] [default to false]

## Methods

### NewFileSystem

`func NewFileSystem() *FileSystem`

NewFileSystem instantiates a new FileSystem object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewFileSystemWithDefaults

`func NewFileSystemWithDefaults() *FileSystem`

NewFileSystemWithDefaults instantiates a new FileSystem object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetId

`func (o *FileSystem) GetId() string`

GetId returns the Id field if non-nil, zero value otherwise.

### GetIdOk

`func (o *FileSystem) GetIdOk() (*string, bool)`

GetIdOk returns a tuple with the Id field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetId

`func (o *FileSystem) SetId(v string)`

SetId sets Id field to given value.

### HasId

`func (o *FileSystem) HasId() bool`

HasId returns a boolean if a field has been set.

### GetParentOid

`func (o *FileSystem) GetParentOid() string`

GetParentOid returns the ParentOid field if non-nil, zero value otherwise.

### GetParentOidOk

`func (o *FileSystem) GetParentOidOk() (*string, bool)`

GetParentOidOk returns a tuple with the ParentOid field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetParentOid

`func (o *FileSystem) SetParentOid(v string)`

SetParentOid sets ParentOid field to given value.

### HasParentOid

`func (o *FileSystem) HasParentOid() bool`

HasParentOid returns a boolean if a field has been set.

### GetName

`func (o *FileSystem) GetName() string`

GetName returns the Name field if non-nil, zero value otherwise.

### GetNameOk

`func (o *FileSystem) GetNameOk() (*string, bool)`

GetNameOk returns a tuple with the Name field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetName

`func (o *FileSystem) SetName(v string)`

SetName sets Name field to given value.

### HasName

`func (o *FileSystem) HasName() bool`

HasName returns a boolean if a field has been set.

### GetStorageWwn

`func (o *FileSystem) GetStorageWwn() string`

GetStorageWwn returns the StorageWwn field if non-nil, zero value otherwise.

### GetStorageWwnOk

`func (o *FileSystem) GetStorageWwnOk() (*string, bool)`

GetStorageWwnOk returns a tuple with the StorageWwn field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetStorageWwn

`func (o *FileSystem) SetStorageWwn(v string)`

SetStorageWwn sets StorageWwn field to given value.

### HasStorageWwn

`func (o *FileSystem) HasStorageWwn() bool`

HasStorageWwn returns a boolean if a field has been set.

### GetExportFsid

`func (o *FileSystem) GetExportFsid() string`

GetExportFsid returns the ExportFsid field if non-nil, zero value otherwise.

### GetExportFsidOk

`func (o *FileSystem) GetExportFsidOk() (*string, bool)`

GetExportFsidOk returns a tuple with the ExportFsid field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetExportFsid

`func (o *FileSystem) SetExportFsid(v string)`

SetExportFsid sets ExportFsid field to given value.

### HasExportFsid

`func (o *FileSystem) HasExportFsid() bool`

HasExportFsid returns a boolean if a field has been set.

### GetDescription

`func (o *FileSystem) GetDescription() string`

GetDescription returns the Description field if non-nil, zero value otherwise.

### GetDescriptionOk

`func (o *FileSystem) GetDescriptionOk() (*string, bool)`

GetDescriptionOk returns a tuple with the Description field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetDescription

`func (o *FileSystem) SetDescription(v string)`

SetDescription sets Description field to given value.

### HasDescription

`func (o *FileSystem) HasDescription() bool`

HasDescription returns a boolean if a field has been set.

### GetSizeTotal

`func (o *FileSystem) GetSizeTotal() int64`

GetSizeTotal returns the SizeTotal field if non-nil, zero value otherwise.

### GetSizeTotalOk

`func (o *FileSystem) GetSizeTotalOk() (*int64, bool)`

GetSizeTotalOk returns a tuple with the SizeTotal field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetSizeTotal

`func (o *FileSystem) SetSizeTotal(v int64)`

SetSizeTotal sets SizeTotal field to given value.

### HasSizeTotal

`func (o *FileSystem) HasSizeTotal() bool`

HasSizeTotal returns a boolean if a field has been set.

### GetSizeUsed

`func (o *FileSystem) GetSizeUsed() int64`

GetSizeUsed returns the SizeUsed field if non-nil, zero value otherwise.

### GetSizeUsedOk

`func (o *FileSystem) GetSizeUsedOk() (*int64, bool)`

GetSizeUsedOk returns a tuple with the SizeUsed field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetSizeUsed

`func (o *FileSystem) SetSizeUsed(v int64)`

SetSizeUsed sets SizeUsed field to given value.

### HasSizeUsed

`func (o *FileSystem) HasSizeUsed() bool`

HasSizeUsed returns a boolean if a field has been set.

### GetHealth

`func (o *FileSystem) GetHealth() Health`

GetHealth returns the Health field if non-nil, zero value otherwise.

### GetHealthOk

`func (o *FileSystem) GetHealthOk() (*Health, bool)`

GetHealthOk returns a tuple with the Health field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetHealth

`func (o *FileSystem) SetHealth(v Health)`

SetHealth sets Health field to given value.

### HasHealth

`func (o *FileSystem) HasHealth() bool`

HasHealth returns a boolean if a field has been set.

### GetReadOnly

`func (o *FileSystem) GetReadOnly() bool`

GetReadOnly returns the ReadOnly field if non-nil, zero value otherwise.

### GetReadOnlyOk

`func (o *FileSystem) GetReadOnlyOk() (*bool, bool)`

GetReadOnlyOk returns a tuple with the ReadOnly field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetReadOnly

`func (o *FileSystem) SetReadOnly(v bool)`

SetReadOnly sets ReadOnly field to given value.

### HasReadOnly

`func (o *FileSystem) HasReadOnly() bool`

HasReadOnly returns a boolean if a field has been set.

### GetFsType

`func (o *FileSystem) GetFsType() string`

GetFsType returns the FsType field if non-nil, zero value otherwise.

### GetFsTypeOk

`func (o *FileSystem) GetFsTypeOk() (*string, bool)`

GetFsTypeOk returns a tuple with the FsType field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetFsType

`func (o *FileSystem) SetFsType(v string)`

SetFsType sets FsType field to given value.

### HasFsType

`func (o *FileSystem) HasFsType() bool`

HasFsType returns a boolean if a field has been set.

### GetMountState

`func (o *FileSystem) GetMountState() string`

GetMountState returns the MountState field if non-nil, zero value otherwise.

### GetMountStateOk

`func (o *FileSystem) GetMountStateOk() (*string, bool)`

GetMountStateOk returns a tuple with the MountState field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetMountState

`func (o *FileSystem) SetMountState(v string)`

SetMountState sets MountState field to given value.

### HasMountState

`func (o *FileSystem) HasMountState() bool`

HasMountState returns a boolean if a field has been set.

### GetAccessPolicy

`func (o *FileSystem) GetAccessPolicy() string`

GetAccessPolicy returns the AccessPolicy field if non-nil, zero value otherwise.

### GetAccessPolicyOk

`func (o *FileSystem) GetAccessPolicyOk() (*string, bool)`

GetAccessPolicyOk returns a tuple with the AccessPolicy field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetAccessPolicy

`func (o *FileSystem) SetAccessPolicy(v string)`

SetAccessPolicy sets AccessPolicy field to given value.

### HasAccessPolicy

`func (o *FileSystem) HasAccessPolicy() bool`

HasAccessPolicy returns a boolean if a field has been set.

### GetLockingPolicy

`func (o *FileSystem) GetLockingPolicy() string`

GetLockingPolicy returns the LockingPolicy field if non-nil, zero value otherwise.

### GetLockingPolicyOk

`func (o *FileSystem) GetLockingPolicyOk() (*string, bool)`

GetLockingPolicyOk returns a tuple with the LockingPolicy field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetLockingPolicy

`func (o *FileSystem) SetLockingPolicy(v string)`

SetLockingPolicy sets LockingPolicy field to given value.

### HasLockingPolicy

`func (o *FileSystem) HasLockingPolicy() bool`

HasLockingPolicy returns a boolean if a field has been set.

### GetFolderRenamePolicy

`func (o *FileSystem) GetFolderRenamePolicy() string`

GetFolderRenamePolicy returns the FolderRenamePolicy field if non-nil, zero value otherwise.

### GetFolderRenamePolicyOk

`func (o *FileSystem) GetFolderRenamePolicyOk() (*string, bool)`

GetFolderRenamePolicyOk returns a tuple with the FolderRenamePolicy field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetFolderRenamePolicy

`func (o *FileSystem) SetFolderRenamePolicy(v string)`

SetFolderRenamePolicy sets FolderRenamePolicy field to given value.

### HasFolderRenamePolicy

`func (o *FileSystem) HasFolderRenamePolicy() bool`

HasFolderRenamePolicy returns a boolean if a field has been set.

### GetHostIoblockSize

`func (o *FileSystem) GetHostIoblockSize() int64`

GetHostIoblockSize returns the HostIoblockSize field if non-nil, zero value otherwise.

### GetHostIoblockSizeOk

`func (o *FileSystem) GetHostIoblockSizeOk() (*int64, bool)`

GetHostIoblockSizeOk returns a tuple with the HostIoblockSize field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetHostIoblockSize

`func (o *FileSystem) SetHostIoblockSize(v int64)`

SetHostIoblockSize sets HostIoblockSize field to given value.

### HasHostIoblockSize

`func (o *FileSystem) HasHostIoblockSize() bool`

HasHostIoblockSize returns a boolean if a field has been set.

### GetNasServer

`func (o *FileSystem) GetNasServer() string`

GetNasServer returns the NasServer field if non-nil, zero value otherwise.

### GetNasServerOk

`func (o *FileSystem) GetNasServerOk() (*string, bool)`

GetNasServerOk returns a tuple with the NasServer field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetNasServer

`func (o *FileSystem) SetNasServer(v string)`

SetNasServer sets NasServer field to given value.

### HasNasServer

`func (o *FileSystem) HasNasServer() bool`

HasNasServer returns a boolean if a field has been set.

### GetSmbSyncWrites

`func (o *FileSystem) GetSmbSyncWrites() bool`

GetSmbSyncWrites returns the SmbSyncWrites field if non-nil, zero value otherwise.

### GetSmbSyncWritesOk

`func (o *FileSystem) GetSmbSyncWritesOk() (*bool, bool)`

GetSmbSyncWritesOk returns a tuple with the SmbSyncWrites field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetSmbSyncWrites

`func (o *FileSystem) SetSmbSyncWrites(v bool)`

SetSmbSyncWrites sets SmbSyncWrites field to given value.

### HasSmbSyncWrites

`func (o *FileSystem) HasSmbSyncWrites() bool`

HasSmbSyncWrites returns a boolean if a field has been set.

### GetSmbOpLocks

`func (o *FileSystem) GetSmbOpLocks() bool`

GetSmbOpLocks returns the SmbOpLocks field if non-nil, zero value otherwise.

### GetSmbOpLocksOk

`func (o *FileSystem) GetSmbOpLocksOk() (*bool, bool)`

GetSmbOpLocksOk returns a tuple with the SmbOpLocks field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetSmbOpLocks

`func (o *FileSystem) SetSmbOpLocks(v bool)`

SetSmbOpLocks sets SmbOpLocks field to given value.

### HasSmbOpLocks

`func (o *FileSystem) HasSmbOpLocks() bool`

HasSmbOpLocks returns a boolean if a field has been set.

### GetSmbNoNotify

`func (o *FileSystem) GetSmbNoNotify() bool`

GetSmbNoNotify returns the SmbNoNotify field if non-nil, zero value otherwise.

### GetSmbNoNotifyOk

`func (o *FileSystem) GetSmbNoNotifyOk() (*bool, bool)`

GetSmbNoNotifyOk returns a tuple with the SmbNoNotify field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetSmbNoNotify

`func (o *FileSystem) SetSmbNoNotify(v bool)`

SetSmbNoNotify sets SmbNoNotify field to given value.

### HasSmbNoNotify

`func (o *FileSystem) HasSmbNoNotify() bool`

HasSmbNoNotify returns a boolean if a field has been set.

### GetSmbNotifyOnAccess

`func (o *FileSystem) GetSmbNotifyOnAccess() bool`

GetSmbNotifyOnAccess returns the SmbNotifyOnAccess field if non-nil, zero value otherwise.

### GetSmbNotifyOnAccessOk

`func (o *FileSystem) GetSmbNotifyOnAccessOk() (*bool, bool)`

GetSmbNotifyOnAccessOk returns a tuple with the SmbNotifyOnAccess field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetSmbNotifyOnAccess

`func (o *FileSystem) SetSmbNotifyOnAccess(v bool)`

SetSmbNotifyOnAccess sets SmbNotifyOnAccess field to given value.

### HasSmbNotifyOnAccess

`func (o *FileSystem) HasSmbNotifyOnAccess() bool`

HasSmbNotifyOnAccess returns a boolean if a field has been set.

### GetSmbNotifyOnWrite

`func (o *FileSystem) GetSmbNotifyOnWrite() bool`

GetSmbNotifyOnWrite returns the SmbNotifyOnWrite field if non-nil, zero value otherwise.

### GetSmbNotifyOnWriteOk

`func (o *FileSystem) GetSmbNotifyOnWriteOk() (*bool, bool)`

GetSmbNotifyOnWriteOk returns a tuple with the SmbNotifyOnWrite field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetSmbNotifyOnWrite

`func (o *FileSystem) SetSmbNotifyOnWrite(v bool)`

SetSmbNotifyOnWrite sets SmbNotifyOnWrite field to given value.

### HasSmbNotifyOnWrite

`func (o *FileSystem) HasSmbNotifyOnWrite() bool`

HasSmbNotifyOnWrite returns a boolean if a field has been set.

### GetSmbNotifyOnChangeDirDepth

`func (o *FileSystem) GetSmbNotifyOnChangeDirDepth() int32`

GetSmbNotifyOnChangeDirDepth returns the SmbNotifyOnChangeDirDepth field if non-nil, zero value otherwise.

### GetSmbNotifyOnChangeDirDepthOk

`func (o *FileSystem) GetSmbNotifyOnChangeDirDepthOk() (*int32, bool)`

GetSmbNotifyOnChangeDirDepthOk returns a tuple with the SmbNotifyOnChangeDirDepth field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetSmbNotifyOnChangeDirDepth

`func (o *FileSystem) SetSmbNotifyOnChangeDirDepth(v int32)`

SetSmbNotifyOnChangeDirDepth sets SmbNotifyOnChangeDirDepth field to given value.

### HasSmbNotifyOnChangeDirDepth

`func (o *FileSystem) HasSmbNotifyOnChangeDirDepth() bool`

HasSmbNotifyOnChangeDirDepth returns a boolean if a field has been set.

### GetAsyncMtime

`func (o *FileSystem) GetAsyncMtime() bool`

GetAsyncMtime returns the AsyncMtime field if non-nil, zero value otherwise.

### GetAsyncMtimeOk

`func (o *FileSystem) GetAsyncMtimeOk() (*bool, bool)`

GetAsyncMtimeOk returns a tuple with the AsyncMtime field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetAsyncMtime

`func (o *FileSystem) SetAsyncMtime(v bool)`

SetAsyncMtime sets AsyncMtime field to given value.

### HasAsyncMtime

`func (o *FileSystem) HasAsyncMtime() bool`

HasAsyncMtime returns a boolean if a field has been set.

### GetOpaqueMountOptions

`func (o *FileSystem) GetOpaqueMountOptions() string`

GetOpaqueMountOptions returns the OpaqueMountOptions field if non-nil, zero value otherwise.

### GetOpaqueMountOptionsOk

`func (o *FileSystem) GetOpaqueMountOptionsOk() (*string, bool)`

GetOpaqueMountOptionsOk returns a tuple with the OpaqueMountOptions field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetOpaqueMountOptions

`func (o *FileSystem) SetOpaqueMountOptions(v string)`

SetOpaqueMountOptions sets OpaqueMountOptions field to given value.

### HasOpaqueMountOptions

`func (o *FileSystem) HasOpaqueMountOptions() bool`

HasOpaqueMountOptions returns a boolean if a field has been set.

### GetFlrMode

`func (o *FileSystem) GetFlrMode() string`

GetFlrMode returns the FlrMode field if non-nil, zero value otherwise.

### GetFlrModeOk

`func (o *FileSystem) GetFlrModeOk() (*string, bool)`

GetFlrModeOk returns a tuple with the FlrMode field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetFlrMode

`func (o *FileSystem) SetFlrMode(v string)`

SetFlrMode sets FlrMode field to given value.

### HasFlrMode

`func (o *FileSystem) HasFlrMode() bool`

HasFlrMode returns a boolean if a field has been set.

### GetFlrMinRet

`func (o *FileSystem) GetFlrMinRet() string`

GetFlrMinRet returns the FlrMinRet field if non-nil, zero value otherwise.

### GetFlrMinRetOk

`func (o *FileSystem) GetFlrMinRetOk() (*string, bool)`

GetFlrMinRetOk returns a tuple with the FlrMinRet field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetFlrMinRet

`func (o *FileSystem) SetFlrMinRet(v string)`

SetFlrMinRet sets FlrMinRet field to given value.

### HasFlrMinRet

`func (o *FileSystem) HasFlrMinRet() bool`

HasFlrMinRet returns a boolean if a field has been set.

### GetFlrDefRet

`func (o *FileSystem) GetFlrDefRet() string`

GetFlrDefRet returns the FlrDefRet field if non-nil, zero value otherwise.

### GetFlrDefRetOk

`func (o *FileSystem) GetFlrDefRetOk() (*string, bool)`

GetFlrDefRetOk returns a tuple with the FlrDefRet field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetFlrDefRet

`func (o *FileSystem) SetFlrDefRet(v string)`

SetFlrDefRet sets FlrDefRet field to given value.

### HasFlrDefRet

`func (o *FileSystem) HasFlrDefRet() bool`

HasFlrDefRet returns a boolean if a field has been set.

### GetFlrMaxRet

`func (o *FileSystem) GetFlrMaxRet() string`

GetFlrMaxRet returns the FlrMaxRet field if non-nil, zero value otherwise.

### GetFlrMaxRetOk

`func (o *FileSystem) GetFlrMaxRetOk() (*string, bool)`

GetFlrMaxRetOk returns a tuple with the FlrMaxRet field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetFlrMaxRet

`func (o *FileSystem) SetFlrMaxRet(v string)`

SetFlrMaxRet sets FlrMaxRet field to given value.

### HasFlrMaxRet

`func (o *FileSystem) HasFlrMaxRet() bool`

HasFlrMaxRet returns a boolean if a field has been set.

### GetFlrAutoLock

`func (o *FileSystem) GetFlrAutoLock() bool`

GetFlrAutoLock returns the FlrAutoLock field if non-nil, zero value otherwise.

### GetFlrAutoLockOk

`func (o *FileSystem) GetFlrAutoLockOk() (*bool, bool)`

GetFlrAutoLockOk returns a tuple with the FlrAutoLock field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetFlrAutoLock

`func (o *FileSystem) SetFlrAutoLock(v bool)`

SetFlrAutoLock sets FlrAutoLock field to given value.

### HasFlrAutoLock

`func (o *FileSystem) HasFlrAutoLock() bool`

HasFlrAutoLock returns a boolean if a field has been set.

### GetFlrAutoDelete

`func (o *FileSystem) GetFlrAutoDelete() bool`

GetFlrAutoDelete returns the FlrAutoDelete field if non-nil, zero value otherwise.

### GetFlrAutoDeleteOk

`func (o *FileSystem) GetFlrAutoDeleteOk() (*bool, bool)`

GetFlrAutoDeleteOk returns a tuple with the FlrAutoDelete field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetFlrAutoDelete

`func (o *FileSystem) SetFlrAutoDelete(v bool)`

SetFlrAutoDelete sets FlrAutoDelete field to given value.

### HasFlrAutoDelete

`func (o *FileSystem) HasFlrAutoDelete() bool`

HasFlrAutoDelete returns a boolean if a field has been set.

### GetFlrPolicyInterval

`func (o *FileSystem) GetFlrPolicyInterval() int32`

GetFlrPolicyInterval returns the FlrPolicyInterval field if non-nil, zero value otherwise.

### GetFlrPolicyIntervalOk

`func (o *FileSystem) GetFlrPolicyIntervalOk() (*int32, bool)`

GetFlrPolicyIntervalOk returns a tuple with the FlrPolicyInterval field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetFlrPolicyInterval

`func (o *FileSystem) SetFlrPolicyInterval(v int32)`

SetFlrPolicyInterval sets FlrPolicyInterval field to given value.

### HasFlrPolicyInterval

`func (o *FileSystem) HasFlrPolicyInterval() bool`

HasFlrPolicyInterval returns a boolean if a field has been set.

### GetFlrEnabled

`func (o *FileSystem) GetFlrEnabled() bool`

GetFlrEnabled returns the FlrEnabled field if non-nil, zero value otherwise.

### GetFlrEnabledOk

`func (o *FileSystem) GetFlrEnabledOk() (*bool, bool)`

GetFlrEnabledOk returns a tuple with the FlrEnabled field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetFlrEnabled

`func (o *FileSystem) SetFlrEnabled(v bool)`

SetFlrEnabled sets FlrEnabled field to given value.

### HasFlrEnabled

`func (o *FileSystem) HasFlrEnabled() bool`

HasFlrEnabled returns a boolean if a field has been set.

### GetFlrClockTime

`func (o *FileSystem) GetFlrClockTime() string`

GetFlrClockTime returns the FlrClockTime field if non-nil, zero value otherwise.

### GetFlrClockTimeOk

`func (o *FileSystem) GetFlrClockTimeOk() (*string, bool)`

GetFlrClockTimeOk returns a tuple with the FlrClockTime field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetFlrClockTime

`func (o *FileSystem) SetFlrClockTime(v string)`

SetFlrClockTime sets FlrClockTime field to given value.

### HasFlrClockTime

`func (o *FileSystem) HasFlrClockTime() bool`

HasFlrClockTime returns a boolean if a field has been set.

### GetFlrMaxRetentionDate

`func (o *FileSystem) GetFlrMaxRetentionDate() string`

GetFlrMaxRetentionDate returns the FlrMaxRetentionDate field if non-nil, zero value otherwise.

### GetFlrMaxRetentionDateOk

`func (o *FileSystem) GetFlrMaxRetentionDateOk() (*string, bool)`

GetFlrMaxRetentionDateOk returns a tuple with the FlrMaxRetentionDate field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetFlrMaxRetentionDate

`func (o *FileSystem) SetFlrMaxRetentionDate(v string)`

SetFlrMaxRetentionDate sets FlrMaxRetentionDate field to given value.

### HasFlrMaxRetentionDate

`func (o *FileSystem) HasFlrMaxRetentionDate() bool`

HasFlrMaxRetentionDate returns a boolean if a field has been set.

### GetFlrHasProtectedFiles

`func (o *FileSystem) GetFlrHasProtectedFiles() bool`

GetFlrHasProtectedFiles returns the FlrHasProtectedFiles field if non-nil, zero value otherwise.

### GetFlrHasProtectedFilesOk

`func (o *FileSystem) GetFlrHasProtectedFilesOk() (*bool, bool)`

GetFlrHasProtectedFilesOk returns a tuple with the FlrHasProtectedFiles field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetFlrHasProtectedFiles

`func (o *FileSystem) SetFlrHasProtectedFiles(v bool)`

SetFlrHasProtectedFiles sets FlrHasProtectedFiles field to given value.

### HasFlrHasProtectedFiles

`func (o *FileSystem) HasFlrHasProtectedFiles() bool`

HasFlrHasProtectedFiles returns a boolean if a field has been set.

### GetQuotaConfig

`func (o *FileSystem) GetQuotaConfig() QuotaConfig`

GetQuotaConfig returns the QuotaConfig field if non-nil, zero value otherwise.

### GetQuotaConfigOk

`func (o *FileSystem) GetQuotaConfigOk() (*QuotaConfig, bool)`

GetQuotaConfigOk returns a tuple with the QuotaConfig field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetQuotaConfig

`func (o *FileSystem) SetQuotaConfig(v QuotaConfig)`

SetQuotaConfig sets QuotaConfig field to given value.

### HasQuotaConfig

`func (o *FileSystem) HasQuotaConfig() bool`

HasQuotaConfig returns a boolean if a field has been set.

### GetSnapPolicyList

`func (o *FileSystem) GetSnapPolicyList() []string`

GetSnapPolicyList returns the SnapPolicyList field if non-nil, zero value otherwise.

### GetSnapPolicyListOk

`func (o *FileSystem) GetSnapPolicyListOk() (*[]string, bool)`

GetSnapPolicyListOk returns a tuple with the SnapPolicyList field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetSnapPolicyList

`func (o *FileSystem) SetSnapPolicyList(v []string)`

SetSnapPolicyList sets SnapPolicyList field to given value.

### HasSnapPolicyList

`func (o *FileSystem) HasSnapPolicyList() bool`

HasSnapPolicyList returns a boolean if a field has been set.

### GetEventNotifications

`func (o *FileSystem) GetEventNotifications() string`

GetEventNotifications returns the EventNotifications field if non-nil, zero value otherwise.

### GetEventNotificationsOk

`func (o *FileSystem) GetEventNotificationsOk() (*string, bool)`

GetEventNotificationsOk returns a tuple with the EventNotifications field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetEventNotifications

`func (o *FileSystem) SetEventNotifications(v string)`

SetEventNotifications sets EventNotifications field to given value.

### HasEventNotifications

`func (o *FileSystem) HasEventNotifications() bool`

HasEventNotifications returns a boolean if a field has been set.

### GetInfoThreshold

`func (o *FileSystem) GetInfoThreshold() int32`

GetInfoThreshold returns the InfoThreshold field if non-nil, zero value otherwise.

### GetInfoThresholdOk

`func (o *FileSystem) GetInfoThresholdOk() (*int32, bool)`

GetInfoThresholdOk returns a tuple with the InfoThreshold field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetInfoThreshold

`func (o *FileSystem) SetInfoThreshold(v int32)`

SetInfoThreshold sets InfoThreshold field to given value.

### HasInfoThreshold

`func (o *FileSystem) HasInfoThreshold() bool`

HasInfoThreshold returns a boolean if a field has been set.

### GetHighThreshold

`func (o *FileSystem) GetHighThreshold() int32`

GetHighThreshold returns the HighThreshold field if non-nil, zero value otherwise.

### GetHighThresholdOk

`func (o *FileSystem) GetHighThresholdOk() (*int32, bool)`

GetHighThresholdOk returns a tuple with the HighThreshold field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetHighThreshold

`func (o *FileSystem) SetHighThreshold(v int32)`

SetHighThreshold sets HighThreshold field to given value.

### HasHighThreshold

`func (o *FileSystem) HasHighThreshold() bool`

HasHighThreshold returns a boolean if a field has been set.

### GetWarningThreshold

`func (o *FileSystem) GetWarningThreshold() int32`

GetWarningThreshold returns the WarningThreshold field if non-nil, zero value otherwise.

### GetWarningThresholdOk

`func (o *FileSystem) GetWarningThresholdOk() (*int32, bool)`

GetWarningThresholdOk returns a tuple with the WarningThreshold field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetWarningThreshold

`func (o *FileSystem) SetWarningThreshold(v int32)`

SetWarningThreshold sets WarningThreshold field to given value.

### HasWarningThreshold

`func (o *FileSystem) HasWarningThreshold() bool`

HasWarningThreshold returns a boolean if a field has been set.

### GetServiceLevel

`func (o *FileSystem) GetServiceLevel() string`

GetServiceLevel returns the ServiceLevel field if non-nil, zero value otherwise.

### GetServiceLevelOk

`func (o *FileSystem) GetServiceLevelOk() (*string, bool)`

GetServiceLevelOk returns a tuple with the ServiceLevel field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetServiceLevel

`func (o *FileSystem) SetServiceLevel(v string)`

SetServiceLevel sets ServiceLevel field to given value.

### HasServiceLevel

`func (o *FileSystem) HasServiceLevel() bool`

HasServiceLevel returns a boolean if a field has been set.

### GetDataReduction

`func (o *FileSystem) GetDataReduction() bool`

GetDataReduction returns the DataReduction field if non-nil, zero value otherwise.

### GetDataReductionOk

`func (o *FileSystem) GetDataReductionOk() (*bool, bool)`

GetDataReductionOk returns a tuple with the DataReduction field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetDataReduction

`func (o *FileSystem) SetDataReduction(v bool)`

SetDataReduction sets DataReduction field to given value.

### HasDataReduction

`func (o *FileSystem) HasDataReduction() bool`

HasDataReduction returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


