# EndpointParam

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**StartDate** | **int64** | startDate | 
**EndDate** | **int64** | endDate | 
**SystemId** | **string** | systemId | 
**EndpointId** | **string** | endpointId | 
**DataFormat** | Pointer to **string** | dataFormat   Enumeration values: * **Average** * **Maximum**  | [optional] 
**Metrics** | **[]string** | metrics   Enumeration values: * **MBs** -                          MBs/sec                      * **PacketCount** -                          Packets/sec                      * **Reads** -                          The number of read operations performed each second.                      * **Writes** -                          The number of write operations performed each second.                      * **IoRate** -                          The number of host operations performed each second.                      * **TotalReadTime** -                          Total time spent performing reads.                      * **TotalWriteTime** -                          Total time spent performing writess.                      * **ResponseTime** -                          The average response time for the reads and writes.                      * **DuplicateAcksReceivedPerSec** -                          Duplicate Acks Received/sec                      * **TCPRetransmitsPerSec** -                          TCP Retransmits/sec                       | 

## Methods

### NewEndpointParam

`func NewEndpointParam(startDate int64, endDate int64, systemId string, endpointId string, metrics []string, ) *EndpointParam`

NewEndpointParam instantiates a new EndpointParam object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewEndpointParamWithDefaults

`func NewEndpointParamWithDefaults() *EndpointParam`

NewEndpointParamWithDefaults instantiates a new EndpointParam object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetStartDate

`func (o *EndpointParam) GetStartDate() int64`

GetStartDate returns the StartDate field if non-nil, zero value otherwise.

### GetStartDateOk

`func (o *EndpointParam) GetStartDateOk() (*int64, bool)`

GetStartDateOk returns a tuple with the StartDate field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetStartDate

`func (o *EndpointParam) SetStartDate(v int64)`

SetStartDate sets StartDate field to given value.


### GetEndDate

`func (o *EndpointParam) GetEndDate() int64`

GetEndDate returns the EndDate field if non-nil, zero value otherwise.

### GetEndDateOk

`func (o *EndpointParam) GetEndDateOk() (*int64, bool)`

GetEndDateOk returns a tuple with the EndDate field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetEndDate

`func (o *EndpointParam) SetEndDate(v int64)`

SetEndDate sets EndDate field to given value.


### GetSystemId

`func (o *EndpointParam) GetSystemId() string`

GetSystemId returns the SystemId field if non-nil, zero value otherwise.

### GetSystemIdOk

`func (o *EndpointParam) GetSystemIdOk() (*string, bool)`

GetSystemIdOk returns a tuple with the SystemId field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetSystemId

`func (o *EndpointParam) SetSystemId(v string)`

SetSystemId sets SystemId field to given value.


### GetEndpointId

`func (o *EndpointParam) GetEndpointId() string`

GetEndpointId returns the EndpointId field if non-nil, zero value otherwise.

### GetEndpointIdOk

`func (o *EndpointParam) GetEndpointIdOk() (*string, bool)`

GetEndpointIdOk returns a tuple with the EndpointId field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetEndpointId

`func (o *EndpointParam) SetEndpointId(v string)`

SetEndpointId sets EndpointId field to given value.


### GetDataFormat

`func (o *EndpointParam) GetDataFormat() string`

GetDataFormat returns the DataFormat field if non-nil, zero value otherwise.

### GetDataFormatOk

`func (o *EndpointParam) GetDataFormatOk() (*string, bool)`

GetDataFormatOk returns a tuple with the DataFormat field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetDataFormat

`func (o *EndpointParam) SetDataFormat(v string)`

SetDataFormat sets DataFormat field to given value.

### HasDataFormat

`func (o *EndpointParam) HasDataFormat() bool`

HasDataFormat returns a boolean if a field has been set.

### GetMetrics

`func (o *EndpointParam) GetMetrics() []string`

GetMetrics returns the Metrics field if non-nil, zero value otherwise.

### GetMetricsOk

`func (o *EndpointParam) GetMetricsOk() (*[]string, bool)`

GetMetricsOk returns a tuple with the Metrics field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetMetrics

`func (o *EndpointParam) SetMetrics(v []string)`

SetMetrics sets Metrics field to given value.



[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


