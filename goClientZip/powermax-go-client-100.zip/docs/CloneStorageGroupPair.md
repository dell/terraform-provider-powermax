# CloneStorageGroupPair

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**StorageGroup** | Pointer to **string** | storage_group | [optional] 
**StorageGroupVolumeCount** | Pointer to **int64** | storage_group_volume_count | [optional] 
**TargetStorageGroup** | Pointer to **string** | target_storage_group | [optional] 
**TargetStorageGroupVolumeCount** | Pointer to **int64** | target_storage_group_volume_count | [optional] 
**VolumePairCount** | Pointer to **int64** | volume_pair_count | [optional] 
**State** | Pointer to **[]string** | state | [optional] 
**ModifiedTracks** | Pointer to **int64** | modified_tracks | [optional] 
**SrcProtectedTracks** | Pointer to **int64** | src_protected_tracks | [optional] 
**SrcModifiedTracks** | Pointer to **int64** | src_modified_tracks | [optional] 
**BackgroundCopy** | Pointer to **bool** | background_copy | [optional] 
**Differential** | Pointer to **bool** | differential | [optional] 
**Precopy** | Pointer to **bool** | precopy | [optional] 
**Vse** | Pointer to **bool** | vse | [optional] 

## Methods

### NewCloneStorageGroupPair

`func NewCloneStorageGroupPair() *CloneStorageGroupPair`

NewCloneStorageGroupPair instantiates a new CloneStorageGroupPair object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewCloneStorageGroupPairWithDefaults

`func NewCloneStorageGroupPairWithDefaults() *CloneStorageGroupPair`

NewCloneStorageGroupPairWithDefaults instantiates a new CloneStorageGroupPair object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetStorageGroup

`func (o *CloneStorageGroupPair) GetStorageGroup() string`

GetStorageGroup returns the StorageGroup field if non-nil, zero value otherwise.

### GetStorageGroupOk

`func (o *CloneStorageGroupPair) GetStorageGroupOk() (*string, bool)`

GetStorageGroupOk returns a tuple with the StorageGroup field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetStorageGroup

`func (o *CloneStorageGroupPair) SetStorageGroup(v string)`

SetStorageGroup sets StorageGroup field to given value.

### HasStorageGroup

`func (o *CloneStorageGroupPair) HasStorageGroup() bool`

HasStorageGroup returns a boolean if a field has been set.

### GetStorageGroupVolumeCount

`func (o *CloneStorageGroupPair) GetStorageGroupVolumeCount() int64`

GetStorageGroupVolumeCount returns the StorageGroupVolumeCount field if non-nil, zero value otherwise.

### GetStorageGroupVolumeCountOk

`func (o *CloneStorageGroupPair) GetStorageGroupVolumeCountOk() (*int64, bool)`

GetStorageGroupVolumeCountOk returns a tuple with the StorageGroupVolumeCount field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetStorageGroupVolumeCount

`func (o *CloneStorageGroupPair) SetStorageGroupVolumeCount(v int64)`

SetStorageGroupVolumeCount sets StorageGroupVolumeCount field to given value.

### HasStorageGroupVolumeCount

`func (o *CloneStorageGroupPair) HasStorageGroupVolumeCount() bool`

HasStorageGroupVolumeCount returns a boolean if a field has been set.

### GetTargetStorageGroup

`func (o *CloneStorageGroupPair) GetTargetStorageGroup() string`

GetTargetStorageGroup returns the TargetStorageGroup field if non-nil, zero value otherwise.

### GetTargetStorageGroupOk

`func (o *CloneStorageGroupPair) GetTargetStorageGroupOk() (*string, bool)`

GetTargetStorageGroupOk returns a tuple with the TargetStorageGroup field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetTargetStorageGroup

`func (o *CloneStorageGroupPair) SetTargetStorageGroup(v string)`

SetTargetStorageGroup sets TargetStorageGroup field to given value.

### HasTargetStorageGroup

`func (o *CloneStorageGroupPair) HasTargetStorageGroup() bool`

HasTargetStorageGroup returns a boolean if a field has been set.

### GetTargetStorageGroupVolumeCount

`func (o *CloneStorageGroupPair) GetTargetStorageGroupVolumeCount() int64`

GetTargetStorageGroupVolumeCount returns the TargetStorageGroupVolumeCount field if non-nil, zero value otherwise.

### GetTargetStorageGroupVolumeCountOk

`func (o *CloneStorageGroupPair) GetTargetStorageGroupVolumeCountOk() (*int64, bool)`

GetTargetStorageGroupVolumeCountOk returns a tuple with the TargetStorageGroupVolumeCount field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetTargetStorageGroupVolumeCount

`func (o *CloneStorageGroupPair) SetTargetStorageGroupVolumeCount(v int64)`

SetTargetStorageGroupVolumeCount sets TargetStorageGroupVolumeCount field to given value.

### HasTargetStorageGroupVolumeCount

`func (o *CloneStorageGroupPair) HasTargetStorageGroupVolumeCount() bool`

HasTargetStorageGroupVolumeCount returns a boolean if a field has been set.

### GetVolumePairCount

`func (o *CloneStorageGroupPair) GetVolumePairCount() int64`

GetVolumePairCount returns the VolumePairCount field if non-nil, zero value otherwise.

### GetVolumePairCountOk

`func (o *CloneStorageGroupPair) GetVolumePairCountOk() (*int64, bool)`

GetVolumePairCountOk returns a tuple with the VolumePairCount field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetVolumePairCount

`func (o *CloneStorageGroupPair) SetVolumePairCount(v int64)`

SetVolumePairCount sets VolumePairCount field to given value.

### HasVolumePairCount

`func (o *CloneStorageGroupPair) HasVolumePairCount() bool`

HasVolumePairCount returns a boolean if a field has been set.

### GetState

`func (o *CloneStorageGroupPair) GetState() []string`

GetState returns the State field if non-nil, zero value otherwise.

### GetStateOk

`func (o *CloneStorageGroupPair) GetStateOk() (*[]string, bool)`

GetStateOk returns a tuple with the State field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetState

`func (o *CloneStorageGroupPair) SetState(v []string)`

SetState sets State field to given value.

### HasState

`func (o *CloneStorageGroupPair) HasState() bool`

HasState returns a boolean if a field has been set.

### GetModifiedTracks

`func (o *CloneStorageGroupPair) GetModifiedTracks() int64`

GetModifiedTracks returns the ModifiedTracks field if non-nil, zero value otherwise.

### GetModifiedTracksOk

`func (o *CloneStorageGroupPair) GetModifiedTracksOk() (*int64, bool)`

GetModifiedTracksOk returns a tuple with the ModifiedTracks field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetModifiedTracks

`func (o *CloneStorageGroupPair) SetModifiedTracks(v int64)`

SetModifiedTracks sets ModifiedTracks field to given value.

### HasModifiedTracks

`func (o *CloneStorageGroupPair) HasModifiedTracks() bool`

HasModifiedTracks returns a boolean if a field has been set.

### GetSrcProtectedTracks

`func (o *CloneStorageGroupPair) GetSrcProtectedTracks() int64`

GetSrcProtectedTracks returns the SrcProtectedTracks field if non-nil, zero value otherwise.

### GetSrcProtectedTracksOk

`func (o *CloneStorageGroupPair) GetSrcProtectedTracksOk() (*int64, bool)`

GetSrcProtectedTracksOk returns a tuple with the SrcProtectedTracks field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetSrcProtectedTracks

`func (o *CloneStorageGroupPair) SetSrcProtectedTracks(v int64)`

SetSrcProtectedTracks sets SrcProtectedTracks field to given value.

### HasSrcProtectedTracks

`func (o *CloneStorageGroupPair) HasSrcProtectedTracks() bool`

HasSrcProtectedTracks returns a boolean if a field has been set.

### GetSrcModifiedTracks

`func (o *CloneStorageGroupPair) GetSrcModifiedTracks() int64`

GetSrcModifiedTracks returns the SrcModifiedTracks field if non-nil, zero value otherwise.

### GetSrcModifiedTracksOk

`func (o *CloneStorageGroupPair) GetSrcModifiedTracksOk() (*int64, bool)`

GetSrcModifiedTracksOk returns a tuple with the SrcModifiedTracks field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetSrcModifiedTracks

`func (o *CloneStorageGroupPair) SetSrcModifiedTracks(v int64)`

SetSrcModifiedTracks sets SrcModifiedTracks field to given value.

### HasSrcModifiedTracks

`func (o *CloneStorageGroupPair) HasSrcModifiedTracks() bool`

HasSrcModifiedTracks returns a boolean if a field has been set.

### GetBackgroundCopy

`func (o *CloneStorageGroupPair) GetBackgroundCopy() bool`

GetBackgroundCopy returns the BackgroundCopy field if non-nil, zero value otherwise.

### GetBackgroundCopyOk

`func (o *CloneStorageGroupPair) GetBackgroundCopyOk() (*bool, bool)`

GetBackgroundCopyOk returns a tuple with the BackgroundCopy field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetBackgroundCopy

`func (o *CloneStorageGroupPair) SetBackgroundCopy(v bool)`

SetBackgroundCopy sets BackgroundCopy field to given value.

### HasBackgroundCopy

`func (o *CloneStorageGroupPair) HasBackgroundCopy() bool`

HasBackgroundCopy returns a boolean if a field has been set.

### GetDifferential

`func (o *CloneStorageGroupPair) GetDifferential() bool`

GetDifferential returns the Differential field if non-nil, zero value otherwise.

### GetDifferentialOk

`func (o *CloneStorageGroupPair) GetDifferentialOk() (*bool, bool)`

GetDifferentialOk returns a tuple with the Differential field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetDifferential

`func (o *CloneStorageGroupPair) SetDifferential(v bool)`

SetDifferential sets Differential field to given value.

### HasDifferential

`func (o *CloneStorageGroupPair) HasDifferential() bool`

HasDifferential returns a boolean if a field has been set.

### GetPrecopy

`func (o *CloneStorageGroupPair) GetPrecopy() bool`

GetPrecopy returns the Precopy field if non-nil, zero value otherwise.

### GetPrecopyOk

`func (o *CloneStorageGroupPair) GetPrecopyOk() (*bool, bool)`

GetPrecopyOk returns a tuple with the Precopy field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetPrecopy

`func (o *CloneStorageGroupPair) SetPrecopy(v bool)`

SetPrecopy sets Precopy field to given value.

### HasPrecopy

`func (o *CloneStorageGroupPair) HasPrecopy() bool`

HasPrecopy returns a boolean if a field has been set.

### GetVse

`func (o *CloneStorageGroupPair) GetVse() bool`

GetVse returns the Vse field if non-nil, zero value otherwise.

### GetVseOk

`func (o *CloneStorageGroupPair) GetVseOk() (*bool, bool)`

GetVseOk returns a tuple with the Vse field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetVse

`func (o *CloneStorageGroupPair) SetVse(v bool)`

SetVse sets Vse field to given value.

### HasVse

`func (o *CloneStorageGroupPair) HasVse() bool`

HasVse returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


