# Metrics200ResponseHeaders

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Empty** | Pointer to **bool** |  | [optional] 

## Methods

### NewMetrics200ResponseHeaders

`func NewMetrics200ResponseHeaders() *Metrics200ResponseHeaders`

NewMetrics200ResponseHeaders instantiates a new Metrics200ResponseHeaders object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewMetrics200ResponseHeadersWithDefaults

`func NewMetrics200ResponseHeadersWithDefaults() *Metrics200ResponseHeaders`

NewMetrics200ResponseHeadersWithDefaults instantiates a new Metrics200ResponseHeaders object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetEmpty

`func (o *Metrics200ResponseHeaders) GetEmpty() bool`

GetEmpty returns the Empty field if non-nil, zero value otherwise.

### GetEmptyOk

`func (o *Metrics200ResponseHeaders) GetEmptyOk() (*bool, bool)`

GetEmptyOk returns a tuple with the Empty field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetEmpty

`func (o *Metrics200ResponseHeaders) SetEmpty(v bool)`

SetEmpty sets Empty field to given value.

### HasEmpty

`func (o *Metrics200ResponseHeaders) HasEmpty() bool`

HasEmpty returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


