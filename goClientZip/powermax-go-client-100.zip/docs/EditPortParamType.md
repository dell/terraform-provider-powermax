# EditPortParamType

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ExecutionOption** | Pointer to **string** |  | [optional] [default to "SYNCHRONOUS"]
**EditPortActionParamType** | [**EditPortActionParamType**](EditPortActionParamType.md) |  | 

## Methods

### NewEditPortParamType

`func NewEditPortParamType(editPortActionParamType EditPortActionParamType, ) *EditPortParamType`

NewEditPortParamType instantiates a new EditPortParamType object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewEditPortParamTypeWithDefaults

`func NewEditPortParamTypeWithDefaults() *EditPortParamType`

NewEditPortParamTypeWithDefaults instantiates a new EditPortParamType object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetExecutionOption

`func (o *EditPortParamType) GetExecutionOption() string`

GetExecutionOption returns the ExecutionOption field if non-nil, zero value otherwise.

### GetExecutionOptionOk

`func (o *EditPortParamType) GetExecutionOptionOk() (*string, bool)`

GetExecutionOptionOk returns a tuple with the ExecutionOption field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetExecutionOption

`func (o *EditPortParamType) SetExecutionOption(v string)`

SetExecutionOption sets ExecutionOption field to given value.

### HasExecutionOption

`func (o *EditPortParamType) HasExecutionOption() bool`

HasExecutionOption returns a boolean if a field has been set.

### GetEditPortActionParamType

`func (o *EditPortParamType) GetEditPortActionParamType() EditPortActionParamType`

GetEditPortActionParamType returns the EditPortActionParamType field if non-nil, zero value otherwise.

### GetEditPortActionParamTypeOk

`func (o *EditPortParamType) GetEditPortActionParamTypeOk() (*EditPortActionParamType, bool)`

GetEditPortActionParamTypeOk returns a tuple with the EditPortActionParamType field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetEditPortActionParamType

`func (o *EditPortParamType) SetEditPortActionParamType(v EditPortActionParamType)`

SetEditPortActionParamType sets EditPortActionParamType field to given value.



[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


