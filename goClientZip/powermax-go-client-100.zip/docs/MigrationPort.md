# MigrationPort

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Name** | **string** | The director and port name of the port | 
**Invalid** | **bool** | Flag to indicate if the entity is invalid | 

## Methods

### NewMigrationPort

`func NewMigrationPort(name string, invalid bool, ) *MigrationPort`

NewMigrationPort instantiates a new MigrationPort object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewMigrationPortWithDefaults

`func NewMigrationPortWithDefaults() *MigrationPort`

NewMigrationPortWithDefaults instantiates a new MigrationPort object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetName

`func (o *MigrationPort) GetName() string`

GetName returns the Name field if non-nil, zero value otherwise.

### GetNameOk

`func (o *MigrationPort) GetNameOk() (*string, bool)`

GetNameOk returns a tuple with the Name field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetName

`func (o *MigrationPort) SetName(v string)`

SetName sets Name field to given value.


### GetInvalid

`func (o *MigrationPort) GetInvalid() bool`

GetInvalid returns the Invalid field if non-nil, zero value otherwise.

### GetInvalidOk

`func (o *MigrationPort) GetInvalidOk() (*bool, bool)`

GetInvalidOk returns a tuple with the Invalid field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetInvalid

`func (o *MigrationPort) SetInvalid(v bool)`

SetInvalid sets Invalid field to given value.



[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


