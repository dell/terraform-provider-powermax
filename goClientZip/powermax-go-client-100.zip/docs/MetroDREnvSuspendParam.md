# MetroDREnvSuspendParam

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Metro** | Pointer to **bool** | Indicates that the command is targeted at the SRDF/Metro session. | [optional] 
**Dr** | Pointer to **bool** | Indicates that the command is targeted at the DR session. | [optional] 
**KeepR2** | Pointer to **bool** | Sets the winner side of the SRDF/Metro group to the R1 or the R2 side, as specified.                                  When the SRDF link becomes Not Ready (NR), volumes on the winner side will be made accessible to the host and volumes on                                 the                                 loser (non-winner) side will be made inaccessible to the host. | [optional] 
**Force** | Pointer to **bool** | Attempts to force the operation even though one or more volumes may not be in the normal, expected state(s) for the                                 specified                                 operation. | [optional] 
**Symforce** | Pointer to **bool** | Requests the System force operation be executed when normally it is rejected. Use extreme caution when using                                 this                                 option.                                  CAUTION: Use care when applying symforce, as data could be lost or corrupted. Use of this option is not recommended,                                 except in                                 an emergency.                                  NOTE: To enable symforce, a parameter called SYMAPI_ALLOW_RDF_SYMFORCE in the options file must be set to TRUE and                                 restart the                                 Unisphere server to pick up the change.                                  When used with symforce, a split command executes on an SRDF pair, even when the pair is sync in progress or restore in                                 progress.                                 During the execution of an establish or restore command, -symforce prohibits the verification of valid tracks on the                                 device at                                 the source. | [optional] 

## Methods

### NewMetroDREnvSuspendParam

`func NewMetroDREnvSuspendParam() *MetroDREnvSuspendParam`

NewMetroDREnvSuspendParam instantiates a new MetroDREnvSuspendParam object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewMetroDREnvSuspendParamWithDefaults

`func NewMetroDREnvSuspendParamWithDefaults() *MetroDREnvSuspendParam`

NewMetroDREnvSuspendParamWithDefaults instantiates a new MetroDREnvSuspendParam object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetMetro

`func (o *MetroDREnvSuspendParam) GetMetro() bool`

GetMetro returns the Metro field if non-nil, zero value otherwise.

### GetMetroOk

`func (o *MetroDREnvSuspendParam) GetMetroOk() (*bool, bool)`

GetMetroOk returns a tuple with the Metro field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetMetro

`func (o *MetroDREnvSuspendParam) SetMetro(v bool)`

SetMetro sets Metro field to given value.

### HasMetro

`func (o *MetroDREnvSuspendParam) HasMetro() bool`

HasMetro returns a boolean if a field has been set.

### GetDr

`func (o *MetroDREnvSuspendParam) GetDr() bool`

GetDr returns the Dr field if non-nil, zero value otherwise.

### GetDrOk

`func (o *MetroDREnvSuspendParam) GetDrOk() (*bool, bool)`

GetDrOk returns a tuple with the Dr field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetDr

`func (o *MetroDREnvSuspendParam) SetDr(v bool)`

SetDr sets Dr field to given value.

### HasDr

`func (o *MetroDREnvSuspendParam) HasDr() bool`

HasDr returns a boolean if a field has been set.

### GetKeepR2

`func (o *MetroDREnvSuspendParam) GetKeepR2() bool`

GetKeepR2 returns the KeepR2 field if non-nil, zero value otherwise.

### GetKeepR2Ok

`func (o *MetroDREnvSuspendParam) GetKeepR2Ok() (*bool, bool)`

GetKeepR2Ok returns a tuple with the KeepR2 field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetKeepR2

`func (o *MetroDREnvSuspendParam) SetKeepR2(v bool)`

SetKeepR2 sets KeepR2 field to given value.

### HasKeepR2

`func (o *MetroDREnvSuspendParam) HasKeepR2() bool`

HasKeepR2 returns a boolean if a field has been set.

### GetForce

`func (o *MetroDREnvSuspendParam) GetForce() bool`

GetForce returns the Force field if non-nil, zero value otherwise.

### GetForceOk

`func (o *MetroDREnvSuspendParam) GetForceOk() (*bool, bool)`

GetForceOk returns a tuple with the Force field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetForce

`func (o *MetroDREnvSuspendParam) SetForce(v bool)`

SetForce sets Force field to given value.

### HasForce

`func (o *MetroDREnvSuspendParam) HasForce() bool`

HasForce returns a boolean if a field has been set.

### GetSymforce

`func (o *MetroDREnvSuspendParam) GetSymforce() bool`

GetSymforce returns the Symforce field if non-nil, zero value otherwise.

### GetSymforceOk

`func (o *MetroDREnvSuspendParam) GetSymforceOk() (*bool, bool)`

GetSymforceOk returns a tuple with the Symforce field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetSymforce

`func (o *MetroDREnvSuspendParam) SetSymforce(v bool)`

SetSymforce sets Symforce field to given value.

### HasSymforce

`func (o *MetroDREnvSuspendParam) HasSymforce() bool`

HasSymforce returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


