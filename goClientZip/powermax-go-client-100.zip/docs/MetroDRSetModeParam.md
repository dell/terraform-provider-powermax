# MetroDRSetModeParam

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Mode** | Pointer to **string** | Sets the SRDF mode for the DR Session to asynchronous or adaptive copy disk mode.   Enumeration values: * **AdaptiveCopyDisk** * **Asynchronous**  | [optional] 
**Force** | Pointer to **bool** | Attempts to force the operation even though one or more volumes may not be in the normal, expected state(s) for the                                 specified                                 operation. | [optional] 
**Symforce** | Pointer to **bool** | Requests the System force operation be executed when normally it is rejected. Use extreme caution when using                                 this                                 option.                                  CAUTION: Use care when applying symforce, as data could be lost or corrupted. Use of this option is not recommended,                                 except in                                 an emergency.                                  NOTE: To enable symforce, a parameter called SYMAPI_ALLOW_RDF_SYMFORCE in the options file must be set to TRUE and                                 restart the                                 Unisphere server to pick up the change.                                  When used with symforce, a split command executes on an SRDF pair, even when the pair is sync in progress or restore in                                 progress.                                 During the execution of an establish or restore command, -symforce prohibits the verification of valid tracks on the                                 device at                                 the source. | [optional] 

## Methods

### NewMetroDRSetModeParam

`func NewMetroDRSetModeParam() *MetroDRSetModeParam`

NewMetroDRSetModeParam instantiates a new MetroDRSetModeParam object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewMetroDRSetModeParamWithDefaults

`func NewMetroDRSetModeParamWithDefaults() *MetroDRSetModeParam`

NewMetroDRSetModeParamWithDefaults instantiates a new MetroDRSetModeParam object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetMode

`func (o *MetroDRSetModeParam) GetMode() string`

GetMode returns the Mode field if non-nil, zero value otherwise.

### GetModeOk

`func (o *MetroDRSetModeParam) GetModeOk() (*string, bool)`

GetModeOk returns a tuple with the Mode field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetMode

`func (o *MetroDRSetModeParam) SetMode(v string)`

SetMode sets Mode field to given value.

### HasMode

`func (o *MetroDRSetModeParam) HasMode() bool`

HasMode returns a boolean if a field has been set.

### GetForce

`func (o *MetroDRSetModeParam) GetForce() bool`

GetForce returns the Force field if non-nil, zero value otherwise.

### GetForceOk

`func (o *MetroDRSetModeParam) GetForceOk() (*bool, bool)`

GetForceOk returns a tuple with the Force field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetForce

`func (o *MetroDRSetModeParam) SetForce(v bool)`

SetForce sets Force field to given value.

### HasForce

`func (o *MetroDRSetModeParam) HasForce() bool`

HasForce returns a boolean if a field has been set.

### GetSymforce

`func (o *MetroDRSetModeParam) GetSymforce() bool`

GetSymforce returns the Symforce field if non-nil, zero value otherwise.

### GetSymforceOk

`func (o *MetroDRSetModeParam) GetSymforceOk() (*bool, bool)`

GetSymforceOk returns a tuple with the Symforce field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetSymforce

`func (o *MetroDRSetModeParam) SetSymforce(v bool)`

SetSymforce sets Symforce field to given value.

### HasSymforce

`func (o *MetroDRSetModeParam) HasSymforce() bool`

HasSymforce returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


