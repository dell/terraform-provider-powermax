# FiconPortThreadKeyResult

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**FiconPortThreadInfo** | Pointer to [**[]FiconPortThreadInfo**](FiconPortThreadInfo.md) | ficonPortThreadInfo | [optional] 

## Methods

### NewFiconPortThreadKeyResult

`func NewFiconPortThreadKeyResult() *FiconPortThreadKeyResult`

NewFiconPortThreadKeyResult instantiates a new FiconPortThreadKeyResult object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewFiconPortThreadKeyResultWithDefaults

`func NewFiconPortThreadKeyResultWithDefaults() *FiconPortThreadKeyResult`

NewFiconPortThreadKeyResultWithDefaults instantiates a new FiconPortThreadKeyResult object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetFiconPortThreadInfo

`func (o *FiconPortThreadKeyResult) GetFiconPortThreadInfo() []FiconPortThreadInfo`

GetFiconPortThreadInfo returns the FiconPortThreadInfo field if non-nil, zero value otherwise.

### GetFiconPortThreadInfoOk

`func (o *FiconPortThreadKeyResult) GetFiconPortThreadInfoOk() (*[]FiconPortThreadInfo, bool)`

GetFiconPortThreadInfoOk returns a tuple with the FiconPortThreadInfo field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetFiconPortThreadInfo

`func (o *FiconPortThreadKeyResult) SetFiconPortThreadInfo(v []FiconPortThreadInfo)`

SetFiconPortThreadInfo sets FiconPortThreadInfo field to given value.

### HasFiconPortThreadInfo

`func (o *FiconPortThreadKeyResult) HasFiconPortThreadInfo() bool`

HasFiconPortThreadInfo returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


