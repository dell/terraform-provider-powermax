# CategoryKpisProjectionParam

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**StartDate** | **int64** | Starting date in millisecond. | 
**EndDate** | **int64** | Ending date in millisecond. | 
**SymmetrixId** | **string** | The Symmetrix array ID. | 
**AggregationType** | **string** | Aggreagation Type(Historical or Daily).   Enumeration values: * **Historical** * **Daily**  | 
**DataFormat** | **string** | Data Format (Average or Maximum)   Enumeration values: * **Average** * **Maximum**  | 
**Category** | **string** | SPA Projection Categories 1- Array, 2 - SRP, 3 - ThinPool   Enumeration values: * **Array** * **SRP** * **ThinPool**  | 

## Methods

### NewCategoryKpisProjectionParam

`func NewCategoryKpisProjectionParam(startDate int64, endDate int64, symmetrixId string, aggregationType string, dataFormat string, category string, ) *CategoryKpisProjectionParam`

NewCategoryKpisProjectionParam instantiates a new CategoryKpisProjectionParam object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewCategoryKpisProjectionParamWithDefaults

`func NewCategoryKpisProjectionParamWithDefaults() *CategoryKpisProjectionParam`

NewCategoryKpisProjectionParamWithDefaults instantiates a new CategoryKpisProjectionParam object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetStartDate

`func (o *CategoryKpisProjectionParam) GetStartDate() int64`

GetStartDate returns the StartDate field if non-nil, zero value otherwise.

### GetStartDateOk

`func (o *CategoryKpisProjectionParam) GetStartDateOk() (*int64, bool)`

GetStartDateOk returns a tuple with the StartDate field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetStartDate

`func (o *CategoryKpisProjectionParam) SetStartDate(v int64)`

SetStartDate sets StartDate field to given value.


### GetEndDate

`func (o *CategoryKpisProjectionParam) GetEndDate() int64`

GetEndDate returns the EndDate field if non-nil, zero value otherwise.

### GetEndDateOk

`func (o *CategoryKpisProjectionParam) GetEndDateOk() (*int64, bool)`

GetEndDateOk returns a tuple with the EndDate field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetEndDate

`func (o *CategoryKpisProjectionParam) SetEndDate(v int64)`

SetEndDate sets EndDate field to given value.


### GetSymmetrixId

`func (o *CategoryKpisProjectionParam) GetSymmetrixId() string`

GetSymmetrixId returns the SymmetrixId field if non-nil, zero value otherwise.

### GetSymmetrixIdOk

`func (o *CategoryKpisProjectionParam) GetSymmetrixIdOk() (*string, bool)`

GetSymmetrixIdOk returns a tuple with the SymmetrixId field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetSymmetrixId

`func (o *CategoryKpisProjectionParam) SetSymmetrixId(v string)`

SetSymmetrixId sets SymmetrixId field to given value.


### GetAggregationType

`func (o *CategoryKpisProjectionParam) GetAggregationType() string`

GetAggregationType returns the AggregationType field if non-nil, zero value otherwise.

### GetAggregationTypeOk

`func (o *CategoryKpisProjectionParam) GetAggregationTypeOk() (*string, bool)`

GetAggregationTypeOk returns a tuple with the AggregationType field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetAggregationType

`func (o *CategoryKpisProjectionParam) SetAggregationType(v string)`

SetAggregationType sets AggregationType field to given value.


### GetDataFormat

`func (o *CategoryKpisProjectionParam) GetDataFormat() string`

GetDataFormat returns the DataFormat field if non-nil, zero value otherwise.

### GetDataFormatOk

`func (o *CategoryKpisProjectionParam) GetDataFormatOk() (*string, bool)`

GetDataFormatOk returns a tuple with the DataFormat field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetDataFormat

`func (o *CategoryKpisProjectionParam) SetDataFormat(v string)`

SetDataFormat sets DataFormat field to given value.


### GetCategory

`func (o *CategoryKpisProjectionParam) GetCategory() string`

GetCategory returns the Category field if non-nil, zero value otherwise.

### GetCategoryOk

`func (o *CategoryKpisProjectionParam) GetCategoryOk() (*string, bool)`

GetCategoryOk returns a tuple with the Category field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetCategory

`func (o *CategoryKpisProjectionParam) SetCategory(v string)`

SetCategory sets Category field to given value.



[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


