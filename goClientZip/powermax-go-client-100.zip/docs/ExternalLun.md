# ExternalLun

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**LunWwn** | Pointer to **string** | The WWN of the external LUN | [optional] 
**LunNumber** | Pointer to **int64** | The external volumes LUN number | [optional] 
**BlockSize** | Pointer to **int64** | The block size of the external volume | [optional] 
**BlockCount** | Pointer to **int64** | The block count of the external volume | [optional] 
**CapacityByte** | Pointer to **float64** | The byte capacity of the external volume | [optional] 
**CapacityGb** | Pointer to **float64** | The byte capacity of the external volume | [optional] 
**DeviceNumber** | Pointer to **int64** | The block size of the external volume | [optional] 
**LunStatus** | Pointer to **string** | The status of the external volume | [optional] 
**LunType** | Pointer to **string** | The type/emulation of the external volume | [optional] 
**LocalPorts** | Pointer to [**[]SymmetrixPortKey**](SymmetrixPortKey.md) | The paths from ports to external ports | [optional] 
**Incomplete** | Pointer to **bool** | The description goes here... | [optional] 
**Controller** | Pointer to **bool** | The description goes here... | [optional] 
**ThinDev** | Pointer to **bool** | The description goes here... | [optional] 
**SymDev** | Pointer to **bool** | The description goes here... | [optional] 
**NonNative** | Pointer to **bool** | The description goes here... | [optional] 
**Native** | Pointer to **bool** |  | [optional] 

## Methods

### NewExternalLun

`func NewExternalLun() *ExternalLun`

NewExternalLun instantiates a new ExternalLun object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewExternalLunWithDefaults

`func NewExternalLunWithDefaults() *ExternalLun`

NewExternalLunWithDefaults instantiates a new ExternalLun object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetLunWwn

`func (o *ExternalLun) GetLunWwn() string`

GetLunWwn returns the LunWwn field if non-nil, zero value otherwise.

### GetLunWwnOk

`func (o *ExternalLun) GetLunWwnOk() (*string, bool)`

GetLunWwnOk returns a tuple with the LunWwn field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetLunWwn

`func (o *ExternalLun) SetLunWwn(v string)`

SetLunWwn sets LunWwn field to given value.

### HasLunWwn

`func (o *ExternalLun) HasLunWwn() bool`

HasLunWwn returns a boolean if a field has been set.

### GetLunNumber

`func (o *ExternalLun) GetLunNumber() int64`

GetLunNumber returns the LunNumber field if non-nil, zero value otherwise.

### GetLunNumberOk

`func (o *ExternalLun) GetLunNumberOk() (*int64, bool)`

GetLunNumberOk returns a tuple with the LunNumber field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetLunNumber

`func (o *ExternalLun) SetLunNumber(v int64)`

SetLunNumber sets LunNumber field to given value.

### HasLunNumber

`func (o *ExternalLun) HasLunNumber() bool`

HasLunNumber returns a boolean if a field has been set.

### GetBlockSize

`func (o *ExternalLun) GetBlockSize() int64`

GetBlockSize returns the BlockSize field if non-nil, zero value otherwise.

### GetBlockSizeOk

`func (o *ExternalLun) GetBlockSizeOk() (*int64, bool)`

GetBlockSizeOk returns a tuple with the BlockSize field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetBlockSize

`func (o *ExternalLun) SetBlockSize(v int64)`

SetBlockSize sets BlockSize field to given value.

### HasBlockSize

`func (o *ExternalLun) HasBlockSize() bool`

HasBlockSize returns a boolean if a field has been set.

### GetBlockCount

`func (o *ExternalLun) GetBlockCount() int64`

GetBlockCount returns the BlockCount field if non-nil, zero value otherwise.

### GetBlockCountOk

`func (o *ExternalLun) GetBlockCountOk() (*int64, bool)`

GetBlockCountOk returns a tuple with the BlockCount field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetBlockCount

`func (o *ExternalLun) SetBlockCount(v int64)`

SetBlockCount sets BlockCount field to given value.

### HasBlockCount

`func (o *ExternalLun) HasBlockCount() bool`

HasBlockCount returns a boolean if a field has been set.

### GetCapacityByte

`func (o *ExternalLun) GetCapacityByte() float64`

GetCapacityByte returns the CapacityByte field if non-nil, zero value otherwise.

### GetCapacityByteOk

`func (o *ExternalLun) GetCapacityByteOk() (*float64, bool)`

GetCapacityByteOk returns a tuple with the CapacityByte field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetCapacityByte

`func (o *ExternalLun) SetCapacityByte(v float64)`

SetCapacityByte sets CapacityByte field to given value.

### HasCapacityByte

`func (o *ExternalLun) HasCapacityByte() bool`

HasCapacityByte returns a boolean if a field has been set.

### GetCapacityGb

`func (o *ExternalLun) GetCapacityGb() float64`

GetCapacityGb returns the CapacityGb field if non-nil, zero value otherwise.

### GetCapacityGbOk

`func (o *ExternalLun) GetCapacityGbOk() (*float64, bool)`

GetCapacityGbOk returns a tuple with the CapacityGb field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetCapacityGb

`func (o *ExternalLun) SetCapacityGb(v float64)`

SetCapacityGb sets CapacityGb field to given value.

### HasCapacityGb

`func (o *ExternalLun) HasCapacityGb() bool`

HasCapacityGb returns a boolean if a field has been set.

### GetDeviceNumber

`func (o *ExternalLun) GetDeviceNumber() int64`

GetDeviceNumber returns the DeviceNumber field if non-nil, zero value otherwise.

### GetDeviceNumberOk

`func (o *ExternalLun) GetDeviceNumberOk() (*int64, bool)`

GetDeviceNumberOk returns a tuple with the DeviceNumber field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetDeviceNumber

`func (o *ExternalLun) SetDeviceNumber(v int64)`

SetDeviceNumber sets DeviceNumber field to given value.

### HasDeviceNumber

`func (o *ExternalLun) HasDeviceNumber() bool`

HasDeviceNumber returns a boolean if a field has been set.

### GetLunStatus

`func (o *ExternalLun) GetLunStatus() string`

GetLunStatus returns the LunStatus field if non-nil, zero value otherwise.

### GetLunStatusOk

`func (o *ExternalLun) GetLunStatusOk() (*string, bool)`

GetLunStatusOk returns a tuple with the LunStatus field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetLunStatus

`func (o *ExternalLun) SetLunStatus(v string)`

SetLunStatus sets LunStatus field to given value.

### HasLunStatus

`func (o *ExternalLun) HasLunStatus() bool`

HasLunStatus returns a boolean if a field has been set.

### GetLunType

`func (o *ExternalLun) GetLunType() string`

GetLunType returns the LunType field if non-nil, zero value otherwise.

### GetLunTypeOk

`func (o *ExternalLun) GetLunTypeOk() (*string, bool)`

GetLunTypeOk returns a tuple with the LunType field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetLunType

`func (o *ExternalLun) SetLunType(v string)`

SetLunType sets LunType field to given value.

### HasLunType

`func (o *ExternalLun) HasLunType() bool`

HasLunType returns a boolean if a field has been set.

### GetLocalPorts

`func (o *ExternalLun) GetLocalPorts() []SymmetrixPortKey`

GetLocalPorts returns the LocalPorts field if non-nil, zero value otherwise.

### GetLocalPortsOk

`func (o *ExternalLun) GetLocalPortsOk() (*[]SymmetrixPortKey, bool)`

GetLocalPortsOk returns a tuple with the LocalPorts field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetLocalPorts

`func (o *ExternalLun) SetLocalPorts(v []SymmetrixPortKey)`

SetLocalPorts sets LocalPorts field to given value.

### HasLocalPorts

`func (o *ExternalLun) HasLocalPorts() bool`

HasLocalPorts returns a boolean if a field has been set.

### GetIncomplete

`func (o *ExternalLun) GetIncomplete() bool`

GetIncomplete returns the Incomplete field if non-nil, zero value otherwise.

### GetIncompleteOk

`func (o *ExternalLun) GetIncompleteOk() (*bool, bool)`

GetIncompleteOk returns a tuple with the Incomplete field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetIncomplete

`func (o *ExternalLun) SetIncomplete(v bool)`

SetIncomplete sets Incomplete field to given value.

### HasIncomplete

`func (o *ExternalLun) HasIncomplete() bool`

HasIncomplete returns a boolean if a field has been set.

### GetController

`func (o *ExternalLun) GetController() bool`

GetController returns the Controller field if non-nil, zero value otherwise.

### GetControllerOk

`func (o *ExternalLun) GetControllerOk() (*bool, bool)`

GetControllerOk returns a tuple with the Controller field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetController

`func (o *ExternalLun) SetController(v bool)`

SetController sets Controller field to given value.

### HasController

`func (o *ExternalLun) HasController() bool`

HasController returns a boolean if a field has been set.

### GetThinDev

`func (o *ExternalLun) GetThinDev() bool`

GetThinDev returns the ThinDev field if non-nil, zero value otherwise.

### GetThinDevOk

`func (o *ExternalLun) GetThinDevOk() (*bool, bool)`

GetThinDevOk returns a tuple with the ThinDev field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetThinDev

`func (o *ExternalLun) SetThinDev(v bool)`

SetThinDev sets ThinDev field to given value.

### HasThinDev

`func (o *ExternalLun) HasThinDev() bool`

HasThinDev returns a boolean if a field has been set.

### GetSymDev

`func (o *ExternalLun) GetSymDev() bool`

GetSymDev returns the SymDev field if non-nil, zero value otherwise.

### GetSymDevOk

`func (o *ExternalLun) GetSymDevOk() (*bool, bool)`

GetSymDevOk returns a tuple with the SymDev field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetSymDev

`func (o *ExternalLun) SetSymDev(v bool)`

SetSymDev sets SymDev field to given value.

### HasSymDev

`func (o *ExternalLun) HasSymDev() bool`

HasSymDev returns a boolean if a field has been set.

### GetNonNative

`func (o *ExternalLun) GetNonNative() bool`

GetNonNative returns the NonNative field if non-nil, zero value otherwise.

### GetNonNativeOk

`func (o *ExternalLun) GetNonNativeOk() (*bool, bool)`

GetNonNativeOk returns a tuple with the NonNative field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetNonNative

`func (o *ExternalLun) SetNonNative(v bool)`

SetNonNative sets NonNative field to given value.

### HasNonNative

`func (o *ExternalLun) HasNonNative() bool`

HasNonNative returns a boolean if a field has been set.

### GetNative

`func (o *ExternalLun) GetNative() bool`

GetNative returns the Native field if non-nil, zero value otherwise.

### GetNativeOk

`func (o *ExternalLun) GetNativeOk() (*bool, bool)`

GetNativeOk returns a tuple with the Native field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetNative

`func (o *ExternalLun) SetNative(v bool)`

SetNative sets Native field to given value.

### HasNative

`func (o *ExternalLun) HasNative() bool`

HasNative returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


