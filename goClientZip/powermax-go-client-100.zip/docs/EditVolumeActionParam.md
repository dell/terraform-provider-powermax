# EditVolumeActionParam

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**EnableMobilityIdParam** | Pointer to [**EnableMobilityIdParam**](EnableMobilityIdParam.md) |  | [optional] 
**FreeVolumeParam** | Pointer to [**FreeVolumeParam**](FreeVolumeParam.md) |  | [optional] 
**ExpandVolumeParam** | Pointer to [**ExpandVolumeParam**](ExpandVolumeParam.md) |  | [optional] 
**ModifyVolumeIdentifierParam** | Pointer to [**ModifyVolumeIdentifierParam**](ModifyVolumeIdentifierParam.md) |  | [optional] 

## Methods

### NewEditVolumeActionParam

`func NewEditVolumeActionParam() *EditVolumeActionParam`

NewEditVolumeActionParam instantiates a new EditVolumeActionParam object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewEditVolumeActionParamWithDefaults

`func NewEditVolumeActionParamWithDefaults() *EditVolumeActionParam`

NewEditVolumeActionParamWithDefaults instantiates a new EditVolumeActionParam object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetEnableMobilityIdParam

`func (o *EditVolumeActionParam) GetEnableMobilityIdParam() EnableMobilityIdParam`

GetEnableMobilityIdParam returns the EnableMobilityIdParam field if non-nil, zero value otherwise.

### GetEnableMobilityIdParamOk

`func (o *EditVolumeActionParam) GetEnableMobilityIdParamOk() (*EnableMobilityIdParam, bool)`

GetEnableMobilityIdParamOk returns a tuple with the EnableMobilityIdParam field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetEnableMobilityIdParam

`func (o *EditVolumeActionParam) SetEnableMobilityIdParam(v EnableMobilityIdParam)`

SetEnableMobilityIdParam sets EnableMobilityIdParam field to given value.

### HasEnableMobilityIdParam

`func (o *EditVolumeActionParam) HasEnableMobilityIdParam() bool`

HasEnableMobilityIdParam returns a boolean if a field has been set.

### GetFreeVolumeParam

`func (o *EditVolumeActionParam) GetFreeVolumeParam() FreeVolumeParam`

GetFreeVolumeParam returns the FreeVolumeParam field if non-nil, zero value otherwise.

### GetFreeVolumeParamOk

`func (o *EditVolumeActionParam) GetFreeVolumeParamOk() (*FreeVolumeParam, bool)`

GetFreeVolumeParamOk returns a tuple with the FreeVolumeParam field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetFreeVolumeParam

`func (o *EditVolumeActionParam) SetFreeVolumeParam(v FreeVolumeParam)`

SetFreeVolumeParam sets FreeVolumeParam field to given value.

### HasFreeVolumeParam

`func (o *EditVolumeActionParam) HasFreeVolumeParam() bool`

HasFreeVolumeParam returns a boolean if a field has been set.

### GetExpandVolumeParam

`func (o *EditVolumeActionParam) GetExpandVolumeParam() ExpandVolumeParam`

GetExpandVolumeParam returns the ExpandVolumeParam field if non-nil, zero value otherwise.

### GetExpandVolumeParamOk

`func (o *EditVolumeActionParam) GetExpandVolumeParamOk() (*ExpandVolumeParam, bool)`

GetExpandVolumeParamOk returns a tuple with the ExpandVolumeParam field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetExpandVolumeParam

`func (o *EditVolumeActionParam) SetExpandVolumeParam(v ExpandVolumeParam)`

SetExpandVolumeParam sets ExpandVolumeParam field to given value.

### HasExpandVolumeParam

`func (o *EditVolumeActionParam) HasExpandVolumeParam() bool`

HasExpandVolumeParam returns a boolean if a field has been set.

### GetModifyVolumeIdentifierParam

`func (o *EditVolumeActionParam) GetModifyVolumeIdentifierParam() ModifyVolumeIdentifierParam`

GetModifyVolumeIdentifierParam returns the ModifyVolumeIdentifierParam field if non-nil, zero value otherwise.

### GetModifyVolumeIdentifierParamOk

`func (o *EditVolumeActionParam) GetModifyVolumeIdentifierParamOk() (*ModifyVolumeIdentifierParam, bool)`

GetModifyVolumeIdentifierParamOk returns a tuple with the ModifyVolumeIdentifierParam field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetModifyVolumeIdentifierParam

`func (o *EditVolumeActionParam) SetModifyVolumeIdentifierParam(v ModifyVolumeIdentifierParam)`

SetModifyVolumeIdentifierParam sets ModifyVolumeIdentifierParam field to given value.

### HasModifyVolumeIdentifierParam

`func (o *EditVolumeActionParam) HasModifyVolumeIdentifierParam() bool`

HasModifyVolumeIdentifierParam returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


