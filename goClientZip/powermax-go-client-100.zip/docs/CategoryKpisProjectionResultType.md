# CategoryKpisProjectionResultType

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**PercentUsedCapacity** | Pointer to **float64** | PercentUsedCapacity | [optional] 
**PercentUsedCapacityProjection** | Pointer to **float64** | PercentUsedCapacityProjection | [optional] 
**Timestamp** | **int64** | timestamp | 

## Methods

### NewCategoryKpisProjectionResultType

`func NewCategoryKpisProjectionResultType(timestamp int64, ) *CategoryKpisProjectionResultType`

NewCategoryKpisProjectionResultType instantiates a new CategoryKpisProjectionResultType object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewCategoryKpisProjectionResultTypeWithDefaults

`func NewCategoryKpisProjectionResultTypeWithDefaults() *CategoryKpisProjectionResultType`

NewCategoryKpisProjectionResultTypeWithDefaults instantiates a new CategoryKpisProjectionResultType object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetPercentUsedCapacity

`func (o *CategoryKpisProjectionResultType) GetPercentUsedCapacity() float64`

GetPercentUsedCapacity returns the PercentUsedCapacity field if non-nil, zero value otherwise.

### GetPercentUsedCapacityOk

`func (o *CategoryKpisProjectionResultType) GetPercentUsedCapacityOk() (*float64, bool)`

GetPercentUsedCapacityOk returns a tuple with the PercentUsedCapacity field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetPercentUsedCapacity

`func (o *CategoryKpisProjectionResultType) SetPercentUsedCapacity(v float64)`

SetPercentUsedCapacity sets PercentUsedCapacity field to given value.

### HasPercentUsedCapacity

`func (o *CategoryKpisProjectionResultType) HasPercentUsedCapacity() bool`

HasPercentUsedCapacity returns a boolean if a field has been set.

### GetPercentUsedCapacityProjection

`func (o *CategoryKpisProjectionResultType) GetPercentUsedCapacityProjection() float64`

GetPercentUsedCapacityProjection returns the PercentUsedCapacityProjection field if non-nil, zero value otherwise.

### GetPercentUsedCapacityProjectionOk

`func (o *CategoryKpisProjectionResultType) GetPercentUsedCapacityProjectionOk() (*float64, bool)`

GetPercentUsedCapacityProjectionOk returns a tuple with the PercentUsedCapacityProjection field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetPercentUsedCapacityProjection

`func (o *CategoryKpisProjectionResultType) SetPercentUsedCapacityProjection(v float64)`

SetPercentUsedCapacityProjection sets PercentUsedCapacityProjection field to given value.

### HasPercentUsedCapacityProjection

`func (o *CategoryKpisProjectionResultType) HasPercentUsedCapacityProjection() bool`

HasPercentUsedCapacityProjection returns a boolean if a field has been set.

### GetTimestamp

`func (o *CategoryKpisProjectionResultType) GetTimestamp() int64`

GetTimestamp returns the Timestamp field if non-nil, zero value otherwise.

### GetTimestampOk

`func (o *CategoryKpisProjectionResultType) GetTimestampOk() (*int64, bool)`

GetTimestampOk returns a tuple with the Timestamp field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetTimestamp

`func (o *CategoryKpisProjectionResultType) SetTimestamp(v int64)`

SetTimestamp sets Timestamp field to given value.



[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


