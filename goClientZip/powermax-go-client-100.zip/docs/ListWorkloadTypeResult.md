# ListWorkloadTypeResult

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**WorkloadId** | Pointer to **[]string** | A list of workloads. | [optional] 

## Methods

### NewListWorkloadTypeResult

`func NewListWorkloadTypeResult() *ListWorkloadTypeResult`

NewListWorkloadTypeResult instantiates a new ListWorkloadTypeResult object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewListWorkloadTypeResultWithDefaults

`func NewListWorkloadTypeResultWithDefaults() *ListWorkloadTypeResult`

NewListWorkloadTypeResultWithDefaults instantiates a new ListWorkloadTypeResult object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetWorkloadId

`func (o *ListWorkloadTypeResult) GetWorkloadId() []string`

GetWorkloadId returns the WorkloadId field if non-nil, zero value otherwise.

### GetWorkloadIdOk

`func (o *ListWorkloadTypeResult) GetWorkloadIdOk() (*[]string, bool)`

GetWorkloadIdOk returns a tuple with the WorkloadId field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetWorkloadId

`func (o *ListWorkloadTypeResult) SetWorkloadId(v []string)`

SetWorkloadId sets WorkloadId field to given value.

### HasWorkloadId

`func (o *ListWorkloadTypeResult) HasWorkloadId() bool`

HasWorkloadId returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


