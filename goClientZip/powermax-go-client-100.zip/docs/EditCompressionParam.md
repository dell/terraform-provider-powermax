# EditCompressionParam

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Compression** | Pointer to **bool** | Whether compression is enabled or disabled on SG. | [optional] 

## Methods

### NewEditCompressionParam

`func NewEditCompressionParam() *EditCompressionParam`

NewEditCompressionParam instantiates a new EditCompressionParam object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewEditCompressionParamWithDefaults

`func NewEditCompressionParamWithDefaults() *EditCompressionParam`

NewEditCompressionParamWithDefaults instantiates a new EditCompressionParam object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetCompression

`func (o *EditCompressionParam) GetCompression() bool`

GetCompression returns the Compression field if non-nil, zero value otherwise.

### GetCompressionOk

`func (o *EditCompressionParam) GetCompressionOk() (*bool, bool)`

GetCompressionOk returns a tuple with the Compression field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetCompression

`func (o *EditCompressionParam) SetCompression(v bool)`

SetCompression sets Compression field to given value.

### HasCompression

`func (o *EditCompressionParam) HasCompression() bool`

HasCompression returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


