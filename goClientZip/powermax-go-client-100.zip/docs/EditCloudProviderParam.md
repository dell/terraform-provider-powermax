# EditCloudProviderParam

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ExecutionOption** | Pointer to **string** |  | [optional] [default to "SYNCHRONOUS"]
**EditCloudProviderActionParam** | [**EditCloudProviderActionParam**](EditCloudProviderActionParam.md) |  | 

## Methods

### NewEditCloudProviderParam

`func NewEditCloudProviderParam(editCloudProviderActionParam EditCloudProviderActionParam, ) *EditCloudProviderParam`

NewEditCloudProviderParam instantiates a new EditCloudProviderParam object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewEditCloudProviderParamWithDefaults

`func NewEditCloudProviderParamWithDefaults() *EditCloudProviderParam`

NewEditCloudProviderParamWithDefaults instantiates a new EditCloudProviderParam object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetExecutionOption

`func (o *EditCloudProviderParam) GetExecutionOption() string`

GetExecutionOption returns the ExecutionOption field if non-nil, zero value otherwise.

### GetExecutionOptionOk

`func (o *EditCloudProviderParam) GetExecutionOptionOk() (*string, bool)`

GetExecutionOptionOk returns a tuple with the ExecutionOption field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetExecutionOption

`func (o *EditCloudProviderParam) SetExecutionOption(v string)`

SetExecutionOption sets ExecutionOption field to given value.

### HasExecutionOption

`func (o *EditCloudProviderParam) HasExecutionOption() bool`

HasExecutionOption returns a boolean if a field has been set.

### GetEditCloudProviderActionParam

`func (o *EditCloudProviderParam) GetEditCloudProviderActionParam() EditCloudProviderActionParam`

GetEditCloudProviderActionParam returns the EditCloudProviderActionParam field if non-nil, zero value otherwise.

### GetEditCloudProviderActionParamOk

`func (o *EditCloudProviderParam) GetEditCloudProviderActionParamOk() (*EditCloudProviderActionParam, bool)`

GetEditCloudProviderActionParamOk returns a tuple with the EditCloudProviderActionParam field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetEditCloudProviderActionParam

`func (o *EditCloudProviderParam) SetEditCloudProviderActionParam(v EditCloudProviderActionParam)`

SetEditCloudProviderActionParam sets EditCloudProviderActionParam field to given value.



[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


