# EditCloudSystemInterfaceActionParam

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**EditInterfaceIpSettings** | Pointer to [**EditInterfaceIpSettingsParam**](EditInterfaceIpSettingsParam.md) |  | [optional] 

## Methods

### NewEditCloudSystemInterfaceActionParam

`func NewEditCloudSystemInterfaceActionParam() *EditCloudSystemInterfaceActionParam`

NewEditCloudSystemInterfaceActionParam instantiates a new EditCloudSystemInterfaceActionParam object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewEditCloudSystemInterfaceActionParamWithDefaults

`func NewEditCloudSystemInterfaceActionParamWithDefaults() *EditCloudSystemInterfaceActionParam`

NewEditCloudSystemInterfaceActionParamWithDefaults instantiates a new EditCloudSystemInterfaceActionParam object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetEditInterfaceIpSettings

`func (o *EditCloudSystemInterfaceActionParam) GetEditInterfaceIpSettings() EditInterfaceIpSettingsParam`

GetEditInterfaceIpSettings returns the EditInterfaceIpSettings field if non-nil, zero value otherwise.

### GetEditInterfaceIpSettingsOk

`func (o *EditCloudSystemInterfaceActionParam) GetEditInterfaceIpSettingsOk() (*EditInterfaceIpSettingsParam, bool)`

GetEditInterfaceIpSettingsOk returns a tuple with the EditInterfaceIpSettings field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetEditInterfaceIpSettings

`func (o *EditCloudSystemInterfaceActionParam) SetEditInterfaceIpSettings(v EditInterfaceIpSettingsParam)`

SetEditInterfaceIpSettings sets EditInterfaceIpSettings field to given value.

### HasEditInterfaceIpSettings

`func (o *EditCloudSystemInterfaceActionParam) HasEditInterfaceIpSettings() bool`

HasEditInterfaceIpSettings returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


