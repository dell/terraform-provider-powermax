# CreateEndpointParamType

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ExecutionOption** | Pointer to **string** |  | [optional] [default to "SYNCHRONOUS"]
**EthernetEndpointType** | **string** | ethernet_Endpoint_Type   Enumeration values: * **iSCSI** * **NVMeTCP**  | 
**EndpointName** | Pointer to **string** | endpoint_name | [optional] 
**NetworkId** | **int64** | network_id | [default to 1]
**TcpPort** | Pointer to **int64** | tcp_port | [optional] [default to 3260]
**VolumeSetAddressing** | Pointer to **bool** | volume_set_addressing | [optional] 
**AvoidResetBroadcast** | Pointer to **bool** | avoid_reset_broadcast | [optional] 
**EnvironSet** | Pointer to **bool** | environ_set | [optional] 
**DisableQResetOnUa** | Pointer to **bool** | disable_q_reset_on_ua | [optional] 
**SoftReset** | Pointer to **bool** | soft_reset | [optional] 
**Scsi3** | Pointer to **bool** | scsi_3 | [optional] 
**ScsiSupport1** | Pointer to **bool** | scsi_support1 | [optional] 
**Spc2ProtocolVersion** | Pointer to **bool** | spc2_protocol_version | [optional] 
**OpenVms** | Pointer to **bool** | open_vms | [optional] 
**IsidProtected** | Pointer to **bool** | isid_protected | [optional] 

## Methods

### NewCreateEndpointParamType

`func NewCreateEndpointParamType(ethernetEndpointType string, networkId int64, ) *CreateEndpointParamType`

NewCreateEndpointParamType instantiates a new CreateEndpointParamType object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewCreateEndpointParamTypeWithDefaults

`func NewCreateEndpointParamTypeWithDefaults() *CreateEndpointParamType`

NewCreateEndpointParamTypeWithDefaults instantiates a new CreateEndpointParamType object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetExecutionOption

`func (o *CreateEndpointParamType) GetExecutionOption() string`

GetExecutionOption returns the ExecutionOption field if non-nil, zero value otherwise.

### GetExecutionOptionOk

`func (o *CreateEndpointParamType) GetExecutionOptionOk() (*string, bool)`

GetExecutionOptionOk returns a tuple with the ExecutionOption field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetExecutionOption

`func (o *CreateEndpointParamType) SetExecutionOption(v string)`

SetExecutionOption sets ExecutionOption field to given value.

### HasExecutionOption

`func (o *CreateEndpointParamType) HasExecutionOption() bool`

HasExecutionOption returns a boolean if a field has been set.

### GetEthernetEndpointType

`func (o *CreateEndpointParamType) GetEthernetEndpointType() string`

GetEthernetEndpointType returns the EthernetEndpointType field if non-nil, zero value otherwise.

### GetEthernetEndpointTypeOk

`func (o *CreateEndpointParamType) GetEthernetEndpointTypeOk() (*string, bool)`

GetEthernetEndpointTypeOk returns a tuple with the EthernetEndpointType field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetEthernetEndpointType

`func (o *CreateEndpointParamType) SetEthernetEndpointType(v string)`

SetEthernetEndpointType sets EthernetEndpointType field to given value.


### GetEndpointName

`func (o *CreateEndpointParamType) GetEndpointName() string`

GetEndpointName returns the EndpointName field if non-nil, zero value otherwise.

### GetEndpointNameOk

`func (o *CreateEndpointParamType) GetEndpointNameOk() (*string, bool)`

GetEndpointNameOk returns a tuple with the EndpointName field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetEndpointName

`func (o *CreateEndpointParamType) SetEndpointName(v string)`

SetEndpointName sets EndpointName field to given value.

### HasEndpointName

`func (o *CreateEndpointParamType) HasEndpointName() bool`

HasEndpointName returns a boolean if a field has been set.

### GetNetworkId

`func (o *CreateEndpointParamType) GetNetworkId() int64`

GetNetworkId returns the NetworkId field if non-nil, zero value otherwise.

### GetNetworkIdOk

`func (o *CreateEndpointParamType) GetNetworkIdOk() (*int64, bool)`

GetNetworkIdOk returns a tuple with the NetworkId field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetNetworkId

`func (o *CreateEndpointParamType) SetNetworkId(v int64)`

SetNetworkId sets NetworkId field to given value.


### GetTcpPort

`func (o *CreateEndpointParamType) GetTcpPort() int64`

GetTcpPort returns the TcpPort field if non-nil, zero value otherwise.

### GetTcpPortOk

`func (o *CreateEndpointParamType) GetTcpPortOk() (*int64, bool)`

GetTcpPortOk returns a tuple with the TcpPort field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetTcpPort

`func (o *CreateEndpointParamType) SetTcpPort(v int64)`

SetTcpPort sets TcpPort field to given value.

### HasTcpPort

`func (o *CreateEndpointParamType) HasTcpPort() bool`

HasTcpPort returns a boolean if a field has been set.

### GetVolumeSetAddressing

`func (o *CreateEndpointParamType) GetVolumeSetAddressing() bool`

GetVolumeSetAddressing returns the VolumeSetAddressing field if non-nil, zero value otherwise.

### GetVolumeSetAddressingOk

`func (o *CreateEndpointParamType) GetVolumeSetAddressingOk() (*bool, bool)`

GetVolumeSetAddressingOk returns a tuple with the VolumeSetAddressing field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetVolumeSetAddressing

`func (o *CreateEndpointParamType) SetVolumeSetAddressing(v bool)`

SetVolumeSetAddressing sets VolumeSetAddressing field to given value.

### HasVolumeSetAddressing

`func (o *CreateEndpointParamType) HasVolumeSetAddressing() bool`

HasVolumeSetAddressing returns a boolean if a field has been set.

### GetAvoidResetBroadcast

`func (o *CreateEndpointParamType) GetAvoidResetBroadcast() bool`

GetAvoidResetBroadcast returns the AvoidResetBroadcast field if non-nil, zero value otherwise.

### GetAvoidResetBroadcastOk

`func (o *CreateEndpointParamType) GetAvoidResetBroadcastOk() (*bool, bool)`

GetAvoidResetBroadcastOk returns a tuple with the AvoidResetBroadcast field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetAvoidResetBroadcast

`func (o *CreateEndpointParamType) SetAvoidResetBroadcast(v bool)`

SetAvoidResetBroadcast sets AvoidResetBroadcast field to given value.

### HasAvoidResetBroadcast

`func (o *CreateEndpointParamType) HasAvoidResetBroadcast() bool`

HasAvoidResetBroadcast returns a boolean if a field has been set.

### GetEnvironSet

`func (o *CreateEndpointParamType) GetEnvironSet() bool`

GetEnvironSet returns the EnvironSet field if non-nil, zero value otherwise.

### GetEnvironSetOk

`func (o *CreateEndpointParamType) GetEnvironSetOk() (*bool, bool)`

GetEnvironSetOk returns a tuple with the EnvironSet field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetEnvironSet

`func (o *CreateEndpointParamType) SetEnvironSet(v bool)`

SetEnvironSet sets EnvironSet field to given value.

### HasEnvironSet

`func (o *CreateEndpointParamType) HasEnvironSet() bool`

HasEnvironSet returns a boolean if a field has been set.

### GetDisableQResetOnUa

`func (o *CreateEndpointParamType) GetDisableQResetOnUa() bool`

GetDisableQResetOnUa returns the DisableQResetOnUa field if non-nil, zero value otherwise.

### GetDisableQResetOnUaOk

`func (o *CreateEndpointParamType) GetDisableQResetOnUaOk() (*bool, bool)`

GetDisableQResetOnUaOk returns a tuple with the DisableQResetOnUa field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetDisableQResetOnUa

`func (o *CreateEndpointParamType) SetDisableQResetOnUa(v bool)`

SetDisableQResetOnUa sets DisableQResetOnUa field to given value.

### HasDisableQResetOnUa

`func (o *CreateEndpointParamType) HasDisableQResetOnUa() bool`

HasDisableQResetOnUa returns a boolean if a field has been set.

### GetSoftReset

`func (o *CreateEndpointParamType) GetSoftReset() bool`

GetSoftReset returns the SoftReset field if non-nil, zero value otherwise.

### GetSoftResetOk

`func (o *CreateEndpointParamType) GetSoftResetOk() (*bool, bool)`

GetSoftResetOk returns a tuple with the SoftReset field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetSoftReset

`func (o *CreateEndpointParamType) SetSoftReset(v bool)`

SetSoftReset sets SoftReset field to given value.

### HasSoftReset

`func (o *CreateEndpointParamType) HasSoftReset() bool`

HasSoftReset returns a boolean if a field has been set.

### GetScsi3

`func (o *CreateEndpointParamType) GetScsi3() bool`

GetScsi3 returns the Scsi3 field if non-nil, zero value otherwise.

### GetScsi3Ok

`func (o *CreateEndpointParamType) GetScsi3Ok() (*bool, bool)`

GetScsi3Ok returns a tuple with the Scsi3 field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetScsi3

`func (o *CreateEndpointParamType) SetScsi3(v bool)`

SetScsi3 sets Scsi3 field to given value.

### HasScsi3

`func (o *CreateEndpointParamType) HasScsi3() bool`

HasScsi3 returns a boolean if a field has been set.

### GetScsiSupport1

`func (o *CreateEndpointParamType) GetScsiSupport1() bool`

GetScsiSupport1 returns the ScsiSupport1 field if non-nil, zero value otherwise.

### GetScsiSupport1Ok

`func (o *CreateEndpointParamType) GetScsiSupport1Ok() (*bool, bool)`

GetScsiSupport1Ok returns a tuple with the ScsiSupport1 field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetScsiSupport1

`func (o *CreateEndpointParamType) SetScsiSupport1(v bool)`

SetScsiSupport1 sets ScsiSupport1 field to given value.

### HasScsiSupport1

`func (o *CreateEndpointParamType) HasScsiSupport1() bool`

HasScsiSupport1 returns a boolean if a field has been set.

### GetSpc2ProtocolVersion

`func (o *CreateEndpointParamType) GetSpc2ProtocolVersion() bool`

GetSpc2ProtocolVersion returns the Spc2ProtocolVersion field if non-nil, zero value otherwise.

### GetSpc2ProtocolVersionOk

`func (o *CreateEndpointParamType) GetSpc2ProtocolVersionOk() (*bool, bool)`

GetSpc2ProtocolVersionOk returns a tuple with the Spc2ProtocolVersion field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetSpc2ProtocolVersion

`func (o *CreateEndpointParamType) SetSpc2ProtocolVersion(v bool)`

SetSpc2ProtocolVersion sets Spc2ProtocolVersion field to given value.

### HasSpc2ProtocolVersion

`func (o *CreateEndpointParamType) HasSpc2ProtocolVersion() bool`

HasSpc2ProtocolVersion returns a boolean if a field has been set.

### GetOpenVms

`func (o *CreateEndpointParamType) GetOpenVms() bool`

GetOpenVms returns the OpenVms field if non-nil, zero value otherwise.

### GetOpenVmsOk

`func (o *CreateEndpointParamType) GetOpenVmsOk() (*bool, bool)`

GetOpenVmsOk returns a tuple with the OpenVms field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetOpenVms

`func (o *CreateEndpointParamType) SetOpenVms(v bool)`

SetOpenVms sets OpenVms field to given value.

### HasOpenVms

`func (o *CreateEndpointParamType) HasOpenVms() bool`

HasOpenVms returns a boolean if a field has been set.

### GetIsidProtected

`func (o *CreateEndpointParamType) GetIsidProtected() bool`

GetIsidProtected returns the IsidProtected field if non-nil, zero value otherwise.

### GetIsidProtectedOk

`func (o *CreateEndpointParamType) GetIsidProtectedOk() (*bool, bool)`

GetIsidProtectedOk returns a tuple with the IsidProtected field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetIsidProtected

`func (o *CreateEndpointParamType) SetIsidProtected(v bool)`

SetIsidProtected sets IsidProtected field to given value.

### HasIsidProtected

`func (o *CreateEndpointParamType) HasIsidProtected() bool`

HasIsidProtected returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


