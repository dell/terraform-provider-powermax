# CreateIpRouteParam

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ExecutionOption** | Pointer to **string** |  | [optional] [default to "SYNCHRONOUS"]
**DestinationIp** | **string** | destinationIp | 
**Prefix** | **int32** | prefix | 
**GatewayIp** | **string** | gatewayIp | 
**NetworkId** | Pointer to **int32** | networkId | [optional] 

## Methods

### NewCreateIpRouteParam

`func NewCreateIpRouteParam(destinationIp string, prefix int32, gatewayIp string, ) *CreateIpRouteParam`

NewCreateIpRouteParam instantiates a new CreateIpRouteParam object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewCreateIpRouteParamWithDefaults

`func NewCreateIpRouteParamWithDefaults() *CreateIpRouteParam`

NewCreateIpRouteParamWithDefaults instantiates a new CreateIpRouteParam object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetExecutionOption

`func (o *CreateIpRouteParam) GetExecutionOption() string`

GetExecutionOption returns the ExecutionOption field if non-nil, zero value otherwise.

### GetExecutionOptionOk

`func (o *CreateIpRouteParam) GetExecutionOptionOk() (*string, bool)`

GetExecutionOptionOk returns a tuple with the ExecutionOption field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetExecutionOption

`func (o *CreateIpRouteParam) SetExecutionOption(v string)`

SetExecutionOption sets ExecutionOption field to given value.

### HasExecutionOption

`func (o *CreateIpRouteParam) HasExecutionOption() bool`

HasExecutionOption returns a boolean if a field has been set.

### GetDestinationIp

`func (o *CreateIpRouteParam) GetDestinationIp() string`

GetDestinationIp returns the DestinationIp field if non-nil, zero value otherwise.

### GetDestinationIpOk

`func (o *CreateIpRouteParam) GetDestinationIpOk() (*string, bool)`

GetDestinationIpOk returns a tuple with the DestinationIp field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetDestinationIp

`func (o *CreateIpRouteParam) SetDestinationIp(v string)`

SetDestinationIp sets DestinationIp field to given value.


### GetPrefix

`func (o *CreateIpRouteParam) GetPrefix() int32`

GetPrefix returns the Prefix field if non-nil, zero value otherwise.

### GetPrefixOk

`func (o *CreateIpRouteParam) GetPrefixOk() (*int32, bool)`

GetPrefixOk returns a tuple with the Prefix field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetPrefix

`func (o *CreateIpRouteParam) SetPrefix(v int32)`

SetPrefix sets Prefix field to given value.


### GetGatewayIp

`func (o *CreateIpRouteParam) GetGatewayIp() string`

GetGatewayIp returns the GatewayIp field if non-nil, zero value otherwise.

### GetGatewayIpOk

`func (o *CreateIpRouteParam) GetGatewayIpOk() (*string, bool)`

GetGatewayIpOk returns a tuple with the GatewayIp field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetGatewayIp

`func (o *CreateIpRouteParam) SetGatewayIp(v string)`

SetGatewayIp sets GatewayIp field to given value.


### GetNetworkId

`func (o *CreateIpRouteParam) GetNetworkId() int32`

GetNetworkId returns the NetworkId field if non-nil, zero value otherwise.

### GetNetworkIdOk

`func (o *CreateIpRouteParam) GetNetworkIdOk() (*int32, bool)`

GetNetworkIdOk returns a tuple with the NetworkId field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetNetworkId

`func (o *CreateIpRouteParam) SetNetworkId(v int32)`

SetNetworkId sets NetworkId field to given value.

### HasNetworkId

`func (o *CreateIpRouteParam) HasNetworkId() bool`

HasNetworkId returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


