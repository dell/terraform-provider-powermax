# FiconEmulationKeyResult

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**FiconEmulationInfo** | Pointer to [**[]FiconEmulationInfo**](FiconEmulationInfo.md) | ficonEmulationInfo | [optional] 

## Methods

### NewFiconEmulationKeyResult

`func NewFiconEmulationKeyResult() *FiconEmulationKeyResult`

NewFiconEmulationKeyResult instantiates a new FiconEmulationKeyResult object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewFiconEmulationKeyResultWithDefaults

`func NewFiconEmulationKeyResultWithDefaults() *FiconEmulationKeyResult`

NewFiconEmulationKeyResultWithDefaults instantiates a new FiconEmulationKeyResult object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetFiconEmulationInfo

`func (o *FiconEmulationKeyResult) GetFiconEmulationInfo() []FiconEmulationInfo`

GetFiconEmulationInfo returns the FiconEmulationInfo field if non-nil, zero value otherwise.

### GetFiconEmulationInfoOk

`func (o *FiconEmulationKeyResult) GetFiconEmulationInfoOk() (*[]FiconEmulationInfo, bool)`

GetFiconEmulationInfoOk returns a tuple with the FiconEmulationInfo field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetFiconEmulationInfo

`func (o *FiconEmulationKeyResult) SetFiconEmulationInfo(v []FiconEmulationInfo)`

SetFiconEmulationInfo sets FiconEmulationInfo field to given value.

### HasFiconEmulationInfo

`func (o *FiconEmulationKeyResult) HasFiconEmulationInfo() bool`

HasFiconEmulationInfo returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


