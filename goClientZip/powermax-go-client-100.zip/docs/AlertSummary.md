# AlertSummary

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ServerAlertSummary** | Pointer to [**ServerAlertSummary**](ServerAlertSummary.md) |  | [optional] 
**SymmAlertSummary** | Pointer to [**[]SymmAlertSummary**](SymmAlertSummary.md) | symmAlertSummary | [optional] 

## Methods

### NewAlertSummary

`func NewAlertSummary() *AlertSummary`

NewAlertSummary instantiates a new AlertSummary object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewAlertSummaryWithDefaults

`func NewAlertSummaryWithDefaults() *AlertSummary`

NewAlertSummaryWithDefaults instantiates a new AlertSummary object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetServerAlertSummary

`func (o *AlertSummary) GetServerAlertSummary() ServerAlertSummary`

GetServerAlertSummary returns the ServerAlertSummary field if non-nil, zero value otherwise.

### GetServerAlertSummaryOk

`func (o *AlertSummary) GetServerAlertSummaryOk() (*ServerAlertSummary, bool)`

GetServerAlertSummaryOk returns a tuple with the ServerAlertSummary field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetServerAlertSummary

`func (o *AlertSummary) SetServerAlertSummary(v ServerAlertSummary)`

SetServerAlertSummary sets ServerAlertSummary field to given value.

### HasServerAlertSummary

`func (o *AlertSummary) HasServerAlertSummary() bool`

HasServerAlertSummary returns a boolean if a field has been set.

### GetSymmAlertSummary

`func (o *AlertSummary) GetSymmAlertSummary() []SymmAlertSummary`

GetSymmAlertSummary returns the SymmAlertSummary field if non-nil, zero value otherwise.

### GetSymmAlertSummaryOk

`func (o *AlertSummary) GetSymmAlertSummaryOk() (*[]SymmAlertSummary, bool)`

GetSymmAlertSummaryOk returns a tuple with the SymmAlertSummary field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetSymmAlertSummary

`func (o *AlertSummary) SetSymmAlertSummary(v []SymmAlertSummary)`

SetSymmAlertSummary sets SymmAlertSummary field to given value.

### HasSymmAlertSummary

`func (o *AlertSummary) HasSymmAlertSummary() bool`

HasSymmAlertSummary returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


