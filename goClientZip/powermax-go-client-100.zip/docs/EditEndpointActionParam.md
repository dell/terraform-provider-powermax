# EditEndpointActionParam

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**DetachIPInterfaceParam** | Pointer to [**DetachIPInterfaceParam**](DetachIPInterfaceParam.md) |  | [optional] 
**AttachIPInterfaceParam** | Pointer to [**AttachIPInterfaceParam**](AttachIPInterfaceParam.md) |  | [optional] 
**ModifyPortFlagsParam** | Pointer to [**ModifyPortFlagsParam**](ModifyPortFlagsParam.md) |  | [optional] 
**ModifyEndpointParam** | Pointer to [**ModifyEndpointParam**](ModifyEndpointParam.md) |  | [optional] 
**RenameEndpointParam** | Pointer to [**RenameEndpointParam**](RenameEndpointParam.md) |  | [optional] 

## Methods

### NewEditEndpointActionParam

`func NewEditEndpointActionParam() *EditEndpointActionParam`

NewEditEndpointActionParam instantiates a new EditEndpointActionParam object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewEditEndpointActionParamWithDefaults

`func NewEditEndpointActionParamWithDefaults() *EditEndpointActionParam`

NewEditEndpointActionParamWithDefaults instantiates a new EditEndpointActionParam object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetDetachIPInterfaceParam

`func (o *EditEndpointActionParam) GetDetachIPInterfaceParam() DetachIPInterfaceParam`

GetDetachIPInterfaceParam returns the DetachIPInterfaceParam field if non-nil, zero value otherwise.

### GetDetachIPInterfaceParamOk

`func (o *EditEndpointActionParam) GetDetachIPInterfaceParamOk() (*DetachIPInterfaceParam, bool)`

GetDetachIPInterfaceParamOk returns a tuple with the DetachIPInterfaceParam field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetDetachIPInterfaceParam

`func (o *EditEndpointActionParam) SetDetachIPInterfaceParam(v DetachIPInterfaceParam)`

SetDetachIPInterfaceParam sets DetachIPInterfaceParam field to given value.

### HasDetachIPInterfaceParam

`func (o *EditEndpointActionParam) HasDetachIPInterfaceParam() bool`

HasDetachIPInterfaceParam returns a boolean if a field has been set.

### GetAttachIPInterfaceParam

`func (o *EditEndpointActionParam) GetAttachIPInterfaceParam() AttachIPInterfaceParam`

GetAttachIPInterfaceParam returns the AttachIPInterfaceParam field if non-nil, zero value otherwise.

### GetAttachIPInterfaceParamOk

`func (o *EditEndpointActionParam) GetAttachIPInterfaceParamOk() (*AttachIPInterfaceParam, bool)`

GetAttachIPInterfaceParamOk returns a tuple with the AttachIPInterfaceParam field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetAttachIPInterfaceParam

`func (o *EditEndpointActionParam) SetAttachIPInterfaceParam(v AttachIPInterfaceParam)`

SetAttachIPInterfaceParam sets AttachIPInterfaceParam field to given value.

### HasAttachIPInterfaceParam

`func (o *EditEndpointActionParam) HasAttachIPInterfaceParam() bool`

HasAttachIPInterfaceParam returns a boolean if a field has been set.

### GetModifyPortFlagsParam

`func (o *EditEndpointActionParam) GetModifyPortFlagsParam() ModifyPortFlagsParam`

GetModifyPortFlagsParam returns the ModifyPortFlagsParam field if non-nil, zero value otherwise.

### GetModifyPortFlagsParamOk

`func (o *EditEndpointActionParam) GetModifyPortFlagsParamOk() (*ModifyPortFlagsParam, bool)`

GetModifyPortFlagsParamOk returns a tuple with the ModifyPortFlagsParam field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetModifyPortFlagsParam

`func (o *EditEndpointActionParam) SetModifyPortFlagsParam(v ModifyPortFlagsParam)`

SetModifyPortFlagsParam sets ModifyPortFlagsParam field to given value.

### HasModifyPortFlagsParam

`func (o *EditEndpointActionParam) HasModifyPortFlagsParam() bool`

HasModifyPortFlagsParam returns a boolean if a field has been set.

### GetModifyEndpointParam

`func (o *EditEndpointActionParam) GetModifyEndpointParam() ModifyEndpointParam`

GetModifyEndpointParam returns the ModifyEndpointParam field if non-nil, zero value otherwise.

### GetModifyEndpointParamOk

`func (o *EditEndpointActionParam) GetModifyEndpointParamOk() (*ModifyEndpointParam, bool)`

GetModifyEndpointParamOk returns a tuple with the ModifyEndpointParam field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetModifyEndpointParam

`func (o *EditEndpointActionParam) SetModifyEndpointParam(v ModifyEndpointParam)`

SetModifyEndpointParam sets ModifyEndpointParam field to given value.

### HasModifyEndpointParam

`func (o *EditEndpointActionParam) HasModifyEndpointParam() bool`

HasModifyEndpointParam returns a boolean if a field has been set.

### GetRenameEndpointParam

`func (o *EditEndpointActionParam) GetRenameEndpointParam() RenameEndpointParam`

GetRenameEndpointParam returns the RenameEndpointParam field if non-nil, zero value otherwise.

### GetRenameEndpointParamOk

`func (o *EditEndpointActionParam) GetRenameEndpointParamOk() (*RenameEndpointParam, bool)`

GetRenameEndpointParamOk returns a tuple with the RenameEndpointParam field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetRenameEndpointParam

`func (o *EditEndpointActionParam) SetRenameEndpointParam(v RenameEndpointParam)`

SetRenameEndpointParam sets RenameEndpointParam field to given value.

### HasRenameEndpointParam

`func (o *EditEndpointActionParam) HasRenameEndpointParam() bool`

HasRenameEndpointParam returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


