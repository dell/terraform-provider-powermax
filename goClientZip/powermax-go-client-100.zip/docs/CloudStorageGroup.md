# CloudStorageGroup

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**StorageGroupUuid** | **string** | The unique identifier of the cloud storage group | 
**StorageGroupId** | Pointer to **string** | The name of the current local storage group based on the UUID of the cloud storage group                                 or                                 The name of the storage group at the time the most recent cloud snapshot was taken | [optional] 
**CapacityGb** | Pointer to **float64** | The Current capacity of the storage group on the System                                 or                                 The storage group capacity GB at the time the most recent cloud snapshot was taken | [optional] 
**NumOfVolumes** | Pointer to **int32** | The Current number of volume in the storage group on the System                                 or                                 The number of volume in the storage group at the time the most recent cloud snapshot was taken | [optional] 
**LastCreationDate** | Pointer to **string** | The date the most recent cloud snapshot was taken | [optional] 
**LastCreationDateTimestamp** | Pointer to **int64** | The timestamp at the time the most recent cloud snapshot was taken | [optional] 
**Orphaned** | Pointer to **bool** | States if the cloud storage group Still exists on the System or not | [optional] 
**NumOfCloudSnapshots** | Pointer to **int32** | The total number of cloud snapshots related to the cloud storage group | [optional] 
**NumOfCloudProviders** | Pointer to **int32** | The total number of cloud snapshots related to the cloud storage group | [optional] 

## Methods

### NewCloudStorageGroup

`func NewCloudStorageGroup(storageGroupUuid string, ) *CloudStorageGroup`

NewCloudStorageGroup instantiates a new CloudStorageGroup object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewCloudStorageGroupWithDefaults

`func NewCloudStorageGroupWithDefaults() *CloudStorageGroup`

NewCloudStorageGroupWithDefaults instantiates a new CloudStorageGroup object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetStorageGroupUuid

`func (o *CloudStorageGroup) GetStorageGroupUuid() string`

GetStorageGroupUuid returns the StorageGroupUuid field if non-nil, zero value otherwise.

### GetStorageGroupUuidOk

`func (o *CloudStorageGroup) GetStorageGroupUuidOk() (*string, bool)`

GetStorageGroupUuidOk returns a tuple with the StorageGroupUuid field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetStorageGroupUuid

`func (o *CloudStorageGroup) SetStorageGroupUuid(v string)`

SetStorageGroupUuid sets StorageGroupUuid field to given value.


### GetStorageGroupId

`func (o *CloudStorageGroup) GetStorageGroupId() string`

GetStorageGroupId returns the StorageGroupId field if non-nil, zero value otherwise.

### GetStorageGroupIdOk

`func (o *CloudStorageGroup) GetStorageGroupIdOk() (*string, bool)`

GetStorageGroupIdOk returns a tuple with the StorageGroupId field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetStorageGroupId

`func (o *CloudStorageGroup) SetStorageGroupId(v string)`

SetStorageGroupId sets StorageGroupId field to given value.

### HasStorageGroupId

`func (o *CloudStorageGroup) HasStorageGroupId() bool`

HasStorageGroupId returns a boolean if a field has been set.

### GetCapacityGb

`func (o *CloudStorageGroup) GetCapacityGb() float64`

GetCapacityGb returns the CapacityGb field if non-nil, zero value otherwise.

### GetCapacityGbOk

`func (o *CloudStorageGroup) GetCapacityGbOk() (*float64, bool)`

GetCapacityGbOk returns a tuple with the CapacityGb field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetCapacityGb

`func (o *CloudStorageGroup) SetCapacityGb(v float64)`

SetCapacityGb sets CapacityGb field to given value.

### HasCapacityGb

`func (o *CloudStorageGroup) HasCapacityGb() bool`

HasCapacityGb returns a boolean if a field has been set.

### GetNumOfVolumes

`func (o *CloudStorageGroup) GetNumOfVolumes() int32`

GetNumOfVolumes returns the NumOfVolumes field if non-nil, zero value otherwise.

### GetNumOfVolumesOk

`func (o *CloudStorageGroup) GetNumOfVolumesOk() (*int32, bool)`

GetNumOfVolumesOk returns a tuple with the NumOfVolumes field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetNumOfVolumes

`func (o *CloudStorageGroup) SetNumOfVolumes(v int32)`

SetNumOfVolumes sets NumOfVolumes field to given value.

### HasNumOfVolumes

`func (o *CloudStorageGroup) HasNumOfVolumes() bool`

HasNumOfVolumes returns a boolean if a field has been set.

### GetLastCreationDate

`func (o *CloudStorageGroup) GetLastCreationDate() string`

GetLastCreationDate returns the LastCreationDate field if non-nil, zero value otherwise.

### GetLastCreationDateOk

`func (o *CloudStorageGroup) GetLastCreationDateOk() (*string, bool)`

GetLastCreationDateOk returns a tuple with the LastCreationDate field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetLastCreationDate

`func (o *CloudStorageGroup) SetLastCreationDate(v string)`

SetLastCreationDate sets LastCreationDate field to given value.

### HasLastCreationDate

`func (o *CloudStorageGroup) HasLastCreationDate() bool`

HasLastCreationDate returns a boolean if a field has been set.

### GetLastCreationDateTimestamp

`func (o *CloudStorageGroup) GetLastCreationDateTimestamp() int64`

GetLastCreationDateTimestamp returns the LastCreationDateTimestamp field if non-nil, zero value otherwise.

### GetLastCreationDateTimestampOk

`func (o *CloudStorageGroup) GetLastCreationDateTimestampOk() (*int64, bool)`

GetLastCreationDateTimestampOk returns a tuple with the LastCreationDateTimestamp field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetLastCreationDateTimestamp

`func (o *CloudStorageGroup) SetLastCreationDateTimestamp(v int64)`

SetLastCreationDateTimestamp sets LastCreationDateTimestamp field to given value.

### HasLastCreationDateTimestamp

`func (o *CloudStorageGroup) HasLastCreationDateTimestamp() bool`

HasLastCreationDateTimestamp returns a boolean if a field has been set.

### GetOrphaned

`func (o *CloudStorageGroup) GetOrphaned() bool`

GetOrphaned returns the Orphaned field if non-nil, zero value otherwise.

### GetOrphanedOk

`func (o *CloudStorageGroup) GetOrphanedOk() (*bool, bool)`

GetOrphanedOk returns a tuple with the Orphaned field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetOrphaned

`func (o *CloudStorageGroup) SetOrphaned(v bool)`

SetOrphaned sets Orphaned field to given value.

### HasOrphaned

`func (o *CloudStorageGroup) HasOrphaned() bool`

HasOrphaned returns a boolean if a field has been set.

### GetNumOfCloudSnapshots

`func (o *CloudStorageGroup) GetNumOfCloudSnapshots() int32`

GetNumOfCloudSnapshots returns the NumOfCloudSnapshots field if non-nil, zero value otherwise.

### GetNumOfCloudSnapshotsOk

`func (o *CloudStorageGroup) GetNumOfCloudSnapshotsOk() (*int32, bool)`

GetNumOfCloudSnapshotsOk returns a tuple with the NumOfCloudSnapshots field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetNumOfCloudSnapshots

`func (o *CloudStorageGroup) SetNumOfCloudSnapshots(v int32)`

SetNumOfCloudSnapshots sets NumOfCloudSnapshots field to given value.

### HasNumOfCloudSnapshots

`func (o *CloudStorageGroup) HasNumOfCloudSnapshots() bool`

HasNumOfCloudSnapshots returns a boolean if a field has been set.

### GetNumOfCloudProviders

`func (o *CloudStorageGroup) GetNumOfCloudProviders() int32`

GetNumOfCloudProviders returns the NumOfCloudProviders field if non-nil, zero value otherwise.

### GetNumOfCloudProvidersOk

`func (o *CloudStorageGroup) GetNumOfCloudProvidersOk() (*int32, bool)`

GetNumOfCloudProvidersOk returns a tuple with the NumOfCloudProviders field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetNumOfCloudProviders

`func (o *CloudStorageGroup) SetNumOfCloudProviders(v int32)`

SetNumOfCloudProviders sets NumOfCloudProviders field to given value.

### HasNumOfCloudProviders

`func (o *CloudStorageGroup) HasNumOfCloudProviders() bool`

HasNumOfCloudProviders returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


