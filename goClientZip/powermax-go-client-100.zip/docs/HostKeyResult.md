# HostKeyResult

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**HostInfo** | Pointer to [**[]HostInfo**](HostInfo.md) | hostInfo | [optional] 

## Methods

### NewHostKeyResult

`func NewHostKeyResult() *HostKeyResult`

NewHostKeyResult instantiates a new HostKeyResult object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewHostKeyResultWithDefaults

`func NewHostKeyResultWithDefaults() *HostKeyResult`

NewHostKeyResultWithDefaults instantiates a new HostKeyResult object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetHostInfo

`func (o *HostKeyResult) GetHostInfo() []HostInfo`

GetHostInfo returns the HostInfo field if non-nil, zero value otherwise.

### GetHostInfoOk

`func (o *HostKeyResult) GetHostInfoOk() (*[]HostInfo, bool)`

GetHostInfoOk returns a tuple with the HostInfo field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetHostInfo

`func (o *HostKeyResult) SetHostInfo(v []HostInfo)`

SetHostInfo sets HostInfo field to given value.

### HasHostInfo

`func (o *HostKeyResult) HasHostInfo() bool`

HasHostInfo returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


