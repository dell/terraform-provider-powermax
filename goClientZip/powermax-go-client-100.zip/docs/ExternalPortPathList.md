# ExternalPortPathList

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**PathCount** | Pointer to **int32** | The number of remote LUNs | [optional] 
**Paths** | Pointer to [**[]ExternalPortPath**](ExternalPortPath.md) | The remote ports visible | [optional] 

## Methods

### NewExternalPortPathList

`func NewExternalPortPathList() *ExternalPortPathList`

NewExternalPortPathList instantiates a new ExternalPortPathList object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewExternalPortPathListWithDefaults

`func NewExternalPortPathListWithDefaults() *ExternalPortPathList`

NewExternalPortPathListWithDefaults instantiates a new ExternalPortPathList object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetPathCount

`func (o *ExternalPortPathList) GetPathCount() int32`

GetPathCount returns the PathCount field if non-nil, zero value otherwise.

### GetPathCountOk

`func (o *ExternalPortPathList) GetPathCountOk() (*int32, bool)`

GetPathCountOk returns a tuple with the PathCount field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetPathCount

`func (o *ExternalPortPathList) SetPathCount(v int32)`

SetPathCount sets PathCount field to given value.

### HasPathCount

`func (o *ExternalPortPathList) HasPathCount() bool`

HasPathCount returns a boolean if a field has been set.

### GetPaths

`func (o *ExternalPortPathList) GetPaths() []ExternalPortPath`

GetPaths returns the Paths field if non-nil, zero value otherwise.

### GetPathsOk

`func (o *ExternalPortPathList) GetPathsOk() (*[]ExternalPortPath, bool)`

GetPathsOk returns a tuple with the Paths field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetPaths

`func (o *ExternalPortPathList) SetPaths(v []ExternalPortPath)`

SetPaths sets Paths field to given value.

### HasPaths

`func (o *ExternalPortPathList) HasPaths() bool`

HasPaths returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


