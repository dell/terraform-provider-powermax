# DiskIdList

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**DiskIds** | Pointer to **[]string** | disk_ids | [optional] 

## Methods

### NewDiskIdList

`func NewDiskIdList() *DiskIdList`

NewDiskIdList instantiates a new DiskIdList object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewDiskIdListWithDefaults

`func NewDiskIdListWithDefaults() *DiskIdList`

NewDiskIdListWithDefaults instantiates a new DiskIdList object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetDiskIds

`func (o *DiskIdList) GetDiskIds() []string`

GetDiskIds returns the DiskIds field if non-nil, zero value otherwise.

### GetDiskIdsOk

`func (o *DiskIdList) GetDiskIdsOk() (*[]string, bool)`

GetDiskIdsOk returns a tuple with the DiskIds field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetDiskIds

`func (o *DiskIdList) SetDiskIds(v []string)`

SetDiskIds sets DiskIds field to given value.

### HasDiskIds

`func (o *DiskIdList) HasDiskIds() bool`

HasDiskIds returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


