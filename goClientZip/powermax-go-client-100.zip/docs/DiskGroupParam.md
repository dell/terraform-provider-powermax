# DiskGroupParam

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**StartDate** | **int64** | Starting date in millisecond. | 
**EndDate** | **int64** | Ending date in millisecond. | 
**SymmetrixId** | **string** | &lt;p&gt;The Symmetrix array ID.&lt;/p&gt; | 
**DiskGroupId** | **string** | diskGroupId | 
**DataFormat** | Pointer to **string** | &lt;p&gt;Data Format (Average or Maximum).&lt;/p&gt;   Enumeration values: * **Average** * **Maximum**  | [optional] 
**Metrics** | **[]string** | metrics   Enumeration values: * **PercentBusy** - The percent of time that the disk group is busy serving IOs. * **TotalSCSICommands** - The total number of read commands, write commands, skip mask commands, verify commands, XOR write commands, and XOR write-read commands performed by the disk group each second. * **DiskReads** - The number of reads per second for the disk group. * **DiskWrites** - The number of writes per second for the disk group. * **MBReads** - The read throughput (MBs) of the disk group per second. * **MBWritten** - The write throughput (MBs) of the disk group per second. * **AvgReadSize** - The average number of kilobytes for a single read command. * **AvgWriteSize** - The average number of kilobytes for a single write command. * **ReadResponseTime** - The average time it took the disk group to serve one read command. * **WriteResponseTime** - The average time it took the disk group to serve one write command. * **ResponseTime** - The average time it took the disk group to serve one read command. * **MBs** - The total number of MBs per second for the disk group. * **IOs** - The total number of read and write IOs per second. * **TotalCapacity** - The total capacity of all the disks in the disk group. * **UsedCapacity** - The total capacity allocated for all the disks in the disk group. * **PercentCapacityUsed** - The percent of the disk group capacity that is allocated. * **PercentCapacityFree** - The percent of the disk group capacity that is free. * **IODensity** - % Idle. * **PercentIdle** - The number of BE requests per GB of disk. (BE Reads + BE Writes) / allocated capacity With FAST moving active extents to higher tiers, this metric is a good indication of success (the IO density on Flash tiers should be higher than the density on SATA tiers.) * **UnmapCommandCount** - UNMAP command count * **SpareHypersCount** - Spare Hypers Count * **RebuildBlocksRead** - Rebuild Blocks Read * **RebuildBlocksWritten** - Rebuild Blocks Written. * **VAAIUnmapCommandCount** - VAAI (VMwares Storage APIs for Array Integration) UNMAP command count * **AVG_KB_PER_READ** - The average number of kilobytes for a single read command. * **AVG_KB_PER_WRITE** - The average number of kilobytes for a single write command. * **IO_DENSITY** - The number of BE requests per GB of disk. (BE Reads + BE Writes) / allocated capacity With FAST moving active extents to higher tiers, this metric is a good indication of success (the IO density on Flash tiers should be higher than the density on SATA tiers.) * **IO_RATE** - The total number of read and write IOs per second. * **MB_RATE** - The total number of MBs per second for the disk group. * **MB_READ_PER_SEC** - The read throughput (MBs) of the disk group per second. * **MB_WRITE_PER_SEC** - The write throughput (MBs) of the disk group per second. * **PERCENT_DISK_BUSY** - The percent of time that the disk group is busy serving IOs. * **PERCENT_DISK_IDLE** - The percent of time the disk group is idle. * **PERCENT_FREE_CAPACITY** - The percent of the disk group capacity that is free. * **PERCENT_USED_CAPACITY** - The percent of the disk group capacity that is allocated. * **READS** - The number of reads per second for the disk group. * **RESPONSE_TIME_READ** - The average time it took the disk group to serve one read command. * **RESPONSE_TIME** - The average time it took the disk group to service IO. * **RESPONSE_TIME_WRITE** - The average time it took the disk group to serve one write command. * **SCSI_COMM** - The total number of read commands, write commands, skip mask commands, verify commands, XOR write commands, and XOR write-read commands performed by the disk group each second. * **USED_DISK_CAPACITY_GB** - The total capacity allocated for all the disks in the disk group. * **WRITES** - The number of writes per second for the disk group. * **TOTAL_DISK_CAPACITY_GB** - The total capacity of all the disks in the disk group.  | 

## Methods

### NewDiskGroupParam

`func NewDiskGroupParam(startDate int64, endDate int64, symmetrixId string, diskGroupId string, metrics []string, ) *DiskGroupParam`

NewDiskGroupParam instantiates a new DiskGroupParam object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewDiskGroupParamWithDefaults

`func NewDiskGroupParamWithDefaults() *DiskGroupParam`

NewDiskGroupParamWithDefaults instantiates a new DiskGroupParam object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetStartDate

`func (o *DiskGroupParam) GetStartDate() int64`

GetStartDate returns the StartDate field if non-nil, zero value otherwise.

### GetStartDateOk

`func (o *DiskGroupParam) GetStartDateOk() (*int64, bool)`

GetStartDateOk returns a tuple with the StartDate field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetStartDate

`func (o *DiskGroupParam) SetStartDate(v int64)`

SetStartDate sets StartDate field to given value.


### GetEndDate

`func (o *DiskGroupParam) GetEndDate() int64`

GetEndDate returns the EndDate field if non-nil, zero value otherwise.

### GetEndDateOk

`func (o *DiskGroupParam) GetEndDateOk() (*int64, bool)`

GetEndDateOk returns a tuple with the EndDate field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetEndDate

`func (o *DiskGroupParam) SetEndDate(v int64)`

SetEndDate sets EndDate field to given value.


### GetSymmetrixId

`func (o *DiskGroupParam) GetSymmetrixId() string`

GetSymmetrixId returns the SymmetrixId field if non-nil, zero value otherwise.

### GetSymmetrixIdOk

`func (o *DiskGroupParam) GetSymmetrixIdOk() (*string, bool)`

GetSymmetrixIdOk returns a tuple with the SymmetrixId field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetSymmetrixId

`func (o *DiskGroupParam) SetSymmetrixId(v string)`

SetSymmetrixId sets SymmetrixId field to given value.


### GetDiskGroupId

`func (o *DiskGroupParam) GetDiskGroupId() string`

GetDiskGroupId returns the DiskGroupId field if non-nil, zero value otherwise.

### GetDiskGroupIdOk

`func (o *DiskGroupParam) GetDiskGroupIdOk() (*string, bool)`

GetDiskGroupIdOk returns a tuple with the DiskGroupId field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetDiskGroupId

`func (o *DiskGroupParam) SetDiskGroupId(v string)`

SetDiskGroupId sets DiskGroupId field to given value.


### GetDataFormat

`func (o *DiskGroupParam) GetDataFormat() string`

GetDataFormat returns the DataFormat field if non-nil, zero value otherwise.

### GetDataFormatOk

`func (o *DiskGroupParam) GetDataFormatOk() (*string, bool)`

GetDataFormatOk returns a tuple with the DataFormat field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetDataFormat

`func (o *DiskGroupParam) SetDataFormat(v string)`

SetDataFormat sets DataFormat field to given value.

### HasDataFormat

`func (o *DiskGroupParam) HasDataFormat() bool`

HasDataFormat returns a boolean if a field has been set.

### GetMetrics

`func (o *DiskGroupParam) GetMetrics() []string`

GetMetrics returns the Metrics field if non-nil, zero value otherwise.

### GetMetricsOk

`func (o *DiskGroupParam) GetMetricsOk() (*[]string, bool)`

GetMetricsOk returns a tuple with the Metrics field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetMetrics

`func (o *DiskGroupParam) SetMetrics(v []string)`

SetMetrics sets Metrics field to given value.



[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


