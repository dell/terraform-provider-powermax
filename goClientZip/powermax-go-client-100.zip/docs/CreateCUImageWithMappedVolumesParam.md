# CreateCUImageWithMappedVolumesParam

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ExecutionOption** | Pointer to **string** |  | [optional] [default to "SYNCHRONOUS"]
**CuImageSSID** | **string** | The new CU image SSID. | 
**CuImageNumber** | **string** | The new CU image number. | 
**StartBaseAddress** | **string** | The starting base address to use for the volume mapping. | 
**VolumeId** | **[]string** | The ID of the volume be mapped to the CU image. | 

## Methods

### NewCreateCUImageWithMappedVolumesParam

`func NewCreateCUImageWithMappedVolumesParam(cuImageSSID string, cuImageNumber string, startBaseAddress string, volumeId []string, ) *CreateCUImageWithMappedVolumesParam`

NewCreateCUImageWithMappedVolumesParam instantiates a new CreateCUImageWithMappedVolumesParam object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewCreateCUImageWithMappedVolumesParamWithDefaults

`func NewCreateCUImageWithMappedVolumesParamWithDefaults() *CreateCUImageWithMappedVolumesParam`

NewCreateCUImageWithMappedVolumesParamWithDefaults instantiates a new CreateCUImageWithMappedVolumesParam object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetExecutionOption

`func (o *CreateCUImageWithMappedVolumesParam) GetExecutionOption() string`

GetExecutionOption returns the ExecutionOption field if non-nil, zero value otherwise.

### GetExecutionOptionOk

`func (o *CreateCUImageWithMappedVolumesParam) GetExecutionOptionOk() (*string, bool)`

GetExecutionOptionOk returns a tuple with the ExecutionOption field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetExecutionOption

`func (o *CreateCUImageWithMappedVolumesParam) SetExecutionOption(v string)`

SetExecutionOption sets ExecutionOption field to given value.

### HasExecutionOption

`func (o *CreateCUImageWithMappedVolumesParam) HasExecutionOption() bool`

HasExecutionOption returns a boolean if a field has been set.

### GetCuImageSSID

`func (o *CreateCUImageWithMappedVolumesParam) GetCuImageSSID() string`

GetCuImageSSID returns the CuImageSSID field if non-nil, zero value otherwise.

### GetCuImageSSIDOk

`func (o *CreateCUImageWithMappedVolumesParam) GetCuImageSSIDOk() (*string, bool)`

GetCuImageSSIDOk returns a tuple with the CuImageSSID field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetCuImageSSID

`func (o *CreateCUImageWithMappedVolumesParam) SetCuImageSSID(v string)`

SetCuImageSSID sets CuImageSSID field to given value.


### GetCuImageNumber

`func (o *CreateCUImageWithMappedVolumesParam) GetCuImageNumber() string`

GetCuImageNumber returns the CuImageNumber field if non-nil, zero value otherwise.

### GetCuImageNumberOk

`func (o *CreateCUImageWithMappedVolumesParam) GetCuImageNumberOk() (*string, bool)`

GetCuImageNumberOk returns a tuple with the CuImageNumber field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetCuImageNumber

`func (o *CreateCUImageWithMappedVolumesParam) SetCuImageNumber(v string)`

SetCuImageNumber sets CuImageNumber field to given value.


### GetStartBaseAddress

`func (o *CreateCUImageWithMappedVolumesParam) GetStartBaseAddress() string`

GetStartBaseAddress returns the StartBaseAddress field if non-nil, zero value otherwise.

### GetStartBaseAddressOk

`func (o *CreateCUImageWithMappedVolumesParam) GetStartBaseAddressOk() (*string, bool)`

GetStartBaseAddressOk returns a tuple with the StartBaseAddress field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetStartBaseAddress

`func (o *CreateCUImageWithMappedVolumesParam) SetStartBaseAddress(v string)`

SetStartBaseAddress sets StartBaseAddress field to given value.


### GetVolumeId

`func (o *CreateCUImageWithMappedVolumesParam) GetVolumeId() []string`

GetVolumeId returns the VolumeId field if non-nil, zero value otherwise.

### GetVolumeIdOk

`func (o *CreateCUImageWithMappedVolumesParam) GetVolumeIdOk() (*[]string, bool)`

GetVolumeIdOk returns a tuple with the VolumeId field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetVolumeId

`func (o *CreateCUImageWithMappedVolumesParam) SetVolumeId(v []string)`

SetVolumeId sets VolumeId field to given value.



[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


