# CreateCloudProviderParam

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ExecutionOption** | Pointer to **string** |  | [optional] [default to "SYNCHRONOUS"]
**CloudProviderId** | **string** | The name of the Cloud Provider | 
**CloudProviderConnectionDetails** | [**CloudProviderConnectionDetails**](CloudProviderConnectionDetails.md) |  | 

## Methods

### NewCreateCloudProviderParam

`func NewCreateCloudProviderParam(cloudProviderId string, cloudProviderConnectionDetails CloudProviderConnectionDetails, ) *CreateCloudProviderParam`

NewCreateCloudProviderParam instantiates a new CreateCloudProviderParam object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewCreateCloudProviderParamWithDefaults

`func NewCreateCloudProviderParamWithDefaults() *CreateCloudProviderParam`

NewCreateCloudProviderParamWithDefaults instantiates a new CreateCloudProviderParam object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetExecutionOption

`func (o *CreateCloudProviderParam) GetExecutionOption() string`

GetExecutionOption returns the ExecutionOption field if non-nil, zero value otherwise.

### GetExecutionOptionOk

`func (o *CreateCloudProviderParam) GetExecutionOptionOk() (*string, bool)`

GetExecutionOptionOk returns a tuple with the ExecutionOption field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetExecutionOption

`func (o *CreateCloudProviderParam) SetExecutionOption(v string)`

SetExecutionOption sets ExecutionOption field to given value.

### HasExecutionOption

`func (o *CreateCloudProviderParam) HasExecutionOption() bool`

HasExecutionOption returns a boolean if a field has been set.

### GetCloudProviderId

`func (o *CreateCloudProviderParam) GetCloudProviderId() string`

GetCloudProviderId returns the CloudProviderId field if non-nil, zero value otherwise.

### GetCloudProviderIdOk

`func (o *CreateCloudProviderParam) GetCloudProviderIdOk() (*string, bool)`

GetCloudProviderIdOk returns a tuple with the CloudProviderId field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetCloudProviderId

`func (o *CreateCloudProviderParam) SetCloudProviderId(v string)`

SetCloudProviderId sets CloudProviderId field to given value.


### GetCloudProviderConnectionDetails

`func (o *CreateCloudProviderParam) GetCloudProviderConnectionDetails() CloudProviderConnectionDetails`

GetCloudProviderConnectionDetails returns the CloudProviderConnectionDetails field if non-nil, zero value otherwise.

### GetCloudProviderConnectionDetailsOk

`func (o *CreateCloudProviderParam) GetCloudProviderConnectionDetailsOk() (*CloudProviderConnectionDetails, bool)`

GetCloudProviderConnectionDetailsOk returns a tuple with the CloudProviderConnectionDetails field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetCloudProviderConnectionDetails

`func (o *CreateCloudProviderParam) SetCloudProviderConnectionDetails(v CloudProviderConnectionDetails)`

SetCloudProviderConnectionDetails sets CloudProviderConnectionDetails field to given value.



[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


