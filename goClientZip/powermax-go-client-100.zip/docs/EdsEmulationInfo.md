# EdsEmulationInfo

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**FirstAvailableDate** | Pointer to **int64** |  | [optional] 
**LastAvailableDate** | Pointer to **int64** |  | [optional] 
**EdsEmulationId** | **string** | edsEmulationId | 

## Methods

### NewEdsEmulationInfo

`func NewEdsEmulationInfo(edsEmulationId string, ) *EdsEmulationInfo`

NewEdsEmulationInfo instantiates a new EdsEmulationInfo object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewEdsEmulationInfoWithDefaults

`func NewEdsEmulationInfoWithDefaults() *EdsEmulationInfo`

NewEdsEmulationInfoWithDefaults instantiates a new EdsEmulationInfo object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetFirstAvailableDate

`func (o *EdsEmulationInfo) GetFirstAvailableDate() int64`

GetFirstAvailableDate returns the FirstAvailableDate field if non-nil, zero value otherwise.

### GetFirstAvailableDateOk

`func (o *EdsEmulationInfo) GetFirstAvailableDateOk() (*int64, bool)`

GetFirstAvailableDateOk returns a tuple with the FirstAvailableDate field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetFirstAvailableDate

`func (o *EdsEmulationInfo) SetFirstAvailableDate(v int64)`

SetFirstAvailableDate sets FirstAvailableDate field to given value.

### HasFirstAvailableDate

`func (o *EdsEmulationInfo) HasFirstAvailableDate() bool`

HasFirstAvailableDate returns a boolean if a field has been set.

### GetLastAvailableDate

`func (o *EdsEmulationInfo) GetLastAvailableDate() int64`

GetLastAvailableDate returns the LastAvailableDate field if non-nil, zero value otherwise.

### GetLastAvailableDateOk

`func (o *EdsEmulationInfo) GetLastAvailableDateOk() (*int64, bool)`

GetLastAvailableDateOk returns a tuple with the LastAvailableDate field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetLastAvailableDate

`func (o *EdsEmulationInfo) SetLastAvailableDate(v int64)`

SetLastAvailableDate sets LastAvailableDate field to given value.

### HasLastAvailableDate

`func (o *EdsEmulationInfo) HasLastAvailableDate() bool`

HasLastAvailableDate returns a boolean if a field has been set.

### GetEdsEmulationId

`func (o *EdsEmulationInfo) GetEdsEmulationId() string`

GetEdsEmulationId returns the EdsEmulationId field if non-nil, zero value otherwise.

### GetEdsEmulationIdOk

`func (o *EdsEmulationInfo) GetEdsEmulationIdOk() (*string, bool)`

GetEdsEmulationIdOk returns a tuple with the EdsEmulationId field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetEdsEmulationId

`func (o *EdsEmulationInfo) SetEdsEmulationId(v string)`

SetEdsEmulationId sets EdsEmulationId field to given value.



[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


