# DiskTechPoolParam

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**StartDate** | **int64** | Starting date in millisecond. | 
**EndDate** | **int64** | Ending date in millisecond. | 
**SymmetrixId** | **string** | &lt;p&gt;The Symmetrix array ID.&lt;/p&gt; | 
**DiskTechnology** | **string** | diskTechnology | 
**DataFormat** | Pointer to **string** | &lt;p&gt;Data Format (Average or Maximum).&lt;/p&gt;   Enumeration values: * **Average** * **Maximum**  | [optional] 
**Metrics** | **[]string** | metrics   Enumeration values: * **PercentBusy** - The percent of time that the disk is busy serving IOs. * **PercentIdle** - The percent of time the disk is idle. * **TotalSCSICommands** - The total number of read commands, write commands, skip mask commands, verify commands, XOR write commands, and XOR write-read commands performed by the Symmetrix disk each second. * **Reads** - Reads/sec * **Writes** - Writes/sec * **MBReads** - The reads per second in MBs. * **MBWrittens** - The write throughput (MBs) of the disk per second. * **AvgReadSize** - The average number of kilobytes for a single read command. * **AvgWriteSize** - The average number of kilobytes for a single write command. * **ReadResponseTime** - The average time it took the disk to serve one read command. * **WriteResponseTime** - The average time it took the disk to serve one write command. * **ResponseTime** - Calculated value: (Total Read Time/sec + Total Write Time/sec) / (Reads/sec + Writes/sec) * **MBs** - The total IO (reads and writes) per second in MBs. * **IOs** - An IO command to the disk. * **TotalCapacity** - The total capacity of the disk in GBs. * **UsedCapacity** - The used capacity of the disk in GBs. * **PercentCapacityUsed** - The percent of the pools capacity that is used. * **PercentCapacityFree** - The percent of the disk capacity that is free. * **IODensity** - The number of backend reads and writes per GB of disk. * **UnmapCommandCount** - UNMAP command count * **SpareHypersCount** - Spare Hypers Count * **RebuildBlocksRead** - Rebuild Blocks Read * **RebuildBlocksWritten** - Rebuild Blocks Written. * **VAAIUnmapCommandCount** - VAAI (VMwares Storage APIs for Array Integration) UNMAP command count  | 

## Methods

### NewDiskTechPoolParam

`func NewDiskTechPoolParam(startDate int64, endDate int64, symmetrixId string, diskTechnology string, metrics []string, ) *DiskTechPoolParam`

NewDiskTechPoolParam instantiates a new DiskTechPoolParam object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewDiskTechPoolParamWithDefaults

`func NewDiskTechPoolParamWithDefaults() *DiskTechPoolParam`

NewDiskTechPoolParamWithDefaults instantiates a new DiskTechPoolParam object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetStartDate

`func (o *DiskTechPoolParam) GetStartDate() int64`

GetStartDate returns the StartDate field if non-nil, zero value otherwise.

### GetStartDateOk

`func (o *DiskTechPoolParam) GetStartDateOk() (*int64, bool)`

GetStartDateOk returns a tuple with the StartDate field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetStartDate

`func (o *DiskTechPoolParam) SetStartDate(v int64)`

SetStartDate sets StartDate field to given value.


### GetEndDate

`func (o *DiskTechPoolParam) GetEndDate() int64`

GetEndDate returns the EndDate field if non-nil, zero value otherwise.

### GetEndDateOk

`func (o *DiskTechPoolParam) GetEndDateOk() (*int64, bool)`

GetEndDateOk returns a tuple with the EndDate field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetEndDate

`func (o *DiskTechPoolParam) SetEndDate(v int64)`

SetEndDate sets EndDate field to given value.


### GetSymmetrixId

`func (o *DiskTechPoolParam) GetSymmetrixId() string`

GetSymmetrixId returns the SymmetrixId field if non-nil, zero value otherwise.

### GetSymmetrixIdOk

`func (o *DiskTechPoolParam) GetSymmetrixIdOk() (*string, bool)`

GetSymmetrixIdOk returns a tuple with the SymmetrixId field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetSymmetrixId

`func (o *DiskTechPoolParam) SetSymmetrixId(v string)`

SetSymmetrixId sets SymmetrixId field to given value.


### GetDiskTechnology

`func (o *DiskTechPoolParam) GetDiskTechnology() string`

GetDiskTechnology returns the DiskTechnology field if non-nil, zero value otherwise.

### GetDiskTechnologyOk

`func (o *DiskTechPoolParam) GetDiskTechnologyOk() (*string, bool)`

GetDiskTechnologyOk returns a tuple with the DiskTechnology field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetDiskTechnology

`func (o *DiskTechPoolParam) SetDiskTechnology(v string)`

SetDiskTechnology sets DiskTechnology field to given value.


### GetDataFormat

`func (o *DiskTechPoolParam) GetDataFormat() string`

GetDataFormat returns the DataFormat field if non-nil, zero value otherwise.

### GetDataFormatOk

`func (o *DiskTechPoolParam) GetDataFormatOk() (*string, bool)`

GetDataFormatOk returns a tuple with the DataFormat field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetDataFormat

`func (o *DiskTechPoolParam) SetDataFormat(v string)`

SetDataFormat sets DataFormat field to given value.

### HasDataFormat

`func (o *DiskTechPoolParam) HasDataFormat() bool`

HasDataFormat returns a boolean if a field has been set.

### GetMetrics

`func (o *DiskTechPoolParam) GetMetrics() []string`

GetMetrics returns the Metrics field if non-nil, zero value otherwise.

### GetMetricsOk

`func (o *DiskTechPoolParam) GetMetricsOk() (*[]string, bool)`

GetMetricsOk returns a tuple with the Metrics field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetMetrics

`func (o *DiskTechPoolParam) SetMetrics(v []string)`

SetMetrics sets Metrics field to given value.



[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


