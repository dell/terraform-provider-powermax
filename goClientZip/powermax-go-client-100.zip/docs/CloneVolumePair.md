# CloneVolumePair

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**SourceVolumeName** | Pointer to **string** | source_volume_name | [optional] 
**TargetVolumeName** | Pointer to **string** | target_volume_name | [optional] 
**State** | Pointer to **string** | state | [optional] 
**ModifiedTracks** | Pointer to **int64** | modified_tracks | [optional] 
**SrcProtectedTracks** | Pointer to **int64** | src_protected_tracks | [optional] 
**SrcModifiedTracks** | Pointer to **int64** | src_modified_tracks | [optional] 
**BackgroundCopy** | Pointer to **bool** | background_copy | [optional] 
**Differential** | Pointer to **bool** | differential | [optional] 
**Precopy** | Pointer to **bool** | precopy | [optional] 
**Vse** | Pointer to **bool** | vse | [optional] 

## Methods

### NewCloneVolumePair

`func NewCloneVolumePair() *CloneVolumePair`

NewCloneVolumePair instantiates a new CloneVolumePair object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewCloneVolumePairWithDefaults

`func NewCloneVolumePairWithDefaults() *CloneVolumePair`

NewCloneVolumePairWithDefaults instantiates a new CloneVolumePair object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetSourceVolumeName

`func (o *CloneVolumePair) GetSourceVolumeName() string`

GetSourceVolumeName returns the SourceVolumeName field if non-nil, zero value otherwise.

### GetSourceVolumeNameOk

`func (o *CloneVolumePair) GetSourceVolumeNameOk() (*string, bool)`

GetSourceVolumeNameOk returns a tuple with the SourceVolumeName field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetSourceVolumeName

`func (o *CloneVolumePair) SetSourceVolumeName(v string)`

SetSourceVolumeName sets SourceVolumeName field to given value.

### HasSourceVolumeName

`func (o *CloneVolumePair) HasSourceVolumeName() bool`

HasSourceVolumeName returns a boolean if a field has been set.

### GetTargetVolumeName

`func (o *CloneVolumePair) GetTargetVolumeName() string`

GetTargetVolumeName returns the TargetVolumeName field if non-nil, zero value otherwise.

### GetTargetVolumeNameOk

`func (o *CloneVolumePair) GetTargetVolumeNameOk() (*string, bool)`

GetTargetVolumeNameOk returns a tuple with the TargetVolumeName field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetTargetVolumeName

`func (o *CloneVolumePair) SetTargetVolumeName(v string)`

SetTargetVolumeName sets TargetVolumeName field to given value.

### HasTargetVolumeName

`func (o *CloneVolumePair) HasTargetVolumeName() bool`

HasTargetVolumeName returns a boolean if a field has been set.

### GetState

`func (o *CloneVolumePair) GetState() string`

GetState returns the State field if non-nil, zero value otherwise.

### GetStateOk

`func (o *CloneVolumePair) GetStateOk() (*string, bool)`

GetStateOk returns a tuple with the State field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetState

`func (o *CloneVolumePair) SetState(v string)`

SetState sets State field to given value.

### HasState

`func (o *CloneVolumePair) HasState() bool`

HasState returns a boolean if a field has been set.

### GetModifiedTracks

`func (o *CloneVolumePair) GetModifiedTracks() int64`

GetModifiedTracks returns the ModifiedTracks field if non-nil, zero value otherwise.

### GetModifiedTracksOk

`func (o *CloneVolumePair) GetModifiedTracksOk() (*int64, bool)`

GetModifiedTracksOk returns a tuple with the ModifiedTracks field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetModifiedTracks

`func (o *CloneVolumePair) SetModifiedTracks(v int64)`

SetModifiedTracks sets ModifiedTracks field to given value.

### HasModifiedTracks

`func (o *CloneVolumePair) HasModifiedTracks() bool`

HasModifiedTracks returns a boolean if a field has been set.

### GetSrcProtectedTracks

`func (o *CloneVolumePair) GetSrcProtectedTracks() int64`

GetSrcProtectedTracks returns the SrcProtectedTracks field if non-nil, zero value otherwise.

### GetSrcProtectedTracksOk

`func (o *CloneVolumePair) GetSrcProtectedTracksOk() (*int64, bool)`

GetSrcProtectedTracksOk returns a tuple with the SrcProtectedTracks field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetSrcProtectedTracks

`func (o *CloneVolumePair) SetSrcProtectedTracks(v int64)`

SetSrcProtectedTracks sets SrcProtectedTracks field to given value.

### HasSrcProtectedTracks

`func (o *CloneVolumePair) HasSrcProtectedTracks() bool`

HasSrcProtectedTracks returns a boolean if a field has been set.

### GetSrcModifiedTracks

`func (o *CloneVolumePair) GetSrcModifiedTracks() int64`

GetSrcModifiedTracks returns the SrcModifiedTracks field if non-nil, zero value otherwise.

### GetSrcModifiedTracksOk

`func (o *CloneVolumePair) GetSrcModifiedTracksOk() (*int64, bool)`

GetSrcModifiedTracksOk returns a tuple with the SrcModifiedTracks field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetSrcModifiedTracks

`func (o *CloneVolumePair) SetSrcModifiedTracks(v int64)`

SetSrcModifiedTracks sets SrcModifiedTracks field to given value.

### HasSrcModifiedTracks

`func (o *CloneVolumePair) HasSrcModifiedTracks() bool`

HasSrcModifiedTracks returns a boolean if a field has been set.

### GetBackgroundCopy

`func (o *CloneVolumePair) GetBackgroundCopy() bool`

GetBackgroundCopy returns the BackgroundCopy field if non-nil, zero value otherwise.

### GetBackgroundCopyOk

`func (o *CloneVolumePair) GetBackgroundCopyOk() (*bool, bool)`

GetBackgroundCopyOk returns a tuple with the BackgroundCopy field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetBackgroundCopy

`func (o *CloneVolumePair) SetBackgroundCopy(v bool)`

SetBackgroundCopy sets BackgroundCopy field to given value.

### HasBackgroundCopy

`func (o *CloneVolumePair) HasBackgroundCopy() bool`

HasBackgroundCopy returns a boolean if a field has been set.

### GetDifferential

`func (o *CloneVolumePair) GetDifferential() bool`

GetDifferential returns the Differential field if non-nil, zero value otherwise.

### GetDifferentialOk

`func (o *CloneVolumePair) GetDifferentialOk() (*bool, bool)`

GetDifferentialOk returns a tuple with the Differential field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetDifferential

`func (o *CloneVolumePair) SetDifferential(v bool)`

SetDifferential sets Differential field to given value.

### HasDifferential

`func (o *CloneVolumePair) HasDifferential() bool`

HasDifferential returns a boolean if a field has been set.

### GetPrecopy

`func (o *CloneVolumePair) GetPrecopy() bool`

GetPrecopy returns the Precopy field if non-nil, zero value otherwise.

### GetPrecopyOk

`func (o *CloneVolumePair) GetPrecopyOk() (*bool, bool)`

GetPrecopyOk returns a tuple with the Precopy field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetPrecopy

`func (o *CloneVolumePair) SetPrecopy(v bool)`

SetPrecopy sets Precopy field to given value.

### HasPrecopy

`func (o *CloneVolumePair) HasPrecopy() bool`

HasPrecopy returns a boolean if a field has been set.

### GetVse

`func (o *CloneVolumePair) GetVse() bool`

GetVse returns the Vse field if non-nil, zero value otherwise.

### GetVseOk

`func (o *CloneVolumePair) GetVseOk() (*bool, bool)`

GetVseOk returns a tuple with the Vse field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetVse

`func (o *CloneVolumePair) SetVse(v bool)`

SetVse sets Vse field to given value.

### HasVse

`func (o *CloneVolumePair) HasVse() bool`

HasVse returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


