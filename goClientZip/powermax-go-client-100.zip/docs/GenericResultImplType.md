# GenericResultImplType

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Success** | Pointer to **bool** |  | [optional] [default to false]
**Message** | Pointer to **string** |  | [optional] 

## Methods

### NewGenericResultImplType

`func NewGenericResultImplType() *GenericResultImplType`

NewGenericResultImplType instantiates a new GenericResultImplType object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewGenericResultImplTypeWithDefaults

`func NewGenericResultImplTypeWithDefaults() *GenericResultImplType`

NewGenericResultImplTypeWithDefaults instantiates a new GenericResultImplType object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetSuccess

`func (o *GenericResultImplType) GetSuccess() bool`

GetSuccess returns the Success field if non-nil, zero value otherwise.

### GetSuccessOk

`func (o *GenericResultImplType) GetSuccessOk() (*bool, bool)`

GetSuccessOk returns a tuple with the Success field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetSuccess

`func (o *GenericResultImplType) SetSuccess(v bool)`

SetSuccess sets Success field to given value.

### HasSuccess

`func (o *GenericResultImplType) HasSuccess() bool`

HasSuccess returns a boolean if a field has been set.

### GetMessage

`func (o *GenericResultImplType) GetMessage() string`

GetMessage returns the Message field if non-nil, zero value otherwise.

### GetMessageOk

`func (o *GenericResultImplType) GetMessageOk() (*string, bool)`

GetMessageOk returns a tuple with the Message field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetMessage

`func (o *GenericResultImplType) SetMessage(v string)`

SetMessage sets Message field to given value.

### HasMessage

`func (o *GenericResultImplType) HasMessage() bool`

HasMessage returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


