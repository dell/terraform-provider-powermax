# ConfigurationManagementParamType

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ExecutionOption** | Pointer to **string** |  | [optional] [default to "SYNCHRONOUS"]

## Methods

### NewConfigurationManagementParamType

`func NewConfigurationManagementParamType() *ConfigurationManagementParamType`

NewConfigurationManagementParamType instantiates a new ConfigurationManagementParamType object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewConfigurationManagementParamTypeWithDefaults

`func NewConfigurationManagementParamTypeWithDefaults() *ConfigurationManagementParamType`

NewConfigurationManagementParamTypeWithDefaults instantiates a new ConfigurationManagementParamType object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetExecutionOption

`func (o *ConfigurationManagementParamType) GetExecutionOption() string`

GetExecutionOption returns the ExecutionOption field if non-nil, zero value otherwise.

### GetExecutionOptionOk

`func (o *ConfigurationManagementParamType) GetExecutionOptionOk() (*string, bool)`

GetExecutionOptionOk returns a tuple with the ExecutionOption field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetExecutionOption

`func (o *ConfigurationManagementParamType) SetExecutionOption(v string)`

SetExecutionOption sets ExecutionOption field to given value.

### HasExecutionOption

`func (o *ConfigurationManagementParamType) HasExecutionOption() bool`

HasExecutionOption returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


