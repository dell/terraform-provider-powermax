# AssociateSnapshotPolicyParam

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**SnapshotPolicies** | Pointer to **[]string** | The name/id of the snapshot policy | [optional] 

## Methods

### NewAssociateSnapshotPolicyParam

`func NewAssociateSnapshotPolicyParam() *AssociateSnapshotPolicyParam`

NewAssociateSnapshotPolicyParam instantiates a new AssociateSnapshotPolicyParam object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewAssociateSnapshotPolicyParamWithDefaults

`func NewAssociateSnapshotPolicyParamWithDefaults() *AssociateSnapshotPolicyParam`

NewAssociateSnapshotPolicyParamWithDefaults instantiates a new AssociateSnapshotPolicyParam object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetSnapshotPolicies

`func (o *AssociateSnapshotPolicyParam) GetSnapshotPolicies() []string`

GetSnapshotPolicies returns the SnapshotPolicies field if non-nil, zero value otherwise.

### GetSnapshotPoliciesOk

`func (o *AssociateSnapshotPolicyParam) GetSnapshotPoliciesOk() (*[]string, bool)`

GetSnapshotPoliciesOk returns a tuple with the SnapshotPolicies field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetSnapshotPolicies

`func (o *AssociateSnapshotPolicyParam) SetSnapshotPolicies(v []string)`

SetSnapshotPolicies sets SnapshotPolicies field to given value.

### HasSnapshotPolicies

`func (o *AssociateSnapshotPolicyParam) HasSnapshotPolicies() bool`

HasSnapshotPolicies returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


