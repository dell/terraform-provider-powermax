# CloudSystemInterfaceIpSettingsParam

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**InterfaceId** | **string** | The ID of the Cloud System Interface | 
**EditInterfaceIpSettings** | [**EditInterfaceIpSettingsParam**](EditInterfaceIpSettingsParam.md) |  | 

## Methods

### NewCloudSystemInterfaceIpSettingsParam

`func NewCloudSystemInterfaceIpSettingsParam(interfaceId string, editInterfaceIpSettings EditInterfaceIpSettingsParam, ) *CloudSystemInterfaceIpSettingsParam`

NewCloudSystemInterfaceIpSettingsParam instantiates a new CloudSystemInterfaceIpSettingsParam object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewCloudSystemInterfaceIpSettingsParamWithDefaults

`func NewCloudSystemInterfaceIpSettingsParamWithDefaults() *CloudSystemInterfaceIpSettingsParam`

NewCloudSystemInterfaceIpSettingsParamWithDefaults instantiates a new CloudSystemInterfaceIpSettingsParam object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetInterfaceId

`func (o *CloudSystemInterfaceIpSettingsParam) GetInterfaceId() string`

GetInterfaceId returns the InterfaceId field if non-nil, zero value otherwise.

### GetInterfaceIdOk

`func (o *CloudSystemInterfaceIpSettingsParam) GetInterfaceIdOk() (*string, bool)`

GetInterfaceIdOk returns a tuple with the InterfaceId field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetInterfaceId

`func (o *CloudSystemInterfaceIpSettingsParam) SetInterfaceId(v string)`

SetInterfaceId sets InterfaceId field to given value.


### GetEditInterfaceIpSettings

`func (o *CloudSystemInterfaceIpSettingsParam) GetEditInterfaceIpSettings() EditInterfaceIpSettingsParam`

GetEditInterfaceIpSettings returns the EditInterfaceIpSettings field if non-nil, zero value otherwise.

### GetEditInterfaceIpSettingsOk

`func (o *CloudSystemInterfaceIpSettingsParam) GetEditInterfaceIpSettingsOk() (*EditInterfaceIpSettingsParam, bool)`

GetEditInterfaceIpSettingsOk returns a tuple with the EditInterfaceIpSettings field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetEditInterfaceIpSettings

`func (o *CloudSystemInterfaceIpSettingsParam) SetEditInterfaceIpSettings(v EditInterfaceIpSettingsParam)`

SetEditInterfaceIpSettings sets EditInterfaceIpSettings field to given value.



[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


