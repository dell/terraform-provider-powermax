# KeyInfo

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Type** | Pointer to **string** | type   Enumeration values: * **Array** * **BEDirector** * **StorageGroup** * **FEDirector** * **RDFDirector** * **Disk** * **DeviceGroup** * **RDFA** * **FastPolicy** * **ThinTier** * **SRP** * **ThinPool** * **RDFS** * **DiskGroup** * **TierByStorageGroup** * **StorageGroupByTier**  | [optional] 
**Count** | **int32** | count | 

## Methods

### NewKeyInfo

`func NewKeyInfo(count int32, ) *KeyInfo`

NewKeyInfo instantiates a new KeyInfo object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewKeyInfoWithDefaults

`func NewKeyInfoWithDefaults() *KeyInfo`

NewKeyInfoWithDefaults instantiates a new KeyInfo object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetType

`func (o *KeyInfo) GetType() string`

GetType returns the Type field if non-nil, zero value otherwise.

### GetTypeOk

`func (o *KeyInfo) GetTypeOk() (*string, bool)`

GetTypeOk returns a tuple with the Type field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetType

`func (o *KeyInfo) SetType(v string)`

SetType sets Type field to given value.

### HasType

`func (o *KeyInfo) HasType() bool`

HasType returns a boolean if a field has been set.

### GetCount

`func (o *KeyInfo) GetCount() int32`

GetCount returns the Count field if non-nil, zero value otherwise.

### GetCountOk

`func (o *KeyInfo) GetCountOk() (*int32, bool)`

GetCountOk returns a tuple with the Count field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetCount

`func (o *KeyInfo) SetCount(v int32)`

SetCount sets Count field to given value.



[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


