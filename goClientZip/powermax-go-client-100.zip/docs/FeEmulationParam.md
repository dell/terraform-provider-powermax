# FeEmulationParam

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**StartDate** | **int64** | Starting date in millisecond. | 
**EndDate** | **int64** | Ending date in millisecond. | 
**SymmetrixId** | **string** | &lt;p&gt;The Symmetrix array ID.&lt;/p&gt; | 
**FeEmulationId** | **string** | feEmulationId | 
**DataFormat** | Pointer to **string** | &lt;p&gt;Data Format (Average or Maximum).&lt;/p&gt;   Enumeration values: * **Average** * **Maximum**  | [optional] 
**Metrics** | **[]string** | metrics   Enumeration values: * **ReadsTime** -  * **WritesTime** -  * **SyscallsTime** -  * **ManagementTime** -  * **LinkPortTime** -  * **XrcReplicationTime** -  * **ZhpfReadsTime** -  * **ZhpfWritesTime** -  * **OdxVaaiXcopyTime** -  * **OdxVaaiWriteSameTime** -  * **OdxVaaiLockTime** -  * **LpTasksTime** -  * **SymmkTotalTime** -  * **OrsTime** -  * **SymmkIdleTime** -  * **TotalWorkTime** - Total Work Time. * **PercentBusy** - % Busy  | 

## Methods

### NewFeEmulationParam

`func NewFeEmulationParam(startDate int64, endDate int64, symmetrixId string, feEmulationId string, metrics []string, ) *FeEmulationParam`

NewFeEmulationParam instantiates a new FeEmulationParam object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewFeEmulationParamWithDefaults

`func NewFeEmulationParamWithDefaults() *FeEmulationParam`

NewFeEmulationParamWithDefaults instantiates a new FeEmulationParam object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetStartDate

`func (o *FeEmulationParam) GetStartDate() int64`

GetStartDate returns the StartDate field if non-nil, zero value otherwise.

### GetStartDateOk

`func (o *FeEmulationParam) GetStartDateOk() (*int64, bool)`

GetStartDateOk returns a tuple with the StartDate field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetStartDate

`func (o *FeEmulationParam) SetStartDate(v int64)`

SetStartDate sets StartDate field to given value.


### GetEndDate

`func (o *FeEmulationParam) GetEndDate() int64`

GetEndDate returns the EndDate field if non-nil, zero value otherwise.

### GetEndDateOk

`func (o *FeEmulationParam) GetEndDateOk() (*int64, bool)`

GetEndDateOk returns a tuple with the EndDate field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetEndDate

`func (o *FeEmulationParam) SetEndDate(v int64)`

SetEndDate sets EndDate field to given value.


### GetSymmetrixId

`func (o *FeEmulationParam) GetSymmetrixId() string`

GetSymmetrixId returns the SymmetrixId field if non-nil, zero value otherwise.

### GetSymmetrixIdOk

`func (o *FeEmulationParam) GetSymmetrixIdOk() (*string, bool)`

GetSymmetrixIdOk returns a tuple with the SymmetrixId field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetSymmetrixId

`func (o *FeEmulationParam) SetSymmetrixId(v string)`

SetSymmetrixId sets SymmetrixId field to given value.


### GetFeEmulationId

`func (o *FeEmulationParam) GetFeEmulationId() string`

GetFeEmulationId returns the FeEmulationId field if non-nil, zero value otherwise.

### GetFeEmulationIdOk

`func (o *FeEmulationParam) GetFeEmulationIdOk() (*string, bool)`

GetFeEmulationIdOk returns a tuple with the FeEmulationId field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetFeEmulationId

`func (o *FeEmulationParam) SetFeEmulationId(v string)`

SetFeEmulationId sets FeEmulationId field to given value.


### GetDataFormat

`func (o *FeEmulationParam) GetDataFormat() string`

GetDataFormat returns the DataFormat field if non-nil, zero value otherwise.

### GetDataFormatOk

`func (o *FeEmulationParam) GetDataFormatOk() (*string, bool)`

GetDataFormatOk returns a tuple with the DataFormat field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetDataFormat

`func (o *FeEmulationParam) SetDataFormat(v string)`

SetDataFormat sets DataFormat field to given value.

### HasDataFormat

`func (o *FeEmulationParam) HasDataFormat() bool`

HasDataFormat returns a boolean if a field has been set.

### GetMetrics

`func (o *FeEmulationParam) GetMetrics() []string`

GetMetrics returns the Metrics field if non-nil, zero value otherwise.

### GetMetricsOk

`func (o *FeEmulationParam) GetMetricsOk() (*[]string, bool)`

GetMetricsOk returns a tuple with the Metrics field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetMetrics

`func (o *FeEmulationParam) SetMetrics(v []string)`

SetMetrics sets Metrics field to given value.



[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


