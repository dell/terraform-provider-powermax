# IpRoute

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**IpRouteId** | **string** | ipRouteId | 
**DestinationIp** | **string** | destination_ip | 
**Prefix** | **int32** | prefix | 
**GatewayIp** | **string** | gateway_ip | 
**NetworkId** | **int32** | network_id | 
**Director** | **string** | director | 

## Methods

### NewIpRoute

`func NewIpRoute(ipRouteId string, destinationIp string, prefix int32, gatewayIp string, networkId int32, director string, ) *IpRoute`

NewIpRoute instantiates a new IpRoute object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewIpRouteWithDefaults

`func NewIpRouteWithDefaults() *IpRoute`

NewIpRouteWithDefaults instantiates a new IpRoute object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetIpRouteId

`func (o *IpRoute) GetIpRouteId() string`

GetIpRouteId returns the IpRouteId field if non-nil, zero value otherwise.

### GetIpRouteIdOk

`func (o *IpRoute) GetIpRouteIdOk() (*string, bool)`

GetIpRouteIdOk returns a tuple with the IpRouteId field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetIpRouteId

`func (o *IpRoute) SetIpRouteId(v string)`

SetIpRouteId sets IpRouteId field to given value.


### GetDestinationIp

`func (o *IpRoute) GetDestinationIp() string`

GetDestinationIp returns the DestinationIp field if non-nil, zero value otherwise.

### GetDestinationIpOk

`func (o *IpRoute) GetDestinationIpOk() (*string, bool)`

GetDestinationIpOk returns a tuple with the DestinationIp field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetDestinationIp

`func (o *IpRoute) SetDestinationIp(v string)`

SetDestinationIp sets DestinationIp field to given value.


### GetPrefix

`func (o *IpRoute) GetPrefix() int32`

GetPrefix returns the Prefix field if non-nil, zero value otherwise.

### GetPrefixOk

`func (o *IpRoute) GetPrefixOk() (*int32, bool)`

GetPrefixOk returns a tuple with the Prefix field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetPrefix

`func (o *IpRoute) SetPrefix(v int32)`

SetPrefix sets Prefix field to given value.


### GetGatewayIp

`func (o *IpRoute) GetGatewayIp() string`

GetGatewayIp returns the GatewayIp field if non-nil, zero value otherwise.

### GetGatewayIpOk

`func (o *IpRoute) GetGatewayIpOk() (*string, bool)`

GetGatewayIpOk returns a tuple with the GatewayIp field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetGatewayIp

`func (o *IpRoute) SetGatewayIp(v string)`

SetGatewayIp sets GatewayIp field to given value.


### GetNetworkId

`func (o *IpRoute) GetNetworkId() int32`

GetNetworkId returns the NetworkId field if non-nil, zero value otherwise.

### GetNetworkIdOk

`func (o *IpRoute) GetNetworkIdOk() (*int32, bool)`

GetNetworkIdOk returns a tuple with the NetworkId field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetNetworkId

`func (o *IpRoute) SetNetworkId(v int32)`

SetNetworkId sets NetworkId field to given value.


### GetDirector

`func (o *IpRoute) GetDirector() string`

GetDirector returns the Director field if non-nil, zero value otherwise.

### GetDirectorOk

`func (o *IpRoute) GetDirectorOk() (*string, bool)`

GetDirectorOk returns a tuple with the Director field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetDirector

`func (o *IpRoute) SetDirector(v string)`

SetDirector sets Director field to given value.



[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


