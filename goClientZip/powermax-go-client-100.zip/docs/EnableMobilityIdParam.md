# EnableMobilityIdParam

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**EnableMobilityId** | **bool** | Specify whether to enable or disable(therefore enabling compatiblity id) mobility id on a device | 

## Methods

### NewEnableMobilityIdParam

`func NewEnableMobilityIdParam(enableMobilityId bool, ) *EnableMobilityIdParam`

NewEnableMobilityIdParam instantiates a new EnableMobilityIdParam object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewEnableMobilityIdParamWithDefaults

`func NewEnableMobilityIdParamWithDefaults() *EnableMobilityIdParam`

NewEnableMobilityIdParamWithDefaults instantiates a new EnableMobilityIdParam object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetEnableMobilityId

`func (o *EnableMobilityIdParam) GetEnableMobilityId() bool`

GetEnableMobilityId returns the EnableMobilityId field if non-nil, zero value otherwise.

### GetEnableMobilityIdOk

`func (o *EnableMobilityIdParam) GetEnableMobilityIdOk() (*bool, bool)`

GetEnableMobilityIdOk returns a tuple with the EnableMobilityId field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetEnableMobilityId

`func (o *EnableMobilityIdParam) SetEnableMobilityId(v bool)`

SetEnableMobilityId sets EnableMobilityId field to given value.



[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


