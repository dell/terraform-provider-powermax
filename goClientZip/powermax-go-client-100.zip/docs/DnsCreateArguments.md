# DnsCreateArguments

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**NasServer** | **string** |                          Id of associated Nas Server instance that uses this DNS object. Only one DNS object per Nas Server is supported.                      | 
**Domain** | **string** |                          Mandatory name of the DNS domain, where Nas Server does host names lookup when FQDN is not specified in the request.                      | 
**Addresses** | **[]string** |                          The list of DNS server IP addresses.                      | 
**Transport** | Pointer to **string** |                          Transport used when connecting to the DNS Server                         - 0 - UDP &#x3D;&gt; DNS uses the UDP protocol (default)                         - 1 - TCP &#x3D;&gt; DNS uses the TCP protocol                        Enumeration values: * **UDP** * **TCP**  | [optional] 

## Methods

### NewDnsCreateArguments

`func NewDnsCreateArguments(nasServer string, domain string, addresses []string, ) *DnsCreateArguments`

NewDnsCreateArguments instantiates a new DnsCreateArguments object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewDnsCreateArgumentsWithDefaults

`func NewDnsCreateArgumentsWithDefaults() *DnsCreateArguments`

NewDnsCreateArgumentsWithDefaults instantiates a new DnsCreateArguments object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetNasServer

`func (o *DnsCreateArguments) GetNasServer() string`

GetNasServer returns the NasServer field if non-nil, zero value otherwise.

### GetNasServerOk

`func (o *DnsCreateArguments) GetNasServerOk() (*string, bool)`

GetNasServerOk returns a tuple with the NasServer field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetNasServer

`func (o *DnsCreateArguments) SetNasServer(v string)`

SetNasServer sets NasServer field to given value.


### GetDomain

`func (o *DnsCreateArguments) GetDomain() string`

GetDomain returns the Domain field if non-nil, zero value otherwise.

### GetDomainOk

`func (o *DnsCreateArguments) GetDomainOk() (*string, bool)`

GetDomainOk returns a tuple with the Domain field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetDomain

`func (o *DnsCreateArguments) SetDomain(v string)`

SetDomain sets Domain field to given value.


### GetAddresses

`func (o *DnsCreateArguments) GetAddresses() []string`

GetAddresses returns the Addresses field if non-nil, zero value otherwise.

### GetAddressesOk

`func (o *DnsCreateArguments) GetAddressesOk() (*[]string, bool)`

GetAddressesOk returns a tuple with the Addresses field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetAddresses

`func (o *DnsCreateArguments) SetAddresses(v []string)`

SetAddresses sets Addresses field to given value.


### GetTransport

`func (o *DnsCreateArguments) GetTransport() string`

GetTransport returns the Transport field if non-nil, zero value otherwise.

### GetTransportOk

`func (o *DnsCreateArguments) GetTransportOk() (*string, bool)`

GetTransportOk returns a tuple with the Transport field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetTransport

`func (o *DnsCreateArguments) SetTransport(v string)`

SetTransport sets Transport field to given value.

### HasTransport

`func (o *DnsCreateArguments) HasTransport() bool`

HasTransport returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


