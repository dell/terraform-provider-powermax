# MaskingView

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**MaskingViewId** | **string** | Masking view name | 
**HostId** | Pointer to **string** | Host name | [optional] 
**HostGroupId** | Pointer to **string** | Host group name | [optional] 
**PortGroupId** | Pointer to **string** | Port group name | [optional] 
**StorageGroupId** | Pointer to **string** | Storage group name | [optional] 

## Methods

### NewMaskingView

`func NewMaskingView(maskingViewId string, ) *MaskingView`

NewMaskingView instantiates a new MaskingView object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewMaskingViewWithDefaults

`func NewMaskingViewWithDefaults() *MaskingView`

NewMaskingViewWithDefaults instantiates a new MaskingView object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetMaskingViewId

`func (o *MaskingView) GetMaskingViewId() string`

GetMaskingViewId returns the MaskingViewId field if non-nil, zero value otherwise.

### GetMaskingViewIdOk

`func (o *MaskingView) GetMaskingViewIdOk() (*string, bool)`

GetMaskingViewIdOk returns a tuple with the MaskingViewId field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetMaskingViewId

`func (o *MaskingView) SetMaskingViewId(v string)`

SetMaskingViewId sets MaskingViewId field to given value.


### GetHostId

`func (o *MaskingView) GetHostId() string`

GetHostId returns the HostId field if non-nil, zero value otherwise.

### GetHostIdOk

`func (o *MaskingView) GetHostIdOk() (*string, bool)`

GetHostIdOk returns a tuple with the HostId field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetHostId

`func (o *MaskingView) SetHostId(v string)`

SetHostId sets HostId field to given value.

### HasHostId

`func (o *MaskingView) HasHostId() bool`

HasHostId returns a boolean if a field has been set.

### GetHostGroupId

`func (o *MaskingView) GetHostGroupId() string`

GetHostGroupId returns the HostGroupId field if non-nil, zero value otherwise.

### GetHostGroupIdOk

`func (o *MaskingView) GetHostGroupIdOk() (*string, bool)`

GetHostGroupIdOk returns a tuple with the HostGroupId field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetHostGroupId

`func (o *MaskingView) SetHostGroupId(v string)`

SetHostGroupId sets HostGroupId field to given value.

### HasHostGroupId

`func (o *MaskingView) HasHostGroupId() bool`

HasHostGroupId returns a boolean if a field has been set.

### GetPortGroupId

`func (o *MaskingView) GetPortGroupId() string`

GetPortGroupId returns the PortGroupId field if non-nil, zero value otherwise.

### GetPortGroupIdOk

`func (o *MaskingView) GetPortGroupIdOk() (*string, bool)`

GetPortGroupIdOk returns a tuple with the PortGroupId field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetPortGroupId

`func (o *MaskingView) SetPortGroupId(v string)`

SetPortGroupId sets PortGroupId field to given value.

### HasPortGroupId

`func (o *MaskingView) HasPortGroupId() bool`

HasPortGroupId returns a boolean if a field has been set.

### GetStorageGroupId

`func (o *MaskingView) GetStorageGroupId() string`

GetStorageGroupId returns the StorageGroupId field if non-nil, zero value otherwise.

### GetStorageGroupIdOk

`func (o *MaskingView) GetStorageGroupIdOk() (*string, bool)`

GetStorageGroupIdOk returns a tuple with the StorageGroupId field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetStorageGroupId

`func (o *MaskingView) SetStorageGroupId(v string)`

SetStorageGroupId sets StorageGroupId field to given value.

### HasStorageGroupId

`func (o *MaskingView) HasStorageGroupId() bool`

HasStorageGroupId returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


