# DhsmServerIdentifier

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Id** | Pointer to **string** |                                  Identifier of Network Device                              | [optional] 

## Methods

### NewDhsmServerIdentifier

`func NewDhsmServerIdentifier() *DhsmServerIdentifier`

NewDhsmServerIdentifier instantiates a new DhsmServerIdentifier object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewDhsmServerIdentifierWithDefaults

`func NewDhsmServerIdentifierWithDefaults() *DhsmServerIdentifier`

NewDhsmServerIdentifierWithDefaults instantiates a new DhsmServerIdentifier object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetId

`func (o *DhsmServerIdentifier) GetId() string`

GetId returns the Id field if non-nil, zero value otherwise.

### GetIdOk

`func (o *DhsmServerIdentifier) GetIdOk() (*string, bool)`

GetIdOk returns a tuple with the Id field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetId

`func (o *DhsmServerIdentifier) SetId(v string)`

SetId sets Id field to given value.

### HasId

`func (o *DhsmServerIdentifier) HasId() bool`

HasId returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


