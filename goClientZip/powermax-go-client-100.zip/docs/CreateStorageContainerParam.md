# CreateStorageContainerParam

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ExecutionOption** | Pointer to **string** |  | [optional] [default to "SYNCHRONOUS"]
**StorageContainerId** | **string** | The storage container identifier | 
**Description** | Pointer to **string** | The description of the storage container | [optional] 
**StorageResourceParam** | Pointer to [**[]VvolStorageResourceParam**](VvolStorageResourceParam.md) | Parameters required to create a Storage Resource. multiple occurrences                                 will create multiple storage resources | [optional] 

## Methods

### NewCreateStorageContainerParam

`func NewCreateStorageContainerParam(storageContainerId string, ) *CreateStorageContainerParam`

NewCreateStorageContainerParam instantiates a new CreateStorageContainerParam object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewCreateStorageContainerParamWithDefaults

`func NewCreateStorageContainerParamWithDefaults() *CreateStorageContainerParam`

NewCreateStorageContainerParamWithDefaults instantiates a new CreateStorageContainerParam object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetExecutionOption

`func (o *CreateStorageContainerParam) GetExecutionOption() string`

GetExecutionOption returns the ExecutionOption field if non-nil, zero value otherwise.

### GetExecutionOptionOk

`func (o *CreateStorageContainerParam) GetExecutionOptionOk() (*string, bool)`

GetExecutionOptionOk returns a tuple with the ExecutionOption field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetExecutionOption

`func (o *CreateStorageContainerParam) SetExecutionOption(v string)`

SetExecutionOption sets ExecutionOption field to given value.

### HasExecutionOption

`func (o *CreateStorageContainerParam) HasExecutionOption() bool`

HasExecutionOption returns a boolean if a field has been set.

### GetStorageContainerId

`func (o *CreateStorageContainerParam) GetStorageContainerId() string`

GetStorageContainerId returns the StorageContainerId field if non-nil, zero value otherwise.

### GetStorageContainerIdOk

`func (o *CreateStorageContainerParam) GetStorageContainerIdOk() (*string, bool)`

GetStorageContainerIdOk returns a tuple with the StorageContainerId field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetStorageContainerId

`func (o *CreateStorageContainerParam) SetStorageContainerId(v string)`

SetStorageContainerId sets StorageContainerId field to given value.


### GetDescription

`func (o *CreateStorageContainerParam) GetDescription() string`

GetDescription returns the Description field if non-nil, zero value otherwise.

### GetDescriptionOk

`func (o *CreateStorageContainerParam) GetDescriptionOk() (*string, bool)`

GetDescriptionOk returns a tuple with the Description field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetDescription

`func (o *CreateStorageContainerParam) SetDescription(v string)`

SetDescription sets Description field to given value.

### HasDescription

`func (o *CreateStorageContainerParam) HasDescription() bool`

HasDescription returns a boolean if a field has been set.

### GetStorageResourceParam

`func (o *CreateStorageContainerParam) GetStorageResourceParam() []VvolStorageResourceParam`

GetStorageResourceParam returns the StorageResourceParam field if non-nil, zero value otherwise.

### GetStorageResourceParamOk

`func (o *CreateStorageContainerParam) GetStorageResourceParamOk() (*[]VvolStorageResourceParam, bool)`

GetStorageResourceParamOk returns a tuple with the StorageResourceParam field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetStorageResourceParam

`func (o *CreateStorageContainerParam) SetStorageResourceParam(v []VvolStorageResourceParam)`

SetStorageResourceParam sets StorageResourceParam field to given value.

### HasStorageResourceParam

`func (o *CreateStorageContainerParam) HasStorageResourceParam() bool`

HasStorageResourceParam returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


