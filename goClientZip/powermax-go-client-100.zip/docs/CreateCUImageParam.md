# CreateCUImageParam

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ExecutionOption** | Pointer to **string** |  | [optional] [default to "SYNCHRONOUS"]
**CuImageSSID** | **string** | The new CU image SSID. | 
**CuImageNumber** | **string** | The new CU image number. | 
**StartBaseAddress** | **string** | The starting base address to use for the volume mapping. | 

## Methods

### NewCreateCUImageParam

`func NewCreateCUImageParam(cuImageSSID string, cuImageNumber string, startBaseAddress string, ) *CreateCUImageParam`

NewCreateCUImageParam instantiates a new CreateCUImageParam object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewCreateCUImageParamWithDefaults

`func NewCreateCUImageParamWithDefaults() *CreateCUImageParam`

NewCreateCUImageParamWithDefaults instantiates a new CreateCUImageParam object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetExecutionOption

`func (o *CreateCUImageParam) GetExecutionOption() string`

GetExecutionOption returns the ExecutionOption field if non-nil, zero value otherwise.

### GetExecutionOptionOk

`func (o *CreateCUImageParam) GetExecutionOptionOk() (*string, bool)`

GetExecutionOptionOk returns a tuple with the ExecutionOption field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetExecutionOption

`func (o *CreateCUImageParam) SetExecutionOption(v string)`

SetExecutionOption sets ExecutionOption field to given value.

### HasExecutionOption

`func (o *CreateCUImageParam) HasExecutionOption() bool`

HasExecutionOption returns a boolean if a field has been set.

### GetCuImageSSID

`func (o *CreateCUImageParam) GetCuImageSSID() string`

GetCuImageSSID returns the CuImageSSID field if non-nil, zero value otherwise.

### GetCuImageSSIDOk

`func (o *CreateCUImageParam) GetCuImageSSIDOk() (*string, bool)`

GetCuImageSSIDOk returns a tuple with the CuImageSSID field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetCuImageSSID

`func (o *CreateCUImageParam) SetCuImageSSID(v string)`

SetCuImageSSID sets CuImageSSID field to given value.


### GetCuImageNumber

`func (o *CreateCUImageParam) GetCuImageNumber() string`

GetCuImageNumber returns the CuImageNumber field if non-nil, zero value otherwise.

### GetCuImageNumberOk

`func (o *CreateCUImageParam) GetCuImageNumberOk() (*string, bool)`

GetCuImageNumberOk returns a tuple with the CuImageNumber field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetCuImageNumber

`func (o *CreateCUImageParam) SetCuImageNumber(v string)`

SetCuImageNumber sets CuImageNumber field to given value.


### GetStartBaseAddress

`func (o *CreateCUImageParam) GetStartBaseAddress() string`

GetStartBaseAddress returns the StartBaseAddress field if non-nil, zero value otherwise.

### GetStartBaseAddressOk

`func (o *CreateCUImageParam) GetStartBaseAddressOk() (*string, bool)`

GetStartBaseAddressOk returns a tuple with the StartBaseAddress field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetStartBaseAddress

`func (o *CreateCUImageParam) SetStartBaseAddress(v string)`

SetStartBaseAddress sets StartBaseAddress field to given value.



[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


