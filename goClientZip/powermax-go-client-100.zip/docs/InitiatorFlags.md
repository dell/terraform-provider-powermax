# InitiatorFlags

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**DisableQResetOnUa** | [**DisableQResetOnUa**](DisableQResetOnUa.md) |  | 
**EnvironSet** | [**EnvironSet**](EnvironSet.md) |  | 
**AvoidResetBroadcast** | [**AvoidResetBroadcast**](AvoidResetBroadcast.md) |  | 
**Openvms** | [**Openvms**](Openvms.md) |  | 
**Scsi3** | [**Scsi3**](Scsi3.md) |  | 
**Spc2ProtocolVersion** | [**Spc2ProtocolVersion**](Spc2ProtocolVersion.md) |  | 
**ScsiSupport1** | [**ScsiSupport1**](ScsiSupport1.md) |  | 

## Methods

### NewInitiatorFlags

`func NewInitiatorFlags(disableQResetOnUa DisableQResetOnUa, environSet EnvironSet, avoidResetBroadcast AvoidResetBroadcast, openvms Openvms, scsi3 Scsi3, spc2ProtocolVersion Spc2ProtocolVersion, scsiSupport1 ScsiSupport1, ) *InitiatorFlags`

NewInitiatorFlags instantiates a new InitiatorFlags object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewInitiatorFlagsWithDefaults

`func NewInitiatorFlagsWithDefaults() *InitiatorFlags`

NewInitiatorFlagsWithDefaults instantiates a new InitiatorFlags object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetDisableQResetOnUa

`func (o *InitiatorFlags) GetDisableQResetOnUa() DisableQResetOnUa`

GetDisableQResetOnUa returns the DisableQResetOnUa field if non-nil, zero value otherwise.

### GetDisableQResetOnUaOk

`func (o *InitiatorFlags) GetDisableQResetOnUaOk() (*DisableQResetOnUa, bool)`

GetDisableQResetOnUaOk returns a tuple with the DisableQResetOnUa field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetDisableQResetOnUa

`func (o *InitiatorFlags) SetDisableQResetOnUa(v DisableQResetOnUa)`

SetDisableQResetOnUa sets DisableQResetOnUa field to given value.


### GetEnvironSet

`func (o *InitiatorFlags) GetEnvironSet() EnvironSet`

GetEnvironSet returns the EnvironSet field if non-nil, zero value otherwise.

### GetEnvironSetOk

`func (o *InitiatorFlags) GetEnvironSetOk() (*EnvironSet, bool)`

GetEnvironSetOk returns a tuple with the EnvironSet field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetEnvironSet

`func (o *InitiatorFlags) SetEnvironSet(v EnvironSet)`

SetEnvironSet sets EnvironSet field to given value.


### GetAvoidResetBroadcast

`func (o *InitiatorFlags) GetAvoidResetBroadcast() AvoidResetBroadcast`

GetAvoidResetBroadcast returns the AvoidResetBroadcast field if non-nil, zero value otherwise.

### GetAvoidResetBroadcastOk

`func (o *InitiatorFlags) GetAvoidResetBroadcastOk() (*AvoidResetBroadcast, bool)`

GetAvoidResetBroadcastOk returns a tuple with the AvoidResetBroadcast field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetAvoidResetBroadcast

`func (o *InitiatorFlags) SetAvoidResetBroadcast(v AvoidResetBroadcast)`

SetAvoidResetBroadcast sets AvoidResetBroadcast field to given value.


### GetOpenvms

`func (o *InitiatorFlags) GetOpenvms() Openvms`

GetOpenvms returns the Openvms field if non-nil, zero value otherwise.

### GetOpenvmsOk

`func (o *InitiatorFlags) GetOpenvmsOk() (*Openvms, bool)`

GetOpenvmsOk returns a tuple with the Openvms field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetOpenvms

`func (o *InitiatorFlags) SetOpenvms(v Openvms)`

SetOpenvms sets Openvms field to given value.


### GetScsi3

`func (o *InitiatorFlags) GetScsi3() Scsi3`

GetScsi3 returns the Scsi3 field if non-nil, zero value otherwise.

### GetScsi3Ok

`func (o *InitiatorFlags) GetScsi3Ok() (*Scsi3, bool)`

GetScsi3Ok returns a tuple with the Scsi3 field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetScsi3

`func (o *InitiatorFlags) SetScsi3(v Scsi3)`

SetScsi3 sets Scsi3 field to given value.


### GetSpc2ProtocolVersion

`func (o *InitiatorFlags) GetSpc2ProtocolVersion() Spc2ProtocolVersion`

GetSpc2ProtocolVersion returns the Spc2ProtocolVersion field if non-nil, zero value otherwise.

### GetSpc2ProtocolVersionOk

`func (o *InitiatorFlags) GetSpc2ProtocolVersionOk() (*Spc2ProtocolVersion, bool)`

GetSpc2ProtocolVersionOk returns a tuple with the Spc2ProtocolVersion field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetSpc2ProtocolVersion

`func (o *InitiatorFlags) SetSpc2ProtocolVersion(v Spc2ProtocolVersion)`

SetSpc2ProtocolVersion sets Spc2ProtocolVersion field to given value.


### GetScsiSupport1

`func (o *InitiatorFlags) GetScsiSupport1() ScsiSupport1`

GetScsiSupport1 returns the ScsiSupport1 field if non-nil, zero value otherwise.

### GetScsiSupport1Ok

`func (o *InitiatorFlags) GetScsiSupport1Ok() (*ScsiSupport1, bool)`

GetScsiSupport1Ok returns a tuple with the ScsiSupport1 field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetScsiSupport1

`func (o *InitiatorFlags) SetScsiSupport1(v ScsiSupport1)`

SetScsiSupport1 sets ScsiSupport1 field to given value.



[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


