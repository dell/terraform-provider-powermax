# DisableQResetOnUa

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Enabled** | **bool** | Disable Q Reset on UA enabled status | 
**Override** | **bool** | Disable Q Reset on UA overridden status | 

## Methods

### NewDisableQResetOnUa

`func NewDisableQResetOnUa(enabled bool, override bool, ) *DisableQResetOnUa`

NewDisableQResetOnUa instantiates a new DisableQResetOnUa object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewDisableQResetOnUaWithDefaults

`func NewDisableQResetOnUaWithDefaults() *DisableQResetOnUa`

NewDisableQResetOnUaWithDefaults instantiates a new DisableQResetOnUa object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetEnabled

`func (o *DisableQResetOnUa) GetEnabled() bool`

GetEnabled returns the Enabled field if non-nil, zero value otherwise.

### GetEnabledOk

`func (o *DisableQResetOnUa) GetEnabledOk() (*bool, bool)`

GetEnabledOk returns a tuple with the Enabled field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetEnabled

`func (o *DisableQResetOnUa) SetEnabled(v bool)`

SetEnabled sets Enabled field to given value.


### GetOverride

`func (o *DisableQResetOnUa) GetOverride() bool`

GetOverride returns the Override field if non-nil, zero value otherwise.

### GetOverrideOk

`func (o *DisableQResetOnUa) GetOverrideOk() (*bool, bool)`

GetOverrideOk returns a tuple with the Override field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetOverride

`func (o *DisableQResetOnUa) SetOverride(v bool)`

SetOverride sets Override field to given value.



[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


