# EditStorageGroupParam

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ExecutionOption** | Pointer to **string** |  | [optional] [default to "SYNCHRONOUS"]
**EditStorageGroupActionParam** | [**EditStorageGroupActionParam**](EditStorageGroupActionParam.md) |  | 

## Methods

### NewEditStorageGroupParam

`func NewEditStorageGroupParam(editStorageGroupActionParam EditStorageGroupActionParam, ) *EditStorageGroupParam`

NewEditStorageGroupParam instantiates a new EditStorageGroupParam object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewEditStorageGroupParamWithDefaults

`func NewEditStorageGroupParamWithDefaults() *EditStorageGroupParam`

NewEditStorageGroupParamWithDefaults instantiates a new EditStorageGroupParam object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetExecutionOption

`func (o *EditStorageGroupParam) GetExecutionOption() string`

GetExecutionOption returns the ExecutionOption field if non-nil, zero value otherwise.

### GetExecutionOptionOk

`func (o *EditStorageGroupParam) GetExecutionOptionOk() (*string, bool)`

GetExecutionOptionOk returns a tuple with the ExecutionOption field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetExecutionOption

`func (o *EditStorageGroupParam) SetExecutionOption(v string)`

SetExecutionOption sets ExecutionOption field to given value.

### HasExecutionOption

`func (o *EditStorageGroupParam) HasExecutionOption() bool`

HasExecutionOption returns a boolean if a field has been set.

### GetEditStorageGroupActionParam

`func (o *EditStorageGroupParam) GetEditStorageGroupActionParam() EditStorageGroupActionParam`

GetEditStorageGroupActionParam returns the EditStorageGroupActionParam field if non-nil, zero value otherwise.

### GetEditStorageGroupActionParamOk

`func (o *EditStorageGroupParam) GetEditStorageGroupActionParamOk() (*EditStorageGroupActionParam, bool)`

GetEditStorageGroupActionParamOk returns a tuple with the EditStorageGroupActionParam field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetEditStorageGroupActionParam

`func (o *EditStorageGroupParam) SetEditStorageGroupActionParam(v EditStorageGroupActionParam)`

SetEditStorageGroupActionParam sets EditStorageGroupActionParam field to given value.



[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


