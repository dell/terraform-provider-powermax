# ListSymmetrixResult

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**SymmetrixId** | Pointer to **[]string** | The System ID. | [optional] 

## Methods

### NewListSymmetrixResult

`func NewListSymmetrixResult() *ListSymmetrixResult`

NewListSymmetrixResult instantiates a new ListSymmetrixResult object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewListSymmetrixResultWithDefaults

`func NewListSymmetrixResultWithDefaults() *ListSymmetrixResult`

NewListSymmetrixResultWithDefaults instantiates a new ListSymmetrixResult object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetSymmetrixId

`func (o *ListSymmetrixResult) GetSymmetrixId() []string`

GetSymmetrixId returns the SymmetrixId field if non-nil, zero value otherwise.

### GetSymmetrixIdOk

`func (o *ListSymmetrixResult) GetSymmetrixIdOk() (*[]string, bool)`

GetSymmetrixIdOk returns a tuple with the SymmetrixId field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetSymmetrixId

`func (o *ListSymmetrixResult) SetSymmetrixId(v []string)`

SetSymmetrixId sets SymmetrixId field to given value.

### HasSymmetrixId

`func (o *ListSymmetrixResult) HasSymmetrixId() bool`

HasSymmetrixId returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


