# DeviceGroupKeyResult

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**DeviceGroupInfo** | Pointer to [**[]DeviceGroupInfo**](DeviceGroupInfo.md) | deviceGroupInfo | [optional] 

## Methods

### NewDeviceGroupKeyResult

`func NewDeviceGroupKeyResult() *DeviceGroupKeyResult`

NewDeviceGroupKeyResult instantiates a new DeviceGroupKeyResult object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewDeviceGroupKeyResultWithDefaults

`func NewDeviceGroupKeyResultWithDefaults() *DeviceGroupKeyResult`

NewDeviceGroupKeyResultWithDefaults instantiates a new DeviceGroupKeyResult object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetDeviceGroupInfo

`func (o *DeviceGroupKeyResult) GetDeviceGroupInfo() []DeviceGroupInfo`

GetDeviceGroupInfo returns the DeviceGroupInfo field if non-nil, zero value otherwise.

### GetDeviceGroupInfoOk

`func (o *DeviceGroupKeyResult) GetDeviceGroupInfoOk() (*[]DeviceGroupInfo, bool)`

GetDeviceGroupInfoOk returns a tuple with the DeviceGroupInfo field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetDeviceGroupInfo

`func (o *DeviceGroupKeyResult) SetDeviceGroupInfo(v []DeviceGroupInfo)`

SetDeviceGroupInfo sets DeviceGroupInfo field to given value.

### HasDeviceGroupInfo

`func (o *DeviceGroupKeyResult) HasDeviceGroupInfo() bool`

HasDeviceGroupInfo returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


