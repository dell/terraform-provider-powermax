# FilesystemModifyArguments

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Description** | Pointer to **string** |                      Filesystem description.                  | [optional] 
**ServiceLevel** | Pointer to **string** |                      Service Level Object                    Enumeration values: * **Optimized** * **Diamond** * **Platinum** * **Gold** * **Silver** * **Bronze**  | [optional] [default to "Optimized"]
**DataReduction** | Pointer to **bool** |                      Platform attribute                     - true if data reduction enabled                     - false if data reduction disabled                  | [optional] [default to false]
**SizeTotal** | Pointer to **int64** |                      Size, in MiB, that the system presents to the host or end user.                  | [optional] 
**SmbSyncWrites** | Pointer to **bool** |                      Indicates whether the synchronous writes option is enabled on the file system. Values are:                     - true - Synchronous writes option is enabled on the file system.                     - false - Synchronous writes option is disabled on the file system.                  | [optional] 
**SmbOpLocks** | Pointer to **bool** |                      Indicates whether opportunistic file locking is enabled on the file system. Values are:                     - true - Opportunistic file locking is enabled on the file system.                     - false - Opportunistic file locking is disabled on the file system.                  | [optional] 
**SmbNotifyOnAccess** | Pointer to **bool** |                      Indicates whether notifications on file access are enabled on the file system. Values are:                     - true - Notifications on file access are enabled on the file system.                     - false - Notifications on file access are disabled on the file system.                  | [optional] 
**SmbNotifyOnWrite** | Pointer to **bool** |                      Indicates whether notifications on file writes are enabled on the file system. Values are:                     - true - Notifications on file writes are enabled on the file system.                     - false - Notifications on file writes are disabled on the file system.                  | [optional] 
**SmbNotifyOnChangeDirDepth** | Pointer to **int32** |                      Lowest directory level to which the enabled notifications apply, if any.                  | [optional] 
**SmbNoNotify** | Pointer to **bool** |                      Indicates whether notifications of changes to directory file structure are enabled.                     - true - Notifications are enabled.                     - false - Notifications are disabled.                  | [optional] 
**EventNotifications** | Pointer to **string** |                      State of the event notification services for file system or protocol snap.                     - 0 : off                     - 1 : smb only notifications                     - 2 : nfs only notifications                     - 3 : smb and nfs notifications                    Enumeration values: * **off** * **SMB** * **NFS** * **SMB_NFS**  | [optional] [default to "off"]
**AccessPolicy** | Pointer to **string** |                      File system or protocol snap security access policies.                     - 0: Native Security.                     - 1: UNIX Security.                     - 2: Windows Security.                    Enumeration values: * **Native** * **UNIX** * **Windows**  | [optional] [default to "Native"]
**LockingPolicy** | Pointer to **string** |                      File system or protocol snap locking policies. These policy choices control whether the NFSv4 range locks must be honored. Because NFSv3 is advisory by design, this policy allows specifying whether the NFSv4 locking feature behaves like NFSv3 (advisory mode) in order to be backward compatible with applications expecting an advisory locking scheme.                     - 0: Advisory - No lock checking for NFS and honor SMB lock range only for SMB.                     - 1: Mandatory - Honor SMB and NFS lock range.                    Enumeration values: * **Advisory** * **Mandatory**  | [optional] [default to "Advisory"]
**FolderRenamePolicy** | Pointer to **string** |                      File system or protocol snap folder rename policies. These policy choices control whether directory can be renamed from NFS or SMB clients if at least one file is opened in the directory or in one of its child directories.                     - 0: SMB_Rename_Forbidden - A directory rename from the SMB protocol will be denied if at least one file is opened in the directory or in one of its child directories.                     - 1: All_Rename_Forbidden - Any directory rename request will be denied regardless of the protocol used, if at least one file is opened in the directory or in one of its child directories.                     - 2: All_Rename_Allowed - All protocols are allowed to rename directories without any restrictions.                    Enumeration values: * **SMB_Rename_Forbidden** * **All_Rename_Forbidden** * **All_Rename_Allowed**  | [optional] [default to "SMB_Rename_Forbidden"]
**FlrMinRet** | Pointer to **string** |                      The shortest retention period for which files on an FLR-enabled file system can be locked and protected from deletion. This value must be less than or equal to the maximum retention period. Any attempt to lock a file for less than the minimum retention period results in the file being locked until the current system time plus the minimum retention period is reached.                     Format [Y|M|D] (example 5Y for 5 years), specify Y for years, M for months, D for days, or the keyword infinite. Setting infinite means that the files can never be deleted.  This attribute should be set only for FLR enabled filesystems.                  | [optional] 
**FlrDefRet** | Pointer to **string** |                      The default retention period that is used in an FLR-enabled file system when a file is locked and a retention period is not specified. This value must be greater than or equal to the minimum retention period, and less than or equal to the maximum retention period.                     Format [Y|M|D] (example 5Y for 5 years).  Specify Y for years, M for months, D for days, or infinite. The default value for the default retention period is infinite for Enterprise FLR mode, and 1 year for Compliance FLR mode.  This attribute should be set only for FLR enabled filesystems.                  | [optional] 
**FlrMaxRet** | Pointer to **string** |                      The longest retention period for which files on an FLR-enabled file system can be locked and protected from deletion. Any attempt to lock a file for more than this maximum retention period results in the file being locked until the current system time plus the maximum retention period is reached. Specify Y for years, M for months, D for days, or infinite. setting infinite means that the files can never be deleted.  This attribute should be set only for FLR enabled filesystems.                  | [optional] 
**FlrAutoLock** | Pointer to **bool** |                      Indicates whether to automatically lock files in an FLR-enabled file system.  When true files are locked automatically after modification based on the flrPolicyInterval interval.  When enabled, auto-locked files are set with the default retention period value. Values:                     - true - automatic lock is enabled on the file system.                     - false - automatic lock is disabled on the file system.                     This setting can only be applied to mounted FLR enabled file systems.                  | [optional] 
**FlrAutoDelete** | Pointer to **bool** |                      Indicates whether locked files will be automatically delete from an FLR-enabled file system once their retention periods have expired. Values:                     - true - automatic delete is enabled on the file system.                     - false - automatic delete is disabled on the file system.                     This setting can only be applied to mounted FLR enabled file systems.                  | [optional] 
**FlrPolicyInterval** | Pointer to **int32** |                      Indicates how long to wait (in seconds) after files are modified before the files are automatically locked. This setting can only be applied to mounted FLR enabled file systems.                  | [optional] 
**InfoThreshold** | Pointer to **int32** |                      The info threshold will trigger info event if the file system used space exceeds this threshold. Default value is 0 (disabled).                   | [optional] 
**HighThreshold** | Pointer to **int32** |                  The high threshold will trigger info event if the file system used space exceeds this threshold. Default value is 75%. (set to 0 to disable)                  | [optional] 
**WarningThreshold** | Pointer to **int32** |                      The warning threshold will trigger alert event if the file system used space exceeds this threshold. Default value is 95%. (set to 0 to disable)                  | [optional] 

## Methods

### NewFilesystemModifyArguments

`func NewFilesystemModifyArguments() *FilesystemModifyArguments`

NewFilesystemModifyArguments instantiates a new FilesystemModifyArguments object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewFilesystemModifyArgumentsWithDefaults

`func NewFilesystemModifyArgumentsWithDefaults() *FilesystemModifyArguments`

NewFilesystemModifyArgumentsWithDefaults instantiates a new FilesystemModifyArguments object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetDescription

`func (o *FilesystemModifyArguments) GetDescription() string`

GetDescription returns the Description field if non-nil, zero value otherwise.

### GetDescriptionOk

`func (o *FilesystemModifyArguments) GetDescriptionOk() (*string, bool)`

GetDescriptionOk returns a tuple with the Description field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetDescription

`func (o *FilesystemModifyArguments) SetDescription(v string)`

SetDescription sets Description field to given value.

### HasDescription

`func (o *FilesystemModifyArguments) HasDescription() bool`

HasDescription returns a boolean if a field has been set.

### GetServiceLevel

`func (o *FilesystemModifyArguments) GetServiceLevel() string`

GetServiceLevel returns the ServiceLevel field if non-nil, zero value otherwise.

### GetServiceLevelOk

`func (o *FilesystemModifyArguments) GetServiceLevelOk() (*string, bool)`

GetServiceLevelOk returns a tuple with the ServiceLevel field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetServiceLevel

`func (o *FilesystemModifyArguments) SetServiceLevel(v string)`

SetServiceLevel sets ServiceLevel field to given value.

### HasServiceLevel

`func (o *FilesystemModifyArguments) HasServiceLevel() bool`

HasServiceLevel returns a boolean if a field has been set.

### GetDataReduction

`func (o *FilesystemModifyArguments) GetDataReduction() bool`

GetDataReduction returns the DataReduction field if non-nil, zero value otherwise.

### GetDataReductionOk

`func (o *FilesystemModifyArguments) GetDataReductionOk() (*bool, bool)`

GetDataReductionOk returns a tuple with the DataReduction field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetDataReduction

`func (o *FilesystemModifyArguments) SetDataReduction(v bool)`

SetDataReduction sets DataReduction field to given value.

### HasDataReduction

`func (o *FilesystemModifyArguments) HasDataReduction() bool`

HasDataReduction returns a boolean if a field has been set.

### GetSizeTotal

`func (o *FilesystemModifyArguments) GetSizeTotal() int64`

GetSizeTotal returns the SizeTotal field if non-nil, zero value otherwise.

### GetSizeTotalOk

`func (o *FilesystemModifyArguments) GetSizeTotalOk() (*int64, bool)`

GetSizeTotalOk returns a tuple with the SizeTotal field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetSizeTotal

`func (o *FilesystemModifyArguments) SetSizeTotal(v int64)`

SetSizeTotal sets SizeTotal field to given value.

### HasSizeTotal

`func (o *FilesystemModifyArguments) HasSizeTotal() bool`

HasSizeTotal returns a boolean if a field has been set.

### GetSmbSyncWrites

`func (o *FilesystemModifyArguments) GetSmbSyncWrites() bool`

GetSmbSyncWrites returns the SmbSyncWrites field if non-nil, zero value otherwise.

### GetSmbSyncWritesOk

`func (o *FilesystemModifyArguments) GetSmbSyncWritesOk() (*bool, bool)`

GetSmbSyncWritesOk returns a tuple with the SmbSyncWrites field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetSmbSyncWrites

`func (o *FilesystemModifyArguments) SetSmbSyncWrites(v bool)`

SetSmbSyncWrites sets SmbSyncWrites field to given value.

### HasSmbSyncWrites

`func (o *FilesystemModifyArguments) HasSmbSyncWrites() bool`

HasSmbSyncWrites returns a boolean if a field has been set.

### GetSmbOpLocks

`func (o *FilesystemModifyArguments) GetSmbOpLocks() bool`

GetSmbOpLocks returns the SmbOpLocks field if non-nil, zero value otherwise.

### GetSmbOpLocksOk

`func (o *FilesystemModifyArguments) GetSmbOpLocksOk() (*bool, bool)`

GetSmbOpLocksOk returns a tuple with the SmbOpLocks field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetSmbOpLocks

`func (o *FilesystemModifyArguments) SetSmbOpLocks(v bool)`

SetSmbOpLocks sets SmbOpLocks field to given value.

### HasSmbOpLocks

`func (o *FilesystemModifyArguments) HasSmbOpLocks() bool`

HasSmbOpLocks returns a boolean if a field has been set.

### GetSmbNotifyOnAccess

`func (o *FilesystemModifyArguments) GetSmbNotifyOnAccess() bool`

GetSmbNotifyOnAccess returns the SmbNotifyOnAccess field if non-nil, zero value otherwise.

### GetSmbNotifyOnAccessOk

`func (o *FilesystemModifyArguments) GetSmbNotifyOnAccessOk() (*bool, bool)`

GetSmbNotifyOnAccessOk returns a tuple with the SmbNotifyOnAccess field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetSmbNotifyOnAccess

`func (o *FilesystemModifyArguments) SetSmbNotifyOnAccess(v bool)`

SetSmbNotifyOnAccess sets SmbNotifyOnAccess field to given value.

### HasSmbNotifyOnAccess

`func (o *FilesystemModifyArguments) HasSmbNotifyOnAccess() bool`

HasSmbNotifyOnAccess returns a boolean if a field has been set.

### GetSmbNotifyOnWrite

`func (o *FilesystemModifyArguments) GetSmbNotifyOnWrite() bool`

GetSmbNotifyOnWrite returns the SmbNotifyOnWrite field if non-nil, zero value otherwise.

### GetSmbNotifyOnWriteOk

`func (o *FilesystemModifyArguments) GetSmbNotifyOnWriteOk() (*bool, bool)`

GetSmbNotifyOnWriteOk returns a tuple with the SmbNotifyOnWrite field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetSmbNotifyOnWrite

`func (o *FilesystemModifyArguments) SetSmbNotifyOnWrite(v bool)`

SetSmbNotifyOnWrite sets SmbNotifyOnWrite field to given value.

### HasSmbNotifyOnWrite

`func (o *FilesystemModifyArguments) HasSmbNotifyOnWrite() bool`

HasSmbNotifyOnWrite returns a boolean if a field has been set.

### GetSmbNotifyOnChangeDirDepth

`func (o *FilesystemModifyArguments) GetSmbNotifyOnChangeDirDepth() int32`

GetSmbNotifyOnChangeDirDepth returns the SmbNotifyOnChangeDirDepth field if non-nil, zero value otherwise.

### GetSmbNotifyOnChangeDirDepthOk

`func (o *FilesystemModifyArguments) GetSmbNotifyOnChangeDirDepthOk() (*int32, bool)`

GetSmbNotifyOnChangeDirDepthOk returns a tuple with the SmbNotifyOnChangeDirDepth field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetSmbNotifyOnChangeDirDepth

`func (o *FilesystemModifyArguments) SetSmbNotifyOnChangeDirDepth(v int32)`

SetSmbNotifyOnChangeDirDepth sets SmbNotifyOnChangeDirDepth field to given value.

### HasSmbNotifyOnChangeDirDepth

`func (o *FilesystemModifyArguments) HasSmbNotifyOnChangeDirDepth() bool`

HasSmbNotifyOnChangeDirDepth returns a boolean if a field has been set.

### GetSmbNoNotify

`func (o *FilesystemModifyArguments) GetSmbNoNotify() bool`

GetSmbNoNotify returns the SmbNoNotify field if non-nil, zero value otherwise.

### GetSmbNoNotifyOk

`func (o *FilesystemModifyArguments) GetSmbNoNotifyOk() (*bool, bool)`

GetSmbNoNotifyOk returns a tuple with the SmbNoNotify field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetSmbNoNotify

`func (o *FilesystemModifyArguments) SetSmbNoNotify(v bool)`

SetSmbNoNotify sets SmbNoNotify field to given value.

### HasSmbNoNotify

`func (o *FilesystemModifyArguments) HasSmbNoNotify() bool`

HasSmbNoNotify returns a boolean if a field has been set.

### GetEventNotifications

`func (o *FilesystemModifyArguments) GetEventNotifications() string`

GetEventNotifications returns the EventNotifications field if non-nil, zero value otherwise.

### GetEventNotificationsOk

`func (o *FilesystemModifyArguments) GetEventNotificationsOk() (*string, bool)`

GetEventNotificationsOk returns a tuple with the EventNotifications field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetEventNotifications

`func (o *FilesystemModifyArguments) SetEventNotifications(v string)`

SetEventNotifications sets EventNotifications field to given value.

### HasEventNotifications

`func (o *FilesystemModifyArguments) HasEventNotifications() bool`

HasEventNotifications returns a boolean if a field has been set.

### GetAccessPolicy

`func (o *FilesystemModifyArguments) GetAccessPolicy() string`

GetAccessPolicy returns the AccessPolicy field if non-nil, zero value otherwise.

### GetAccessPolicyOk

`func (o *FilesystemModifyArguments) GetAccessPolicyOk() (*string, bool)`

GetAccessPolicyOk returns a tuple with the AccessPolicy field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetAccessPolicy

`func (o *FilesystemModifyArguments) SetAccessPolicy(v string)`

SetAccessPolicy sets AccessPolicy field to given value.

### HasAccessPolicy

`func (o *FilesystemModifyArguments) HasAccessPolicy() bool`

HasAccessPolicy returns a boolean if a field has been set.

### GetLockingPolicy

`func (o *FilesystemModifyArguments) GetLockingPolicy() string`

GetLockingPolicy returns the LockingPolicy field if non-nil, zero value otherwise.

### GetLockingPolicyOk

`func (o *FilesystemModifyArguments) GetLockingPolicyOk() (*string, bool)`

GetLockingPolicyOk returns a tuple with the LockingPolicy field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetLockingPolicy

`func (o *FilesystemModifyArguments) SetLockingPolicy(v string)`

SetLockingPolicy sets LockingPolicy field to given value.

### HasLockingPolicy

`func (o *FilesystemModifyArguments) HasLockingPolicy() bool`

HasLockingPolicy returns a boolean if a field has been set.

### GetFolderRenamePolicy

`func (o *FilesystemModifyArguments) GetFolderRenamePolicy() string`

GetFolderRenamePolicy returns the FolderRenamePolicy field if non-nil, zero value otherwise.

### GetFolderRenamePolicyOk

`func (o *FilesystemModifyArguments) GetFolderRenamePolicyOk() (*string, bool)`

GetFolderRenamePolicyOk returns a tuple with the FolderRenamePolicy field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetFolderRenamePolicy

`func (o *FilesystemModifyArguments) SetFolderRenamePolicy(v string)`

SetFolderRenamePolicy sets FolderRenamePolicy field to given value.

### HasFolderRenamePolicy

`func (o *FilesystemModifyArguments) HasFolderRenamePolicy() bool`

HasFolderRenamePolicy returns a boolean if a field has been set.

### GetFlrMinRet

`func (o *FilesystemModifyArguments) GetFlrMinRet() string`

GetFlrMinRet returns the FlrMinRet field if non-nil, zero value otherwise.

### GetFlrMinRetOk

`func (o *FilesystemModifyArguments) GetFlrMinRetOk() (*string, bool)`

GetFlrMinRetOk returns a tuple with the FlrMinRet field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetFlrMinRet

`func (o *FilesystemModifyArguments) SetFlrMinRet(v string)`

SetFlrMinRet sets FlrMinRet field to given value.

### HasFlrMinRet

`func (o *FilesystemModifyArguments) HasFlrMinRet() bool`

HasFlrMinRet returns a boolean if a field has been set.

### GetFlrDefRet

`func (o *FilesystemModifyArguments) GetFlrDefRet() string`

GetFlrDefRet returns the FlrDefRet field if non-nil, zero value otherwise.

### GetFlrDefRetOk

`func (o *FilesystemModifyArguments) GetFlrDefRetOk() (*string, bool)`

GetFlrDefRetOk returns a tuple with the FlrDefRet field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetFlrDefRet

`func (o *FilesystemModifyArguments) SetFlrDefRet(v string)`

SetFlrDefRet sets FlrDefRet field to given value.

### HasFlrDefRet

`func (o *FilesystemModifyArguments) HasFlrDefRet() bool`

HasFlrDefRet returns a boolean if a field has been set.

### GetFlrMaxRet

`func (o *FilesystemModifyArguments) GetFlrMaxRet() string`

GetFlrMaxRet returns the FlrMaxRet field if non-nil, zero value otherwise.

### GetFlrMaxRetOk

`func (o *FilesystemModifyArguments) GetFlrMaxRetOk() (*string, bool)`

GetFlrMaxRetOk returns a tuple with the FlrMaxRet field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetFlrMaxRet

`func (o *FilesystemModifyArguments) SetFlrMaxRet(v string)`

SetFlrMaxRet sets FlrMaxRet field to given value.

### HasFlrMaxRet

`func (o *FilesystemModifyArguments) HasFlrMaxRet() bool`

HasFlrMaxRet returns a boolean if a field has been set.

### GetFlrAutoLock

`func (o *FilesystemModifyArguments) GetFlrAutoLock() bool`

GetFlrAutoLock returns the FlrAutoLock field if non-nil, zero value otherwise.

### GetFlrAutoLockOk

`func (o *FilesystemModifyArguments) GetFlrAutoLockOk() (*bool, bool)`

GetFlrAutoLockOk returns a tuple with the FlrAutoLock field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetFlrAutoLock

`func (o *FilesystemModifyArguments) SetFlrAutoLock(v bool)`

SetFlrAutoLock sets FlrAutoLock field to given value.

### HasFlrAutoLock

`func (o *FilesystemModifyArguments) HasFlrAutoLock() bool`

HasFlrAutoLock returns a boolean if a field has been set.

### GetFlrAutoDelete

`func (o *FilesystemModifyArguments) GetFlrAutoDelete() bool`

GetFlrAutoDelete returns the FlrAutoDelete field if non-nil, zero value otherwise.

### GetFlrAutoDeleteOk

`func (o *FilesystemModifyArguments) GetFlrAutoDeleteOk() (*bool, bool)`

GetFlrAutoDeleteOk returns a tuple with the FlrAutoDelete field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetFlrAutoDelete

`func (o *FilesystemModifyArguments) SetFlrAutoDelete(v bool)`

SetFlrAutoDelete sets FlrAutoDelete field to given value.

### HasFlrAutoDelete

`func (o *FilesystemModifyArguments) HasFlrAutoDelete() bool`

HasFlrAutoDelete returns a boolean if a field has been set.

### GetFlrPolicyInterval

`func (o *FilesystemModifyArguments) GetFlrPolicyInterval() int32`

GetFlrPolicyInterval returns the FlrPolicyInterval field if non-nil, zero value otherwise.

### GetFlrPolicyIntervalOk

`func (o *FilesystemModifyArguments) GetFlrPolicyIntervalOk() (*int32, bool)`

GetFlrPolicyIntervalOk returns a tuple with the FlrPolicyInterval field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetFlrPolicyInterval

`func (o *FilesystemModifyArguments) SetFlrPolicyInterval(v int32)`

SetFlrPolicyInterval sets FlrPolicyInterval field to given value.

### HasFlrPolicyInterval

`func (o *FilesystemModifyArguments) HasFlrPolicyInterval() bool`

HasFlrPolicyInterval returns a boolean if a field has been set.

### GetInfoThreshold

`func (o *FilesystemModifyArguments) GetInfoThreshold() int32`

GetInfoThreshold returns the InfoThreshold field if non-nil, zero value otherwise.

### GetInfoThresholdOk

`func (o *FilesystemModifyArguments) GetInfoThresholdOk() (*int32, bool)`

GetInfoThresholdOk returns a tuple with the InfoThreshold field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetInfoThreshold

`func (o *FilesystemModifyArguments) SetInfoThreshold(v int32)`

SetInfoThreshold sets InfoThreshold field to given value.

### HasInfoThreshold

`func (o *FilesystemModifyArguments) HasInfoThreshold() bool`

HasInfoThreshold returns a boolean if a field has been set.

### GetHighThreshold

`func (o *FilesystemModifyArguments) GetHighThreshold() int32`

GetHighThreshold returns the HighThreshold field if non-nil, zero value otherwise.

### GetHighThresholdOk

`func (o *FilesystemModifyArguments) GetHighThresholdOk() (*int32, bool)`

GetHighThresholdOk returns a tuple with the HighThreshold field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetHighThreshold

`func (o *FilesystemModifyArguments) SetHighThreshold(v int32)`

SetHighThreshold sets HighThreshold field to given value.

### HasHighThreshold

`func (o *FilesystemModifyArguments) HasHighThreshold() bool`

HasHighThreshold returns a boolean if a field has been set.

### GetWarningThreshold

`func (o *FilesystemModifyArguments) GetWarningThreshold() int32`

GetWarningThreshold returns the WarningThreshold field if non-nil, zero value otherwise.

### GetWarningThresholdOk

`func (o *FilesystemModifyArguments) GetWarningThresholdOk() (*int32, bool)`

GetWarningThresholdOk returns a tuple with the WarningThreshold field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetWarningThreshold

`func (o *FilesystemModifyArguments) SetWarningThreshold(v int32)`

SetWarningThreshold sets WarningThreshold field to given value.

### HasWarningThreshold

`func (o *FilesystemModifyArguments) HasWarningThreshold() bool`

HasWarningThreshold returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


