# InitiatorByPortInfo

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**FirstAvailableDate** | Pointer to **int64** |  | [optional] 
**LastAvailableDate** | Pointer to **int64** |  | [optional] 
**InitiatorByPortId** | **string** | initiatorByPortId | 

## Methods

### NewInitiatorByPortInfo

`func NewInitiatorByPortInfo(initiatorByPortId string, ) *InitiatorByPortInfo`

NewInitiatorByPortInfo instantiates a new InitiatorByPortInfo object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewInitiatorByPortInfoWithDefaults

`func NewInitiatorByPortInfoWithDefaults() *InitiatorByPortInfo`

NewInitiatorByPortInfoWithDefaults instantiates a new InitiatorByPortInfo object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetFirstAvailableDate

`func (o *InitiatorByPortInfo) GetFirstAvailableDate() int64`

GetFirstAvailableDate returns the FirstAvailableDate field if non-nil, zero value otherwise.

### GetFirstAvailableDateOk

`func (o *InitiatorByPortInfo) GetFirstAvailableDateOk() (*int64, bool)`

GetFirstAvailableDateOk returns a tuple with the FirstAvailableDate field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetFirstAvailableDate

`func (o *InitiatorByPortInfo) SetFirstAvailableDate(v int64)`

SetFirstAvailableDate sets FirstAvailableDate field to given value.

### HasFirstAvailableDate

`func (o *InitiatorByPortInfo) HasFirstAvailableDate() bool`

HasFirstAvailableDate returns a boolean if a field has been set.

### GetLastAvailableDate

`func (o *InitiatorByPortInfo) GetLastAvailableDate() int64`

GetLastAvailableDate returns the LastAvailableDate field if non-nil, zero value otherwise.

### GetLastAvailableDateOk

`func (o *InitiatorByPortInfo) GetLastAvailableDateOk() (*int64, bool)`

GetLastAvailableDateOk returns a tuple with the LastAvailableDate field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetLastAvailableDate

`func (o *InitiatorByPortInfo) SetLastAvailableDate(v int64)`

SetLastAvailableDate sets LastAvailableDate field to given value.

### HasLastAvailableDate

`func (o *InitiatorByPortInfo) HasLastAvailableDate() bool`

HasLastAvailableDate returns a boolean if a field has been set.

### GetInitiatorByPortId

`func (o *InitiatorByPortInfo) GetInitiatorByPortId() string`

GetInitiatorByPortId returns the InitiatorByPortId field if non-nil, zero value otherwise.

### GetInitiatorByPortIdOk

`func (o *InitiatorByPortInfo) GetInitiatorByPortIdOk() (*string, bool)`

GetInitiatorByPortIdOk returns a tuple with the InitiatorByPortId field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetInitiatorByPortId

`func (o *InitiatorByPortInfo) SetInitiatorByPortId(v string)`

SetInitiatorByPortId sets InitiatorByPortId field to given value.



[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


