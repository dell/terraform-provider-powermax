# CloudSystemCertificates

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**CloudCertificate** | Pointer to **[]string** | cloud_certificate | [optional] 

## Methods

### NewCloudSystemCertificates

`func NewCloudSystemCertificates() *CloudSystemCertificates`

NewCloudSystemCertificates instantiates a new CloudSystemCertificates object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewCloudSystemCertificatesWithDefaults

`func NewCloudSystemCertificatesWithDefaults() *CloudSystemCertificates`

NewCloudSystemCertificatesWithDefaults instantiates a new CloudSystemCertificates object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetCloudCertificate

`func (o *CloudSystemCertificates) GetCloudCertificate() []string`

GetCloudCertificate returns the CloudCertificate field if non-nil, zero value otherwise.

### GetCloudCertificateOk

`func (o *CloudSystemCertificates) GetCloudCertificateOk() (*[]string, bool)`

GetCloudCertificateOk returns a tuple with the CloudCertificate field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetCloudCertificate

`func (o *CloudSystemCertificates) SetCloudCertificate(v []string)`

SetCloudCertificate sets CloudCertificate field to given value.

### HasCloudCertificate

`func (o *CloudSystemCertificates) HasCloudCertificate() bool`

HasCloudCertificate returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


