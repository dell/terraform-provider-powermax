# CreateRMTEntryParamType

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ExecutionOption** | Pointer to **string** |  | [optional] [default to "SYNCHRONOUS"]
**RemoteSymmetrixId** | **string** | The Remote System ID. | 
**RmtTargetList** | [**[]RmtTargetInfoType**](RmtTargetInfoType.md) | &lt;p&gt;The Remote Targets.&lt;/p&gt; | 

## Methods

### NewCreateRMTEntryParamType

`func NewCreateRMTEntryParamType(remoteSymmetrixId string, rmtTargetList []RmtTargetInfoType, ) *CreateRMTEntryParamType`

NewCreateRMTEntryParamType instantiates a new CreateRMTEntryParamType object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewCreateRMTEntryParamTypeWithDefaults

`func NewCreateRMTEntryParamTypeWithDefaults() *CreateRMTEntryParamType`

NewCreateRMTEntryParamTypeWithDefaults instantiates a new CreateRMTEntryParamType object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetExecutionOption

`func (o *CreateRMTEntryParamType) GetExecutionOption() string`

GetExecutionOption returns the ExecutionOption field if non-nil, zero value otherwise.

### GetExecutionOptionOk

`func (o *CreateRMTEntryParamType) GetExecutionOptionOk() (*string, bool)`

GetExecutionOptionOk returns a tuple with the ExecutionOption field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetExecutionOption

`func (o *CreateRMTEntryParamType) SetExecutionOption(v string)`

SetExecutionOption sets ExecutionOption field to given value.

### HasExecutionOption

`func (o *CreateRMTEntryParamType) HasExecutionOption() bool`

HasExecutionOption returns a boolean if a field has been set.

### GetRemoteSymmetrixId

`func (o *CreateRMTEntryParamType) GetRemoteSymmetrixId() string`

GetRemoteSymmetrixId returns the RemoteSymmetrixId field if non-nil, zero value otherwise.

### GetRemoteSymmetrixIdOk

`func (o *CreateRMTEntryParamType) GetRemoteSymmetrixIdOk() (*string, bool)`

GetRemoteSymmetrixIdOk returns a tuple with the RemoteSymmetrixId field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetRemoteSymmetrixId

`func (o *CreateRMTEntryParamType) SetRemoteSymmetrixId(v string)`

SetRemoteSymmetrixId sets RemoteSymmetrixId field to given value.


### GetRmtTargetList

`func (o *CreateRMTEntryParamType) GetRmtTargetList() []RmtTargetInfoType`

GetRmtTargetList returns the RmtTargetList field if non-nil, zero value otherwise.

### GetRmtTargetListOk

`func (o *CreateRMTEntryParamType) GetRmtTargetListOk() (*[]RmtTargetInfoType, bool)`

GetRmtTargetListOk returns a tuple with the RmtTargetList field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetRmtTargetList

`func (o *CreateRMTEntryParamType) SetRmtTargetList(v []RmtTargetInfoType)`

SetRmtTargetList sets RmtTargetList field to given value.



[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


