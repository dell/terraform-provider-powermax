# ListIpRouteResult

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**IpRouteId** | Pointer to **[]string** | ipRouteId | [optional] 

## Methods

### NewListIpRouteResult

`func NewListIpRouteResult() *ListIpRouteResult`

NewListIpRouteResult instantiates a new ListIpRouteResult object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewListIpRouteResultWithDefaults

`func NewListIpRouteResultWithDefaults() *ListIpRouteResult`

NewListIpRouteResultWithDefaults instantiates a new ListIpRouteResult object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetIpRouteId

`func (o *ListIpRouteResult) GetIpRouteId() []string`

GetIpRouteId returns the IpRouteId field if non-nil, zero value otherwise.

### GetIpRouteIdOk

`func (o *ListIpRouteResult) GetIpRouteIdOk() (*[]string, bool)`

GetIpRouteIdOk returns a tuple with the IpRouteId field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetIpRouteId

`func (o *ListIpRouteResult) SetIpRouteId(v []string)`

SetIpRouteId sets IpRouteId field to given value.

### HasIpRouteId

`func (o *ListIpRouteResult) HasIpRouteId() bool`

HasIpRouteId returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


