# CachePartitionInfo

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**FirstAvailableDate** | Pointer to **int64** |  | [optional] 
**LastAvailableDate** | Pointer to **int64** |  | [optional] 
**CachePartitionId** | **string** | cachePartitionId | 

## Methods

### NewCachePartitionInfo

`func NewCachePartitionInfo(cachePartitionId string, ) *CachePartitionInfo`

NewCachePartitionInfo instantiates a new CachePartitionInfo object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewCachePartitionInfoWithDefaults

`func NewCachePartitionInfoWithDefaults() *CachePartitionInfo`

NewCachePartitionInfoWithDefaults instantiates a new CachePartitionInfo object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetFirstAvailableDate

`func (o *CachePartitionInfo) GetFirstAvailableDate() int64`

GetFirstAvailableDate returns the FirstAvailableDate field if non-nil, zero value otherwise.

### GetFirstAvailableDateOk

`func (o *CachePartitionInfo) GetFirstAvailableDateOk() (*int64, bool)`

GetFirstAvailableDateOk returns a tuple with the FirstAvailableDate field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetFirstAvailableDate

`func (o *CachePartitionInfo) SetFirstAvailableDate(v int64)`

SetFirstAvailableDate sets FirstAvailableDate field to given value.

### HasFirstAvailableDate

`func (o *CachePartitionInfo) HasFirstAvailableDate() bool`

HasFirstAvailableDate returns a boolean if a field has been set.

### GetLastAvailableDate

`func (o *CachePartitionInfo) GetLastAvailableDate() int64`

GetLastAvailableDate returns the LastAvailableDate field if non-nil, zero value otherwise.

### GetLastAvailableDateOk

`func (o *CachePartitionInfo) GetLastAvailableDateOk() (*int64, bool)`

GetLastAvailableDateOk returns a tuple with the LastAvailableDate field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetLastAvailableDate

`func (o *CachePartitionInfo) SetLastAvailableDate(v int64)`

SetLastAvailableDate sets LastAvailableDate field to given value.

### HasLastAvailableDate

`func (o *CachePartitionInfo) HasLastAvailableDate() bool`

HasLastAvailableDate returns a boolean if a field has been set.

### GetCachePartitionId

`func (o *CachePartitionInfo) GetCachePartitionId() string`

GetCachePartitionId returns the CachePartitionId field if non-nil, zero value otherwise.

### GetCachePartitionIdOk

`func (o *CachePartitionInfo) GetCachePartitionIdOk() (*string, bool)`

GetCachePartitionIdOk returns a tuple with the CachePartitionId field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetCachePartitionId

`func (o *CachePartitionInfo) SetCachePartitionId(v string)`

SetCachePartitionId sets CachePartitionId field to given value.



[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


