# ArrayAlertSummary

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**AlertCount** | Pointer to **int32** | alert_count | [optional] 
**AllUnacknowledgedCount** | Pointer to **int32** | all_unacknowledged_count | [optional] 
**FatalUnacknowledgedCount** | Pointer to **int32** | fatal_unacknowledged_count | [optional] 
**CriticalUnacknowledgedCount** | Pointer to **int32** | critical_unacknowledged_count | [optional] 
**WarningUnacknowledgedCount** | Pointer to **int32** | warning_unacknowledged_count | [optional] 
**InfoUnacknowledgedCount** | Pointer to **int32** | info_unacknowledged_count | [optional] 
**MinorUnacknowledgedCount** | Pointer to **int32** | minor_unacknowledged_count | [optional] 
**NormalUnacknowledgedCount** | Pointer to **int32** | normal_unacknowledged_count | [optional] 
**AllAcknowledgedCount** | Pointer to **int32** | all_acknowledged_count | [optional] 
**FatalAcknowledgedCount** | Pointer to **int32** | fatal_acknowledged_count | [optional] 
**CriticalAcknowledgedCount** | Pointer to **int32** | critical_acknowledged_count | [optional] 
**WarningAcknowledgedCount** | Pointer to **int32** | warning_acknowledged_count | [optional] 
**InfoAcknowledgedCount** | Pointer to **int32** | info_acknowledged_count | [optional] 
**MinorAcknowledgedCount** | Pointer to **int32** | minor_acknowledged_count | [optional] 
**NormalAcknowledgedCount** | Pointer to **int32** | normal_acknowledged_count | [optional] 

## Methods

### NewArrayAlertSummary

`func NewArrayAlertSummary() *ArrayAlertSummary`

NewArrayAlertSummary instantiates a new ArrayAlertSummary object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewArrayAlertSummaryWithDefaults

`func NewArrayAlertSummaryWithDefaults() *ArrayAlertSummary`

NewArrayAlertSummaryWithDefaults instantiates a new ArrayAlertSummary object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetAlertCount

`func (o *ArrayAlertSummary) GetAlertCount() int32`

GetAlertCount returns the AlertCount field if non-nil, zero value otherwise.

### GetAlertCountOk

`func (o *ArrayAlertSummary) GetAlertCountOk() (*int32, bool)`

GetAlertCountOk returns a tuple with the AlertCount field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetAlertCount

`func (o *ArrayAlertSummary) SetAlertCount(v int32)`

SetAlertCount sets AlertCount field to given value.

### HasAlertCount

`func (o *ArrayAlertSummary) HasAlertCount() bool`

HasAlertCount returns a boolean if a field has been set.

### GetAllUnacknowledgedCount

`func (o *ArrayAlertSummary) GetAllUnacknowledgedCount() int32`

GetAllUnacknowledgedCount returns the AllUnacknowledgedCount field if non-nil, zero value otherwise.

### GetAllUnacknowledgedCountOk

`func (o *ArrayAlertSummary) GetAllUnacknowledgedCountOk() (*int32, bool)`

GetAllUnacknowledgedCountOk returns a tuple with the AllUnacknowledgedCount field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetAllUnacknowledgedCount

`func (o *ArrayAlertSummary) SetAllUnacknowledgedCount(v int32)`

SetAllUnacknowledgedCount sets AllUnacknowledgedCount field to given value.

### HasAllUnacknowledgedCount

`func (o *ArrayAlertSummary) HasAllUnacknowledgedCount() bool`

HasAllUnacknowledgedCount returns a boolean if a field has been set.

### GetFatalUnacknowledgedCount

`func (o *ArrayAlertSummary) GetFatalUnacknowledgedCount() int32`

GetFatalUnacknowledgedCount returns the FatalUnacknowledgedCount field if non-nil, zero value otherwise.

### GetFatalUnacknowledgedCountOk

`func (o *ArrayAlertSummary) GetFatalUnacknowledgedCountOk() (*int32, bool)`

GetFatalUnacknowledgedCountOk returns a tuple with the FatalUnacknowledgedCount field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetFatalUnacknowledgedCount

`func (o *ArrayAlertSummary) SetFatalUnacknowledgedCount(v int32)`

SetFatalUnacknowledgedCount sets FatalUnacknowledgedCount field to given value.

### HasFatalUnacknowledgedCount

`func (o *ArrayAlertSummary) HasFatalUnacknowledgedCount() bool`

HasFatalUnacknowledgedCount returns a boolean if a field has been set.

### GetCriticalUnacknowledgedCount

`func (o *ArrayAlertSummary) GetCriticalUnacknowledgedCount() int32`

GetCriticalUnacknowledgedCount returns the CriticalUnacknowledgedCount field if non-nil, zero value otherwise.

### GetCriticalUnacknowledgedCountOk

`func (o *ArrayAlertSummary) GetCriticalUnacknowledgedCountOk() (*int32, bool)`

GetCriticalUnacknowledgedCountOk returns a tuple with the CriticalUnacknowledgedCount field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetCriticalUnacknowledgedCount

`func (o *ArrayAlertSummary) SetCriticalUnacknowledgedCount(v int32)`

SetCriticalUnacknowledgedCount sets CriticalUnacknowledgedCount field to given value.

### HasCriticalUnacknowledgedCount

`func (o *ArrayAlertSummary) HasCriticalUnacknowledgedCount() bool`

HasCriticalUnacknowledgedCount returns a boolean if a field has been set.

### GetWarningUnacknowledgedCount

`func (o *ArrayAlertSummary) GetWarningUnacknowledgedCount() int32`

GetWarningUnacknowledgedCount returns the WarningUnacknowledgedCount field if non-nil, zero value otherwise.

### GetWarningUnacknowledgedCountOk

`func (o *ArrayAlertSummary) GetWarningUnacknowledgedCountOk() (*int32, bool)`

GetWarningUnacknowledgedCountOk returns a tuple with the WarningUnacknowledgedCount field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetWarningUnacknowledgedCount

`func (o *ArrayAlertSummary) SetWarningUnacknowledgedCount(v int32)`

SetWarningUnacknowledgedCount sets WarningUnacknowledgedCount field to given value.

### HasWarningUnacknowledgedCount

`func (o *ArrayAlertSummary) HasWarningUnacknowledgedCount() bool`

HasWarningUnacknowledgedCount returns a boolean if a field has been set.

### GetInfoUnacknowledgedCount

`func (o *ArrayAlertSummary) GetInfoUnacknowledgedCount() int32`

GetInfoUnacknowledgedCount returns the InfoUnacknowledgedCount field if non-nil, zero value otherwise.

### GetInfoUnacknowledgedCountOk

`func (o *ArrayAlertSummary) GetInfoUnacknowledgedCountOk() (*int32, bool)`

GetInfoUnacknowledgedCountOk returns a tuple with the InfoUnacknowledgedCount field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetInfoUnacknowledgedCount

`func (o *ArrayAlertSummary) SetInfoUnacknowledgedCount(v int32)`

SetInfoUnacknowledgedCount sets InfoUnacknowledgedCount field to given value.

### HasInfoUnacknowledgedCount

`func (o *ArrayAlertSummary) HasInfoUnacknowledgedCount() bool`

HasInfoUnacknowledgedCount returns a boolean if a field has been set.

### GetMinorUnacknowledgedCount

`func (o *ArrayAlertSummary) GetMinorUnacknowledgedCount() int32`

GetMinorUnacknowledgedCount returns the MinorUnacknowledgedCount field if non-nil, zero value otherwise.

### GetMinorUnacknowledgedCountOk

`func (o *ArrayAlertSummary) GetMinorUnacknowledgedCountOk() (*int32, bool)`

GetMinorUnacknowledgedCountOk returns a tuple with the MinorUnacknowledgedCount field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetMinorUnacknowledgedCount

`func (o *ArrayAlertSummary) SetMinorUnacknowledgedCount(v int32)`

SetMinorUnacknowledgedCount sets MinorUnacknowledgedCount field to given value.

### HasMinorUnacknowledgedCount

`func (o *ArrayAlertSummary) HasMinorUnacknowledgedCount() bool`

HasMinorUnacknowledgedCount returns a boolean if a field has been set.

### GetNormalUnacknowledgedCount

`func (o *ArrayAlertSummary) GetNormalUnacknowledgedCount() int32`

GetNormalUnacknowledgedCount returns the NormalUnacknowledgedCount field if non-nil, zero value otherwise.

### GetNormalUnacknowledgedCountOk

`func (o *ArrayAlertSummary) GetNormalUnacknowledgedCountOk() (*int32, bool)`

GetNormalUnacknowledgedCountOk returns a tuple with the NormalUnacknowledgedCount field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetNormalUnacknowledgedCount

`func (o *ArrayAlertSummary) SetNormalUnacknowledgedCount(v int32)`

SetNormalUnacknowledgedCount sets NormalUnacknowledgedCount field to given value.

### HasNormalUnacknowledgedCount

`func (o *ArrayAlertSummary) HasNormalUnacknowledgedCount() bool`

HasNormalUnacknowledgedCount returns a boolean if a field has been set.

### GetAllAcknowledgedCount

`func (o *ArrayAlertSummary) GetAllAcknowledgedCount() int32`

GetAllAcknowledgedCount returns the AllAcknowledgedCount field if non-nil, zero value otherwise.

### GetAllAcknowledgedCountOk

`func (o *ArrayAlertSummary) GetAllAcknowledgedCountOk() (*int32, bool)`

GetAllAcknowledgedCountOk returns a tuple with the AllAcknowledgedCount field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetAllAcknowledgedCount

`func (o *ArrayAlertSummary) SetAllAcknowledgedCount(v int32)`

SetAllAcknowledgedCount sets AllAcknowledgedCount field to given value.

### HasAllAcknowledgedCount

`func (o *ArrayAlertSummary) HasAllAcknowledgedCount() bool`

HasAllAcknowledgedCount returns a boolean if a field has been set.

### GetFatalAcknowledgedCount

`func (o *ArrayAlertSummary) GetFatalAcknowledgedCount() int32`

GetFatalAcknowledgedCount returns the FatalAcknowledgedCount field if non-nil, zero value otherwise.

### GetFatalAcknowledgedCountOk

`func (o *ArrayAlertSummary) GetFatalAcknowledgedCountOk() (*int32, bool)`

GetFatalAcknowledgedCountOk returns a tuple with the FatalAcknowledgedCount field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetFatalAcknowledgedCount

`func (o *ArrayAlertSummary) SetFatalAcknowledgedCount(v int32)`

SetFatalAcknowledgedCount sets FatalAcknowledgedCount field to given value.

### HasFatalAcknowledgedCount

`func (o *ArrayAlertSummary) HasFatalAcknowledgedCount() bool`

HasFatalAcknowledgedCount returns a boolean if a field has been set.

### GetCriticalAcknowledgedCount

`func (o *ArrayAlertSummary) GetCriticalAcknowledgedCount() int32`

GetCriticalAcknowledgedCount returns the CriticalAcknowledgedCount field if non-nil, zero value otherwise.

### GetCriticalAcknowledgedCountOk

`func (o *ArrayAlertSummary) GetCriticalAcknowledgedCountOk() (*int32, bool)`

GetCriticalAcknowledgedCountOk returns a tuple with the CriticalAcknowledgedCount field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetCriticalAcknowledgedCount

`func (o *ArrayAlertSummary) SetCriticalAcknowledgedCount(v int32)`

SetCriticalAcknowledgedCount sets CriticalAcknowledgedCount field to given value.

### HasCriticalAcknowledgedCount

`func (o *ArrayAlertSummary) HasCriticalAcknowledgedCount() bool`

HasCriticalAcknowledgedCount returns a boolean if a field has been set.

### GetWarningAcknowledgedCount

`func (o *ArrayAlertSummary) GetWarningAcknowledgedCount() int32`

GetWarningAcknowledgedCount returns the WarningAcknowledgedCount field if non-nil, zero value otherwise.

### GetWarningAcknowledgedCountOk

`func (o *ArrayAlertSummary) GetWarningAcknowledgedCountOk() (*int32, bool)`

GetWarningAcknowledgedCountOk returns a tuple with the WarningAcknowledgedCount field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetWarningAcknowledgedCount

`func (o *ArrayAlertSummary) SetWarningAcknowledgedCount(v int32)`

SetWarningAcknowledgedCount sets WarningAcknowledgedCount field to given value.

### HasWarningAcknowledgedCount

`func (o *ArrayAlertSummary) HasWarningAcknowledgedCount() bool`

HasWarningAcknowledgedCount returns a boolean if a field has been set.

### GetInfoAcknowledgedCount

`func (o *ArrayAlertSummary) GetInfoAcknowledgedCount() int32`

GetInfoAcknowledgedCount returns the InfoAcknowledgedCount field if non-nil, zero value otherwise.

### GetInfoAcknowledgedCountOk

`func (o *ArrayAlertSummary) GetInfoAcknowledgedCountOk() (*int32, bool)`

GetInfoAcknowledgedCountOk returns a tuple with the InfoAcknowledgedCount field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetInfoAcknowledgedCount

`func (o *ArrayAlertSummary) SetInfoAcknowledgedCount(v int32)`

SetInfoAcknowledgedCount sets InfoAcknowledgedCount field to given value.

### HasInfoAcknowledgedCount

`func (o *ArrayAlertSummary) HasInfoAcknowledgedCount() bool`

HasInfoAcknowledgedCount returns a boolean if a field has been set.

### GetMinorAcknowledgedCount

`func (o *ArrayAlertSummary) GetMinorAcknowledgedCount() int32`

GetMinorAcknowledgedCount returns the MinorAcknowledgedCount field if non-nil, zero value otherwise.

### GetMinorAcknowledgedCountOk

`func (o *ArrayAlertSummary) GetMinorAcknowledgedCountOk() (*int32, bool)`

GetMinorAcknowledgedCountOk returns a tuple with the MinorAcknowledgedCount field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetMinorAcknowledgedCount

`func (o *ArrayAlertSummary) SetMinorAcknowledgedCount(v int32)`

SetMinorAcknowledgedCount sets MinorAcknowledgedCount field to given value.

### HasMinorAcknowledgedCount

`func (o *ArrayAlertSummary) HasMinorAcknowledgedCount() bool`

HasMinorAcknowledgedCount returns a boolean if a field has been set.

### GetNormalAcknowledgedCount

`func (o *ArrayAlertSummary) GetNormalAcknowledgedCount() int32`

GetNormalAcknowledgedCount returns the NormalAcknowledgedCount field if non-nil, zero value otherwise.

### GetNormalAcknowledgedCountOk

`func (o *ArrayAlertSummary) GetNormalAcknowledgedCountOk() (*int32, bool)`

GetNormalAcknowledgedCountOk returns a tuple with the NormalAcknowledgedCount field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetNormalAcknowledgedCount

`func (o *ArrayAlertSummary) SetNormalAcknowledgedCount(v int32)`

SetNormalAcknowledgedCount sets NormalAcknowledgedCount field to given value.

### HasNormalAcknowledgedCount

`func (o *ArrayAlertSummary) HasNormalAcknowledgedCount() bool`

HasNormalAcknowledgedCount returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


