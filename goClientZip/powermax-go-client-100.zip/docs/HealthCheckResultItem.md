# HealthCheckResultItem

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ItemName** | Pointer to **string** | item_name | [optional] 
**Result** | Pointer to **bool** | result | [optional] 

## Methods

### NewHealthCheckResultItem

`func NewHealthCheckResultItem() *HealthCheckResultItem`

NewHealthCheckResultItem instantiates a new HealthCheckResultItem object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewHealthCheckResultItemWithDefaults

`func NewHealthCheckResultItemWithDefaults() *HealthCheckResultItem`

NewHealthCheckResultItemWithDefaults instantiates a new HealthCheckResultItem object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetItemName

`func (o *HealthCheckResultItem) GetItemName() string`

GetItemName returns the ItemName field if non-nil, zero value otherwise.

### GetItemNameOk

`func (o *HealthCheckResultItem) GetItemNameOk() (*string, bool)`

GetItemNameOk returns a tuple with the ItemName field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetItemName

`func (o *HealthCheckResultItem) SetItemName(v string)`

SetItemName sets ItemName field to given value.

### HasItemName

`func (o *HealthCheckResultItem) HasItemName() bool`

HasItemName returns a boolean if a field has been set.

### GetResult

`func (o *HealthCheckResultItem) GetResult() bool`

GetResult returns the Result field if non-nil, zero value otherwise.

### GetResultOk

`func (o *HealthCheckResultItem) GetResultOk() (*bool, bool)`

GetResultOk returns a tuple with the Result field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetResult

`func (o *HealthCheckResultItem) SetResult(v bool)`

SetResult sets Result field to given value.

### HasResult

`func (o *HealthCheckResultItem) HasResult() bool`

HasResult returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


