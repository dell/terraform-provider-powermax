# EditIPInterfaceParam

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ExecutionOption** | Pointer to **string** |  | [optional] [default to "SYNCHRONOUS"]
**EditIPInterfaceActionParam** | [**EditIPInterfaceActionParam**](EditIPInterfaceActionParam.md) |  | 

## Methods

### NewEditIPInterfaceParam

`func NewEditIPInterfaceParam(editIPInterfaceActionParam EditIPInterfaceActionParam, ) *EditIPInterfaceParam`

NewEditIPInterfaceParam instantiates a new EditIPInterfaceParam object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewEditIPInterfaceParamWithDefaults

`func NewEditIPInterfaceParamWithDefaults() *EditIPInterfaceParam`

NewEditIPInterfaceParamWithDefaults instantiates a new EditIPInterfaceParam object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetExecutionOption

`func (o *EditIPInterfaceParam) GetExecutionOption() string`

GetExecutionOption returns the ExecutionOption field if non-nil, zero value otherwise.

### GetExecutionOptionOk

`func (o *EditIPInterfaceParam) GetExecutionOptionOk() (*string, bool)`

GetExecutionOptionOk returns a tuple with the ExecutionOption field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetExecutionOption

`func (o *EditIPInterfaceParam) SetExecutionOption(v string)`

SetExecutionOption sets ExecutionOption field to given value.

### HasExecutionOption

`func (o *EditIPInterfaceParam) HasExecutionOption() bool`

HasExecutionOption returns a boolean if a field has been set.

### GetEditIPInterfaceActionParam

`func (o *EditIPInterfaceParam) GetEditIPInterfaceActionParam() EditIPInterfaceActionParam`

GetEditIPInterfaceActionParam returns the EditIPInterfaceActionParam field if non-nil, zero value otherwise.

### GetEditIPInterfaceActionParamOk

`func (o *EditIPInterfaceParam) GetEditIPInterfaceActionParamOk() (*EditIPInterfaceActionParam, bool)`

GetEditIPInterfaceActionParamOk returns a tuple with the EditIPInterfaceActionParam field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetEditIPInterfaceActionParam

`func (o *EditIPInterfaceParam) SetEditIPInterfaceActionParam(v EditIPInterfaceActionParam)`

SetEditIPInterfaceActionParam sets EditIPInterfaceActionParam field to given value.



[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


