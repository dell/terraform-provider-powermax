# DirectorPort

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ExecutionOption** | Pointer to **string** |  | [optional] [default to "SYNCHRONOUS"]
**SymmetrixPort** | Pointer to [**SymmetrixPort**](SymmetrixPort.md) |  | [optional] 

## Methods

### NewDirectorPort

`func NewDirectorPort() *DirectorPort`

NewDirectorPort instantiates a new DirectorPort object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewDirectorPortWithDefaults

`func NewDirectorPortWithDefaults() *DirectorPort`

NewDirectorPortWithDefaults instantiates a new DirectorPort object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetExecutionOption

`func (o *DirectorPort) GetExecutionOption() string`

GetExecutionOption returns the ExecutionOption field if non-nil, zero value otherwise.

### GetExecutionOptionOk

`func (o *DirectorPort) GetExecutionOptionOk() (*string, bool)`

GetExecutionOptionOk returns a tuple with the ExecutionOption field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetExecutionOption

`func (o *DirectorPort) SetExecutionOption(v string)`

SetExecutionOption sets ExecutionOption field to given value.

### HasExecutionOption

`func (o *DirectorPort) HasExecutionOption() bool`

HasExecutionOption returns a boolean if a field has been set.

### GetSymmetrixPort

`func (o *DirectorPort) GetSymmetrixPort() SymmetrixPort`

GetSymmetrixPort returns the SymmetrixPort field if non-nil, zero value otherwise.

### GetSymmetrixPortOk

`func (o *DirectorPort) GetSymmetrixPortOk() (*SymmetrixPort, bool)`

GetSymmetrixPortOk returns a tuple with the SymmetrixPort field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetSymmetrixPort

`func (o *DirectorPort) SetSymmetrixPort(v SymmetrixPort)`

SetSymmetrixPort sets SymmetrixPort field to given value.

### HasSymmetrixPort

`func (o *DirectorPort) HasSymmetrixPort() bool`

HasSymmetrixPort returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


