# Effective

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**UsedTb** | Pointer to **float64** | Used capacity in TB | [optional] 
**TotalTb** | Pointer to **float64** | Total capacity in TB | [optional] 
**FreeTb** | Pointer to **float64** | Free capacity in TB | [optional] 
**EffectiveUsedPercent** | Pointer to **float64** | Percentage of effective capacity used | [optional] 
**TargetTb** | Pointer to **float64** | Target effective capacity in TB | [optional] 
**AddCapacityState** | Pointer to **string** | Current state of Add Capacity operation | [optional] 
**AddCapacityEstTimeToCompletion** | Pointer to **string** | Estimated completion time of Add Capacity operation | [optional] 
**PhysicalCapacity** | Pointer to [**PhysicalCapacity**](PhysicalCapacity.md) |  | [optional] 
**EffectiveCapacityResources** | Pointer to [**EffectiveCapacityResources**](EffectiveCapacityResources.md) |  | [optional] 
**EffectiveCapacityUsage** | Pointer to [**EffectiveCapacityUsage**](EffectiveCapacityUsage.md) |  | [optional] 

## Methods

### NewEffective

`func NewEffective() *Effective`

NewEffective instantiates a new Effective object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewEffectiveWithDefaults

`func NewEffectiveWithDefaults() *Effective`

NewEffectiveWithDefaults instantiates a new Effective object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetUsedTb

`func (o *Effective) GetUsedTb() float64`

GetUsedTb returns the UsedTb field if non-nil, zero value otherwise.

### GetUsedTbOk

`func (o *Effective) GetUsedTbOk() (*float64, bool)`

GetUsedTbOk returns a tuple with the UsedTb field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetUsedTb

`func (o *Effective) SetUsedTb(v float64)`

SetUsedTb sets UsedTb field to given value.

### HasUsedTb

`func (o *Effective) HasUsedTb() bool`

HasUsedTb returns a boolean if a field has been set.

### GetTotalTb

`func (o *Effective) GetTotalTb() float64`

GetTotalTb returns the TotalTb field if non-nil, zero value otherwise.

### GetTotalTbOk

`func (o *Effective) GetTotalTbOk() (*float64, bool)`

GetTotalTbOk returns a tuple with the TotalTb field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetTotalTb

`func (o *Effective) SetTotalTb(v float64)`

SetTotalTb sets TotalTb field to given value.

### HasTotalTb

`func (o *Effective) HasTotalTb() bool`

HasTotalTb returns a boolean if a field has been set.

### GetFreeTb

`func (o *Effective) GetFreeTb() float64`

GetFreeTb returns the FreeTb field if non-nil, zero value otherwise.

### GetFreeTbOk

`func (o *Effective) GetFreeTbOk() (*float64, bool)`

GetFreeTbOk returns a tuple with the FreeTb field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetFreeTb

`func (o *Effective) SetFreeTb(v float64)`

SetFreeTb sets FreeTb field to given value.

### HasFreeTb

`func (o *Effective) HasFreeTb() bool`

HasFreeTb returns a boolean if a field has been set.

### GetEffectiveUsedPercent

`func (o *Effective) GetEffectiveUsedPercent() float64`

GetEffectiveUsedPercent returns the EffectiveUsedPercent field if non-nil, zero value otherwise.

### GetEffectiveUsedPercentOk

`func (o *Effective) GetEffectiveUsedPercentOk() (*float64, bool)`

GetEffectiveUsedPercentOk returns a tuple with the EffectiveUsedPercent field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetEffectiveUsedPercent

`func (o *Effective) SetEffectiveUsedPercent(v float64)`

SetEffectiveUsedPercent sets EffectiveUsedPercent field to given value.

### HasEffectiveUsedPercent

`func (o *Effective) HasEffectiveUsedPercent() bool`

HasEffectiveUsedPercent returns a boolean if a field has been set.

### GetTargetTb

`func (o *Effective) GetTargetTb() float64`

GetTargetTb returns the TargetTb field if non-nil, zero value otherwise.

### GetTargetTbOk

`func (o *Effective) GetTargetTbOk() (*float64, bool)`

GetTargetTbOk returns a tuple with the TargetTb field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetTargetTb

`func (o *Effective) SetTargetTb(v float64)`

SetTargetTb sets TargetTb field to given value.

### HasTargetTb

`func (o *Effective) HasTargetTb() bool`

HasTargetTb returns a boolean if a field has been set.

### GetAddCapacityState

`func (o *Effective) GetAddCapacityState() string`

GetAddCapacityState returns the AddCapacityState field if non-nil, zero value otherwise.

### GetAddCapacityStateOk

`func (o *Effective) GetAddCapacityStateOk() (*string, bool)`

GetAddCapacityStateOk returns a tuple with the AddCapacityState field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetAddCapacityState

`func (o *Effective) SetAddCapacityState(v string)`

SetAddCapacityState sets AddCapacityState field to given value.

### HasAddCapacityState

`func (o *Effective) HasAddCapacityState() bool`

HasAddCapacityState returns a boolean if a field has been set.

### GetAddCapacityEstTimeToCompletion

`func (o *Effective) GetAddCapacityEstTimeToCompletion() string`

GetAddCapacityEstTimeToCompletion returns the AddCapacityEstTimeToCompletion field if non-nil, zero value otherwise.

### GetAddCapacityEstTimeToCompletionOk

`func (o *Effective) GetAddCapacityEstTimeToCompletionOk() (*string, bool)`

GetAddCapacityEstTimeToCompletionOk returns a tuple with the AddCapacityEstTimeToCompletion field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetAddCapacityEstTimeToCompletion

`func (o *Effective) SetAddCapacityEstTimeToCompletion(v string)`

SetAddCapacityEstTimeToCompletion sets AddCapacityEstTimeToCompletion field to given value.

### HasAddCapacityEstTimeToCompletion

`func (o *Effective) HasAddCapacityEstTimeToCompletion() bool`

HasAddCapacityEstTimeToCompletion returns a boolean if a field has been set.

### GetPhysicalCapacity

`func (o *Effective) GetPhysicalCapacity() PhysicalCapacity`

GetPhysicalCapacity returns the PhysicalCapacity field if non-nil, zero value otherwise.

### GetPhysicalCapacityOk

`func (o *Effective) GetPhysicalCapacityOk() (*PhysicalCapacity, bool)`

GetPhysicalCapacityOk returns a tuple with the PhysicalCapacity field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetPhysicalCapacity

`func (o *Effective) SetPhysicalCapacity(v PhysicalCapacity)`

SetPhysicalCapacity sets PhysicalCapacity field to given value.

### HasPhysicalCapacity

`func (o *Effective) HasPhysicalCapacity() bool`

HasPhysicalCapacity returns a boolean if a field has been set.

### GetEffectiveCapacityResources

`func (o *Effective) GetEffectiveCapacityResources() EffectiveCapacityResources`

GetEffectiveCapacityResources returns the EffectiveCapacityResources field if non-nil, zero value otherwise.

### GetEffectiveCapacityResourcesOk

`func (o *Effective) GetEffectiveCapacityResourcesOk() (*EffectiveCapacityResources, bool)`

GetEffectiveCapacityResourcesOk returns a tuple with the EffectiveCapacityResources field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetEffectiveCapacityResources

`func (o *Effective) SetEffectiveCapacityResources(v EffectiveCapacityResources)`

SetEffectiveCapacityResources sets EffectiveCapacityResources field to given value.

### HasEffectiveCapacityResources

`func (o *Effective) HasEffectiveCapacityResources() bool`

HasEffectiveCapacityResources returns a boolean if a field has been set.

### GetEffectiveCapacityUsage

`func (o *Effective) GetEffectiveCapacityUsage() EffectiveCapacityUsage`

GetEffectiveCapacityUsage returns the EffectiveCapacityUsage field if non-nil, zero value otherwise.

### GetEffectiveCapacityUsageOk

`func (o *Effective) GetEffectiveCapacityUsageOk() (*EffectiveCapacityUsage, bool)`

GetEffectiveCapacityUsageOk returns a tuple with the EffectiveCapacityUsage field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetEffectiveCapacityUsage

`func (o *Effective) SetEffectiveCapacityUsage(v EffectiveCapacityUsage)`

SetEffectiveCapacityUsage sets EffectiveCapacityUsage field to given value.

### HasEffectiveCapacityUsage

`func (o *Effective) HasEffectiveCapacityUsage() bool`

HasEffectiveCapacityUsage returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


