# HealthScoreMetric

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Metric** | **string** | metric | 
**HealthScore** | Pointer to **float64** | health_score | [optional] 
**Expired** | **bool** | expired | 
**DataDate** | Pointer to **int64** | data_date | [optional] 
**CachedDate** | Pointer to **int64** | cached_date | [optional] 
**InstanceMetrics** | Pointer to [**[]HealthScoreInstanceMetricList**](HealthScoreInstanceMetricList.md) | instance_metrics | [optional] 

## Methods

### NewHealthScoreMetric

`func NewHealthScoreMetric(metric string, expired bool, ) *HealthScoreMetric`

NewHealthScoreMetric instantiates a new HealthScoreMetric object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewHealthScoreMetricWithDefaults

`func NewHealthScoreMetricWithDefaults() *HealthScoreMetric`

NewHealthScoreMetricWithDefaults instantiates a new HealthScoreMetric object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetMetric

`func (o *HealthScoreMetric) GetMetric() string`

GetMetric returns the Metric field if non-nil, zero value otherwise.

### GetMetricOk

`func (o *HealthScoreMetric) GetMetricOk() (*string, bool)`

GetMetricOk returns a tuple with the Metric field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetMetric

`func (o *HealthScoreMetric) SetMetric(v string)`

SetMetric sets Metric field to given value.


### GetHealthScore

`func (o *HealthScoreMetric) GetHealthScore() float64`

GetHealthScore returns the HealthScore field if non-nil, zero value otherwise.

### GetHealthScoreOk

`func (o *HealthScoreMetric) GetHealthScoreOk() (*float64, bool)`

GetHealthScoreOk returns a tuple with the HealthScore field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetHealthScore

`func (o *HealthScoreMetric) SetHealthScore(v float64)`

SetHealthScore sets HealthScore field to given value.

### HasHealthScore

`func (o *HealthScoreMetric) HasHealthScore() bool`

HasHealthScore returns a boolean if a field has been set.

### GetExpired

`func (o *HealthScoreMetric) GetExpired() bool`

GetExpired returns the Expired field if non-nil, zero value otherwise.

### GetExpiredOk

`func (o *HealthScoreMetric) GetExpiredOk() (*bool, bool)`

GetExpiredOk returns a tuple with the Expired field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetExpired

`func (o *HealthScoreMetric) SetExpired(v bool)`

SetExpired sets Expired field to given value.


### GetDataDate

`func (o *HealthScoreMetric) GetDataDate() int64`

GetDataDate returns the DataDate field if non-nil, zero value otherwise.

### GetDataDateOk

`func (o *HealthScoreMetric) GetDataDateOk() (*int64, bool)`

GetDataDateOk returns a tuple with the DataDate field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetDataDate

`func (o *HealthScoreMetric) SetDataDate(v int64)`

SetDataDate sets DataDate field to given value.

### HasDataDate

`func (o *HealthScoreMetric) HasDataDate() bool`

HasDataDate returns a boolean if a field has been set.

### GetCachedDate

`func (o *HealthScoreMetric) GetCachedDate() int64`

GetCachedDate returns the CachedDate field if non-nil, zero value otherwise.

### GetCachedDateOk

`func (o *HealthScoreMetric) GetCachedDateOk() (*int64, bool)`

GetCachedDateOk returns a tuple with the CachedDate field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetCachedDate

`func (o *HealthScoreMetric) SetCachedDate(v int64)`

SetCachedDate sets CachedDate field to given value.

### HasCachedDate

`func (o *HealthScoreMetric) HasCachedDate() bool`

HasCachedDate returns a boolean if a field has been set.

### GetInstanceMetrics

`func (o *HealthScoreMetric) GetInstanceMetrics() []HealthScoreInstanceMetricList`

GetInstanceMetrics returns the InstanceMetrics field if non-nil, zero value otherwise.

### GetInstanceMetricsOk

`func (o *HealthScoreMetric) GetInstanceMetricsOk() (*[]HealthScoreInstanceMetricList, bool)`

GetInstanceMetricsOk returns a tuple with the InstanceMetrics field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetInstanceMetrics

`func (o *HealthScoreMetric) SetInstanceMetrics(v []HealthScoreInstanceMetricList)`

SetInstanceMetrics sets InstanceMetrics field to given value.

### HasInstanceMetrics

`func (o *HealthScoreMetric) HasInstanceMetrics() bool`

HasInstanceMetrics returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


