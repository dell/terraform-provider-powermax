# FiconPortThreadInfo

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**FirstAvailableDate** | Pointer to **int64** |  | [optional] 
**LastAvailableDate** | Pointer to **int64** |  | [optional] 
**FiconPortThreadId** | **string** | ficonPortThreadId | 

## Methods

### NewFiconPortThreadInfo

`func NewFiconPortThreadInfo(ficonPortThreadId string, ) *FiconPortThreadInfo`

NewFiconPortThreadInfo instantiates a new FiconPortThreadInfo object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewFiconPortThreadInfoWithDefaults

`func NewFiconPortThreadInfoWithDefaults() *FiconPortThreadInfo`

NewFiconPortThreadInfoWithDefaults instantiates a new FiconPortThreadInfo object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetFirstAvailableDate

`func (o *FiconPortThreadInfo) GetFirstAvailableDate() int64`

GetFirstAvailableDate returns the FirstAvailableDate field if non-nil, zero value otherwise.

### GetFirstAvailableDateOk

`func (o *FiconPortThreadInfo) GetFirstAvailableDateOk() (*int64, bool)`

GetFirstAvailableDateOk returns a tuple with the FirstAvailableDate field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetFirstAvailableDate

`func (o *FiconPortThreadInfo) SetFirstAvailableDate(v int64)`

SetFirstAvailableDate sets FirstAvailableDate field to given value.

### HasFirstAvailableDate

`func (o *FiconPortThreadInfo) HasFirstAvailableDate() bool`

HasFirstAvailableDate returns a boolean if a field has been set.

### GetLastAvailableDate

`func (o *FiconPortThreadInfo) GetLastAvailableDate() int64`

GetLastAvailableDate returns the LastAvailableDate field if non-nil, zero value otherwise.

### GetLastAvailableDateOk

`func (o *FiconPortThreadInfo) GetLastAvailableDateOk() (*int64, bool)`

GetLastAvailableDateOk returns a tuple with the LastAvailableDate field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetLastAvailableDate

`func (o *FiconPortThreadInfo) SetLastAvailableDate(v int64)`

SetLastAvailableDate sets LastAvailableDate field to given value.

### HasLastAvailableDate

`func (o *FiconPortThreadInfo) HasLastAvailableDate() bool`

HasLastAvailableDate returns a boolean if a field has been set.

### GetFiconPortThreadId

`func (o *FiconPortThreadInfo) GetFiconPortThreadId() string`

GetFiconPortThreadId returns the FiconPortThreadId field if non-nil, zero value otherwise.

### GetFiconPortThreadIdOk

`func (o *FiconPortThreadInfo) GetFiconPortThreadIdOk() (*string, bool)`

GetFiconPortThreadIdOk returns a tuple with the FiconPortThreadId field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetFiconPortThreadId

`func (o *FiconPortThreadInfo) SetFiconPortThreadId(v string)`

SetFiconPortThreadId sets FiconPortThreadId field to given value.



[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


