# BeEmulationInfo

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**FirstAvailableDate** | Pointer to **int64** |  | [optional] 
**LastAvailableDate** | Pointer to **int64** |  | [optional] 
**BeEmulationId** | **string** | beEmulationId | 

## Methods

### NewBeEmulationInfo

`func NewBeEmulationInfo(beEmulationId string, ) *BeEmulationInfo`

NewBeEmulationInfo instantiates a new BeEmulationInfo object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewBeEmulationInfoWithDefaults

`func NewBeEmulationInfoWithDefaults() *BeEmulationInfo`

NewBeEmulationInfoWithDefaults instantiates a new BeEmulationInfo object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetFirstAvailableDate

`func (o *BeEmulationInfo) GetFirstAvailableDate() int64`

GetFirstAvailableDate returns the FirstAvailableDate field if non-nil, zero value otherwise.

### GetFirstAvailableDateOk

`func (o *BeEmulationInfo) GetFirstAvailableDateOk() (*int64, bool)`

GetFirstAvailableDateOk returns a tuple with the FirstAvailableDate field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetFirstAvailableDate

`func (o *BeEmulationInfo) SetFirstAvailableDate(v int64)`

SetFirstAvailableDate sets FirstAvailableDate field to given value.

### HasFirstAvailableDate

`func (o *BeEmulationInfo) HasFirstAvailableDate() bool`

HasFirstAvailableDate returns a boolean if a field has been set.

### GetLastAvailableDate

`func (o *BeEmulationInfo) GetLastAvailableDate() int64`

GetLastAvailableDate returns the LastAvailableDate field if non-nil, zero value otherwise.

### GetLastAvailableDateOk

`func (o *BeEmulationInfo) GetLastAvailableDateOk() (*int64, bool)`

GetLastAvailableDateOk returns a tuple with the LastAvailableDate field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetLastAvailableDate

`func (o *BeEmulationInfo) SetLastAvailableDate(v int64)`

SetLastAvailableDate sets LastAvailableDate field to given value.

### HasLastAvailableDate

`func (o *BeEmulationInfo) HasLastAvailableDate() bool`

HasLastAvailableDate returns a boolean if a field has been set.

### GetBeEmulationId

`func (o *BeEmulationInfo) GetBeEmulationId() string`

GetBeEmulationId returns the BeEmulationId field if non-nil, zero value otherwise.

### GetBeEmulationIdOk

`func (o *BeEmulationInfo) GetBeEmulationIdOk() (*string, bool)`

GetBeEmulationIdOk returns a tuple with the BeEmulationId field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetBeEmulationId

`func (o *BeEmulationInfo) SetBeEmulationId(v string)`

SetBeEmulationId sets BeEmulationId field to given value.



[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


