# ExternalLunList

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**LunCount** | Pointer to **int32** | The number of remote LUNs | [optional] 
**Luns** | Pointer to [**[]ExternalLun**](ExternalLun.md) | The remote LUNs visible | [optional] 

## Methods

### NewExternalLunList

`func NewExternalLunList() *ExternalLunList`

NewExternalLunList instantiates a new ExternalLunList object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewExternalLunListWithDefaults

`func NewExternalLunListWithDefaults() *ExternalLunList`

NewExternalLunListWithDefaults instantiates a new ExternalLunList object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetLunCount

`func (o *ExternalLunList) GetLunCount() int32`

GetLunCount returns the LunCount field if non-nil, zero value otherwise.

### GetLunCountOk

`func (o *ExternalLunList) GetLunCountOk() (*int32, bool)`

GetLunCountOk returns a tuple with the LunCount field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetLunCount

`func (o *ExternalLunList) SetLunCount(v int32)`

SetLunCount sets LunCount field to given value.

### HasLunCount

`func (o *ExternalLunList) HasLunCount() bool`

HasLunCount returns a boolean if a field has been set.

### GetLuns

`func (o *ExternalLunList) GetLuns() []ExternalLun`

GetLuns returns the Luns field if non-nil, zero value otherwise.

### GetLunsOk

`func (o *ExternalLunList) GetLunsOk() (*[]ExternalLun, bool)`

GetLunsOk returns a tuple with the Luns field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetLuns

`func (o *ExternalLunList) SetLuns(v []ExternalLun)`

SetLuns sets Luns field to given value.

### HasLuns

`func (o *ExternalLunList) HasLuns() bool`

HasLuns returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


