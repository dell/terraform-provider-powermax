# DataExclusionParam

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ExclusionType** | **string** | The data exclusion types that will be set. Valid values are OneTime, Recurring, or Both.   Enumeration values: * **OneTime** - Set a one-time (expiring) data exclusion. If this value is specified, and no corresponding                         epochTimestamp value is set, any previously set one-time exclusion will be removed. If a                         recurring exclusion is also set, it will not be impacted. * **Recurring** - Set recurring (non-expiring) data exclusions. If this value is specified, and no corresponding                         excludedBucket value is set, any previously set recurring exclusion will be removed. If a                         one-time exclusion is also set, it will not be impacted. * **Both** - Set both one-time (expiring) and recurring (non-expiring) data exclusion values. If this value is                         specified, and either corresponding excludedBucket or epochTimestamp is not set, that setting will                         be removed.  | 
**EpochTimestamp** | Pointer to **int64** | Specifying an epoch timestamp results in a one-time (expiring) data exclusion. Workload planner ignores all workload data before this timestamp. | [optional] 
**ExcludedBucket** | Pointer to **[]int32** | Specifying bucket values results in recurring (non-expiring) data exclusions. A bucket is a four hour time window. A week has 42 buckets (0-indexed). Bucket 0 is Sunday 12am-4am, 1 is Sunday 4am-8am, etc. | [optional] 

## Methods

### NewDataExclusionParam

`func NewDataExclusionParam(exclusionType string, ) *DataExclusionParam`

NewDataExclusionParam instantiates a new DataExclusionParam object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewDataExclusionParamWithDefaults

`func NewDataExclusionParamWithDefaults() *DataExclusionParam`

NewDataExclusionParamWithDefaults instantiates a new DataExclusionParam object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetExclusionType

`func (o *DataExclusionParam) GetExclusionType() string`

GetExclusionType returns the ExclusionType field if non-nil, zero value otherwise.

### GetExclusionTypeOk

`func (o *DataExclusionParam) GetExclusionTypeOk() (*string, bool)`

GetExclusionTypeOk returns a tuple with the ExclusionType field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetExclusionType

`func (o *DataExclusionParam) SetExclusionType(v string)`

SetExclusionType sets ExclusionType field to given value.


### GetEpochTimestamp

`func (o *DataExclusionParam) GetEpochTimestamp() int64`

GetEpochTimestamp returns the EpochTimestamp field if non-nil, zero value otherwise.

### GetEpochTimestampOk

`func (o *DataExclusionParam) GetEpochTimestampOk() (*int64, bool)`

GetEpochTimestampOk returns a tuple with the EpochTimestamp field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetEpochTimestamp

`func (o *DataExclusionParam) SetEpochTimestamp(v int64)`

SetEpochTimestamp sets EpochTimestamp field to given value.

### HasEpochTimestamp

`func (o *DataExclusionParam) HasEpochTimestamp() bool`

HasEpochTimestamp returns a boolean if a field has been set.

### GetExcludedBucket

`func (o *DataExclusionParam) GetExcludedBucket() []int32`

GetExcludedBucket returns the ExcludedBucket field if non-nil, zero value otherwise.

### GetExcludedBucketOk

`func (o *DataExclusionParam) GetExcludedBucketOk() (*[]int32, bool)`

GetExcludedBucketOk returns a tuple with the ExcludedBucket field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetExcludedBucket

`func (o *DataExclusionParam) SetExcludedBucket(v []int32)`

SetExcludedBucket sets ExcludedBucket field to given value.

### HasExcludedBucket

`func (o *DataExclusionParam) HasExcludedBucket() bool`

HasExcludedBucket returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


