# EditInitiatorActionParam

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**RemoveMaskingEntry** | Pointer to **bool** | Remove Masking Entry for specified initiator and Dir:port | [optional] 
**ReplaceInitiatorParam** | Pointer to [**ReplaceInitiatorParam**](ReplaceInitiatorParam.md) |  | [optional] 
**RenameAliasParam** | Pointer to [**RenameAliasParam**](RenameAliasParam.md) |  | [optional] 
**InitiatorSetAttributesParam** | Pointer to [**InitiatorSetAttributesParam**](InitiatorSetAttributesParam.md) |  | [optional] 
**InitiatorSetFlagsParam** | Pointer to [**InitiatorSetFlagsParam**](InitiatorSetFlagsParam.md) |  | [optional] 

## Methods

### NewEditInitiatorActionParam

`func NewEditInitiatorActionParam() *EditInitiatorActionParam`

NewEditInitiatorActionParam instantiates a new EditInitiatorActionParam object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewEditInitiatorActionParamWithDefaults

`func NewEditInitiatorActionParamWithDefaults() *EditInitiatorActionParam`

NewEditInitiatorActionParamWithDefaults instantiates a new EditInitiatorActionParam object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetRemoveMaskingEntry

`func (o *EditInitiatorActionParam) GetRemoveMaskingEntry() bool`

GetRemoveMaskingEntry returns the RemoveMaskingEntry field if non-nil, zero value otherwise.

### GetRemoveMaskingEntryOk

`func (o *EditInitiatorActionParam) GetRemoveMaskingEntryOk() (*bool, bool)`

GetRemoveMaskingEntryOk returns a tuple with the RemoveMaskingEntry field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetRemoveMaskingEntry

`func (o *EditInitiatorActionParam) SetRemoveMaskingEntry(v bool)`

SetRemoveMaskingEntry sets RemoveMaskingEntry field to given value.

### HasRemoveMaskingEntry

`func (o *EditInitiatorActionParam) HasRemoveMaskingEntry() bool`

HasRemoveMaskingEntry returns a boolean if a field has been set.

### GetReplaceInitiatorParam

`func (o *EditInitiatorActionParam) GetReplaceInitiatorParam() ReplaceInitiatorParam`

GetReplaceInitiatorParam returns the ReplaceInitiatorParam field if non-nil, zero value otherwise.

### GetReplaceInitiatorParamOk

`func (o *EditInitiatorActionParam) GetReplaceInitiatorParamOk() (*ReplaceInitiatorParam, bool)`

GetReplaceInitiatorParamOk returns a tuple with the ReplaceInitiatorParam field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetReplaceInitiatorParam

`func (o *EditInitiatorActionParam) SetReplaceInitiatorParam(v ReplaceInitiatorParam)`

SetReplaceInitiatorParam sets ReplaceInitiatorParam field to given value.

### HasReplaceInitiatorParam

`func (o *EditInitiatorActionParam) HasReplaceInitiatorParam() bool`

HasReplaceInitiatorParam returns a boolean if a field has been set.

### GetRenameAliasParam

`func (o *EditInitiatorActionParam) GetRenameAliasParam() RenameAliasParam`

GetRenameAliasParam returns the RenameAliasParam field if non-nil, zero value otherwise.

### GetRenameAliasParamOk

`func (o *EditInitiatorActionParam) GetRenameAliasParamOk() (*RenameAliasParam, bool)`

GetRenameAliasParamOk returns a tuple with the RenameAliasParam field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetRenameAliasParam

`func (o *EditInitiatorActionParam) SetRenameAliasParam(v RenameAliasParam)`

SetRenameAliasParam sets RenameAliasParam field to given value.

### HasRenameAliasParam

`func (o *EditInitiatorActionParam) HasRenameAliasParam() bool`

HasRenameAliasParam returns a boolean if a field has been set.

### GetInitiatorSetAttributesParam

`func (o *EditInitiatorActionParam) GetInitiatorSetAttributesParam() InitiatorSetAttributesParam`

GetInitiatorSetAttributesParam returns the InitiatorSetAttributesParam field if non-nil, zero value otherwise.

### GetInitiatorSetAttributesParamOk

`func (o *EditInitiatorActionParam) GetInitiatorSetAttributesParamOk() (*InitiatorSetAttributesParam, bool)`

GetInitiatorSetAttributesParamOk returns a tuple with the InitiatorSetAttributesParam field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetInitiatorSetAttributesParam

`func (o *EditInitiatorActionParam) SetInitiatorSetAttributesParam(v InitiatorSetAttributesParam)`

SetInitiatorSetAttributesParam sets InitiatorSetAttributesParam field to given value.

### HasInitiatorSetAttributesParam

`func (o *EditInitiatorActionParam) HasInitiatorSetAttributesParam() bool`

HasInitiatorSetAttributesParam returns a boolean if a field has been set.

### GetInitiatorSetFlagsParam

`func (o *EditInitiatorActionParam) GetInitiatorSetFlagsParam() InitiatorSetFlagsParam`

GetInitiatorSetFlagsParam returns the InitiatorSetFlagsParam field if non-nil, zero value otherwise.

### GetInitiatorSetFlagsParamOk

`func (o *EditInitiatorActionParam) GetInitiatorSetFlagsParamOk() (*InitiatorSetFlagsParam, bool)`

GetInitiatorSetFlagsParamOk returns a tuple with the InitiatorSetFlagsParam field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetInitiatorSetFlagsParam

`func (o *EditInitiatorActionParam) SetInitiatorSetFlagsParam(v InitiatorSetFlagsParam)`

SetInitiatorSetFlagsParam sets InitiatorSetFlagsParam field to given value.

### HasInitiatorSetFlagsParam

`func (o *EditInitiatorActionParam) HasInitiatorSetFlagsParam() bool`

HasInitiatorSetFlagsParam returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


