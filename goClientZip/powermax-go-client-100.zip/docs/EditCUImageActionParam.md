# EditCUImageActionParam

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**AssignAliasRangeParam** | Pointer to [**AssignAliasRangeParam**](AssignAliasRangeParam.md) |  | [optional] 
**RemoveAliasRangeParam** | Pointer to [**RemoveAliasRangeParam**](RemoveAliasRangeParam.md) |  | [optional] 
**MapVolumeParam** | Pointer to [**MapVolumeParam**](MapVolumeParam.md) |  | [optional] 
**UnmapVolumeParam** | Pointer to [**UnmapVolumeParam**](UnmapVolumeParam.md) |  | [optional] 

## Methods

### NewEditCUImageActionParam

`func NewEditCUImageActionParam() *EditCUImageActionParam`

NewEditCUImageActionParam instantiates a new EditCUImageActionParam object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewEditCUImageActionParamWithDefaults

`func NewEditCUImageActionParamWithDefaults() *EditCUImageActionParam`

NewEditCUImageActionParamWithDefaults instantiates a new EditCUImageActionParam object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetAssignAliasRangeParam

`func (o *EditCUImageActionParam) GetAssignAliasRangeParam() AssignAliasRangeParam`

GetAssignAliasRangeParam returns the AssignAliasRangeParam field if non-nil, zero value otherwise.

### GetAssignAliasRangeParamOk

`func (o *EditCUImageActionParam) GetAssignAliasRangeParamOk() (*AssignAliasRangeParam, bool)`

GetAssignAliasRangeParamOk returns a tuple with the AssignAliasRangeParam field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetAssignAliasRangeParam

`func (o *EditCUImageActionParam) SetAssignAliasRangeParam(v AssignAliasRangeParam)`

SetAssignAliasRangeParam sets AssignAliasRangeParam field to given value.

### HasAssignAliasRangeParam

`func (o *EditCUImageActionParam) HasAssignAliasRangeParam() bool`

HasAssignAliasRangeParam returns a boolean if a field has been set.

### GetRemoveAliasRangeParam

`func (o *EditCUImageActionParam) GetRemoveAliasRangeParam() RemoveAliasRangeParam`

GetRemoveAliasRangeParam returns the RemoveAliasRangeParam field if non-nil, zero value otherwise.

### GetRemoveAliasRangeParamOk

`func (o *EditCUImageActionParam) GetRemoveAliasRangeParamOk() (*RemoveAliasRangeParam, bool)`

GetRemoveAliasRangeParamOk returns a tuple with the RemoveAliasRangeParam field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetRemoveAliasRangeParam

`func (o *EditCUImageActionParam) SetRemoveAliasRangeParam(v RemoveAliasRangeParam)`

SetRemoveAliasRangeParam sets RemoveAliasRangeParam field to given value.

### HasRemoveAliasRangeParam

`func (o *EditCUImageActionParam) HasRemoveAliasRangeParam() bool`

HasRemoveAliasRangeParam returns a boolean if a field has been set.

### GetMapVolumeParam

`func (o *EditCUImageActionParam) GetMapVolumeParam() MapVolumeParam`

GetMapVolumeParam returns the MapVolumeParam field if non-nil, zero value otherwise.

### GetMapVolumeParamOk

`func (o *EditCUImageActionParam) GetMapVolumeParamOk() (*MapVolumeParam, bool)`

GetMapVolumeParamOk returns a tuple with the MapVolumeParam field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetMapVolumeParam

`func (o *EditCUImageActionParam) SetMapVolumeParam(v MapVolumeParam)`

SetMapVolumeParam sets MapVolumeParam field to given value.

### HasMapVolumeParam

`func (o *EditCUImageActionParam) HasMapVolumeParam() bool`

HasMapVolumeParam returns a boolean if a field has been set.

### GetUnmapVolumeParam

`func (o *EditCUImageActionParam) GetUnmapVolumeParam() UnmapVolumeParam`

GetUnmapVolumeParam returns the UnmapVolumeParam field if non-nil, zero value otherwise.

### GetUnmapVolumeParamOk

`func (o *EditCUImageActionParam) GetUnmapVolumeParamOk() (*UnmapVolumeParam, bool)`

GetUnmapVolumeParamOk returns a tuple with the UnmapVolumeParam field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetUnmapVolumeParam

`func (o *EditCUImageActionParam) SetUnmapVolumeParam(v UnmapVolumeParam)`

SetUnmapVolumeParam sets UnmapVolumeParam field to given value.

### HasUnmapVolumeParam

`func (o *EditCUImageActionParam) HasUnmapVolumeParam() bool`

HasUnmapVolumeParam returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


