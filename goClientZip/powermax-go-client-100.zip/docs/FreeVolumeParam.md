# FreeVolumeParam

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**FreeVolume** | **bool** | Specify whether to remove all allocations on the volume | 

## Methods

### NewFreeVolumeParam

`func NewFreeVolumeParam(freeVolume bool, ) *FreeVolumeParam`

NewFreeVolumeParam instantiates a new FreeVolumeParam object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewFreeVolumeParamWithDefaults

`func NewFreeVolumeParamWithDefaults() *FreeVolumeParam`

NewFreeVolumeParamWithDefaults instantiates a new FreeVolumeParam object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetFreeVolume

`func (o *FreeVolumeParam) GetFreeVolume() bool`

GetFreeVolume returns the FreeVolume field if non-nil, zero value otherwise.

### GetFreeVolumeOk

`func (o *FreeVolumeParam) GetFreeVolumeOk() (*bool, bool)`

GetFreeVolumeOk returns a tuple with the FreeVolume field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetFreeVolume

`func (o *FreeVolumeParam) SetFreeVolume(v bool)`

SetFreeVolume sets FreeVolume field to given value.



[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


