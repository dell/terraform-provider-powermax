# BondDeviceCreateArguments

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Node** | **int32** |                          It is the internalId of the node returned by SDNAS.                      | 
**FdnList** | **[]string** |                          Array of two or more FDNs from same subnet.                      | 
**Mode** | Pointer to **string** |                          Two types of mode supported.                         - 0 : &#x3D;&gt; ACTIVE_BACKUP                         - 1 : &#x3D;&gt; DLA                        Enumeration values: * **ACTIVE_BACKUP** * **DLA**  | [optional] [default to "ACTIVE_BACKUP"]

## Methods

### NewBondDeviceCreateArguments

`func NewBondDeviceCreateArguments(node int32, fdnList []string, ) *BondDeviceCreateArguments`

NewBondDeviceCreateArguments instantiates a new BondDeviceCreateArguments object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewBondDeviceCreateArgumentsWithDefaults

`func NewBondDeviceCreateArgumentsWithDefaults() *BondDeviceCreateArguments`

NewBondDeviceCreateArgumentsWithDefaults instantiates a new BondDeviceCreateArguments object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetNode

`func (o *BondDeviceCreateArguments) GetNode() int32`

GetNode returns the Node field if non-nil, zero value otherwise.

### GetNodeOk

`func (o *BondDeviceCreateArguments) GetNodeOk() (*int32, bool)`

GetNodeOk returns a tuple with the Node field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetNode

`func (o *BondDeviceCreateArguments) SetNode(v int32)`

SetNode sets Node field to given value.


### GetFdnList

`func (o *BondDeviceCreateArguments) GetFdnList() []string`

GetFdnList returns the FdnList field if non-nil, zero value otherwise.

### GetFdnListOk

`func (o *BondDeviceCreateArguments) GetFdnListOk() (*[]string, bool)`

GetFdnListOk returns a tuple with the FdnList field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetFdnList

`func (o *BondDeviceCreateArguments) SetFdnList(v []string)`

SetFdnList sets FdnList field to given value.


### GetMode

`func (o *BondDeviceCreateArguments) GetMode() string`

GetMode returns the Mode field if non-nil, zero value otherwise.

### GetModeOk

`func (o *BondDeviceCreateArguments) GetModeOk() (*string, bool)`

GetModeOk returns a tuple with the Mode field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetMode

`func (o *BondDeviceCreateArguments) SetMode(v string)`

SetMode sets Mode field to given value.

### HasMode

`func (o *BondDeviceCreateArguments) HasMode() bool`

HasMode returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


