# ExportModifyArguments

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Description** | Pointer to **string** |                          User defined NFS export description.                      | [optional] 
**DefaultAccess** | Pointer to **string** |                          Default access level for all hosts that can access the export.                         - 0 : **NoAccess** &#x3D;&gt; Deny access to the export for the hosts.                         - 1 : **ReadOnly** &#x3D;&gt; Allow read only access to the export for the hosts.                         - 2 : **ReadWrite** &#x3D;&gt; Allow read write access to the export for the hosts.                         - 3 : **Root** &#x3D;&gt; Allow read write access to the export for the hosts. Allow access to the share for root user.                         - 4 : **RoRoot** &#x3D;&gt; Allow read only root access to the export for the hosts.                        Enumeration values: * **NoAccess** * **ReadOnly** * **ReadWrite** * **Root** * **RoRoot**  | [optional] 
**MinSecurity** | Pointer to **string** |                          NFS minimum enforced security type for users accessing an NFS export.                         - 0 : **Sys** &#x3D;&gt; Allow user to authenticate with any NFS security types: UNIX, Kerberos, Kerberos with integrity and Kerberos with encryption. *sys/krb5/krb5i/krb5p*                         - 1 : **Kerberos** &#x3D;&gt; Allow only Kerberos security for user authentication. *krb5/krb5i/krb5p*                         - 2 : **KerberosWithIntegrity** &#x3D;&gt; Allow only Kerberos with integrity and Kerberos with encryption security for user authentication. *krb5i/krb5p*                         - 3 : **KerberosWithEncryption** &#x3D;&gt; Allow only Kerberos with encryption security for user authentication. *krb5p*                         Enumeration values: * **Sys** * **Kerberos** * **KerberosWithIntegrity** * **KerberosWithEncryption**  | [optional] 
**NoAccessHosts** | Pointer to **[]string** |                          Hosts with **no** access to the NFS export or its snapshots. This list is useful when \&quot;defaultAccess\&quot; is not \&quot;NoAccess\&quot;.                      | [optional] 
**ReadOnlyHosts** | Pointer to **[]string** |                          Hosts with **read-only** access to the NFS export and its snapshots.                      | [optional] 
**ReadOnlyRootHosts** | Pointer to **[]string** |                          Hosts with **read-only** *and* **ready-only for root user** access * to the NFS export and its snapshots.                      | [optional] 
**ReadWriteHosts** | Pointer to **[]string** |                          Hosts with **read and write** access to the NFS export and its snapshots.                      | [optional] 
**ReadWriteRootHosts** | Pointer to **[]string** |                          Hosts with **read and write** *and* **read and write for root user** access to the NFS export and its snapshots.                      | [optional] 
**AnonymousUid** | Pointer to **int32** |                          Specifies the user ID of the anonymous account.                      | [optional] 
**AnonymousGid** | Pointer to **int32** |                          Specifies the group ID of the anonymous account.                      | [optional] 
**NoSuid** | Pointer to **bool** |                          if set, do not allow access to set SUID. Otherwise, allow access.                      | [optional] 
**NfsOwnerUsername** | Pointer to **bool** |                          Set the owner of the local path this export points to.                         *  Required when the storage resource is used as a VMWare datastore with secure NFS enabled.                         *  When a username (string) is provided, the nas Server will try to resolve its UID using its current Unix Directory Service settings, operation will fail if no mapping is found.                         *  When a number is provided, ownership of the local path will be set using this UID.  The default owner is root.                      | [optional] 

## Methods

### NewExportModifyArguments

`func NewExportModifyArguments() *ExportModifyArguments`

NewExportModifyArguments instantiates a new ExportModifyArguments object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewExportModifyArgumentsWithDefaults

`func NewExportModifyArgumentsWithDefaults() *ExportModifyArguments`

NewExportModifyArgumentsWithDefaults instantiates a new ExportModifyArguments object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetDescription

`func (o *ExportModifyArguments) GetDescription() string`

GetDescription returns the Description field if non-nil, zero value otherwise.

### GetDescriptionOk

`func (o *ExportModifyArguments) GetDescriptionOk() (*string, bool)`

GetDescriptionOk returns a tuple with the Description field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetDescription

`func (o *ExportModifyArguments) SetDescription(v string)`

SetDescription sets Description field to given value.

### HasDescription

`func (o *ExportModifyArguments) HasDescription() bool`

HasDescription returns a boolean if a field has been set.

### GetDefaultAccess

`func (o *ExportModifyArguments) GetDefaultAccess() string`

GetDefaultAccess returns the DefaultAccess field if non-nil, zero value otherwise.

### GetDefaultAccessOk

`func (o *ExportModifyArguments) GetDefaultAccessOk() (*string, bool)`

GetDefaultAccessOk returns a tuple with the DefaultAccess field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetDefaultAccess

`func (o *ExportModifyArguments) SetDefaultAccess(v string)`

SetDefaultAccess sets DefaultAccess field to given value.

### HasDefaultAccess

`func (o *ExportModifyArguments) HasDefaultAccess() bool`

HasDefaultAccess returns a boolean if a field has been set.

### GetMinSecurity

`func (o *ExportModifyArguments) GetMinSecurity() string`

GetMinSecurity returns the MinSecurity field if non-nil, zero value otherwise.

### GetMinSecurityOk

`func (o *ExportModifyArguments) GetMinSecurityOk() (*string, bool)`

GetMinSecurityOk returns a tuple with the MinSecurity field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetMinSecurity

`func (o *ExportModifyArguments) SetMinSecurity(v string)`

SetMinSecurity sets MinSecurity field to given value.

### HasMinSecurity

`func (o *ExportModifyArguments) HasMinSecurity() bool`

HasMinSecurity returns a boolean if a field has been set.

### GetNoAccessHosts

`func (o *ExportModifyArguments) GetNoAccessHosts() []string`

GetNoAccessHosts returns the NoAccessHosts field if non-nil, zero value otherwise.

### GetNoAccessHostsOk

`func (o *ExportModifyArguments) GetNoAccessHostsOk() (*[]string, bool)`

GetNoAccessHostsOk returns a tuple with the NoAccessHosts field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetNoAccessHosts

`func (o *ExportModifyArguments) SetNoAccessHosts(v []string)`

SetNoAccessHosts sets NoAccessHosts field to given value.

### HasNoAccessHosts

`func (o *ExportModifyArguments) HasNoAccessHosts() bool`

HasNoAccessHosts returns a boolean if a field has been set.

### GetReadOnlyHosts

`func (o *ExportModifyArguments) GetReadOnlyHosts() []string`

GetReadOnlyHosts returns the ReadOnlyHosts field if non-nil, zero value otherwise.

### GetReadOnlyHostsOk

`func (o *ExportModifyArguments) GetReadOnlyHostsOk() (*[]string, bool)`

GetReadOnlyHostsOk returns a tuple with the ReadOnlyHosts field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetReadOnlyHosts

`func (o *ExportModifyArguments) SetReadOnlyHosts(v []string)`

SetReadOnlyHosts sets ReadOnlyHosts field to given value.

### HasReadOnlyHosts

`func (o *ExportModifyArguments) HasReadOnlyHosts() bool`

HasReadOnlyHosts returns a boolean if a field has been set.

### GetReadOnlyRootHosts

`func (o *ExportModifyArguments) GetReadOnlyRootHosts() []string`

GetReadOnlyRootHosts returns the ReadOnlyRootHosts field if non-nil, zero value otherwise.

### GetReadOnlyRootHostsOk

`func (o *ExportModifyArguments) GetReadOnlyRootHostsOk() (*[]string, bool)`

GetReadOnlyRootHostsOk returns a tuple with the ReadOnlyRootHosts field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetReadOnlyRootHosts

`func (o *ExportModifyArguments) SetReadOnlyRootHosts(v []string)`

SetReadOnlyRootHosts sets ReadOnlyRootHosts field to given value.

### HasReadOnlyRootHosts

`func (o *ExportModifyArguments) HasReadOnlyRootHosts() bool`

HasReadOnlyRootHosts returns a boolean if a field has been set.

### GetReadWriteHosts

`func (o *ExportModifyArguments) GetReadWriteHosts() []string`

GetReadWriteHosts returns the ReadWriteHosts field if non-nil, zero value otherwise.

### GetReadWriteHostsOk

`func (o *ExportModifyArguments) GetReadWriteHostsOk() (*[]string, bool)`

GetReadWriteHostsOk returns a tuple with the ReadWriteHosts field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetReadWriteHosts

`func (o *ExportModifyArguments) SetReadWriteHosts(v []string)`

SetReadWriteHosts sets ReadWriteHosts field to given value.

### HasReadWriteHosts

`func (o *ExportModifyArguments) HasReadWriteHosts() bool`

HasReadWriteHosts returns a boolean if a field has been set.

### GetReadWriteRootHosts

`func (o *ExportModifyArguments) GetReadWriteRootHosts() []string`

GetReadWriteRootHosts returns the ReadWriteRootHosts field if non-nil, zero value otherwise.

### GetReadWriteRootHostsOk

`func (o *ExportModifyArguments) GetReadWriteRootHostsOk() (*[]string, bool)`

GetReadWriteRootHostsOk returns a tuple with the ReadWriteRootHosts field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetReadWriteRootHosts

`func (o *ExportModifyArguments) SetReadWriteRootHosts(v []string)`

SetReadWriteRootHosts sets ReadWriteRootHosts field to given value.

### HasReadWriteRootHosts

`func (o *ExportModifyArguments) HasReadWriteRootHosts() bool`

HasReadWriteRootHosts returns a boolean if a field has been set.

### GetAnonymousUid

`func (o *ExportModifyArguments) GetAnonymousUid() int32`

GetAnonymousUid returns the AnonymousUid field if non-nil, zero value otherwise.

### GetAnonymousUidOk

`func (o *ExportModifyArguments) GetAnonymousUidOk() (*int32, bool)`

GetAnonymousUidOk returns a tuple with the AnonymousUid field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetAnonymousUid

`func (o *ExportModifyArguments) SetAnonymousUid(v int32)`

SetAnonymousUid sets AnonymousUid field to given value.

### HasAnonymousUid

`func (o *ExportModifyArguments) HasAnonymousUid() bool`

HasAnonymousUid returns a boolean if a field has been set.

### GetAnonymousGid

`func (o *ExportModifyArguments) GetAnonymousGid() int32`

GetAnonymousGid returns the AnonymousGid field if non-nil, zero value otherwise.

### GetAnonymousGidOk

`func (o *ExportModifyArguments) GetAnonymousGidOk() (*int32, bool)`

GetAnonymousGidOk returns a tuple with the AnonymousGid field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetAnonymousGid

`func (o *ExportModifyArguments) SetAnonymousGid(v int32)`

SetAnonymousGid sets AnonymousGid field to given value.

### HasAnonymousGid

`func (o *ExportModifyArguments) HasAnonymousGid() bool`

HasAnonymousGid returns a boolean if a field has been set.

### GetNoSuid

`func (o *ExportModifyArguments) GetNoSuid() bool`

GetNoSuid returns the NoSuid field if non-nil, zero value otherwise.

### GetNoSuidOk

`func (o *ExportModifyArguments) GetNoSuidOk() (*bool, bool)`

GetNoSuidOk returns a tuple with the NoSuid field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetNoSuid

`func (o *ExportModifyArguments) SetNoSuid(v bool)`

SetNoSuid sets NoSuid field to given value.

### HasNoSuid

`func (o *ExportModifyArguments) HasNoSuid() bool`

HasNoSuid returns a boolean if a field has been set.

### GetNfsOwnerUsername

`func (o *ExportModifyArguments) GetNfsOwnerUsername() bool`

GetNfsOwnerUsername returns the NfsOwnerUsername field if non-nil, zero value otherwise.

### GetNfsOwnerUsernameOk

`func (o *ExportModifyArguments) GetNfsOwnerUsernameOk() (*bool, bool)`

GetNfsOwnerUsernameOk returns a tuple with the NfsOwnerUsername field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetNfsOwnerUsername

`func (o *ExportModifyArguments) SetNfsOwnerUsername(v bool)`

SetNfsOwnerUsername sets NfsOwnerUsername field to given value.

### HasNfsOwnerUsername

`func (o *ExportModifyArguments) HasNfsOwnerUsername() bool`

HasNfsOwnerUsername returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


