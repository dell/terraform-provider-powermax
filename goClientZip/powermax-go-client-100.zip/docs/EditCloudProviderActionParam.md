# EditCloudProviderActionParam

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ModifyCloudProvider** | Pointer to [**ModifyCloudProviderParam**](ModifyCloudProviderParam.md) |  | [optional] 

## Methods

### NewEditCloudProviderActionParam

`func NewEditCloudProviderActionParam() *EditCloudProviderActionParam`

NewEditCloudProviderActionParam instantiates a new EditCloudProviderActionParam object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewEditCloudProviderActionParamWithDefaults

`func NewEditCloudProviderActionParamWithDefaults() *EditCloudProviderActionParam`

NewEditCloudProviderActionParamWithDefaults instantiates a new EditCloudProviderActionParam object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetModifyCloudProvider

`func (o *EditCloudProviderActionParam) GetModifyCloudProvider() ModifyCloudProviderParam`

GetModifyCloudProvider returns the ModifyCloudProvider field if non-nil, zero value otherwise.

### GetModifyCloudProviderOk

`func (o *EditCloudProviderActionParam) GetModifyCloudProviderOk() (*ModifyCloudProviderParam, bool)`

GetModifyCloudProviderOk returns a tuple with the ModifyCloudProvider field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetModifyCloudProvider

`func (o *EditCloudProviderActionParam) SetModifyCloudProvider(v ModifyCloudProviderParam)`

SetModifyCloudProvider sets ModifyCloudProvider field to given value.

### HasModifyCloudProvider

`func (o *EditCloudProviderActionParam) HasModifyCloudProvider() bool`

HasModifyCloudProvider returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


