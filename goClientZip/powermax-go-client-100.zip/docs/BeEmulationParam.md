# BeEmulationParam

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**StartDate** | **int64** | Starting date in millisecond. | 
**EndDate** | **int64** | Ending date in millisecond. | 
**SymmetrixId** | **string** | The Symmetrix array ID. | 
**BeEmulationId** | **string** | beEmulationId | 
**DataFormat** | Pointer to **string** | &lt;p&gt;Data Format (Average or Maximum).&lt;/p&gt;   Enumeration values: * **Average** * **Maximum**  | [optional] 
**Metrics** | **[]string** | metrics   Enumeration values: * **ReadMissesTime** -  * **WritesTime** -  * **PrefetchTime** -  * **CopyReadsTime** -  * **CopyWritesTime** -  * **SyscallsTime** -  * **ManagementTime** -  * **RebuildTime** -  * **IvtocTime** -  * **SWCompressionTime** -  * **OtherTime** -  * **CDITime** -  * **LpTasksTime** -  * **SymmkTotalTime** -  * **SymmkIdleTime** -  * **TotalWorkTime** - Total Work Time. * **PercentBusy** - % Busy  | 

## Methods

### NewBeEmulationParam

`func NewBeEmulationParam(startDate int64, endDate int64, symmetrixId string, beEmulationId string, metrics []string, ) *BeEmulationParam`

NewBeEmulationParam instantiates a new BeEmulationParam object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewBeEmulationParamWithDefaults

`func NewBeEmulationParamWithDefaults() *BeEmulationParam`

NewBeEmulationParamWithDefaults instantiates a new BeEmulationParam object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetStartDate

`func (o *BeEmulationParam) GetStartDate() int64`

GetStartDate returns the StartDate field if non-nil, zero value otherwise.

### GetStartDateOk

`func (o *BeEmulationParam) GetStartDateOk() (*int64, bool)`

GetStartDateOk returns a tuple with the StartDate field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetStartDate

`func (o *BeEmulationParam) SetStartDate(v int64)`

SetStartDate sets StartDate field to given value.


### GetEndDate

`func (o *BeEmulationParam) GetEndDate() int64`

GetEndDate returns the EndDate field if non-nil, zero value otherwise.

### GetEndDateOk

`func (o *BeEmulationParam) GetEndDateOk() (*int64, bool)`

GetEndDateOk returns a tuple with the EndDate field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetEndDate

`func (o *BeEmulationParam) SetEndDate(v int64)`

SetEndDate sets EndDate field to given value.


### GetSymmetrixId

`func (o *BeEmulationParam) GetSymmetrixId() string`

GetSymmetrixId returns the SymmetrixId field if non-nil, zero value otherwise.

### GetSymmetrixIdOk

`func (o *BeEmulationParam) GetSymmetrixIdOk() (*string, bool)`

GetSymmetrixIdOk returns a tuple with the SymmetrixId field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetSymmetrixId

`func (o *BeEmulationParam) SetSymmetrixId(v string)`

SetSymmetrixId sets SymmetrixId field to given value.


### GetBeEmulationId

`func (o *BeEmulationParam) GetBeEmulationId() string`

GetBeEmulationId returns the BeEmulationId field if non-nil, zero value otherwise.

### GetBeEmulationIdOk

`func (o *BeEmulationParam) GetBeEmulationIdOk() (*string, bool)`

GetBeEmulationIdOk returns a tuple with the BeEmulationId field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetBeEmulationId

`func (o *BeEmulationParam) SetBeEmulationId(v string)`

SetBeEmulationId sets BeEmulationId field to given value.


### GetDataFormat

`func (o *BeEmulationParam) GetDataFormat() string`

GetDataFormat returns the DataFormat field if non-nil, zero value otherwise.

### GetDataFormatOk

`func (o *BeEmulationParam) GetDataFormatOk() (*string, bool)`

GetDataFormatOk returns a tuple with the DataFormat field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetDataFormat

`func (o *BeEmulationParam) SetDataFormat(v string)`

SetDataFormat sets DataFormat field to given value.

### HasDataFormat

`func (o *BeEmulationParam) HasDataFormat() bool`

HasDataFormat returns a boolean if a field has been set.

### GetMetrics

`func (o *BeEmulationParam) GetMetrics() []string`

GetMetrics returns the Metrics field if non-nil, zero value otherwise.

### GetMetricsOk

`func (o *BeEmulationParam) GetMetricsOk() (*[]string, bool)`

GetMetricsOk returns a tuple with the Metrics field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetMetrics

`func (o *BeEmulationParam) SetMetrics(v []string)`

SetMetrics sets Metrics field to given value.



[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


