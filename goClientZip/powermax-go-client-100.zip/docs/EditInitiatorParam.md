# EditInitiatorParam

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ExecutionOption** | Pointer to **string** |  | [optional] [default to "SYNCHRONOUS"]
**EditInitiatorActionParam** | [**EditInitiatorActionParam**](EditInitiatorActionParam.md) |  | 

## Methods

### NewEditInitiatorParam

`func NewEditInitiatorParam(editInitiatorActionParam EditInitiatorActionParam, ) *EditInitiatorParam`

NewEditInitiatorParam instantiates a new EditInitiatorParam object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewEditInitiatorParamWithDefaults

`func NewEditInitiatorParamWithDefaults() *EditInitiatorParam`

NewEditInitiatorParamWithDefaults instantiates a new EditInitiatorParam object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetExecutionOption

`func (o *EditInitiatorParam) GetExecutionOption() string`

GetExecutionOption returns the ExecutionOption field if non-nil, zero value otherwise.

### GetExecutionOptionOk

`func (o *EditInitiatorParam) GetExecutionOptionOk() (*string, bool)`

GetExecutionOptionOk returns a tuple with the ExecutionOption field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetExecutionOption

`func (o *EditInitiatorParam) SetExecutionOption(v string)`

SetExecutionOption sets ExecutionOption field to given value.

### HasExecutionOption

`func (o *EditInitiatorParam) HasExecutionOption() bool`

HasExecutionOption returns a boolean if a field has been set.

### GetEditInitiatorActionParam

`func (o *EditInitiatorParam) GetEditInitiatorActionParam() EditInitiatorActionParam`

GetEditInitiatorActionParam returns the EditInitiatorActionParam field if non-nil, zero value otherwise.

### GetEditInitiatorActionParamOk

`func (o *EditInitiatorParam) GetEditInitiatorActionParamOk() (*EditInitiatorActionParam, bool)`

GetEditInitiatorActionParamOk returns a tuple with the EditInitiatorActionParam field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetEditInitiatorActionParam

`func (o *EditInitiatorParam) SetEditInitiatorActionParam(v EditInitiatorActionParam)`

SetEditInitiatorActionParam sets EditInitiatorActionParam field to given value.



[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


