# LdapCreateArguments

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**NasServer** | **string** |                          Id of associated Nas Server instance that uses this LDAP object.                         Only one LDAP object per Nas Server is supported.                      | 
**AuthenticationType** | **string** |                          Authentication type for the LDAP server.                         - 0 - Anonymous &#x3D;&gt; Anonymous authentication means no authentication occurs and the Nas Server uses an anonymous login to access the LDAP-based directory server.                         - 1 - Simple &#x3D;&gt; Simple authentication means the Nas Server must provide a bind distinguished name and password to access the LDAP-based directory server.                         - 2 - Kerberos &#x3D;&gt; Kerberos authentication means the Nas Server uses a KDC to confirm the identity when accessing the Active Directory.                        Enumeration values: * **Anonymous** * **Simple** * **Kerberos**  | 
**BaseDn** | **string** |                          Base Distinguished Name. This is the root of the LDAP directory tree where the SDNAS server will query information.                         The base DN must be expressed in X.509 format by using the attribute dc&#x3D;. For example, if the fully-qualified domain name is mycompany.com, the base DN is dc&#x3D;mycompany,dc&#x3D;com.                      | 
**Addresses** | Pointer to **[]string** |                          IP addresses of the LDAP servers.                      | [optional] 
**PortNumber** | Pointer to **int32** |                          The TCP/IP port used by the Nas Server to connect to the LDAP servers.                         Default value for LDAP is 389 and LDAPS is 636.                      | [optional] 
**Protocol** | Pointer to **string** |                          Indicates whether the LDAP protocol uses SSL for secure network communication. SSL encrypts data over the network and provides message and server authentication.                         - 0 - ldap &#x3D;&gt; LDAP protocol without SSL.                         - 1 - ldaps &#x3D;&gt; (Default) LDAP protocol with SSL. When you enable LDAPS, make sure to specify the appropriate LDAPS port (usually port 636) and to upload an LDAPS trust certificate to the LDAP server.                         - 2 - unknown &#x3D;&gt; Unknown protocol.                        Enumeration values: * **ldap** * **ldaps** * **unknown**  | [optional] 
**VerifyServerCertificate** | Pointer to **bool** |                          Indicates whether Certification Authority certificate is used to verify the LDAP server certificate for secure SSL connections. Values are:                         - {true} - verifies LDAP server&#39;s certificate.                         - {false} - doesn&#39;t verify LDAP server&#39;s certificate.                      | [optional] 
**ProfileDn** | Pointer to **string** |                          For an iPlanet LDAP server, specifies the DN of the entry with the configuration profile.                      | [optional] 
**BindDn** | Pointer to **string** |                          Bind Distinguished Name (DN) to be used when binding.                      | [optional] 
**BindPassword** | Pointer to **string** | bind_password | [optional] 
**SmbAccountUsed** | Pointer to **bool** |                          Indicates whether SMB authentication is used to authenticate to the LDAP server. Values are:                         - {true} - Indicates that the SMB settings are used for Kerberos authentication.                         - {false} - Indicates that Kerberos uses its own settings.                      | [optional] 
**Principal** | Pointer to **string** |                          Specifies the principal name for Kerberos authentication.                      | [optional] 
**Realm** | Pointer to **string** |                          Specifies the realm name for Kerberos authentication.                      | [optional] 
**Password** | Pointer to **string** | password | [optional] 

## Methods

### NewLdapCreateArguments

`func NewLdapCreateArguments(nasServer string, authenticationType string, baseDn string, ) *LdapCreateArguments`

NewLdapCreateArguments instantiates a new LdapCreateArguments object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewLdapCreateArgumentsWithDefaults

`func NewLdapCreateArgumentsWithDefaults() *LdapCreateArguments`

NewLdapCreateArgumentsWithDefaults instantiates a new LdapCreateArguments object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetNasServer

`func (o *LdapCreateArguments) GetNasServer() string`

GetNasServer returns the NasServer field if non-nil, zero value otherwise.

### GetNasServerOk

`func (o *LdapCreateArguments) GetNasServerOk() (*string, bool)`

GetNasServerOk returns a tuple with the NasServer field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetNasServer

`func (o *LdapCreateArguments) SetNasServer(v string)`

SetNasServer sets NasServer field to given value.


### GetAuthenticationType

`func (o *LdapCreateArguments) GetAuthenticationType() string`

GetAuthenticationType returns the AuthenticationType field if non-nil, zero value otherwise.

### GetAuthenticationTypeOk

`func (o *LdapCreateArguments) GetAuthenticationTypeOk() (*string, bool)`

GetAuthenticationTypeOk returns a tuple with the AuthenticationType field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetAuthenticationType

`func (o *LdapCreateArguments) SetAuthenticationType(v string)`

SetAuthenticationType sets AuthenticationType field to given value.


### GetBaseDn

`func (o *LdapCreateArguments) GetBaseDn() string`

GetBaseDn returns the BaseDn field if non-nil, zero value otherwise.

### GetBaseDnOk

`func (o *LdapCreateArguments) GetBaseDnOk() (*string, bool)`

GetBaseDnOk returns a tuple with the BaseDn field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetBaseDn

`func (o *LdapCreateArguments) SetBaseDn(v string)`

SetBaseDn sets BaseDn field to given value.


### GetAddresses

`func (o *LdapCreateArguments) GetAddresses() []string`

GetAddresses returns the Addresses field if non-nil, zero value otherwise.

### GetAddressesOk

`func (o *LdapCreateArguments) GetAddressesOk() (*[]string, bool)`

GetAddressesOk returns a tuple with the Addresses field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetAddresses

`func (o *LdapCreateArguments) SetAddresses(v []string)`

SetAddresses sets Addresses field to given value.

### HasAddresses

`func (o *LdapCreateArguments) HasAddresses() bool`

HasAddresses returns a boolean if a field has been set.

### GetPortNumber

`func (o *LdapCreateArguments) GetPortNumber() int32`

GetPortNumber returns the PortNumber field if non-nil, zero value otherwise.

### GetPortNumberOk

`func (o *LdapCreateArguments) GetPortNumberOk() (*int32, bool)`

GetPortNumberOk returns a tuple with the PortNumber field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetPortNumber

`func (o *LdapCreateArguments) SetPortNumber(v int32)`

SetPortNumber sets PortNumber field to given value.

### HasPortNumber

`func (o *LdapCreateArguments) HasPortNumber() bool`

HasPortNumber returns a boolean if a field has been set.

### GetProtocol

`func (o *LdapCreateArguments) GetProtocol() string`

GetProtocol returns the Protocol field if non-nil, zero value otherwise.

### GetProtocolOk

`func (o *LdapCreateArguments) GetProtocolOk() (*string, bool)`

GetProtocolOk returns a tuple with the Protocol field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetProtocol

`func (o *LdapCreateArguments) SetProtocol(v string)`

SetProtocol sets Protocol field to given value.

### HasProtocol

`func (o *LdapCreateArguments) HasProtocol() bool`

HasProtocol returns a boolean if a field has been set.

### GetVerifyServerCertificate

`func (o *LdapCreateArguments) GetVerifyServerCertificate() bool`

GetVerifyServerCertificate returns the VerifyServerCertificate field if non-nil, zero value otherwise.

### GetVerifyServerCertificateOk

`func (o *LdapCreateArguments) GetVerifyServerCertificateOk() (*bool, bool)`

GetVerifyServerCertificateOk returns a tuple with the VerifyServerCertificate field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetVerifyServerCertificate

`func (o *LdapCreateArguments) SetVerifyServerCertificate(v bool)`

SetVerifyServerCertificate sets VerifyServerCertificate field to given value.

### HasVerifyServerCertificate

`func (o *LdapCreateArguments) HasVerifyServerCertificate() bool`

HasVerifyServerCertificate returns a boolean if a field has been set.

### GetProfileDn

`func (o *LdapCreateArguments) GetProfileDn() string`

GetProfileDn returns the ProfileDn field if non-nil, zero value otherwise.

### GetProfileDnOk

`func (o *LdapCreateArguments) GetProfileDnOk() (*string, bool)`

GetProfileDnOk returns a tuple with the ProfileDn field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetProfileDn

`func (o *LdapCreateArguments) SetProfileDn(v string)`

SetProfileDn sets ProfileDn field to given value.

### HasProfileDn

`func (o *LdapCreateArguments) HasProfileDn() bool`

HasProfileDn returns a boolean if a field has been set.

### GetBindDn

`func (o *LdapCreateArguments) GetBindDn() string`

GetBindDn returns the BindDn field if non-nil, zero value otherwise.

### GetBindDnOk

`func (o *LdapCreateArguments) GetBindDnOk() (*string, bool)`

GetBindDnOk returns a tuple with the BindDn field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetBindDn

`func (o *LdapCreateArguments) SetBindDn(v string)`

SetBindDn sets BindDn field to given value.

### HasBindDn

`func (o *LdapCreateArguments) HasBindDn() bool`

HasBindDn returns a boolean if a field has been set.

### GetBindPassword

`func (o *LdapCreateArguments) GetBindPassword() string`

GetBindPassword returns the BindPassword field if non-nil, zero value otherwise.

### GetBindPasswordOk

`func (o *LdapCreateArguments) GetBindPasswordOk() (*string, bool)`

GetBindPasswordOk returns a tuple with the BindPassword field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetBindPassword

`func (o *LdapCreateArguments) SetBindPassword(v string)`

SetBindPassword sets BindPassword field to given value.

### HasBindPassword

`func (o *LdapCreateArguments) HasBindPassword() bool`

HasBindPassword returns a boolean if a field has been set.

### GetSmbAccountUsed

`func (o *LdapCreateArguments) GetSmbAccountUsed() bool`

GetSmbAccountUsed returns the SmbAccountUsed field if non-nil, zero value otherwise.

### GetSmbAccountUsedOk

`func (o *LdapCreateArguments) GetSmbAccountUsedOk() (*bool, bool)`

GetSmbAccountUsedOk returns a tuple with the SmbAccountUsed field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetSmbAccountUsed

`func (o *LdapCreateArguments) SetSmbAccountUsed(v bool)`

SetSmbAccountUsed sets SmbAccountUsed field to given value.

### HasSmbAccountUsed

`func (o *LdapCreateArguments) HasSmbAccountUsed() bool`

HasSmbAccountUsed returns a boolean if a field has been set.

### GetPrincipal

`func (o *LdapCreateArguments) GetPrincipal() string`

GetPrincipal returns the Principal field if non-nil, zero value otherwise.

### GetPrincipalOk

`func (o *LdapCreateArguments) GetPrincipalOk() (*string, bool)`

GetPrincipalOk returns a tuple with the Principal field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetPrincipal

`func (o *LdapCreateArguments) SetPrincipal(v string)`

SetPrincipal sets Principal field to given value.

### HasPrincipal

`func (o *LdapCreateArguments) HasPrincipal() bool`

HasPrincipal returns a boolean if a field has been set.

### GetRealm

`func (o *LdapCreateArguments) GetRealm() string`

GetRealm returns the Realm field if non-nil, zero value otherwise.

### GetRealmOk

`func (o *LdapCreateArguments) GetRealmOk() (*string, bool)`

GetRealmOk returns a tuple with the Realm field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetRealm

`func (o *LdapCreateArguments) SetRealm(v string)`

SetRealm sets Realm field to given value.

### HasRealm

`func (o *LdapCreateArguments) HasRealm() bool`

HasRealm returns a boolean if a field has been set.

### GetPassword

`func (o *LdapCreateArguments) GetPassword() string`

GetPassword returns the Password field if non-nil, zero value otherwise.

### GetPasswordOk

`func (o *LdapCreateArguments) GetPasswordOk() (*string, bool)`

GetPasswordOk returns a tuple with the Password field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetPassword

`func (o *LdapCreateArguments) SetPassword(v string)`

SetPassword sets Password field to given value.

### HasPassword

`func (o *LdapCreateArguments) HasPassword() bool`

HasPassword returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


