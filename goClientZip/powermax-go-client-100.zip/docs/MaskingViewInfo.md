# MaskingViewInfo

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**FirstAvailableDate** | Pointer to **int64** |  | [optional] 
**LastAvailableDate** | Pointer to **int64** |  | [optional] 
**MaskingViewId** | **string** | maskingViewId | 

## Methods

### NewMaskingViewInfo

`func NewMaskingViewInfo(maskingViewId string, ) *MaskingViewInfo`

NewMaskingViewInfo instantiates a new MaskingViewInfo object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewMaskingViewInfoWithDefaults

`func NewMaskingViewInfoWithDefaults() *MaskingViewInfo`

NewMaskingViewInfoWithDefaults instantiates a new MaskingViewInfo object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetFirstAvailableDate

`func (o *MaskingViewInfo) GetFirstAvailableDate() int64`

GetFirstAvailableDate returns the FirstAvailableDate field if non-nil, zero value otherwise.

### GetFirstAvailableDateOk

`func (o *MaskingViewInfo) GetFirstAvailableDateOk() (*int64, bool)`

GetFirstAvailableDateOk returns a tuple with the FirstAvailableDate field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetFirstAvailableDate

`func (o *MaskingViewInfo) SetFirstAvailableDate(v int64)`

SetFirstAvailableDate sets FirstAvailableDate field to given value.

### HasFirstAvailableDate

`func (o *MaskingViewInfo) HasFirstAvailableDate() bool`

HasFirstAvailableDate returns a boolean if a field has been set.

### GetLastAvailableDate

`func (o *MaskingViewInfo) GetLastAvailableDate() int64`

GetLastAvailableDate returns the LastAvailableDate field if non-nil, zero value otherwise.

### GetLastAvailableDateOk

`func (o *MaskingViewInfo) GetLastAvailableDateOk() (*int64, bool)`

GetLastAvailableDateOk returns a tuple with the LastAvailableDate field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetLastAvailableDate

`func (o *MaskingViewInfo) SetLastAvailableDate(v int64)`

SetLastAvailableDate sets LastAvailableDate field to given value.

### HasLastAvailableDate

`func (o *MaskingViewInfo) HasLastAvailableDate() bool`

HasLastAvailableDate returns a boolean if a field has been set.

### GetMaskingViewId

`func (o *MaskingViewInfo) GetMaskingViewId() string`

GetMaskingViewId returns the MaskingViewId field if non-nil, zero value otherwise.

### GetMaskingViewIdOk

`func (o *MaskingViewInfo) GetMaskingViewIdOk() (*string, bool)`

GetMaskingViewIdOk returns a tuple with the MaskingViewId field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetMaskingViewId

`func (o *MaskingViewInfo) SetMaskingViewId(v string)`

SetMaskingViewId sets MaskingViewId field to given value.



[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


