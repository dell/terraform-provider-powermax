# BandwidthThrottling

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Enable** | **bool** | states if the bandwidth limit is set or not | 
**BandwidthLimitMbps** | **int64** | defines the limit in mbs per second | 

## Methods

### NewBandwidthThrottling

`func NewBandwidthThrottling(enable bool, bandwidthLimitMbps int64, ) *BandwidthThrottling`

NewBandwidthThrottling instantiates a new BandwidthThrottling object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewBandwidthThrottlingWithDefaults

`func NewBandwidthThrottlingWithDefaults() *BandwidthThrottling`

NewBandwidthThrottlingWithDefaults instantiates a new BandwidthThrottling object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetEnable

`func (o *BandwidthThrottling) GetEnable() bool`

GetEnable returns the Enable field if non-nil, zero value otherwise.

### GetEnableOk

`func (o *BandwidthThrottling) GetEnableOk() (*bool, bool)`

GetEnableOk returns a tuple with the Enable field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetEnable

`func (o *BandwidthThrottling) SetEnable(v bool)`

SetEnable sets Enable field to given value.


### GetBandwidthLimitMbps

`func (o *BandwidthThrottling) GetBandwidthLimitMbps() int64`

GetBandwidthLimitMbps returns the BandwidthLimitMbps field if non-nil, zero value otherwise.

### GetBandwidthLimitMbpsOk

`func (o *BandwidthThrottling) GetBandwidthLimitMbpsOk() (*int64, bool)`

GetBandwidthLimitMbpsOk returns a tuple with the BandwidthLimitMbps field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetBandwidthLimitMbps

`func (o *BandwidthThrottling) SetBandwidthLimitMbps(v int64)`

SetBandwidthLimitMbps sets BandwidthLimitMbps field to given value.



[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


