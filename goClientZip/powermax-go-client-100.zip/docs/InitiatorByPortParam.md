# InitiatorByPortParam

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**StartDate** | **int64** | Starting date in millisecond. | 
**EndDate** | **int64** | Ending date in millisecond. | 
**SymmetrixId** | **string** | &lt;p&gt;The Symmetrix array ID.&lt;/p&gt; | 
**InitiatorByPortId** | **string** | initiatorByPortId | 
**DataFormat** | Pointer to **string** | &lt;p&gt;Data Format (Average or Maximum).&lt;/p&gt;   Enumeration values: * **Average** * **Maximum**  | [optional] 
**Metrics** | **[]string** | metrics   Enumeration values: * **HostIOs** - Host IOs/sec * **MBs** - Host MBs/sec * **HostMBReads** - Host MBs Read/sec * **HostMBWrites** - Host MBs Written/sec * **Reads** - Host Reads/sec * **ResponseTime** - Response Time (ms) * **ReadResponseTime** - Read RT (ms) * **WriteReponseTime** -  * **WriteResponseTime** - Write RT (ms) * **SyscallCount** - Syscall Count/sec * **Writes** - Host Writes/sec * **BandwidthLimitExceededSecs** - Sum of the number of seconds that the dir:port:initiator combination was running with maximum quotas.  | 

## Methods

### NewInitiatorByPortParam

`func NewInitiatorByPortParam(startDate int64, endDate int64, symmetrixId string, initiatorByPortId string, metrics []string, ) *InitiatorByPortParam`

NewInitiatorByPortParam instantiates a new InitiatorByPortParam object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewInitiatorByPortParamWithDefaults

`func NewInitiatorByPortParamWithDefaults() *InitiatorByPortParam`

NewInitiatorByPortParamWithDefaults instantiates a new InitiatorByPortParam object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetStartDate

`func (o *InitiatorByPortParam) GetStartDate() int64`

GetStartDate returns the StartDate field if non-nil, zero value otherwise.

### GetStartDateOk

`func (o *InitiatorByPortParam) GetStartDateOk() (*int64, bool)`

GetStartDateOk returns a tuple with the StartDate field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetStartDate

`func (o *InitiatorByPortParam) SetStartDate(v int64)`

SetStartDate sets StartDate field to given value.


### GetEndDate

`func (o *InitiatorByPortParam) GetEndDate() int64`

GetEndDate returns the EndDate field if non-nil, zero value otherwise.

### GetEndDateOk

`func (o *InitiatorByPortParam) GetEndDateOk() (*int64, bool)`

GetEndDateOk returns a tuple with the EndDate field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetEndDate

`func (o *InitiatorByPortParam) SetEndDate(v int64)`

SetEndDate sets EndDate field to given value.


### GetSymmetrixId

`func (o *InitiatorByPortParam) GetSymmetrixId() string`

GetSymmetrixId returns the SymmetrixId field if non-nil, zero value otherwise.

### GetSymmetrixIdOk

`func (o *InitiatorByPortParam) GetSymmetrixIdOk() (*string, bool)`

GetSymmetrixIdOk returns a tuple with the SymmetrixId field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetSymmetrixId

`func (o *InitiatorByPortParam) SetSymmetrixId(v string)`

SetSymmetrixId sets SymmetrixId field to given value.


### GetInitiatorByPortId

`func (o *InitiatorByPortParam) GetInitiatorByPortId() string`

GetInitiatorByPortId returns the InitiatorByPortId field if non-nil, zero value otherwise.

### GetInitiatorByPortIdOk

`func (o *InitiatorByPortParam) GetInitiatorByPortIdOk() (*string, bool)`

GetInitiatorByPortIdOk returns a tuple with the InitiatorByPortId field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetInitiatorByPortId

`func (o *InitiatorByPortParam) SetInitiatorByPortId(v string)`

SetInitiatorByPortId sets InitiatorByPortId field to given value.


### GetDataFormat

`func (o *InitiatorByPortParam) GetDataFormat() string`

GetDataFormat returns the DataFormat field if non-nil, zero value otherwise.

### GetDataFormatOk

`func (o *InitiatorByPortParam) GetDataFormatOk() (*string, bool)`

GetDataFormatOk returns a tuple with the DataFormat field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetDataFormat

`func (o *InitiatorByPortParam) SetDataFormat(v string)`

SetDataFormat sets DataFormat field to given value.

### HasDataFormat

`func (o *InitiatorByPortParam) HasDataFormat() bool`

HasDataFormat returns a boolean if a field has been set.

### GetMetrics

`func (o *InitiatorByPortParam) GetMetrics() []string`

GetMetrics returns the Metrics field if non-nil, zero value otherwise.

### GetMetricsOk

`func (o *InitiatorByPortParam) GetMetricsOk() (*[]string, bool)`

GetMetricsOk returns a tuple with the Metrics field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetMetrics

`func (o *InitiatorByPortParam) SetMetrics(v []string)`

SetMetrics sets Metrics field to given value.



[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


