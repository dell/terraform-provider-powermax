# CreateCloudSystemTeamParam

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ExecutionOption** | Pointer to **string** |  | [optional] [default to "SYNCHRONOUS"]
**IpAddress** | **string** | The IP Address of the NIC Team | 
**Prefix** | **int32** | The Netmask Prefix Number of the NIC Team | 
**InterfaceId** | **[]string** | The List of the Interface ids to be associated with the NIC Team | 

## Methods

### NewCreateCloudSystemTeamParam

`func NewCreateCloudSystemTeamParam(ipAddress string, prefix int32, interfaceId []string, ) *CreateCloudSystemTeamParam`

NewCreateCloudSystemTeamParam instantiates a new CreateCloudSystemTeamParam object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewCreateCloudSystemTeamParamWithDefaults

`func NewCreateCloudSystemTeamParamWithDefaults() *CreateCloudSystemTeamParam`

NewCreateCloudSystemTeamParamWithDefaults instantiates a new CreateCloudSystemTeamParam object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetExecutionOption

`func (o *CreateCloudSystemTeamParam) GetExecutionOption() string`

GetExecutionOption returns the ExecutionOption field if non-nil, zero value otherwise.

### GetExecutionOptionOk

`func (o *CreateCloudSystemTeamParam) GetExecutionOptionOk() (*string, bool)`

GetExecutionOptionOk returns a tuple with the ExecutionOption field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetExecutionOption

`func (o *CreateCloudSystemTeamParam) SetExecutionOption(v string)`

SetExecutionOption sets ExecutionOption field to given value.

### HasExecutionOption

`func (o *CreateCloudSystemTeamParam) HasExecutionOption() bool`

HasExecutionOption returns a boolean if a field has been set.

### GetIpAddress

`func (o *CreateCloudSystemTeamParam) GetIpAddress() string`

GetIpAddress returns the IpAddress field if non-nil, zero value otherwise.

### GetIpAddressOk

`func (o *CreateCloudSystemTeamParam) GetIpAddressOk() (*string, bool)`

GetIpAddressOk returns a tuple with the IpAddress field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetIpAddress

`func (o *CreateCloudSystemTeamParam) SetIpAddress(v string)`

SetIpAddress sets IpAddress field to given value.


### GetPrefix

`func (o *CreateCloudSystemTeamParam) GetPrefix() int32`

GetPrefix returns the Prefix field if non-nil, zero value otherwise.

### GetPrefixOk

`func (o *CreateCloudSystemTeamParam) GetPrefixOk() (*int32, bool)`

GetPrefixOk returns a tuple with the Prefix field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetPrefix

`func (o *CreateCloudSystemTeamParam) SetPrefix(v int32)`

SetPrefix sets Prefix field to given value.


### GetInterfaceId

`func (o *CreateCloudSystemTeamParam) GetInterfaceId() []string`

GetInterfaceId returns the InterfaceId field if non-nil, zero value otherwise.

### GetInterfaceIdOk

`func (o *CreateCloudSystemTeamParam) GetInterfaceIdOk() (*[]string, bool)`

GetInterfaceIdOk returns a tuple with the InterfaceId field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetInterfaceId

`func (o *CreateCloudSystemTeamParam) SetInterfaceId(v []string)`

SetInterfaceId sets InterfaceId field to given value.



[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


