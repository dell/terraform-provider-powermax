# CloudSnapshotList

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**CloudSnapshotInfos** | Pointer to [**[]CloudSnapshotInfo**](CloudSnapshotInfo.md) | A list of the cloud snapshot Infos | [optional] 

## Methods

### NewCloudSnapshotList

`func NewCloudSnapshotList() *CloudSnapshotList`

NewCloudSnapshotList instantiates a new CloudSnapshotList object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewCloudSnapshotListWithDefaults

`func NewCloudSnapshotListWithDefaults() *CloudSnapshotList`

NewCloudSnapshotListWithDefaults instantiates a new CloudSnapshotList object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetCloudSnapshotInfos

`func (o *CloudSnapshotList) GetCloudSnapshotInfos() []CloudSnapshotInfo`

GetCloudSnapshotInfos returns the CloudSnapshotInfos field if non-nil, zero value otherwise.

### GetCloudSnapshotInfosOk

`func (o *CloudSnapshotList) GetCloudSnapshotInfosOk() (*[]CloudSnapshotInfo, bool)`

GetCloudSnapshotInfosOk returns a tuple with the CloudSnapshotInfos field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetCloudSnapshotInfos

`func (o *CloudSnapshotList) SetCloudSnapshotInfos(v []CloudSnapshotInfo)`

SetCloudSnapshotInfos sets CloudSnapshotInfos field to given value.

### HasCloudSnapshotInfos

`func (o *CloudSnapshotList) HasCloudSnapshotInfos() bool`

HasCloudSnapshotInfos returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


