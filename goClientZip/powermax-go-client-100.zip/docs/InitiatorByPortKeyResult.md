# InitiatorByPortKeyResult

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**InitiatorByPortInfo** | Pointer to [**[]InitiatorByPortInfo**](InitiatorByPortInfo.md) | initiatorByPortInfo | [optional] 

## Methods

### NewInitiatorByPortKeyResult

`func NewInitiatorByPortKeyResult() *InitiatorByPortKeyResult`

NewInitiatorByPortKeyResult instantiates a new InitiatorByPortKeyResult object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewInitiatorByPortKeyResultWithDefaults

`func NewInitiatorByPortKeyResultWithDefaults() *InitiatorByPortKeyResult`

NewInitiatorByPortKeyResultWithDefaults instantiates a new InitiatorByPortKeyResult object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetInitiatorByPortInfo

`func (o *InitiatorByPortKeyResult) GetInitiatorByPortInfo() []InitiatorByPortInfo`

GetInitiatorByPortInfo returns the InitiatorByPortInfo field if non-nil, zero value otherwise.

### GetInitiatorByPortInfoOk

`func (o *InitiatorByPortKeyResult) GetInitiatorByPortInfoOk() (*[]InitiatorByPortInfo, bool)`

GetInitiatorByPortInfoOk returns a tuple with the InitiatorByPortInfo field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetInitiatorByPortInfo

`func (o *InitiatorByPortKeyResult) SetInitiatorByPortInfo(v []InitiatorByPortInfo)`

SetInitiatorByPortInfo sets InitiatorByPortInfo field to given value.

### HasInitiatorByPortInfo

`func (o *InitiatorByPortKeyResult) HasInitiatorByPortInfo() bool`

HasInitiatorByPortInfo returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


