# Director

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Availability** | Pointer to **string** | The Status of the Director | [optional] 
**DirectorNumber** | Pointer to **int64** | The director number | [optional] 
**DirectorSlotNumber** | Pointer to **int64** | The identifier of the SRDF director | [optional] 
**DirectorId** | **string** | The director Id | 
**NumOfPorts** | Pointer to **int64** | The number of ports on that director. | [optional] 
**SrdfGroups** | Pointer to [**[]RdfGroupId**](RdfGroupId.md) | SRDF Group Numbers for RDF directors. | [optional] 
**NumOfCores** | Pointer to **int64** | The number of cores for the director. | [optional] 

## Methods

### NewDirector

`func NewDirector(directorId string, ) *Director`

NewDirector instantiates a new Director object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewDirectorWithDefaults

`func NewDirectorWithDefaults() *Director`

NewDirectorWithDefaults instantiates a new Director object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetAvailability

`func (o *Director) GetAvailability() string`

GetAvailability returns the Availability field if non-nil, zero value otherwise.

### GetAvailabilityOk

`func (o *Director) GetAvailabilityOk() (*string, bool)`

GetAvailabilityOk returns a tuple with the Availability field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetAvailability

`func (o *Director) SetAvailability(v string)`

SetAvailability sets Availability field to given value.

### HasAvailability

`func (o *Director) HasAvailability() bool`

HasAvailability returns a boolean if a field has been set.

### GetDirectorNumber

`func (o *Director) GetDirectorNumber() int64`

GetDirectorNumber returns the DirectorNumber field if non-nil, zero value otherwise.

### GetDirectorNumberOk

`func (o *Director) GetDirectorNumberOk() (*int64, bool)`

GetDirectorNumberOk returns a tuple with the DirectorNumber field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetDirectorNumber

`func (o *Director) SetDirectorNumber(v int64)`

SetDirectorNumber sets DirectorNumber field to given value.

### HasDirectorNumber

`func (o *Director) HasDirectorNumber() bool`

HasDirectorNumber returns a boolean if a field has been set.

### GetDirectorSlotNumber

`func (o *Director) GetDirectorSlotNumber() int64`

GetDirectorSlotNumber returns the DirectorSlotNumber field if non-nil, zero value otherwise.

### GetDirectorSlotNumberOk

`func (o *Director) GetDirectorSlotNumberOk() (*int64, bool)`

GetDirectorSlotNumberOk returns a tuple with the DirectorSlotNumber field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetDirectorSlotNumber

`func (o *Director) SetDirectorSlotNumber(v int64)`

SetDirectorSlotNumber sets DirectorSlotNumber field to given value.

### HasDirectorSlotNumber

`func (o *Director) HasDirectorSlotNumber() bool`

HasDirectorSlotNumber returns a boolean if a field has been set.

### GetDirectorId

`func (o *Director) GetDirectorId() string`

GetDirectorId returns the DirectorId field if non-nil, zero value otherwise.

### GetDirectorIdOk

`func (o *Director) GetDirectorIdOk() (*string, bool)`

GetDirectorIdOk returns a tuple with the DirectorId field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetDirectorId

`func (o *Director) SetDirectorId(v string)`

SetDirectorId sets DirectorId field to given value.


### GetNumOfPorts

`func (o *Director) GetNumOfPorts() int64`

GetNumOfPorts returns the NumOfPorts field if non-nil, zero value otherwise.

### GetNumOfPortsOk

`func (o *Director) GetNumOfPortsOk() (*int64, bool)`

GetNumOfPortsOk returns a tuple with the NumOfPorts field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetNumOfPorts

`func (o *Director) SetNumOfPorts(v int64)`

SetNumOfPorts sets NumOfPorts field to given value.

### HasNumOfPorts

`func (o *Director) HasNumOfPorts() bool`

HasNumOfPorts returns a boolean if a field has been set.

### GetSrdfGroups

`func (o *Director) GetSrdfGroups() []RdfGroupId`

GetSrdfGroups returns the SrdfGroups field if non-nil, zero value otherwise.

### GetSrdfGroupsOk

`func (o *Director) GetSrdfGroupsOk() (*[]RdfGroupId, bool)`

GetSrdfGroupsOk returns a tuple with the SrdfGroups field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetSrdfGroups

`func (o *Director) SetSrdfGroups(v []RdfGroupId)`

SetSrdfGroups sets SrdfGroups field to given value.

### HasSrdfGroups

`func (o *Director) HasSrdfGroups() bool`

HasSrdfGroups returns a boolean if a field has been set.

### GetNumOfCores

`func (o *Director) GetNumOfCores() int64`

GetNumOfCores returns the NumOfCores field if non-nil, zero value otherwise.

### GetNumOfCoresOk

`func (o *Director) GetNumOfCoresOk() (*int64, bool)`

GetNumOfCoresOk returns a tuple with the NumOfCores field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetNumOfCores

`func (o *Director) SetNumOfCores(v int64)`

SetNumOfCores sets NumOfCores field to given value.

### HasNumOfCores

`func (o *Director) HasNumOfCores() bool`

HasNumOfCores returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


