# IpInterfaceList

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ExecutionOption** | Pointer to **string** |  | [optional] [default to "SYNCHRONOUS"]
**IpInterfaceId** | Pointer to **[]string** | ipInterfaceId | [optional] 

## Methods

### NewIpInterfaceList

`func NewIpInterfaceList() *IpInterfaceList`

NewIpInterfaceList instantiates a new IpInterfaceList object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewIpInterfaceListWithDefaults

`func NewIpInterfaceListWithDefaults() *IpInterfaceList`

NewIpInterfaceListWithDefaults instantiates a new IpInterfaceList object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetExecutionOption

`func (o *IpInterfaceList) GetExecutionOption() string`

GetExecutionOption returns the ExecutionOption field if non-nil, zero value otherwise.

### GetExecutionOptionOk

`func (o *IpInterfaceList) GetExecutionOptionOk() (*string, bool)`

GetExecutionOptionOk returns a tuple with the ExecutionOption field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetExecutionOption

`func (o *IpInterfaceList) SetExecutionOption(v string)`

SetExecutionOption sets ExecutionOption field to given value.

### HasExecutionOption

`func (o *IpInterfaceList) HasExecutionOption() bool`

HasExecutionOption returns a boolean if a field has been set.

### GetIpInterfaceId

`func (o *IpInterfaceList) GetIpInterfaceId() []string`

GetIpInterfaceId returns the IpInterfaceId field if non-nil, zero value otherwise.

### GetIpInterfaceIdOk

`func (o *IpInterfaceList) GetIpInterfaceIdOk() (*[]string, bool)`

GetIpInterfaceIdOk returns a tuple with the IpInterfaceId field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetIpInterfaceId

`func (o *IpInterfaceList) SetIpInterfaceId(v []string)`

SetIpInterfaceId sets IpInterfaceId field to given value.

### HasIpInterfaceId

`func (o *IpInterfaceList) HasIpInterfaceId() bool`

HasIpInterfaceId returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


