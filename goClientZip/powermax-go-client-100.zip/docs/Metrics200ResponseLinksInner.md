# Metrics200ResponseLinksInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Type** | Pointer to **string** |  | [optional] 
**Params** | Pointer to **map[string]string** |  | [optional] 
**Uri** | Pointer to **string** |  | [optional] 
**Title** | Pointer to **string** |  | [optional] 
**Rels** | Pointer to **[]string** |  | [optional] 
**Rel** | Pointer to **string** |  | [optional] 
**UriBuilder** | Pointer to **map[string]interface{}** |  | [optional] 

## Methods

### NewMetrics200ResponseLinksInner

`func NewMetrics200ResponseLinksInner() *Metrics200ResponseLinksInner`

NewMetrics200ResponseLinksInner instantiates a new Metrics200ResponseLinksInner object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewMetrics200ResponseLinksInnerWithDefaults

`func NewMetrics200ResponseLinksInnerWithDefaults() *Metrics200ResponseLinksInner`

NewMetrics200ResponseLinksInnerWithDefaults instantiates a new Metrics200ResponseLinksInner object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetType

`func (o *Metrics200ResponseLinksInner) GetType() string`

GetType returns the Type field if non-nil, zero value otherwise.

### GetTypeOk

`func (o *Metrics200ResponseLinksInner) GetTypeOk() (*string, bool)`

GetTypeOk returns a tuple with the Type field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetType

`func (o *Metrics200ResponseLinksInner) SetType(v string)`

SetType sets Type field to given value.

### HasType

`func (o *Metrics200ResponseLinksInner) HasType() bool`

HasType returns a boolean if a field has been set.

### GetParams

`func (o *Metrics200ResponseLinksInner) GetParams() map[string]string`

GetParams returns the Params field if non-nil, zero value otherwise.

### GetParamsOk

`func (o *Metrics200ResponseLinksInner) GetParamsOk() (*map[string]string, bool)`

GetParamsOk returns a tuple with the Params field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetParams

`func (o *Metrics200ResponseLinksInner) SetParams(v map[string]string)`

SetParams sets Params field to given value.

### HasParams

`func (o *Metrics200ResponseLinksInner) HasParams() bool`

HasParams returns a boolean if a field has been set.

### GetUri

`func (o *Metrics200ResponseLinksInner) GetUri() string`

GetUri returns the Uri field if non-nil, zero value otherwise.

### GetUriOk

`func (o *Metrics200ResponseLinksInner) GetUriOk() (*string, bool)`

GetUriOk returns a tuple with the Uri field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetUri

`func (o *Metrics200ResponseLinksInner) SetUri(v string)`

SetUri sets Uri field to given value.

### HasUri

`func (o *Metrics200ResponseLinksInner) HasUri() bool`

HasUri returns a boolean if a field has been set.

### GetTitle

`func (o *Metrics200ResponseLinksInner) GetTitle() string`

GetTitle returns the Title field if non-nil, zero value otherwise.

### GetTitleOk

`func (o *Metrics200ResponseLinksInner) GetTitleOk() (*string, bool)`

GetTitleOk returns a tuple with the Title field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetTitle

`func (o *Metrics200ResponseLinksInner) SetTitle(v string)`

SetTitle sets Title field to given value.

### HasTitle

`func (o *Metrics200ResponseLinksInner) HasTitle() bool`

HasTitle returns a boolean if a field has been set.

### GetRels

`func (o *Metrics200ResponseLinksInner) GetRels() []string`

GetRels returns the Rels field if non-nil, zero value otherwise.

### GetRelsOk

`func (o *Metrics200ResponseLinksInner) GetRelsOk() (*[]string, bool)`

GetRelsOk returns a tuple with the Rels field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetRels

`func (o *Metrics200ResponseLinksInner) SetRels(v []string)`

SetRels sets Rels field to given value.

### HasRels

`func (o *Metrics200ResponseLinksInner) HasRels() bool`

HasRels returns a boolean if a field has been set.

### GetRel

`func (o *Metrics200ResponseLinksInner) GetRel() string`

GetRel returns the Rel field if non-nil, zero value otherwise.

### GetRelOk

`func (o *Metrics200ResponseLinksInner) GetRelOk() (*string, bool)`

GetRelOk returns a tuple with the Rel field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetRel

`func (o *Metrics200ResponseLinksInner) SetRel(v string)`

SetRel sets Rel field to given value.

### HasRel

`func (o *Metrics200ResponseLinksInner) HasRel() bool`

HasRel returns a boolean if a field has been set.

### GetUriBuilder

`func (o *Metrics200ResponseLinksInner) GetUriBuilder() map[string]interface{}`

GetUriBuilder returns the UriBuilder field if non-nil, zero value otherwise.

### GetUriBuilderOk

`func (o *Metrics200ResponseLinksInner) GetUriBuilderOk() (*map[string]interface{}, bool)`

GetUriBuilderOk returns a tuple with the UriBuilder field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetUriBuilder

`func (o *Metrics200ResponseLinksInner) SetUriBuilder(v map[string]interface{})`

SetUriBuilder sets UriBuilder field to given value.

### HasUriBuilder

`func (o *Metrics200ResponseLinksInner) HasUriBuilder() bool`

HasUriBuilder returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


