# ListCloudSystemRouteResult

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**RouteId** | Pointer to **[]string** | route_id | [optional] 

## Methods

### NewListCloudSystemRouteResult

`func NewListCloudSystemRouteResult() *ListCloudSystemRouteResult`

NewListCloudSystemRouteResult instantiates a new ListCloudSystemRouteResult object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewListCloudSystemRouteResultWithDefaults

`func NewListCloudSystemRouteResultWithDefaults() *ListCloudSystemRouteResult`

NewListCloudSystemRouteResultWithDefaults instantiates a new ListCloudSystemRouteResult object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetRouteId

`func (o *ListCloudSystemRouteResult) GetRouteId() []string`

GetRouteId returns the RouteId field if non-nil, zero value otherwise.

### GetRouteIdOk

`func (o *ListCloudSystemRouteResult) GetRouteIdOk() (*[]string, bool)`

GetRouteIdOk returns a tuple with the RouteId field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetRouteId

`func (o *ListCloudSystemRouteResult) SetRouteId(v []string)`

SetRouteId sets RouteId field to given value.

### HasRouteId

`func (o *ListCloudSystemRouteResult) HasRouteId() bool`

HasRouteId returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


