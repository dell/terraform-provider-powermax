# MetroDrEnvironmentCreate

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ExecutionOption** | Pointer to **string** |  | [optional] [default to "SYNCHRONOUS"]
**Action** | **string** | The action to be performed.   Enumeration values: * **CreateEnvironment** * **ConvertToMetroDR**  | 
**CreateEnvironmentParam** | Pointer to [**StorageGroupMetroDrEnvironmentCreate**](StorageGroupMetroDrEnvironmentCreate.md) |  | [optional] 
**ConvertToMetrodrParam** | Pointer to [**SgConvertMetroDRParam**](SgConvertMetroDRParam.md) |  | [optional] 

## Methods

### NewMetroDrEnvironmentCreate

`func NewMetroDrEnvironmentCreate(action string, ) *MetroDrEnvironmentCreate`

NewMetroDrEnvironmentCreate instantiates a new MetroDrEnvironmentCreate object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewMetroDrEnvironmentCreateWithDefaults

`func NewMetroDrEnvironmentCreateWithDefaults() *MetroDrEnvironmentCreate`

NewMetroDrEnvironmentCreateWithDefaults instantiates a new MetroDrEnvironmentCreate object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetExecutionOption

`func (o *MetroDrEnvironmentCreate) GetExecutionOption() string`

GetExecutionOption returns the ExecutionOption field if non-nil, zero value otherwise.

### GetExecutionOptionOk

`func (o *MetroDrEnvironmentCreate) GetExecutionOptionOk() (*string, bool)`

GetExecutionOptionOk returns a tuple with the ExecutionOption field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetExecutionOption

`func (o *MetroDrEnvironmentCreate) SetExecutionOption(v string)`

SetExecutionOption sets ExecutionOption field to given value.

### HasExecutionOption

`func (o *MetroDrEnvironmentCreate) HasExecutionOption() bool`

HasExecutionOption returns a boolean if a field has been set.

### GetAction

`func (o *MetroDrEnvironmentCreate) GetAction() string`

GetAction returns the Action field if non-nil, zero value otherwise.

### GetActionOk

`func (o *MetroDrEnvironmentCreate) GetActionOk() (*string, bool)`

GetActionOk returns a tuple with the Action field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetAction

`func (o *MetroDrEnvironmentCreate) SetAction(v string)`

SetAction sets Action field to given value.


### GetCreateEnvironmentParam

`func (o *MetroDrEnvironmentCreate) GetCreateEnvironmentParam() StorageGroupMetroDrEnvironmentCreate`

GetCreateEnvironmentParam returns the CreateEnvironmentParam field if non-nil, zero value otherwise.

### GetCreateEnvironmentParamOk

`func (o *MetroDrEnvironmentCreate) GetCreateEnvironmentParamOk() (*StorageGroupMetroDrEnvironmentCreate, bool)`

GetCreateEnvironmentParamOk returns a tuple with the CreateEnvironmentParam field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetCreateEnvironmentParam

`func (o *MetroDrEnvironmentCreate) SetCreateEnvironmentParam(v StorageGroupMetroDrEnvironmentCreate)`

SetCreateEnvironmentParam sets CreateEnvironmentParam field to given value.

### HasCreateEnvironmentParam

`func (o *MetroDrEnvironmentCreate) HasCreateEnvironmentParam() bool`

HasCreateEnvironmentParam returns a boolean if a field has been set.

### GetConvertToMetrodrParam

`func (o *MetroDrEnvironmentCreate) GetConvertToMetrodrParam() SgConvertMetroDRParam`

GetConvertToMetrodrParam returns the ConvertToMetrodrParam field if non-nil, zero value otherwise.

### GetConvertToMetrodrParamOk

`func (o *MetroDrEnvironmentCreate) GetConvertToMetrodrParamOk() (*SgConvertMetroDRParam, bool)`

GetConvertToMetrodrParamOk returns a tuple with the ConvertToMetrodrParam field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetConvertToMetrodrParam

`func (o *MetroDrEnvironmentCreate) SetConvertToMetrodrParam(v SgConvertMetroDRParam)`

SetConvertToMetrodrParam sets ConvertToMetrodrParam field to given value.

### HasConvertToMetrodrParam

`func (o *MetroDrEnvironmentCreate) HasConvertToMetrodrParam() bool`

HasConvertToMetrodrParam returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


