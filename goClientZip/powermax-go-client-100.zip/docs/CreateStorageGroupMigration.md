# CreateStorageGroupMigration

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**SourceStorageGroupId** | **string** | The name of the source StorageGroup. | 
**OtherArrayId** | **string** | The System ID for the target of the migration | 
**SrpId** | Pointer to **string** | The name of the migration session target System SRP. | [optional] 
**PortGroupId** | Pointer to **string** | The name of the migration session target System port group if name differs                                 from name on source System.  Port group with matching name must already exist on target                                 System or be defined as a precreate_port_group. | [optional] 
**PrecreatePortGroupParam** | Pointer to [**[]CreatePortGroupParam**](CreatePortGroupParam.md) | Precreate one or more port groups on the migration session target System with                                 the specified names and port lists. PortGroupIds in this object must match portGroupIds from                                 source System unless portGroupId attribute of createStorageGroupMigration is also specified.                                 In that case, only a single precreate_port_group object is allowed and the portGroupId attributes in                                 createStorageGroupMigration and precreate_port_group must match. | [optional] 
**NoCompression** | Pointer to **bool** | Create the target Storage Group without compression. Only supported when the target System and SRP support compression. | [optional] 
**PreCopy** | Pointer to **bool** | Create the migration using the precopy option. Only supported when both the source and target System support create with                                 precopy. | [optional] 
**Offline** | Pointer to **bool** | Used to create a minimally disruptive migration | [optional] 
**MoveIdentity** | Pointer to **bool** | The same device identities as used to access the devices on the source System will be used by the target System devices. | [optional] 
**Validate** | Pointer to **bool** | Just run the validation to see if the Migration can be created. Don&#39;t actually run the create itself. | [optional] 
**PerformanceImpactValidationOption** | Pointer to **string** | performance_Impact_Validation_Option   Enumeration values: * **Preview** -                          Run performance impact tests and return performance impact scores for requested operation.                         Return input object (with generated fields, if applicable) for relevant followup API.                      * **IfRecommended** -                          Run performance impact tests. If no performance capacity threshold is breached, run the                         requested configuration change operation. If a performance capacity threshold is breached,                         Return tested input object (with generated fields, if applicable), performance impact scores                         for requested operation, and relevant warnings/errors.                       | [optional] 

## Methods

### NewCreateStorageGroupMigration

`func NewCreateStorageGroupMigration(sourceStorageGroupId string, otherArrayId string, ) *CreateStorageGroupMigration`

NewCreateStorageGroupMigration instantiates a new CreateStorageGroupMigration object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewCreateStorageGroupMigrationWithDefaults

`func NewCreateStorageGroupMigrationWithDefaults() *CreateStorageGroupMigration`

NewCreateStorageGroupMigrationWithDefaults instantiates a new CreateStorageGroupMigration object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetSourceStorageGroupId

`func (o *CreateStorageGroupMigration) GetSourceStorageGroupId() string`

GetSourceStorageGroupId returns the SourceStorageGroupId field if non-nil, zero value otherwise.

### GetSourceStorageGroupIdOk

`func (o *CreateStorageGroupMigration) GetSourceStorageGroupIdOk() (*string, bool)`

GetSourceStorageGroupIdOk returns a tuple with the SourceStorageGroupId field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetSourceStorageGroupId

`func (o *CreateStorageGroupMigration) SetSourceStorageGroupId(v string)`

SetSourceStorageGroupId sets SourceStorageGroupId field to given value.


### GetOtherArrayId

`func (o *CreateStorageGroupMigration) GetOtherArrayId() string`

GetOtherArrayId returns the OtherArrayId field if non-nil, zero value otherwise.

### GetOtherArrayIdOk

`func (o *CreateStorageGroupMigration) GetOtherArrayIdOk() (*string, bool)`

GetOtherArrayIdOk returns a tuple with the OtherArrayId field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetOtherArrayId

`func (o *CreateStorageGroupMigration) SetOtherArrayId(v string)`

SetOtherArrayId sets OtherArrayId field to given value.


### GetSrpId

`func (o *CreateStorageGroupMigration) GetSrpId() string`

GetSrpId returns the SrpId field if non-nil, zero value otherwise.

### GetSrpIdOk

`func (o *CreateStorageGroupMigration) GetSrpIdOk() (*string, bool)`

GetSrpIdOk returns a tuple with the SrpId field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetSrpId

`func (o *CreateStorageGroupMigration) SetSrpId(v string)`

SetSrpId sets SrpId field to given value.

### HasSrpId

`func (o *CreateStorageGroupMigration) HasSrpId() bool`

HasSrpId returns a boolean if a field has been set.

### GetPortGroupId

`func (o *CreateStorageGroupMigration) GetPortGroupId() string`

GetPortGroupId returns the PortGroupId field if non-nil, zero value otherwise.

### GetPortGroupIdOk

`func (o *CreateStorageGroupMigration) GetPortGroupIdOk() (*string, bool)`

GetPortGroupIdOk returns a tuple with the PortGroupId field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetPortGroupId

`func (o *CreateStorageGroupMigration) SetPortGroupId(v string)`

SetPortGroupId sets PortGroupId field to given value.

### HasPortGroupId

`func (o *CreateStorageGroupMigration) HasPortGroupId() bool`

HasPortGroupId returns a boolean if a field has been set.

### GetPrecreatePortGroupParam

`func (o *CreateStorageGroupMigration) GetPrecreatePortGroupParam() []CreatePortGroupParam`

GetPrecreatePortGroupParam returns the PrecreatePortGroupParam field if non-nil, zero value otherwise.

### GetPrecreatePortGroupParamOk

`func (o *CreateStorageGroupMigration) GetPrecreatePortGroupParamOk() (*[]CreatePortGroupParam, bool)`

GetPrecreatePortGroupParamOk returns a tuple with the PrecreatePortGroupParam field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetPrecreatePortGroupParam

`func (o *CreateStorageGroupMigration) SetPrecreatePortGroupParam(v []CreatePortGroupParam)`

SetPrecreatePortGroupParam sets PrecreatePortGroupParam field to given value.

### HasPrecreatePortGroupParam

`func (o *CreateStorageGroupMigration) HasPrecreatePortGroupParam() bool`

HasPrecreatePortGroupParam returns a boolean if a field has been set.

### GetNoCompression

`func (o *CreateStorageGroupMigration) GetNoCompression() bool`

GetNoCompression returns the NoCompression field if non-nil, zero value otherwise.

### GetNoCompressionOk

`func (o *CreateStorageGroupMigration) GetNoCompressionOk() (*bool, bool)`

GetNoCompressionOk returns a tuple with the NoCompression field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetNoCompression

`func (o *CreateStorageGroupMigration) SetNoCompression(v bool)`

SetNoCompression sets NoCompression field to given value.

### HasNoCompression

`func (o *CreateStorageGroupMigration) HasNoCompression() bool`

HasNoCompression returns a boolean if a field has been set.

### GetPreCopy

`func (o *CreateStorageGroupMigration) GetPreCopy() bool`

GetPreCopy returns the PreCopy field if non-nil, zero value otherwise.

### GetPreCopyOk

`func (o *CreateStorageGroupMigration) GetPreCopyOk() (*bool, bool)`

GetPreCopyOk returns a tuple with the PreCopy field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetPreCopy

`func (o *CreateStorageGroupMigration) SetPreCopy(v bool)`

SetPreCopy sets PreCopy field to given value.

### HasPreCopy

`func (o *CreateStorageGroupMigration) HasPreCopy() bool`

HasPreCopy returns a boolean if a field has been set.

### GetOffline

`func (o *CreateStorageGroupMigration) GetOffline() bool`

GetOffline returns the Offline field if non-nil, zero value otherwise.

### GetOfflineOk

`func (o *CreateStorageGroupMigration) GetOfflineOk() (*bool, bool)`

GetOfflineOk returns a tuple with the Offline field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetOffline

`func (o *CreateStorageGroupMigration) SetOffline(v bool)`

SetOffline sets Offline field to given value.

### HasOffline

`func (o *CreateStorageGroupMigration) HasOffline() bool`

HasOffline returns a boolean if a field has been set.

### GetMoveIdentity

`func (o *CreateStorageGroupMigration) GetMoveIdentity() bool`

GetMoveIdentity returns the MoveIdentity field if non-nil, zero value otherwise.

### GetMoveIdentityOk

`func (o *CreateStorageGroupMigration) GetMoveIdentityOk() (*bool, bool)`

GetMoveIdentityOk returns a tuple with the MoveIdentity field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetMoveIdentity

`func (o *CreateStorageGroupMigration) SetMoveIdentity(v bool)`

SetMoveIdentity sets MoveIdentity field to given value.

### HasMoveIdentity

`func (o *CreateStorageGroupMigration) HasMoveIdentity() bool`

HasMoveIdentity returns a boolean if a field has been set.

### GetValidate

`func (o *CreateStorageGroupMigration) GetValidate() bool`

GetValidate returns the Validate field if non-nil, zero value otherwise.

### GetValidateOk

`func (o *CreateStorageGroupMigration) GetValidateOk() (*bool, bool)`

GetValidateOk returns a tuple with the Validate field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetValidate

`func (o *CreateStorageGroupMigration) SetValidate(v bool)`

SetValidate sets Validate field to given value.

### HasValidate

`func (o *CreateStorageGroupMigration) HasValidate() bool`

HasValidate returns a boolean if a field has been set.

### GetPerformanceImpactValidationOption

`func (o *CreateStorageGroupMigration) GetPerformanceImpactValidationOption() string`

GetPerformanceImpactValidationOption returns the PerformanceImpactValidationOption field if non-nil, zero value otherwise.

### GetPerformanceImpactValidationOptionOk

`func (o *CreateStorageGroupMigration) GetPerformanceImpactValidationOptionOk() (*string, bool)`

GetPerformanceImpactValidationOptionOk returns a tuple with the PerformanceImpactValidationOption field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetPerformanceImpactValidationOption

`func (o *CreateStorageGroupMigration) SetPerformanceImpactValidationOption(v string)`

SetPerformanceImpactValidationOption sets PerformanceImpactValidationOption field to given value.

### HasPerformanceImpactValidationOption

`func (o *CreateStorageGroupMigration) HasPerformanceImpactValidationOption() bool`

HasPerformanceImpactValidationOption returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


