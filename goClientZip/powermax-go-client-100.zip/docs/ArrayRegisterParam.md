# ArrayRegisterParam

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**SymmetrixId** | **string** | &lt;p&gt;Local Symmetrix array ID or \&quot;ALL\&quot;.&lt;/p&gt; | 
**Diagnostic** | **bool** | &lt;p&gt;True to turn on. 5 minute(default) interval diagnostic stats&lt;/p&gt; | 
**Realtime** | **bool** | &lt;p&gt;True to turn on.  5 seconds(default) interval Real Time stats.&lt;/p&gt; | 
**File** | Pointer to **bool** | &lt;p&gt;True to register for file stats.  register/unregister for File stats using RESTAPI. It will only be possible to register for File if File is supported on the embedded system and Block diagnostic registration is enabled.&lt;/p&gt; | [optional] 

## Methods

### NewArrayRegisterParam

`func NewArrayRegisterParam(symmetrixId string, diagnostic bool, realtime bool, ) *ArrayRegisterParam`

NewArrayRegisterParam instantiates a new ArrayRegisterParam object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewArrayRegisterParamWithDefaults

`func NewArrayRegisterParamWithDefaults() *ArrayRegisterParam`

NewArrayRegisterParamWithDefaults instantiates a new ArrayRegisterParam object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetSymmetrixId

`func (o *ArrayRegisterParam) GetSymmetrixId() string`

GetSymmetrixId returns the SymmetrixId field if non-nil, zero value otherwise.

### GetSymmetrixIdOk

`func (o *ArrayRegisterParam) GetSymmetrixIdOk() (*string, bool)`

GetSymmetrixIdOk returns a tuple with the SymmetrixId field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetSymmetrixId

`func (o *ArrayRegisterParam) SetSymmetrixId(v string)`

SetSymmetrixId sets SymmetrixId field to given value.


### GetDiagnostic

`func (o *ArrayRegisterParam) GetDiagnostic() bool`

GetDiagnostic returns the Diagnostic field if non-nil, zero value otherwise.

### GetDiagnosticOk

`func (o *ArrayRegisterParam) GetDiagnosticOk() (*bool, bool)`

GetDiagnosticOk returns a tuple with the Diagnostic field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetDiagnostic

`func (o *ArrayRegisterParam) SetDiagnostic(v bool)`

SetDiagnostic sets Diagnostic field to given value.


### GetRealtime

`func (o *ArrayRegisterParam) GetRealtime() bool`

GetRealtime returns the Realtime field if non-nil, zero value otherwise.

### GetRealtimeOk

`func (o *ArrayRegisterParam) GetRealtimeOk() (*bool, bool)`

GetRealtimeOk returns a tuple with the Realtime field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetRealtime

`func (o *ArrayRegisterParam) SetRealtime(v bool)`

SetRealtime sets Realtime field to given value.


### GetFile

`func (o *ArrayRegisterParam) GetFile() bool`

GetFile returns the File field if non-nil, zero value otherwise.

### GetFileOk

`func (o *ArrayRegisterParam) GetFileOk() (*bool, bool)`

GetFileOk returns a tuple with the File field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetFile

`func (o *ArrayRegisterParam) SetFile(v bool)`

SetFile sets File field to given value.

### HasFile

`func (o *ArrayRegisterParam) HasFile() bool`

HasFile returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


