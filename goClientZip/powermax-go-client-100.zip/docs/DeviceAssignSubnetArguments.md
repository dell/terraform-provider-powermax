# DeviceAssignSubnetArguments

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Node** | **int32** |                          It is the internalId of the node returned by SDNAS.                      | 
**Fdn** | **string** |                          FDN of the device                      | 
**Subnetv4** | Pointer to **string** |                          The value of the subnetv4                      | [optional] 
**Subnetv6** | Pointer to **string** |                          The value of the subnetv6                      | [optional] 
**FileInterfaces** | Pointer to **[]string** |                          fileinterfaces configured on physical device                      | [optional] 
**NasServers** | Pointer to **[]string** |                          nasServer configured on physical device                      | [optional] 
**ImpactedDevice** | Pointer to **[]string** |                          Impacted Device details                      | [optional] 

## Methods

### NewDeviceAssignSubnetArguments

`func NewDeviceAssignSubnetArguments(node int32, fdn string, ) *DeviceAssignSubnetArguments`

NewDeviceAssignSubnetArguments instantiates a new DeviceAssignSubnetArguments object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewDeviceAssignSubnetArgumentsWithDefaults

`func NewDeviceAssignSubnetArgumentsWithDefaults() *DeviceAssignSubnetArguments`

NewDeviceAssignSubnetArgumentsWithDefaults instantiates a new DeviceAssignSubnetArguments object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetNode

`func (o *DeviceAssignSubnetArguments) GetNode() int32`

GetNode returns the Node field if non-nil, zero value otherwise.

### GetNodeOk

`func (o *DeviceAssignSubnetArguments) GetNodeOk() (*int32, bool)`

GetNodeOk returns a tuple with the Node field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetNode

`func (o *DeviceAssignSubnetArguments) SetNode(v int32)`

SetNode sets Node field to given value.


### GetFdn

`func (o *DeviceAssignSubnetArguments) GetFdn() string`

GetFdn returns the Fdn field if non-nil, zero value otherwise.

### GetFdnOk

`func (o *DeviceAssignSubnetArguments) GetFdnOk() (*string, bool)`

GetFdnOk returns a tuple with the Fdn field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetFdn

`func (o *DeviceAssignSubnetArguments) SetFdn(v string)`

SetFdn sets Fdn field to given value.


### GetSubnetv4

`func (o *DeviceAssignSubnetArguments) GetSubnetv4() string`

GetSubnetv4 returns the Subnetv4 field if non-nil, zero value otherwise.

### GetSubnetv4Ok

`func (o *DeviceAssignSubnetArguments) GetSubnetv4Ok() (*string, bool)`

GetSubnetv4Ok returns a tuple with the Subnetv4 field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetSubnetv4

`func (o *DeviceAssignSubnetArguments) SetSubnetv4(v string)`

SetSubnetv4 sets Subnetv4 field to given value.

### HasSubnetv4

`func (o *DeviceAssignSubnetArguments) HasSubnetv4() bool`

HasSubnetv4 returns a boolean if a field has been set.

### GetSubnetv6

`func (o *DeviceAssignSubnetArguments) GetSubnetv6() string`

GetSubnetv6 returns the Subnetv6 field if non-nil, zero value otherwise.

### GetSubnetv6Ok

`func (o *DeviceAssignSubnetArguments) GetSubnetv6Ok() (*string, bool)`

GetSubnetv6Ok returns a tuple with the Subnetv6 field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetSubnetv6

`func (o *DeviceAssignSubnetArguments) SetSubnetv6(v string)`

SetSubnetv6 sets Subnetv6 field to given value.

### HasSubnetv6

`func (o *DeviceAssignSubnetArguments) HasSubnetv6() bool`

HasSubnetv6 returns a boolean if a field has been set.

### GetFileInterfaces

`func (o *DeviceAssignSubnetArguments) GetFileInterfaces() []string`

GetFileInterfaces returns the FileInterfaces field if non-nil, zero value otherwise.

### GetFileInterfacesOk

`func (o *DeviceAssignSubnetArguments) GetFileInterfacesOk() (*[]string, bool)`

GetFileInterfacesOk returns a tuple with the FileInterfaces field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetFileInterfaces

`func (o *DeviceAssignSubnetArguments) SetFileInterfaces(v []string)`

SetFileInterfaces sets FileInterfaces field to given value.

### HasFileInterfaces

`func (o *DeviceAssignSubnetArguments) HasFileInterfaces() bool`

HasFileInterfaces returns a boolean if a field has been set.

### GetNasServers

`func (o *DeviceAssignSubnetArguments) GetNasServers() []string`

GetNasServers returns the NasServers field if non-nil, zero value otherwise.

### GetNasServersOk

`func (o *DeviceAssignSubnetArguments) GetNasServersOk() (*[]string, bool)`

GetNasServersOk returns a tuple with the NasServers field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetNasServers

`func (o *DeviceAssignSubnetArguments) SetNasServers(v []string)`

SetNasServers sets NasServers field to given value.

### HasNasServers

`func (o *DeviceAssignSubnetArguments) HasNasServers() bool`

HasNasServers returns a boolean if a field has been set.

### GetImpactedDevice

`func (o *DeviceAssignSubnetArguments) GetImpactedDevice() []string`

GetImpactedDevice returns the ImpactedDevice field if non-nil, zero value otherwise.

### GetImpactedDeviceOk

`func (o *DeviceAssignSubnetArguments) GetImpactedDeviceOk() (*[]string, bool)`

GetImpactedDeviceOk returns a tuple with the ImpactedDevice field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetImpactedDevice

`func (o *DeviceAssignSubnetArguments) SetImpactedDevice(v []string)`

SetImpactedDevice sets ImpactedDevice field to given value.

### HasImpactedDevice

`func (o *DeviceAssignSubnetArguments) HasImpactedDevice() bool`

HasImpactedDevice returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


