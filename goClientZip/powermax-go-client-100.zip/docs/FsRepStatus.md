# FsRepStatus

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Name** | Pointer to **string** | name | [optional] 
**Severity** | Pointer to **int32** | severity | [optional] 
**BriefDescription** | Pointer to **string** | brief_description | [optional] 
**FullDescription** | Pointer to **string** | full_description | [optional] 
**RecommendedAction** | Pointer to **string** | recommended_action | [optional] 

## Methods

### NewFsRepStatus

`func NewFsRepStatus() *FsRepStatus`

NewFsRepStatus instantiates a new FsRepStatus object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewFsRepStatusWithDefaults

`func NewFsRepStatusWithDefaults() *FsRepStatus`

NewFsRepStatusWithDefaults instantiates a new FsRepStatus object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetName

`func (o *FsRepStatus) GetName() string`

GetName returns the Name field if non-nil, zero value otherwise.

### GetNameOk

`func (o *FsRepStatus) GetNameOk() (*string, bool)`

GetNameOk returns a tuple with the Name field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetName

`func (o *FsRepStatus) SetName(v string)`

SetName sets Name field to given value.

### HasName

`func (o *FsRepStatus) HasName() bool`

HasName returns a boolean if a field has been set.

### GetSeverity

`func (o *FsRepStatus) GetSeverity() int32`

GetSeverity returns the Severity field if non-nil, zero value otherwise.

### GetSeverityOk

`func (o *FsRepStatus) GetSeverityOk() (*int32, bool)`

GetSeverityOk returns a tuple with the Severity field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetSeverity

`func (o *FsRepStatus) SetSeverity(v int32)`

SetSeverity sets Severity field to given value.

### HasSeverity

`func (o *FsRepStatus) HasSeverity() bool`

HasSeverity returns a boolean if a field has been set.

### GetBriefDescription

`func (o *FsRepStatus) GetBriefDescription() string`

GetBriefDescription returns the BriefDescription field if non-nil, zero value otherwise.

### GetBriefDescriptionOk

`func (o *FsRepStatus) GetBriefDescriptionOk() (*string, bool)`

GetBriefDescriptionOk returns a tuple with the BriefDescription field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetBriefDescription

`func (o *FsRepStatus) SetBriefDescription(v string)`

SetBriefDescription sets BriefDescription field to given value.

### HasBriefDescription

`func (o *FsRepStatus) HasBriefDescription() bool`

HasBriefDescription returns a boolean if a field has been set.

### GetFullDescription

`func (o *FsRepStatus) GetFullDescription() string`

GetFullDescription returns the FullDescription field if non-nil, zero value otherwise.

### GetFullDescriptionOk

`func (o *FsRepStatus) GetFullDescriptionOk() (*string, bool)`

GetFullDescriptionOk returns a tuple with the FullDescription field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetFullDescription

`func (o *FsRepStatus) SetFullDescription(v string)`

SetFullDescription sets FullDescription field to given value.

### HasFullDescription

`func (o *FsRepStatus) HasFullDescription() bool`

HasFullDescription returns a boolean if a field has been set.

### GetRecommendedAction

`func (o *FsRepStatus) GetRecommendedAction() string`

GetRecommendedAction returns the RecommendedAction field if non-nil, zero value otherwise.

### GetRecommendedActionOk

`func (o *FsRepStatus) GetRecommendedActionOk() (*string, bool)`

GetRecommendedActionOk returns a tuple with the RecommendedAction field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetRecommendedAction

`func (o *FsRepStatus) SetRecommendedAction(v string)`

SetRecommendedAction sets RecommendedAction field to given value.

### HasRecommendedAction

`func (o *FsRepStatus) HasRecommendedAction() bool`

HasRecommendedAction returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


