# MigrationInitiator

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Name** | **string** | The name of the initiator | 
**Wwn** | Pointer to **string** | The initiator WWN | [optional] 
**Invalid** | Pointer to **bool** | Flag to indicate if the entity is invalid | [optional] 

## Methods

### NewMigrationInitiator

`func NewMigrationInitiator(name string, ) *MigrationInitiator`

NewMigrationInitiator instantiates a new MigrationInitiator object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewMigrationInitiatorWithDefaults

`func NewMigrationInitiatorWithDefaults() *MigrationInitiator`

NewMigrationInitiatorWithDefaults instantiates a new MigrationInitiator object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetName

`func (o *MigrationInitiator) GetName() string`

GetName returns the Name field if non-nil, zero value otherwise.

### GetNameOk

`func (o *MigrationInitiator) GetNameOk() (*string, bool)`

GetNameOk returns a tuple with the Name field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetName

`func (o *MigrationInitiator) SetName(v string)`

SetName sets Name field to given value.


### GetWwn

`func (o *MigrationInitiator) GetWwn() string`

GetWwn returns the Wwn field if non-nil, zero value otherwise.

### GetWwnOk

`func (o *MigrationInitiator) GetWwnOk() (*string, bool)`

GetWwnOk returns a tuple with the Wwn field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetWwn

`func (o *MigrationInitiator) SetWwn(v string)`

SetWwn sets Wwn field to given value.

### HasWwn

`func (o *MigrationInitiator) HasWwn() bool`

HasWwn returns a boolean if a field has been set.

### GetInvalid

`func (o *MigrationInitiator) GetInvalid() bool`

GetInvalid returns the Invalid field if non-nil, zero value otherwise.

### GetInvalidOk

`func (o *MigrationInitiator) GetInvalidOk() (*bool, bool)`

GetInvalidOk returns a tuple with the Invalid field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetInvalid

`func (o *MigrationInitiator) SetInvalid(v bool)`

SetInvalid sets Invalid field to given value.

### HasInvalid

`func (o *MigrationInitiator) HasInvalid() bool`

HasInvalid returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


