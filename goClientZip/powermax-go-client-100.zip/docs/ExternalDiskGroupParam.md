# ExternalDiskGroupParam

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**StartDate** | **int64** | Starting date in millisecond. | 
**EndDate** | **int64** | Ending date in millisecond. | 
**SymmetrixId** | **string** | &lt;p&gt;The Symmetrix array ID.&lt;/p&gt; | 
**DiskGroupId** | **string** | diskGroupId | 
**DataFormat** | Pointer to **string** | &lt;p&gt;Data Format (Average or Maximum).&lt;/p&gt;   Enumeration values: * **Average** * **Maximum**  | [optional] 
**Metrics** | **[]string** | metrics   Enumeration values: * **DiskReads** - Reads/sec * **DiskWrites** - Writes/sec * **MBReads** - The reads per second in MBs. * **MBWrittens** - The write throughput (MBs) of the disk per second. * **AvgReadSize** - The average number of kilobytes for a single read command. * **AvgWriteSize** - The average number of kilobytes for a single write command. * **ReadResponseTime** - The average time it took the disk to serve one read command. * **WriteResponseTime** - The average time it took the disk to serve one write command. * **ResponseTime** - Calculated value: (Total Read Time/sec + Total Write Time/sec) / (Reads/sec + Writes/sec) * **MBs** - The total IO (reads and writes) per second in MBs. * **IOs** - An IO command to the disk. * **TotalCapacity** - The total capacity of the disk in GBs. * **UsedCapacity** - The used capacity of the disk in GBs. * **PercentCapacityUsed** - The percent of the pools capacity that is used. * **AvgQueueDepth** - Avg Queue Depth * **PercentBusy** - The number of backend reads and writes per GB of disk. * **UnmapCommandCount** - UNMAP command count * **PercentDiskIdle** - % Idle * **Members** * **VAAIUnmapCommandCount** - VAAI (VMwares Storage APIs for Array Integration) UNMAP command count  | 

## Methods

### NewExternalDiskGroupParam

`func NewExternalDiskGroupParam(startDate int64, endDate int64, symmetrixId string, diskGroupId string, metrics []string, ) *ExternalDiskGroupParam`

NewExternalDiskGroupParam instantiates a new ExternalDiskGroupParam object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewExternalDiskGroupParamWithDefaults

`func NewExternalDiskGroupParamWithDefaults() *ExternalDiskGroupParam`

NewExternalDiskGroupParamWithDefaults instantiates a new ExternalDiskGroupParam object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetStartDate

`func (o *ExternalDiskGroupParam) GetStartDate() int64`

GetStartDate returns the StartDate field if non-nil, zero value otherwise.

### GetStartDateOk

`func (o *ExternalDiskGroupParam) GetStartDateOk() (*int64, bool)`

GetStartDateOk returns a tuple with the StartDate field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetStartDate

`func (o *ExternalDiskGroupParam) SetStartDate(v int64)`

SetStartDate sets StartDate field to given value.


### GetEndDate

`func (o *ExternalDiskGroupParam) GetEndDate() int64`

GetEndDate returns the EndDate field if non-nil, zero value otherwise.

### GetEndDateOk

`func (o *ExternalDiskGroupParam) GetEndDateOk() (*int64, bool)`

GetEndDateOk returns a tuple with the EndDate field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetEndDate

`func (o *ExternalDiskGroupParam) SetEndDate(v int64)`

SetEndDate sets EndDate field to given value.


### GetSymmetrixId

`func (o *ExternalDiskGroupParam) GetSymmetrixId() string`

GetSymmetrixId returns the SymmetrixId field if non-nil, zero value otherwise.

### GetSymmetrixIdOk

`func (o *ExternalDiskGroupParam) GetSymmetrixIdOk() (*string, bool)`

GetSymmetrixIdOk returns a tuple with the SymmetrixId field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetSymmetrixId

`func (o *ExternalDiskGroupParam) SetSymmetrixId(v string)`

SetSymmetrixId sets SymmetrixId field to given value.


### GetDiskGroupId

`func (o *ExternalDiskGroupParam) GetDiskGroupId() string`

GetDiskGroupId returns the DiskGroupId field if non-nil, zero value otherwise.

### GetDiskGroupIdOk

`func (o *ExternalDiskGroupParam) GetDiskGroupIdOk() (*string, bool)`

GetDiskGroupIdOk returns a tuple with the DiskGroupId field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetDiskGroupId

`func (o *ExternalDiskGroupParam) SetDiskGroupId(v string)`

SetDiskGroupId sets DiskGroupId field to given value.


### GetDataFormat

`func (o *ExternalDiskGroupParam) GetDataFormat() string`

GetDataFormat returns the DataFormat field if non-nil, zero value otherwise.

### GetDataFormatOk

`func (o *ExternalDiskGroupParam) GetDataFormatOk() (*string, bool)`

GetDataFormatOk returns a tuple with the DataFormat field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetDataFormat

`func (o *ExternalDiskGroupParam) SetDataFormat(v string)`

SetDataFormat sets DataFormat field to given value.

### HasDataFormat

`func (o *ExternalDiskGroupParam) HasDataFormat() bool`

HasDataFormat returns a boolean if a field has been set.

### GetMetrics

`func (o *ExternalDiskGroupParam) GetMetrics() []string`

GetMetrics returns the Metrics field if non-nil, zero value otherwise.

### GetMetricsOk

`func (o *ExternalDiskGroupParam) GetMetricsOk() (*[]string, bool)`

GetMetricsOk returns a tuple with the Metrics field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetMetrics

`func (o *ExternalDiskGroupParam) SetMetrics(v []string)`

SetMetrics sets Metrics field to given value.



[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


