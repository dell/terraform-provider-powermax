# EmEmulationKeyResult

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**EmEmulationInfo** | Pointer to [**[]EmEmulationInfo**](EmEmulationInfo.md) | emEmulationInfo | [optional] 

## Methods

### NewEmEmulationKeyResult

`func NewEmEmulationKeyResult() *EmEmulationKeyResult`

NewEmEmulationKeyResult instantiates a new EmEmulationKeyResult object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewEmEmulationKeyResultWithDefaults

`func NewEmEmulationKeyResultWithDefaults() *EmEmulationKeyResult`

NewEmEmulationKeyResultWithDefaults instantiates a new EmEmulationKeyResult object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetEmEmulationInfo

`func (o *EmEmulationKeyResult) GetEmEmulationInfo() []EmEmulationInfo`

GetEmEmulationInfo returns the EmEmulationInfo field if non-nil, zero value otherwise.

### GetEmEmulationInfoOk

`func (o *EmEmulationKeyResult) GetEmEmulationInfoOk() (*[]EmEmulationInfo, bool)`

GetEmEmulationInfoOk returns a tuple with the EmEmulationInfo field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetEmEmulationInfo

`func (o *EmEmulationKeyResult) SetEmEmulationInfo(v []EmEmulationInfo)`

SetEmEmulationInfo sets EmEmulationInfo field to given value.

### HasEmEmulationInfo

`func (o *EmEmulationKeyResult) HasEmEmulationInfo() bool`

HasEmEmulationInfo returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


