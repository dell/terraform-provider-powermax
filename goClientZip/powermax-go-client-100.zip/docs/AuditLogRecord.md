# AuditLogRecord

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**RecordId** | Pointer to **int64** | The ID of the Audit Log Record | [optional] 
**EntryDate** | Pointer to **int64** | Date and time the entry was made | [optional] 
**EntryDateString** | Pointer to **string** | Date and time string the entry was made | [optional] 
**Username** | Pointer to **string** | User who performed the operation | [optional] 
**Message** | Pointer to **string** | Log message | [optional] 
**Hostname** | Pointer to **string** | Name of the host on which operation was executed | [optional] 
**ClientHost** | Pointer to **string** | Name of the client host from wich the operation was triggered | [optional] 
**OsType** | Pointer to **string** | Operating system of the host | [optional] 
**OsRevision** | Pointer to **string** | Revision of the operating system running on the host | [optional] 
**VendorId** | Pointer to **string** | The ID of the application vendor | [optional] 
**ApplicationId** | Pointer to **string** | The ID of the application | [optional] 
**ApplicationVersion** | Pointer to **string** | Version of the application | [optional] 
**ApiLibrary** | Pointer to **string** | API library | [optional] 
**ApiVersion** | Pointer to **string** | Version of the API | [optional] 
**FunctionClass** | Pointer to **string** | Name of the audit function class | [optional] 
**AuditClass** | Pointer to **string** | Name of the audit audit class | [optional] 
**ActionCode** | Pointer to **string** | Name identifying the action executed | [optional] 
**TaskId** | Pointer to **string** | Task number | [optional] 
**ActivityId** | Pointer to **string** | The ID of activity | [optional] 
**ProcessId** | Pointer to **string** | The ID of the process | [optional] 
**OffsetInSequence** | Pointer to **string** | The offset of the record in sequence | [optional] 
**RecordsInSequence** | Pointer to **string** | Number of records in sequence | [optional] 

## Methods

### NewAuditLogRecord

`func NewAuditLogRecord() *AuditLogRecord`

NewAuditLogRecord instantiates a new AuditLogRecord object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewAuditLogRecordWithDefaults

`func NewAuditLogRecordWithDefaults() *AuditLogRecord`

NewAuditLogRecordWithDefaults instantiates a new AuditLogRecord object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetRecordId

`func (o *AuditLogRecord) GetRecordId() int64`

GetRecordId returns the RecordId field if non-nil, zero value otherwise.

### GetRecordIdOk

`func (o *AuditLogRecord) GetRecordIdOk() (*int64, bool)`

GetRecordIdOk returns a tuple with the RecordId field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetRecordId

`func (o *AuditLogRecord) SetRecordId(v int64)`

SetRecordId sets RecordId field to given value.

### HasRecordId

`func (o *AuditLogRecord) HasRecordId() bool`

HasRecordId returns a boolean if a field has been set.

### GetEntryDate

`func (o *AuditLogRecord) GetEntryDate() int64`

GetEntryDate returns the EntryDate field if non-nil, zero value otherwise.

### GetEntryDateOk

`func (o *AuditLogRecord) GetEntryDateOk() (*int64, bool)`

GetEntryDateOk returns a tuple with the EntryDate field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetEntryDate

`func (o *AuditLogRecord) SetEntryDate(v int64)`

SetEntryDate sets EntryDate field to given value.

### HasEntryDate

`func (o *AuditLogRecord) HasEntryDate() bool`

HasEntryDate returns a boolean if a field has been set.

### GetEntryDateString

`func (o *AuditLogRecord) GetEntryDateString() string`

GetEntryDateString returns the EntryDateString field if non-nil, zero value otherwise.

### GetEntryDateStringOk

`func (o *AuditLogRecord) GetEntryDateStringOk() (*string, bool)`

GetEntryDateStringOk returns a tuple with the EntryDateString field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetEntryDateString

`func (o *AuditLogRecord) SetEntryDateString(v string)`

SetEntryDateString sets EntryDateString field to given value.

### HasEntryDateString

`func (o *AuditLogRecord) HasEntryDateString() bool`

HasEntryDateString returns a boolean if a field has been set.

### GetUsername

`func (o *AuditLogRecord) GetUsername() string`

GetUsername returns the Username field if non-nil, zero value otherwise.

### GetUsernameOk

`func (o *AuditLogRecord) GetUsernameOk() (*string, bool)`

GetUsernameOk returns a tuple with the Username field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetUsername

`func (o *AuditLogRecord) SetUsername(v string)`

SetUsername sets Username field to given value.

### HasUsername

`func (o *AuditLogRecord) HasUsername() bool`

HasUsername returns a boolean if a field has been set.

### GetMessage

`func (o *AuditLogRecord) GetMessage() string`

GetMessage returns the Message field if non-nil, zero value otherwise.

### GetMessageOk

`func (o *AuditLogRecord) GetMessageOk() (*string, bool)`

GetMessageOk returns a tuple with the Message field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetMessage

`func (o *AuditLogRecord) SetMessage(v string)`

SetMessage sets Message field to given value.

### HasMessage

`func (o *AuditLogRecord) HasMessage() bool`

HasMessage returns a boolean if a field has been set.

### GetHostname

`func (o *AuditLogRecord) GetHostname() string`

GetHostname returns the Hostname field if non-nil, zero value otherwise.

### GetHostnameOk

`func (o *AuditLogRecord) GetHostnameOk() (*string, bool)`

GetHostnameOk returns a tuple with the Hostname field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetHostname

`func (o *AuditLogRecord) SetHostname(v string)`

SetHostname sets Hostname field to given value.

### HasHostname

`func (o *AuditLogRecord) HasHostname() bool`

HasHostname returns a boolean if a field has been set.

### GetClientHost

`func (o *AuditLogRecord) GetClientHost() string`

GetClientHost returns the ClientHost field if non-nil, zero value otherwise.

### GetClientHostOk

`func (o *AuditLogRecord) GetClientHostOk() (*string, bool)`

GetClientHostOk returns a tuple with the ClientHost field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetClientHost

`func (o *AuditLogRecord) SetClientHost(v string)`

SetClientHost sets ClientHost field to given value.

### HasClientHost

`func (o *AuditLogRecord) HasClientHost() bool`

HasClientHost returns a boolean if a field has been set.

### GetOsType

`func (o *AuditLogRecord) GetOsType() string`

GetOsType returns the OsType field if non-nil, zero value otherwise.

### GetOsTypeOk

`func (o *AuditLogRecord) GetOsTypeOk() (*string, bool)`

GetOsTypeOk returns a tuple with the OsType field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetOsType

`func (o *AuditLogRecord) SetOsType(v string)`

SetOsType sets OsType field to given value.

### HasOsType

`func (o *AuditLogRecord) HasOsType() bool`

HasOsType returns a boolean if a field has been set.

### GetOsRevision

`func (o *AuditLogRecord) GetOsRevision() string`

GetOsRevision returns the OsRevision field if non-nil, zero value otherwise.

### GetOsRevisionOk

`func (o *AuditLogRecord) GetOsRevisionOk() (*string, bool)`

GetOsRevisionOk returns a tuple with the OsRevision field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetOsRevision

`func (o *AuditLogRecord) SetOsRevision(v string)`

SetOsRevision sets OsRevision field to given value.

### HasOsRevision

`func (o *AuditLogRecord) HasOsRevision() bool`

HasOsRevision returns a boolean if a field has been set.

### GetVendorId

`func (o *AuditLogRecord) GetVendorId() string`

GetVendorId returns the VendorId field if non-nil, zero value otherwise.

### GetVendorIdOk

`func (o *AuditLogRecord) GetVendorIdOk() (*string, bool)`

GetVendorIdOk returns a tuple with the VendorId field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetVendorId

`func (o *AuditLogRecord) SetVendorId(v string)`

SetVendorId sets VendorId field to given value.

### HasVendorId

`func (o *AuditLogRecord) HasVendorId() bool`

HasVendorId returns a boolean if a field has been set.

### GetApplicationId

`func (o *AuditLogRecord) GetApplicationId() string`

GetApplicationId returns the ApplicationId field if non-nil, zero value otherwise.

### GetApplicationIdOk

`func (o *AuditLogRecord) GetApplicationIdOk() (*string, bool)`

GetApplicationIdOk returns a tuple with the ApplicationId field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetApplicationId

`func (o *AuditLogRecord) SetApplicationId(v string)`

SetApplicationId sets ApplicationId field to given value.

### HasApplicationId

`func (o *AuditLogRecord) HasApplicationId() bool`

HasApplicationId returns a boolean if a field has been set.

### GetApplicationVersion

`func (o *AuditLogRecord) GetApplicationVersion() string`

GetApplicationVersion returns the ApplicationVersion field if non-nil, zero value otherwise.

### GetApplicationVersionOk

`func (o *AuditLogRecord) GetApplicationVersionOk() (*string, bool)`

GetApplicationVersionOk returns a tuple with the ApplicationVersion field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetApplicationVersion

`func (o *AuditLogRecord) SetApplicationVersion(v string)`

SetApplicationVersion sets ApplicationVersion field to given value.

### HasApplicationVersion

`func (o *AuditLogRecord) HasApplicationVersion() bool`

HasApplicationVersion returns a boolean if a field has been set.

### GetApiLibrary

`func (o *AuditLogRecord) GetApiLibrary() string`

GetApiLibrary returns the ApiLibrary field if non-nil, zero value otherwise.

### GetApiLibraryOk

`func (o *AuditLogRecord) GetApiLibraryOk() (*string, bool)`

GetApiLibraryOk returns a tuple with the ApiLibrary field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetApiLibrary

`func (o *AuditLogRecord) SetApiLibrary(v string)`

SetApiLibrary sets ApiLibrary field to given value.

### HasApiLibrary

`func (o *AuditLogRecord) HasApiLibrary() bool`

HasApiLibrary returns a boolean if a field has been set.

### GetApiVersion

`func (o *AuditLogRecord) GetApiVersion() string`

GetApiVersion returns the ApiVersion field if non-nil, zero value otherwise.

### GetApiVersionOk

`func (o *AuditLogRecord) GetApiVersionOk() (*string, bool)`

GetApiVersionOk returns a tuple with the ApiVersion field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetApiVersion

`func (o *AuditLogRecord) SetApiVersion(v string)`

SetApiVersion sets ApiVersion field to given value.

### HasApiVersion

`func (o *AuditLogRecord) HasApiVersion() bool`

HasApiVersion returns a boolean if a field has been set.

### GetFunctionClass

`func (o *AuditLogRecord) GetFunctionClass() string`

GetFunctionClass returns the FunctionClass field if non-nil, zero value otherwise.

### GetFunctionClassOk

`func (o *AuditLogRecord) GetFunctionClassOk() (*string, bool)`

GetFunctionClassOk returns a tuple with the FunctionClass field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetFunctionClass

`func (o *AuditLogRecord) SetFunctionClass(v string)`

SetFunctionClass sets FunctionClass field to given value.

### HasFunctionClass

`func (o *AuditLogRecord) HasFunctionClass() bool`

HasFunctionClass returns a boolean if a field has been set.

### GetAuditClass

`func (o *AuditLogRecord) GetAuditClass() string`

GetAuditClass returns the AuditClass field if non-nil, zero value otherwise.

### GetAuditClassOk

`func (o *AuditLogRecord) GetAuditClassOk() (*string, bool)`

GetAuditClassOk returns a tuple with the AuditClass field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetAuditClass

`func (o *AuditLogRecord) SetAuditClass(v string)`

SetAuditClass sets AuditClass field to given value.

### HasAuditClass

`func (o *AuditLogRecord) HasAuditClass() bool`

HasAuditClass returns a boolean if a field has been set.

### GetActionCode

`func (o *AuditLogRecord) GetActionCode() string`

GetActionCode returns the ActionCode field if non-nil, zero value otherwise.

### GetActionCodeOk

`func (o *AuditLogRecord) GetActionCodeOk() (*string, bool)`

GetActionCodeOk returns a tuple with the ActionCode field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetActionCode

`func (o *AuditLogRecord) SetActionCode(v string)`

SetActionCode sets ActionCode field to given value.

### HasActionCode

`func (o *AuditLogRecord) HasActionCode() bool`

HasActionCode returns a boolean if a field has been set.

### GetTaskId

`func (o *AuditLogRecord) GetTaskId() string`

GetTaskId returns the TaskId field if non-nil, zero value otherwise.

### GetTaskIdOk

`func (o *AuditLogRecord) GetTaskIdOk() (*string, bool)`

GetTaskIdOk returns a tuple with the TaskId field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetTaskId

`func (o *AuditLogRecord) SetTaskId(v string)`

SetTaskId sets TaskId field to given value.

### HasTaskId

`func (o *AuditLogRecord) HasTaskId() bool`

HasTaskId returns a boolean if a field has been set.

### GetActivityId

`func (o *AuditLogRecord) GetActivityId() string`

GetActivityId returns the ActivityId field if non-nil, zero value otherwise.

### GetActivityIdOk

`func (o *AuditLogRecord) GetActivityIdOk() (*string, bool)`

GetActivityIdOk returns a tuple with the ActivityId field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetActivityId

`func (o *AuditLogRecord) SetActivityId(v string)`

SetActivityId sets ActivityId field to given value.

### HasActivityId

`func (o *AuditLogRecord) HasActivityId() bool`

HasActivityId returns a boolean if a field has been set.

### GetProcessId

`func (o *AuditLogRecord) GetProcessId() string`

GetProcessId returns the ProcessId field if non-nil, zero value otherwise.

### GetProcessIdOk

`func (o *AuditLogRecord) GetProcessIdOk() (*string, bool)`

GetProcessIdOk returns a tuple with the ProcessId field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetProcessId

`func (o *AuditLogRecord) SetProcessId(v string)`

SetProcessId sets ProcessId field to given value.

### HasProcessId

`func (o *AuditLogRecord) HasProcessId() bool`

HasProcessId returns a boolean if a field has been set.

### GetOffsetInSequence

`func (o *AuditLogRecord) GetOffsetInSequence() string`

GetOffsetInSequence returns the OffsetInSequence field if non-nil, zero value otherwise.

### GetOffsetInSequenceOk

`func (o *AuditLogRecord) GetOffsetInSequenceOk() (*string, bool)`

GetOffsetInSequenceOk returns a tuple with the OffsetInSequence field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetOffsetInSequence

`func (o *AuditLogRecord) SetOffsetInSequence(v string)`

SetOffsetInSequence sets OffsetInSequence field to given value.

### HasOffsetInSequence

`func (o *AuditLogRecord) HasOffsetInSequence() bool`

HasOffsetInSequence returns a boolean if a field has been set.

### GetRecordsInSequence

`func (o *AuditLogRecord) GetRecordsInSequence() string`

GetRecordsInSequence returns the RecordsInSequence field if non-nil, zero value otherwise.

### GetRecordsInSequenceOk

`func (o *AuditLogRecord) GetRecordsInSequenceOk() (*string, bool)`

GetRecordsInSequenceOk returns a tuple with the RecordsInSequence field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetRecordsInSequence

`func (o *AuditLogRecord) SetRecordsInSequence(v string)`

SetRecordsInSequence sets RecordsInSequence field to given value.

### HasRecordsInSequence

`func (o *AuditLogRecord) HasRecordsInSequence() bool`

HasRecordsInSequence returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


