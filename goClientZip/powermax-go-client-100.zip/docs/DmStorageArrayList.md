# DmStorageArrayList

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ArrayId** | Pointer to **[]string** | The System IDs. | [optional] 

## Methods

### NewDmStorageArrayList

`func NewDmStorageArrayList() *DmStorageArrayList`

NewDmStorageArrayList instantiates a new DmStorageArrayList object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewDmStorageArrayListWithDefaults

`func NewDmStorageArrayListWithDefaults() *DmStorageArrayList`

NewDmStorageArrayListWithDefaults instantiates a new DmStorageArrayList object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetArrayId

`func (o *DmStorageArrayList) GetArrayId() []string`

GetArrayId returns the ArrayId field if non-nil, zero value otherwise.

### GetArrayIdOk

`func (o *DmStorageArrayList) GetArrayIdOk() (*[]string, bool)`

GetArrayIdOk returns a tuple with the ArrayId field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetArrayId

`func (o *DmStorageArrayList) SetArrayId(v []string)`

SetArrayId sets ArrayId field to given value.

### HasArrayId

`func (o *DmStorageArrayList) HasArrayId() bool`

HasArrayId returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


