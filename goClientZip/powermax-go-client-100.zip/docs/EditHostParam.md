# EditHostParam

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ExecutionOption** | Pointer to **string** |  | [optional] [default to "SYNCHRONOUS"]
**EditHostActionParam** | [**EditHostActionParam**](EditHostActionParam.md) |  | 

## Methods

### NewEditHostParam

`func NewEditHostParam(editHostActionParam EditHostActionParam, ) *EditHostParam`

NewEditHostParam instantiates a new EditHostParam object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewEditHostParamWithDefaults

`func NewEditHostParamWithDefaults() *EditHostParam`

NewEditHostParamWithDefaults instantiates a new EditHostParam object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetExecutionOption

`func (o *EditHostParam) GetExecutionOption() string`

GetExecutionOption returns the ExecutionOption field if non-nil, zero value otherwise.

### GetExecutionOptionOk

`func (o *EditHostParam) GetExecutionOptionOk() (*string, bool)`

GetExecutionOptionOk returns a tuple with the ExecutionOption field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetExecutionOption

`func (o *EditHostParam) SetExecutionOption(v string)`

SetExecutionOption sets ExecutionOption field to given value.

### HasExecutionOption

`func (o *EditHostParam) HasExecutionOption() bool`

HasExecutionOption returns a boolean if a field has been set.

### GetEditHostActionParam

`func (o *EditHostParam) GetEditHostActionParam() EditHostActionParam`

GetEditHostActionParam returns the EditHostActionParam field if non-nil, zero value otherwise.

### GetEditHostActionParamOk

`func (o *EditHostParam) GetEditHostActionParamOk() (*EditHostActionParam, bool)`

GetEditHostActionParamOk returns a tuple with the EditHostActionParam field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetEditHostActionParam

`func (o *EditHostParam) SetEditHostActionParam(v EditHostActionParam)`

SetEditHostActionParam sets EditHostActionParam field to given value.



[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


