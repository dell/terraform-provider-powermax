# Alert

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**AlertId** | **string** | alertId | 
**State** | **string** | state   Enumeration values: * **NEW** * **ACKNOWLEDGED** * **CLEARED**  | 
**Severity** | **string** | severity   Enumeration values: * **NORMAL** * **INFORMATION** * **MINOR** * **WARNING** * **CRITICAL** * **FATAL**  | 
**Type** | **string** | type   Enumeration values: * **ARRAY** * **PERFORMANCE** * **SERVER** * **SLOCOMPLIANCE** * **FILE**  | 
**Array** | Pointer to **string** | array | [optional] 
**Object** | Pointer to **string** | object | [optional] 
**ObjectType** | Pointer to **string** | object_type | [optional] 
**CreatedDate** | **string** | created_date | 
**CreatedDateMilliseconds** | Pointer to **int64** | created_date_milliseconds | [optional] 
**LastModifyDate** | Pointer to **string** | last_modify_date | [optional] 
**LastModifiedDateMilliseconds** | Pointer to **int64** | last_modified_date_milliseconds | [optional] 
**ClearedDate** | Pointer to **string** | cleared_date | [optional] 
**ClearedDateMilliseconds** | Pointer to **int64** | cleared_date_milliseconds | [optional] 
**Description** | **string** | description | 
**Acknowledged** | **bool** | acknowledged | 
**AcknowledgedDate** | Pointer to **string** | acknowledged_date | [optional] 
**Category** | Pointer to **string** | category | [optional] 
**AcknowledgedInfo** | Pointer to [**AcknowledgedInfo**](AcknowledgedInfo.md) |  | [optional] 

## Methods

### NewAlert

`func NewAlert(alertId string, state string, severity string, type_ string, createdDate string, description string, acknowledged bool, ) *Alert`

NewAlert instantiates a new Alert object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewAlertWithDefaults

`func NewAlertWithDefaults() *Alert`

NewAlertWithDefaults instantiates a new Alert object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetAlertId

`func (o *Alert) GetAlertId() string`

GetAlertId returns the AlertId field if non-nil, zero value otherwise.

### GetAlertIdOk

`func (o *Alert) GetAlertIdOk() (*string, bool)`

GetAlertIdOk returns a tuple with the AlertId field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetAlertId

`func (o *Alert) SetAlertId(v string)`

SetAlertId sets AlertId field to given value.


### GetState

`func (o *Alert) GetState() string`

GetState returns the State field if non-nil, zero value otherwise.

### GetStateOk

`func (o *Alert) GetStateOk() (*string, bool)`

GetStateOk returns a tuple with the State field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetState

`func (o *Alert) SetState(v string)`

SetState sets State field to given value.


### GetSeverity

`func (o *Alert) GetSeverity() string`

GetSeverity returns the Severity field if non-nil, zero value otherwise.

### GetSeverityOk

`func (o *Alert) GetSeverityOk() (*string, bool)`

GetSeverityOk returns a tuple with the Severity field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetSeverity

`func (o *Alert) SetSeverity(v string)`

SetSeverity sets Severity field to given value.


### GetType

`func (o *Alert) GetType() string`

GetType returns the Type field if non-nil, zero value otherwise.

### GetTypeOk

`func (o *Alert) GetTypeOk() (*string, bool)`

GetTypeOk returns a tuple with the Type field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetType

`func (o *Alert) SetType(v string)`

SetType sets Type field to given value.


### GetArray

`func (o *Alert) GetArray() string`

GetArray returns the Array field if non-nil, zero value otherwise.

### GetArrayOk

`func (o *Alert) GetArrayOk() (*string, bool)`

GetArrayOk returns a tuple with the Array field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetArray

`func (o *Alert) SetArray(v string)`

SetArray sets Array field to given value.

### HasArray

`func (o *Alert) HasArray() bool`

HasArray returns a boolean if a field has been set.

### GetObject

`func (o *Alert) GetObject() string`

GetObject returns the Object field if non-nil, zero value otherwise.

### GetObjectOk

`func (o *Alert) GetObjectOk() (*string, bool)`

GetObjectOk returns a tuple with the Object field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetObject

`func (o *Alert) SetObject(v string)`

SetObject sets Object field to given value.

### HasObject

`func (o *Alert) HasObject() bool`

HasObject returns a boolean if a field has been set.

### GetObjectType

`func (o *Alert) GetObjectType() string`

GetObjectType returns the ObjectType field if non-nil, zero value otherwise.

### GetObjectTypeOk

`func (o *Alert) GetObjectTypeOk() (*string, bool)`

GetObjectTypeOk returns a tuple with the ObjectType field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetObjectType

`func (o *Alert) SetObjectType(v string)`

SetObjectType sets ObjectType field to given value.

### HasObjectType

`func (o *Alert) HasObjectType() bool`

HasObjectType returns a boolean if a field has been set.

### GetCreatedDate

`func (o *Alert) GetCreatedDate() string`

GetCreatedDate returns the CreatedDate field if non-nil, zero value otherwise.

### GetCreatedDateOk

`func (o *Alert) GetCreatedDateOk() (*string, bool)`

GetCreatedDateOk returns a tuple with the CreatedDate field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetCreatedDate

`func (o *Alert) SetCreatedDate(v string)`

SetCreatedDate sets CreatedDate field to given value.


### GetCreatedDateMilliseconds

`func (o *Alert) GetCreatedDateMilliseconds() int64`

GetCreatedDateMilliseconds returns the CreatedDateMilliseconds field if non-nil, zero value otherwise.

### GetCreatedDateMillisecondsOk

`func (o *Alert) GetCreatedDateMillisecondsOk() (*int64, bool)`

GetCreatedDateMillisecondsOk returns a tuple with the CreatedDateMilliseconds field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetCreatedDateMilliseconds

`func (o *Alert) SetCreatedDateMilliseconds(v int64)`

SetCreatedDateMilliseconds sets CreatedDateMilliseconds field to given value.

### HasCreatedDateMilliseconds

`func (o *Alert) HasCreatedDateMilliseconds() bool`

HasCreatedDateMilliseconds returns a boolean if a field has been set.

### GetLastModifyDate

`func (o *Alert) GetLastModifyDate() string`

GetLastModifyDate returns the LastModifyDate field if non-nil, zero value otherwise.

### GetLastModifyDateOk

`func (o *Alert) GetLastModifyDateOk() (*string, bool)`

GetLastModifyDateOk returns a tuple with the LastModifyDate field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetLastModifyDate

`func (o *Alert) SetLastModifyDate(v string)`

SetLastModifyDate sets LastModifyDate field to given value.

### HasLastModifyDate

`func (o *Alert) HasLastModifyDate() bool`

HasLastModifyDate returns a boolean if a field has been set.

### GetLastModifiedDateMilliseconds

`func (o *Alert) GetLastModifiedDateMilliseconds() int64`

GetLastModifiedDateMilliseconds returns the LastModifiedDateMilliseconds field if non-nil, zero value otherwise.

### GetLastModifiedDateMillisecondsOk

`func (o *Alert) GetLastModifiedDateMillisecondsOk() (*int64, bool)`

GetLastModifiedDateMillisecondsOk returns a tuple with the LastModifiedDateMilliseconds field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetLastModifiedDateMilliseconds

`func (o *Alert) SetLastModifiedDateMilliseconds(v int64)`

SetLastModifiedDateMilliseconds sets LastModifiedDateMilliseconds field to given value.

### HasLastModifiedDateMilliseconds

`func (o *Alert) HasLastModifiedDateMilliseconds() bool`

HasLastModifiedDateMilliseconds returns a boolean if a field has been set.

### GetClearedDate

`func (o *Alert) GetClearedDate() string`

GetClearedDate returns the ClearedDate field if non-nil, zero value otherwise.

### GetClearedDateOk

`func (o *Alert) GetClearedDateOk() (*string, bool)`

GetClearedDateOk returns a tuple with the ClearedDate field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetClearedDate

`func (o *Alert) SetClearedDate(v string)`

SetClearedDate sets ClearedDate field to given value.

### HasClearedDate

`func (o *Alert) HasClearedDate() bool`

HasClearedDate returns a boolean if a field has been set.

### GetClearedDateMilliseconds

`func (o *Alert) GetClearedDateMilliseconds() int64`

GetClearedDateMilliseconds returns the ClearedDateMilliseconds field if non-nil, zero value otherwise.

### GetClearedDateMillisecondsOk

`func (o *Alert) GetClearedDateMillisecondsOk() (*int64, bool)`

GetClearedDateMillisecondsOk returns a tuple with the ClearedDateMilliseconds field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetClearedDateMilliseconds

`func (o *Alert) SetClearedDateMilliseconds(v int64)`

SetClearedDateMilliseconds sets ClearedDateMilliseconds field to given value.

### HasClearedDateMilliseconds

`func (o *Alert) HasClearedDateMilliseconds() bool`

HasClearedDateMilliseconds returns a boolean if a field has been set.

### GetDescription

`func (o *Alert) GetDescription() string`

GetDescription returns the Description field if non-nil, zero value otherwise.

### GetDescriptionOk

`func (o *Alert) GetDescriptionOk() (*string, bool)`

GetDescriptionOk returns a tuple with the Description field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetDescription

`func (o *Alert) SetDescription(v string)`

SetDescription sets Description field to given value.


### GetAcknowledged

`func (o *Alert) GetAcknowledged() bool`

GetAcknowledged returns the Acknowledged field if non-nil, zero value otherwise.

### GetAcknowledgedOk

`func (o *Alert) GetAcknowledgedOk() (*bool, bool)`

GetAcknowledgedOk returns a tuple with the Acknowledged field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetAcknowledged

`func (o *Alert) SetAcknowledged(v bool)`

SetAcknowledged sets Acknowledged field to given value.


### GetAcknowledgedDate

`func (o *Alert) GetAcknowledgedDate() string`

GetAcknowledgedDate returns the AcknowledgedDate field if non-nil, zero value otherwise.

### GetAcknowledgedDateOk

`func (o *Alert) GetAcknowledgedDateOk() (*string, bool)`

GetAcknowledgedDateOk returns a tuple with the AcknowledgedDate field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetAcknowledgedDate

`func (o *Alert) SetAcknowledgedDate(v string)`

SetAcknowledgedDate sets AcknowledgedDate field to given value.

### HasAcknowledgedDate

`func (o *Alert) HasAcknowledgedDate() bool`

HasAcknowledgedDate returns a boolean if a field has been set.

### GetCategory

`func (o *Alert) GetCategory() string`

GetCategory returns the Category field if non-nil, zero value otherwise.

### GetCategoryOk

`func (o *Alert) GetCategoryOk() (*string, bool)`

GetCategoryOk returns a tuple with the Category field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetCategory

`func (o *Alert) SetCategory(v string)`

SetCategory sets Category field to given value.

### HasCategory

`func (o *Alert) HasCategory() bool`

HasCategory returns a boolean if a field has been set.

### GetAcknowledgedInfo

`func (o *Alert) GetAcknowledgedInfo() AcknowledgedInfo`

GetAcknowledgedInfo returns the AcknowledgedInfo field if non-nil, zero value otherwise.

### GetAcknowledgedInfoOk

`func (o *Alert) GetAcknowledgedInfoOk() (*AcknowledgedInfo, bool)`

GetAcknowledgedInfoOk returns a tuple with the AcknowledgedInfo field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetAcknowledgedInfo

`func (o *Alert) SetAcknowledgedInfo(v AcknowledgedInfo)`

SetAcknowledgedInfo sets AcknowledgedInfo field to given value.

### HasAcknowledgedInfo

`func (o *Alert) HasAcknowledgedInfo() bool`

HasAcknowledgedInfo returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


