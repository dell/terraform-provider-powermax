# ISCSIClientParam

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**StartDate** | **int64** | Starting date in millisecond. | 
**EndDate** | **int64** | Ending date in millisecond. | 
**SymmetrixId** | **string** | &lt;p&gt;The Symmetrix array ID.&lt;/p&gt; | 
**IpInterfaceId** | **string** | ipInterfaceId | 
**DataFormat** | Pointer to **string** | &lt;p&gt;Data Format (Average or Maximum).&lt;/p&gt;   Enumeration values: * **Average** * **Maximum**  | [optional] 
**Metrics** | **[]string** | metrics   Enumeration values: * **MBs** - MBs/sec * **PacketCount** - Packets/sec * **Reads** - The number of read operations performed each second. * **Writes** - The number of write operations performed each second. * **IoRate** - The number of host operations performed each second. * **TotalReadTime** - Total time spent performing reads. * **TotalWriteTime** - Total time spent performing writess. * **ResponseTime** - The average response time for the reads and writes. * **DuplicateAcksReceivedPerSec** - Duplicate Acks Received/sec * **TCPRetransmitsPerSec** - TCP Retransmits/sec  | 

## Methods

### NewISCSIClientParam

`func NewISCSIClientParam(startDate int64, endDate int64, symmetrixId string, ipInterfaceId string, metrics []string, ) *ISCSIClientParam`

NewISCSIClientParam instantiates a new ISCSIClientParam object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewISCSIClientParamWithDefaults

`func NewISCSIClientParamWithDefaults() *ISCSIClientParam`

NewISCSIClientParamWithDefaults instantiates a new ISCSIClientParam object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetStartDate

`func (o *ISCSIClientParam) GetStartDate() int64`

GetStartDate returns the StartDate field if non-nil, zero value otherwise.

### GetStartDateOk

`func (o *ISCSIClientParam) GetStartDateOk() (*int64, bool)`

GetStartDateOk returns a tuple with the StartDate field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetStartDate

`func (o *ISCSIClientParam) SetStartDate(v int64)`

SetStartDate sets StartDate field to given value.


### GetEndDate

`func (o *ISCSIClientParam) GetEndDate() int64`

GetEndDate returns the EndDate field if non-nil, zero value otherwise.

### GetEndDateOk

`func (o *ISCSIClientParam) GetEndDateOk() (*int64, bool)`

GetEndDateOk returns a tuple with the EndDate field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetEndDate

`func (o *ISCSIClientParam) SetEndDate(v int64)`

SetEndDate sets EndDate field to given value.


### GetSymmetrixId

`func (o *ISCSIClientParam) GetSymmetrixId() string`

GetSymmetrixId returns the SymmetrixId field if non-nil, zero value otherwise.

### GetSymmetrixIdOk

`func (o *ISCSIClientParam) GetSymmetrixIdOk() (*string, bool)`

GetSymmetrixIdOk returns a tuple with the SymmetrixId field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetSymmetrixId

`func (o *ISCSIClientParam) SetSymmetrixId(v string)`

SetSymmetrixId sets SymmetrixId field to given value.


### GetIpInterfaceId

`func (o *ISCSIClientParam) GetIpInterfaceId() string`

GetIpInterfaceId returns the IpInterfaceId field if non-nil, zero value otherwise.

### GetIpInterfaceIdOk

`func (o *ISCSIClientParam) GetIpInterfaceIdOk() (*string, bool)`

GetIpInterfaceIdOk returns a tuple with the IpInterfaceId field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetIpInterfaceId

`func (o *ISCSIClientParam) SetIpInterfaceId(v string)`

SetIpInterfaceId sets IpInterfaceId field to given value.


### GetDataFormat

`func (o *ISCSIClientParam) GetDataFormat() string`

GetDataFormat returns the DataFormat field if non-nil, zero value otherwise.

### GetDataFormatOk

`func (o *ISCSIClientParam) GetDataFormatOk() (*string, bool)`

GetDataFormatOk returns a tuple with the DataFormat field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetDataFormat

`func (o *ISCSIClientParam) SetDataFormat(v string)`

SetDataFormat sets DataFormat field to given value.

### HasDataFormat

`func (o *ISCSIClientParam) HasDataFormat() bool`

HasDataFormat returns a boolean if a field has been set.

### GetMetrics

`func (o *ISCSIClientParam) GetMetrics() []string`

GetMetrics returns the Metrics field if non-nil, zero value otherwise.

### GetMetricsOk

`func (o *ISCSIClientParam) GetMetricsOk() (*[]string, bool)`

GetMetricsOk returns a tuple with the Metrics field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetMetrics

`func (o *ISCSIClientParam) SetMetrics(v []string)`

SetMetrics sets Metrics field to given value.



[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


