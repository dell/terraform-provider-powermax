# ListHostGroupResult

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**HostGroupId** | Pointer to **[]string** | ID/name of the host group | [optional] 

## Methods

### NewListHostGroupResult

`func NewListHostGroupResult() *ListHostGroupResult`

NewListHostGroupResult instantiates a new ListHostGroupResult object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewListHostGroupResultWithDefaults

`func NewListHostGroupResultWithDefaults() *ListHostGroupResult`

NewListHostGroupResultWithDefaults instantiates a new ListHostGroupResult object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetHostGroupId

`func (o *ListHostGroupResult) GetHostGroupId() []string`

GetHostGroupId returns the HostGroupId field if non-nil, zero value otherwise.

### GetHostGroupIdOk

`func (o *ListHostGroupResult) GetHostGroupIdOk() (*[]string, bool)`

GetHostGroupIdOk returns a tuple with the HostGroupId field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetHostGroupId

`func (o *ListHostGroupResult) SetHostGroupId(v []string)`

SetHostGroupId sets HostGroupId field to given value.

### HasHostGroupId

`func (o *ListHostGroupResult) HasHostGroupId() bool`

HasHostGroupId returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


