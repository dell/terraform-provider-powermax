# AvoidResetBroadcast

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Enabled** | **bool** | Avoid Reset Broadcast enabled status | 
**Override** | **bool** | Avoid Reset Broadcast overridden status | 

## Methods

### NewAvoidResetBroadcast

`func NewAvoidResetBroadcast(enabled bool, override bool, ) *AvoidResetBroadcast`

NewAvoidResetBroadcast instantiates a new AvoidResetBroadcast object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewAvoidResetBroadcastWithDefaults

`func NewAvoidResetBroadcastWithDefaults() *AvoidResetBroadcast`

NewAvoidResetBroadcastWithDefaults instantiates a new AvoidResetBroadcast object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetEnabled

`func (o *AvoidResetBroadcast) GetEnabled() bool`

GetEnabled returns the Enabled field if non-nil, zero value otherwise.

### GetEnabledOk

`func (o *AvoidResetBroadcast) GetEnabledOk() (*bool, bool)`

GetEnabledOk returns a tuple with the Enabled field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetEnabled

`func (o *AvoidResetBroadcast) SetEnabled(v bool)`

SetEnabled sets Enabled field to given value.


### GetOverride

`func (o *AvoidResetBroadcast) GetOverride() bool`

GetOverride returns the Override field if non-nil, zero value otherwise.

### GetOverrideOk

`func (o *AvoidResetBroadcast) GetOverrideOk() (*bool, bool)`

GetOverrideOk returns a tuple with the Override field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetOverride

`func (o *AvoidResetBroadcast) SetOverride(v bool)`

SetOverride sets Override field to given value.



[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


