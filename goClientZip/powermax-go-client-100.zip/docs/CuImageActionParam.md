# CuImageActionParam

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**CreateCUImageParam** | Pointer to [**CreateCUImageParam**](CreateCUImageParam.md) |  | [optional] 
**ExistingCUImageParam** | Pointer to [**ExistingCUImageParam**](ExistingCUImageParam.md) |  | [optional] 

## Methods

### NewCuImageActionParam

`func NewCuImageActionParam() *CuImageActionParam`

NewCuImageActionParam instantiates a new CuImageActionParam object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewCuImageActionParamWithDefaults

`func NewCuImageActionParamWithDefaults() *CuImageActionParam`

NewCuImageActionParamWithDefaults instantiates a new CuImageActionParam object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetCreateCUImageParam

`func (o *CuImageActionParam) GetCreateCUImageParam() CreateCUImageParam`

GetCreateCUImageParam returns the CreateCUImageParam field if non-nil, zero value otherwise.

### GetCreateCUImageParamOk

`func (o *CuImageActionParam) GetCreateCUImageParamOk() (*CreateCUImageParam, bool)`

GetCreateCUImageParamOk returns a tuple with the CreateCUImageParam field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetCreateCUImageParam

`func (o *CuImageActionParam) SetCreateCUImageParam(v CreateCUImageParam)`

SetCreateCUImageParam sets CreateCUImageParam field to given value.

### HasCreateCUImageParam

`func (o *CuImageActionParam) HasCreateCUImageParam() bool`

HasCreateCUImageParam returns a boolean if a field has been set.

### GetExistingCUImageParam

`func (o *CuImageActionParam) GetExistingCUImageParam() ExistingCUImageParam`

GetExistingCUImageParam returns the ExistingCUImageParam field if non-nil, zero value otherwise.

### GetExistingCUImageParamOk

`func (o *CuImageActionParam) GetExistingCUImageParamOk() (*ExistingCUImageParam, bool)`

GetExistingCUImageParamOk returns a tuple with the ExistingCUImageParam field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetExistingCUImageParam

`func (o *CuImageActionParam) SetExistingCUImageParam(v ExistingCUImageParam)`

SetExistingCUImageParam sets ExistingCUImageParam field to given value.

### HasExistingCUImageParam

`func (o *CuImageActionParam) HasExistingCUImageParam() bool`

HasExistingCUImageParam returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


