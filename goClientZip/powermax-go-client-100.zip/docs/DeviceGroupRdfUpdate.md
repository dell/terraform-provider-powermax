# DeviceGroupRdfUpdate

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ExecutionOption** | Pointer to **string** |  | [optional] [default to "SYNCHRONOUS"]
**RdfgNumber** | Pointer to **int64** | The SRDF Group number to perform the action on. Essential if working with Concurrent SRDF setups. | [optional] 
**Action** | **string** | The action to be performed.   Enumeration values: * **Establish** * **Split** * **Suspend** * **Restore** * **Resume** * **Failover** * **Failback** * **Swap**  | 
**Establish** | Pointer to [**DgEstablishParam**](DgEstablishParam.md) |  | [optional] 
**Split** | Pointer to [**DgSplitParam**](DgSplitParam.md) |  | [optional] 
**Suspend** | Pointer to [**DgSuspendParam**](DgSuspendParam.md) |  | [optional] 
**Restore** | Pointer to [**DgRestoreParam**](DgRestoreParam.md) |  | [optional] 
**Resume** | Pointer to [**DgResumeParam**](DgResumeParam.md) |  | [optional] 
**Failover** | Pointer to [**DgFailoverParam**](DgFailoverParam.md) |  | [optional] 
**Failback** | Pointer to [**DgFailbackParam**](DgFailbackParam.md) |  | [optional] 
**Swap** | Pointer to [**DgSwapParam**](DgSwapParam.md) |  | [optional] 

## Methods

### NewDeviceGroupRdfUpdate

`func NewDeviceGroupRdfUpdate(action string, ) *DeviceGroupRdfUpdate`

NewDeviceGroupRdfUpdate instantiates a new DeviceGroupRdfUpdate object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewDeviceGroupRdfUpdateWithDefaults

`func NewDeviceGroupRdfUpdateWithDefaults() *DeviceGroupRdfUpdate`

NewDeviceGroupRdfUpdateWithDefaults instantiates a new DeviceGroupRdfUpdate object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetExecutionOption

`func (o *DeviceGroupRdfUpdate) GetExecutionOption() string`

GetExecutionOption returns the ExecutionOption field if non-nil, zero value otherwise.

### GetExecutionOptionOk

`func (o *DeviceGroupRdfUpdate) GetExecutionOptionOk() (*string, bool)`

GetExecutionOptionOk returns a tuple with the ExecutionOption field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetExecutionOption

`func (o *DeviceGroupRdfUpdate) SetExecutionOption(v string)`

SetExecutionOption sets ExecutionOption field to given value.

### HasExecutionOption

`func (o *DeviceGroupRdfUpdate) HasExecutionOption() bool`

HasExecutionOption returns a boolean if a field has been set.

### GetRdfgNumber

`func (o *DeviceGroupRdfUpdate) GetRdfgNumber() int64`

GetRdfgNumber returns the RdfgNumber field if non-nil, zero value otherwise.

### GetRdfgNumberOk

`func (o *DeviceGroupRdfUpdate) GetRdfgNumberOk() (*int64, bool)`

GetRdfgNumberOk returns a tuple with the RdfgNumber field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetRdfgNumber

`func (o *DeviceGroupRdfUpdate) SetRdfgNumber(v int64)`

SetRdfgNumber sets RdfgNumber field to given value.

### HasRdfgNumber

`func (o *DeviceGroupRdfUpdate) HasRdfgNumber() bool`

HasRdfgNumber returns a boolean if a field has been set.

### GetAction

`func (o *DeviceGroupRdfUpdate) GetAction() string`

GetAction returns the Action field if non-nil, zero value otherwise.

### GetActionOk

`func (o *DeviceGroupRdfUpdate) GetActionOk() (*string, bool)`

GetActionOk returns a tuple with the Action field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetAction

`func (o *DeviceGroupRdfUpdate) SetAction(v string)`

SetAction sets Action field to given value.


### GetEstablish

`func (o *DeviceGroupRdfUpdate) GetEstablish() DgEstablishParam`

GetEstablish returns the Establish field if non-nil, zero value otherwise.

### GetEstablishOk

`func (o *DeviceGroupRdfUpdate) GetEstablishOk() (*DgEstablishParam, bool)`

GetEstablishOk returns a tuple with the Establish field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetEstablish

`func (o *DeviceGroupRdfUpdate) SetEstablish(v DgEstablishParam)`

SetEstablish sets Establish field to given value.

### HasEstablish

`func (o *DeviceGroupRdfUpdate) HasEstablish() bool`

HasEstablish returns a boolean if a field has been set.

### GetSplit

`func (o *DeviceGroupRdfUpdate) GetSplit() DgSplitParam`

GetSplit returns the Split field if non-nil, zero value otherwise.

### GetSplitOk

`func (o *DeviceGroupRdfUpdate) GetSplitOk() (*DgSplitParam, bool)`

GetSplitOk returns a tuple with the Split field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetSplit

`func (o *DeviceGroupRdfUpdate) SetSplit(v DgSplitParam)`

SetSplit sets Split field to given value.

### HasSplit

`func (o *DeviceGroupRdfUpdate) HasSplit() bool`

HasSplit returns a boolean if a field has been set.

### GetSuspend

`func (o *DeviceGroupRdfUpdate) GetSuspend() DgSuspendParam`

GetSuspend returns the Suspend field if non-nil, zero value otherwise.

### GetSuspendOk

`func (o *DeviceGroupRdfUpdate) GetSuspendOk() (*DgSuspendParam, bool)`

GetSuspendOk returns a tuple with the Suspend field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetSuspend

`func (o *DeviceGroupRdfUpdate) SetSuspend(v DgSuspendParam)`

SetSuspend sets Suspend field to given value.

### HasSuspend

`func (o *DeviceGroupRdfUpdate) HasSuspend() bool`

HasSuspend returns a boolean if a field has been set.

### GetRestore

`func (o *DeviceGroupRdfUpdate) GetRestore() DgRestoreParam`

GetRestore returns the Restore field if non-nil, zero value otherwise.

### GetRestoreOk

`func (o *DeviceGroupRdfUpdate) GetRestoreOk() (*DgRestoreParam, bool)`

GetRestoreOk returns a tuple with the Restore field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetRestore

`func (o *DeviceGroupRdfUpdate) SetRestore(v DgRestoreParam)`

SetRestore sets Restore field to given value.

### HasRestore

`func (o *DeviceGroupRdfUpdate) HasRestore() bool`

HasRestore returns a boolean if a field has been set.

### GetResume

`func (o *DeviceGroupRdfUpdate) GetResume() DgResumeParam`

GetResume returns the Resume field if non-nil, zero value otherwise.

### GetResumeOk

`func (o *DeviceGroupRdfUpdate) GetResumeOk() (*DgResumeParam, bool)`

GetResumeOk returns a tuple with the Resume field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetResume

`func (o *DeviceGroupRdfUpdate) SetResume(v DgResumeParam)`

SetResume sets Resume field to given value.

### HasResume

`func (o *DeviceGroupRdfUpdate) HasResume() bool`

HasResume returns a boolean if a field has been set.

### GetFailover

`func (o *DeviceGroupRdfUpdate) GetFailover() DgFailoverParam`

GetFailover returns the Failover field if non-nil, zero value otherwise.

### GetFailoverOk

`func (o *DeviceGroupRdfUpdate) GetFailoverOk() (*DgFailoverParam, bool)`

GetFailoverOk returns a tuple with the Failover field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetFailover

`func (o *DeviceGroupRdfUpdate) SetFailover(v DgFailoverParam)`

SetFailover sets Failover field to given value.

### HasFailover

`func (o *DeviceGroupRdfUpdate) HasFailover() bool`

HasFailover returns a boolean if a field has been set.

### GetFailback

`func (o *DeviceGroupRdfUpdate) GetFailback() DgFailbackParam`

GetFailback returns the Failback field if non-nil, zero value otherwise.

### GetFailbackOk

`func (o *DeviceGroupRdfUpdate) GetFailbackOk() (*DgFailbackParam, bool)`

GetFailbackOk returns a tuple with the Failback field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetFailback

`func (o *DeviceGroupRdfUpdate) SetFailback(v DgFailbackParam)`

SetFailback sets Failback field to given value.

### HasFailback

`func (o *DeviceGroupRdfUpdate) HasFailback() bool`

HasFailback returns a boolean if a field has been set.

### GetSwap

`func (o *DeviceGroupRdfUpdate) GetSwap() DgSwapParam`

GetSwap returns the Swap field if non-nil, zero value otherwise.

### GetSwapOk

`func (o *DeviceGroupRdfUpdate) GetSwapOk() (*DgSwapParam, bool)`

GetSwapOk returns a tuple with the Swap field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetSwap

`func (o *DeviceGroupRdfUpdate) SetSwap(v DgSwapParam)`

SetSwap sets Swap field to given value.

### HasSwap

`func (o *DeviceGroupRdfUpdate) HasSwap() bool`

HasSwap returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


