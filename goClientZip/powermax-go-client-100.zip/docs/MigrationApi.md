# \MigrationApi

All URIs are relative to *https://localhost:8443/univmax/restapi*

Method | HTTP request | Description
------------- | ------------- | -------------
[**CancelMigration**](MigrationApi.md#CancelMigration) | **Delete** /100/migration/symmetrix/{symmetrixId}/storagegroup/{storageGroupId} | Delete Storage Group Migration
[**CreateMigration**](MigrationApi.md#CreateMigration) | **Post** /100/migration/symmetrix/{symmetrixId}/storagegroup/{storageGroupId} | Create Storage Group Migration
[**CreateMigration1**](MigrationApi.md#CreateMigration1) | **Post** /100/migration/symmetrix/{symmetrixId}/storagegroup | Create Migration
[**GetEnvironments**](MigrationApi.md#GetEnvironments) | **Get** /100/migration/symmetrix/{symmetrixId}/environment | List Migration Environments
[**GetStorageGroup**](MigrationApi.md#GetStorageGroup) | **Get** /100/migration/symmetrix/{symmetrixId}/storagegroup/{storageGroupId} | Get Storage Group
[**GetStorageGroupNames**](MigrationApi.md#GetStorageGroupNames) | **Get** /100/migration/symmetrix/{symmetrixId}/storagegroup | List Storage Groups
[**GetSymmetrix**](MigrationApi.md#GetSymmetrix) | **Get** /100/migration/symmetrix/{symmetrixId} | Get Array
[**GetSymmetrixCapabilities**](MigrationApi.md#GetSymmetrixCapabilities) | **Get** /100/migration/capabilities/symmetrix | List Array Capabilities
[**GetSymmetrixIDs**](MigrationApi.md#GetSymmetrixIDs) | **Get** /100/migration/symmetrix | List Arrays
[**GetSymmetrixMigrationEnvironment**](MigrationApi.md#GetSymmetrixMigrationEnvironment) | **Get** /100/migration/symmetrix/{symmetrixId}/environment/{remoteArrayId} | Get Migration Environment
[**RemoveEnvironment**](MigrationApi.md#RemoveEnvironment) | **Delete** /100/migration/symmetrix/{symmetrixId}/environment/{remoteArrayId} | Delete Migration Environment
[**SetupEnvironment**](MigrationApi.md#SetupEnvironment) | **Post** /100/migration/symmetrix/{symmetrixId} | Create Migration Environment
[**UpdateMigration**](MigrationApi.md#UpdateMigration) | **Put** /100/migration/symmetrix/{symmetrixId}/storagegroup/{storageGroupId} | Modify Migration Session



## CancelMigration

> CancelMigration(ctx, symmetrixId, storageGroupId).Revert(revert).Symforce(symforce).Execute()

Delete Storage Group Migration



### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    symmetrixId := "symmetrixId_example" // string | TheSystem ID
    storageGroupId := "storageGroupId_example" // string | The Storage Group name
    revert := "revert_example" // string | Set the revert flag (optional)
    symforce := "symforce_example" // string | Set the symforce flag (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.MigrationApi.CancelMigration(context.Background(), symmetrixId, storageGroupId).Revert(revert).Symforce(symforce).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `MigrationApi.CancelMigration``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**symmetrixId** | **string** | TheSystem ID | 
**storageGroupId** | **string** | The Storage Group name | 

### Other Parameters

Other parameters are passed through a pointer to a apiCancelMigrationRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


 **revert** | **string** | Set the revert flag | 
 **symforce** | **string** | Set the symforce flag | 

### Return type

 (empty response body)

### Authorization

[apiSecurity](../README.md#apiSecurity)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## CreateMigration

> MigrationStorageGroup CreateMigration(ctx, symmetrixId, storageGroupId).MigrationCreate(migrationCreate).Execute()

Create Storage Group Migration



### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    symmetrixId := "symmetrixId_example" // string | The System ID
    storageGroupId := "storageGroupId_example" // string | The Storage Group name
    migrationCreate := *openapiclient.NewMigrationCreate("OtherArrayId_example") // MigrationCreate | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.MigrationApi.CreateMigration(context.Background(), symmetrixId, storageGroupId).MigrationCreate(migrationCreate).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `MigrationApi.CreateMigration``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `CreateMigration`: MigrationStorageGroup
    fmt.Fprintf(os.Stdout, "Response from `MigrationApi.CreateMigration`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**symmetrixId** | **string** | The System ID | 
**storageGroupId** | **string** | The Storage Group name | 

### Other Parameters

Other parameters are passed through a pointer to a apiCreateMigrationRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


 **migrationCreate** | [**MigrationCreate**](MigrationCreate.md) |  | 

### Return type

[**MigrationStorageGroup**](MigrationStorageGroup.md)

### Authorization

[apiSecurity](../README.md#apiSecurity)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## CreateMigration1

> MigrationStorageGroup CreateMigration1(ctx, symmetrixId).CreateMigration(createMigration).Execute()

Create Migration



### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    symmetrixId := "symmetrixId_example" // string | The System ID
    createMigration := *openapiclient.NewCreateMigration("Action_example") // CreateMigration | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.MigrationApi.CreateMigration1(context.Background(), symmetrixId).CreateMigration(createMigration).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `MigrationApi.CreateMigration1``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `CreateMigration1`: MigrationStorageGroup
    fmt.Fprintf(os.Stdout, "Response from `MigrationApi.CreateMigration1`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**symmetrixId** | **string** | The System ID | 

### Other Parameters

Other parameters are passed through a pointer to a apiCreateMigration1Request struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **createMigration** | [**CreateMigration**](CreateMigration.md) |  | 

### Return type

[**MigrationStorageGroup**](MigrationStorageGroup.md)

### Authorization

[apiSecurity](../README.md#apiSecurity)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetEnvironments

> DmStorageArrayList GetEnvironments(ctx, symmetrixId).Execute()

List Migration Environments



### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    symmetrixId := "symmetrixId_example" // string | The System ID

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.MigrationApi.GetEnvironments(context.Background(), symmetrixId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `MigrationApi.GetEnvironments``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetEnvironments`: DmStorageArrayList
    fmt.Fprintf(os.Stdout, "Response from `MigrationApi.GetEnvironments`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**symmetrixId** | **string** | The System ID | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetEnvironmentsRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


### Return type

[**DmStorageArrayList**](DmStorageArrayList.md)

### Authorization

[apiSecurity](../README.md#apiSecurity)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json, application/xml

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetStorageGroup

> MigrationStorageGroup GetStorageGroup(ctx, symmetrixId, storageGroupId).Execute()

Get Storage Group



### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    symmetrixId := "symmetrixId_example" // string | The System ID
    storageGroupId := "storageGroupId_example" // string | The Storage Group name

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.MigrationApi.GetStorageGroup(context.Background(), symmetrixId, storageGroupId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `MigrationApi.GetStorageGroup``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetStorageGroup`: MigrationStorageGroup
    fmt.Fprintf(os.Stdout, "Response from `MigrationApi.GetStorageGroup`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**symmetrixId** | **string** | The System ID | 
**storageGroupId** | **string** | The Storage Group name | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetStorageGroupRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------



### Return type

[**MigrationStorageGroup**](MigrationStorageGroup.md)

### Authorization

[apiSecurity](../README.md#apiSecurity)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json, application/xml

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetStorageGroupNames

> DmStorageGroupList GetStorageGroupNames(ctx, symmetrixId).IncludeMigrations(includeMigrations).Execute()

List Storage Groups



### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    symmetrixId := "symmetrixId_example" // string | The System ID
    includeMigrations := "includeMigrations_example" // string | Include current migrations (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.MigrationApi.GetStorageGroupNames(context.Background(), symmetrixId).IncludeMigrations(includeMigrations).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `MigrationApi.GetStorageGroupNames``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetStorageGroupNames`: DmStorageGroupList
    fmt.Fprintf(os.Stdout, "Response from `MigrationApi.GetStorageGroupNames`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**symmetrixId** | **string** | The System ID | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetStorageGroupNamesRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **includeMigrations** | **string** | Include current migrations | 

### Return type

[**DmStorageGroupList**](DmStorageGroupList.md)

### Authorization

[apiSecurity](../README.md#apiSecurity)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json, application/xml

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetSymmetrix

> StorageArray GetSymmetrix(ctx, symmetrixId).Execute()

Get Array



### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    symmetrixId := "symmetrixId_example" // string | The System ID

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.MigrationApi.GetSymmetrix(context.Background(), symmetrixId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `MigrationApi.GetSymmetrix``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetSymmetrix`: StorageArray
    fmt.Fprintf(os.Stdout, "Response from `MigrationApi.GetSymmetrix`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**symmetrixId** | **string** | The System ID | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetSymmetrixRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


### Return type

[**StorageArray**](StorageArray.md)

### Authorization

[apiSecurity](../README.md#apiSecurity)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json, application/xml

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetSymmetrixCapabilities

> DmStorageArrayCapabilityList GetSymmetrixCapabilities(ctx).Execute()

List Array Capabilities



### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.MigrationApi.GetSymmetrixCapabilities(context.Background()).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `MigrationApi.GetSymmetrixCapabilities``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetSymmetrixCapabilities`: DmStorageArrayCapabilityList
    fmt.Fprintf(os.Stdout, "Response from `MigrationApi.GetSymmetrixCapabilities`: %v\n", resp)
}
```

### Path Parameters

This endpoint does not need any parameter.

### Other Parameters

Other parameters are passed through a pointer to a apiGetSymmetrixCapabilitiesRequest struct via the builder pattern


### Return type

[**DmStorageArrayCapabilityList**](DmStorageArrayCapabilityList.md)

### Authorization

[apiSecurity](../README.md#apiSecurity)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json, application/xml

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetSymmetrixIDs

> DmStorageArrayList GetSymmetrixIDs(ctx).Execute()

List Arrays



### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.MigrationApi.GetSymmetrixIDs(context.Background()).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `MigrationApi.GetSymmetrixIDs``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetSymmetrixIDs`: DmStorageArrayList
    fmt.Fprintf(os.Stdout, "Response from `MigrationApi.GetSymmetrixIDs`: %v\n", resp)
}
```

### Path Parameters

This endpoint does not need any parameter.

### Other Parameters

Other parameters are passed through a pointer to a apiGetSymmetrixIDsRequest struct via the builder pattern


### Return type

[**DmStorageArrayList**](DmStorageArrayList.md)

### Authorization

[apiSecurity](../README.md#apiSecurity)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json, application/xml

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetSymmetrixMigrationEnvironment

> SymmetrixMigrationEnvironment GetSymmetrixMigrationEnvironment(ctx, symmetrixId, remoteArrayId).Execute()

Get Migration Environment



### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    symmetrixId := "symmetrixId_example" // string | The source System ID
    remoteArrayId := "remoteArrayId_example" // string | The target System ID

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.MigrationApi.GetSymmetrixMigrationEnvironment(context.Background(), symmetrixId, remoteArrayId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `MigrationApi.GetSymmetrixMigrationEnvironment``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetSymmetrixMigrationEnvironment`: SymmetrixMigrationEnvironment
    fmt.Fprintf(os.Stdout, "Response from `MigrationApi.GetSymmetrixMigrationEnvironment`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**symmetrixId** | **string** | The source System ID | 
**remoteArrayId** | **string** | The target System ID | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetSymmetrixMigrationEnvironmentRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------



### Return type

[**SymmetrixMigrationEnvironment**](SymmetrixMigrationEnvironment.md)

### Authorization

[apiSecurity](../README.md#apiSecurity)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json, application/xml

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## RemoveEnvironment

> RemoveEnvironment(ctx, symmetrixId, remoteArrayId).Execute()

Delete Migration Environment



### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    symmetrixId := "symmetrixId_example" // string | The System ID
    remoteArrayId := "remoteArrayId_example" // string | The remote System ID

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.MigrationApi.RemoveEnvironment(context.Background(), symmetrixId, remoteArrayId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `MigrationApi.RemoveEnvironment``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**symmetrixId** | **string** | The System ID | 
**remoteArrayId** | **string** | The remote System ID | 

### Other Parameters

Other parameters are passed through a pointer to a apiRemoveEnvironmentRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------



### Return type

 (empty response body)

### Authorization

[apiSecurity](../README.md#apiSecurity)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## SetupEnvironment

> StorageArray SetupEnvironment(ctx, symmetrixId).EnvironmentSetup(environmentSetup).Execute()

Create Migration Environment



### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    symmetrixId := "symmetrixId_example" // string | The Array array ID
    environmentSetup := *openapiclient.NewEnvironmentSetup("OtherArrayId_example") // EnvironmentSetup | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.MigrationApi.SetupEnvironment(context.Background(), symmetrixId).EnvironmentSetup(environmentSetup).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `MigrationApi.SetupEnvironment``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `SetupEnvironment`: StorageArray
    fmt.Fprintf(os.Stdout, "Response from `MigrationApi.SetupEnvironment`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**symmetrixId** | **string** | The Array array ID | 

### Other Parameters

Other parameters are passed through a pointer to a apiSetupEnvironmentRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **environmentSetup** | [**EnvironmentSetup**](EnvironmentSetup.md) |  | 

### Return type

[**StorageArray**](StorageArray.md)

### Authorization

[apiSecurity](../README.md#apiSecurity)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdateMigration

> MigrationStorageGroup UpdateMigration(ctx, symmetrixId, storageGroupId).MigrationUpdate(migrationUpdate).Execute()

Modify Migration Session



### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    symmetrixId := "symmetrixId_example" // string | The System ID
    storageGroupId := "storageGroupId_example" // string | The Storage Group name
    migrationUpdate := *openapiclient.NewMigrationUpdate("Action_example") // MigrationUpdate | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.MigrationApi.UpdateMigration(context.Background(), symmetrixId, storageGroupId).MigrationUpdate(migrationUpdate).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `MigrationApi.UpdateMigration``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `UpdateMigration`: MigrationStorageGroup
    fmt.Fprintf(os.Stdout, "Response from `MigrationApi.UpdateMigration`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**symmetrixId** | **string** | The System ID | 
**storageGroupId** | **string** | The Storage Group name | 

### Other Parameters

Other parameters are passed through a pointer to a apiUpdateMigrationRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


 **migrationUpdate** | [**MigrationUpdate**](MigrationUpdate.md) |  | 

### Return type

[**MigrationStorageGroup**](MigrationStorageGroup.md)

### Authorization

[apiSecurity](../README.md#apiSecurity)

### HTTP request headers

- **Content-Type**: application/json, application/xml
- **Accept**: application/json, application/xml

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)

