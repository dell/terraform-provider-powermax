# AddTagsParam

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**TagName** | **[]string** | Tag Names to be added. | 

## Methods

### NewAddTagsParam

`func NewAddTagsParam(tagName []string, ) *AddTagsParam`

NewAddTagsParam instantiates a new AddTagsParam object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewAddTagsParamWithDefaults

`func NewAddTagsParamWithDefaults() *AddTagsParam`

NewAddTagsParamWithDefaults instantiates a new AddTagsParam object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetTagName

`func (o *AddTagsParam) GetTagName() []string`

GetTagName returns the TagName field if non-nil, zero value otherwise.

### GetTagNameOk

`func (o *AddTagsParam) GetTagNameOk() (*[]string, bool)`

GetTagNameOk returns a tuple with the TagName field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetTagName

`func (o *AddTagsParam) SetTagName(v []string)`

SetTagName sets TagName field to given value.



[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


