# EditSloActionParam

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**RenameSloParam** | Pointer to [**RenameSloParam**](RenameSloParam.md) |  | [optional] 

## Methods

### NewEditSloActionParam

`func NewEditSloActionParam() *EditSloActionParam`

NewEditSloActionParam instantiates a new EditSloActionParam object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewEditSloActionParamWithDefaults

`func NewEditSloActionParamWithDefaults() *EditSloActionParam`

NewEditSloActionParamWithDefaults instantiates a new EditSloActionParam object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetRenameSloParam

`func (o *EditSloActionParam) GetRenameSloParam() RenameSloParam`

GetRenameSloParam returns the RenameSloParam field if non-nil, zero value otherwise.

### GetRenameSloParamOk

`func (o *EditSloActionParam) GetRenameSloParamOk() (*RenameSloParam, bool)`

GetRenameSloParamOk returns a tuple with the RenameSloParam field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetRenameSloParam

`func (o *EditSloActionParam) SetRenameSloParam(v RenameSloParam)`

SetRenameSloParam sets RenameSloParam field to given value.

### HasRenameSloParam

`func (o *EditSloActionParam) HasRenameSloParam() bool`

HasRenameSloParam returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


