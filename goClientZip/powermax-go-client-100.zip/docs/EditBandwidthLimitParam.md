# EditBandwidthLimitParam

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Enable** | **bool** | Enable/Disable the bandwidth limits | 
**BandwidthLimitMbps** | **int64** | defines the limit in mbs per second | 

## Methods

### NewEditBandwidthLimitParam

`func NewEditBandwidthLimitParam(enable bool, bandwidthLimitMbps int64, ) *EditBandwidthLimitParam`

NewEditBandwidthLimitParam instantiates a new EditBandwidthLimitParam object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewEditBandwidthLimitParamWithDefaults

`func NewEditBandwidthLimitParamWithDefaults() *EditBandwidthLimitParam`

NewEditBandwidthLimitParamWithDefaults instantiates a new EditBandwidthLimitParam object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetEnable

`func (o *EditBandwidthLimitParam) GetEnable() bool`

GetEnable returns the Enable field if non-nil, zero value otherwise.

### GetEnableOk

`func (o *EditBandwidthLimitParam) GetEnableOk() (*bool, bool)`

GetEnableOk returns a tuple with the Enable field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetEnable

`func (o *EditBandwidthLimitParam) SetEnable(v bool)`

SetEnable sets Enable field to given value.


### GetBandwidthLimitMbps

`func (o *EditBandwidthLimitParam) GetBandwidthLimitMbps() int64`

GetBandwidthLimitMbps returns the BandwidthLimitMbps field if non-nil, zero value otherwise.

### GetBandwidthLimitMbpsOk

`func (o *EditBandwidthLimitParam) GetBandwidthLimitMbpsOk() (*int64, bool)`

GetBandwidthLimitMbpsOk returns a tuple with the BandwidthLimitMbps field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetBandwidthLimitMbps

`func (o *EditBandwidthLimitParam) SetBandwidthLimitMbps(v int64)`

SetBandwidthLimitMbps sets BandwidthLimitMbps field to given value.



[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


