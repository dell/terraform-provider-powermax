# MixtureIoType

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**IoPercent** | **float64** | The percentage of total IOPS of a specific I/O type. | 
**IoSize** | **float64** | The I/O size of a specific I/O type. | 

## Methods

### NewMixtureIoType

`func NewMixtureIoType(ioPercent float64, ioSize float64, ) *MixtureIoType`

NewMixtureIoType instantiates a new MixtureIoType object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewMixtureIoTypeWithDefaults

`func NewMixtureIoTypeWithDefaults() *MixtureIoType`

NewMixtureIoTypeWithDefaults instantiates a new MixtureIoType object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetIoPercent

`func (o *MixtureIoType) GetIoPercent() float64`

GetIoPercent returns the IoPercent field if non-nil, zero value otherwise.

### GetIoPercentOk

`func (o *MixtureIoType) GetIoPercentOk() (*float64, bool)`

GetIoPercentOk returns a tuple with the IoPercent field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetIoPercent

`func (o *MixtureIoType) SetIoPercent(v float64)`

SetIoPercent sets IoPercent field to given value.


### GetIoSize

`func (o *MixtureIoType) GetIoSize() float64`

GetIoSize returns the IoSize field if non-nil, zero value otherwise.

### GetIoSizeOk

`func (o *MixtureIoType) GetIoSizeOk() (*float64, bool)`

GetIoSizeOk returns a tuple with the IoSize field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetIoSize

`func (o *MixtureIoType) SetIoSize(v float64)`

SetIoSize sets IoSize field to given value.



[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


