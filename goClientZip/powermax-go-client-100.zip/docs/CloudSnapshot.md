# CloudSnapshot

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**CloudSnapshotId** | **string** | The Id of the cloud snapshot | 
**SnapshotName** | Pointer to **string** | The Name of the snapshot | [optional] 
**CreationDate** | Pointer to **string** | The date Time the snapshot was created | [optional] 
**CreationDateTimestamp** | Pointer to **int64** | The Timestamp the snapshot was created | [optional] 
**ExpiryDate** | Pointer to **string** | The date Time of when the snapshot is due to expire in the cloud | [optional] 
**ExpiryDateTimestamp** | Pointer to **int64** | The Timestamp of when the snapshot is due to expire in the cloud | [optional] 
**State** | Pointer to **string** | The current state of the cloud snapshot | [optional] 
**CloudProviderId** | Pointer to **string** | The name of the associated Cloud Provider | [optional] 
**CapacityGb** | Pointer to **float64** | The total capacity of the snapshot at creation time in GBs | [optional] 
**ProtectedPercent** | Pointer to **int64** | The current progress percent of the snapshot being archived up to the cloud where                         applicable | [optional] 
**StorageGroupId** | Pointer to **string** | The name of the associated Storage group at the time of creation | [optional] 
**StorageGroupUuid** | Pointer to **string** | The uuid of the associated Storage group | [optional] 
**NumberOfVolumes** | Pointer to **int32** | The total number of Source volumes associated with this snapshot | [optional] 
**EncryptionEnabled** | Pointer to **bool** | specifies if encryption is enabled or not | [optional] 
**CompressionEnabled** | Pointer to **bool** | specifies if compression is enabled or not | [optional] 
**Orphaned** | Pointer to **bool** | Specifies if the storage group at the creation time still exists or not | [optional] 
**RecoveredStorageGroupInfos** | Pointer to [**[]StorageGroupInfo**](StorageGroupInfo.md) | The List of Recovered Storage Groups Infos | [optional] 

## Methods

### NewCloudSnapshot

`func NewCloudSnapshot(cloudSnapshotId string, ) *CloudSnapshot`

NewCloudSnapshot instantiates a new CloudSnapshot object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewCloudSnapshotWithDefaults

`func NewCloudSnapshotWithDefaults() *CloudSnapshot`

NewCloudSnapshotWithDefaults instantiates a new CloudSnapshot object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetCloudSnapshotId

`func (o *CloudSnapshot) GetCloudSnapshotId() string`

GetCloudSnapshotId returns the CloudSnapshotId field if non-nil, zero value otherwise.

### GetCloudSnapshotIdOk

`func (o *CloudSnapshot) GetCloudSnapshotIdOk() (*string, bool)`

GetCloudSnapshotIdOk returns a tuple with the CloudSnapshotId field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetCloudSnapshotId

`func (o *CloudSnapshot) SetCloudSnapshotId(v string)`

SetCloudSnapshotId sets CloudSnapshotId field to given value.


### GetSnapshotName

`func (o *CloudSnapshot) GetSnapshotName() string`

GetSnapshotName returns the SnapshotName field if non-nil, zero value otherwise.

### GetSnapshotNameOk

`func (o *CloudSnapshot) GetSnapshotNameOk() (*string, bool)`

GetSnapshotNameOk returns a tuple with the SnapshotName field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetSnapshotName

`func (o *CloudSnapshot) SetSnapshotName(v string)`

SetSnapshotName sets SnapshotName field to given value.

### HasSnapshotName

`func (o *CloudSnapshot) HasSnapshotName() bool`

HasSnapshotName returns a boolean if a field has been set.

### GetCreationDate

`func (o *CloudSnapshot) GetCreationDate() string`

GetCreationDate returns the CreationDate field if non-nil, zero value otherwise.

### GetCreationDateOk

`func (o *CloudSnapshot) GetCreationDateOk() (*string, bool)`

GetCreationDateOk returns a tuple with the CreationDate field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetCreationDate

`func (o *CloudSnapshot) SetCreationDate(v string)`

SetCreationDate sets CreationDate field to given value.

### HasCreationDate

`func (o *CloudSnapshot) HasCreationDate() bool`

HasCreationDate returns a boolean if a field has been set.

### GetCreationDateTimestamp

`func (o *CloudSnapshot) GetCreationDateTimestamp() int64`

GetCreationDateTimestamp returns the CreationDateTimestamp field if non-nil, zero value otherwise.

### GetCreationDateTimestampOk

`func (o *CloudSnapshot) GetCreationDateTimestampOk() (*int64, bool)`

GetCreationDateTimestampOk returns a tuple with the CreationDateTimestamp field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetCreationDateTimestamp

`func (o *CloudSnapshot) SetCreationDateTimestamp(v int64)`

SetCreationDateTimestamp sets CreationDateTimestamp field to given value.

### HasCreationDateTimestamp

`func (o *CloudSnapshot) HasCreationDateTimestamp() bool`

HasCreationDateTimestamp returns a boolean if a field has been set.

### GetExpiryDate

`func (o *CloudSnapshot) GetExpiryDate() string`

GetExpiryDate returns the ExpiryDate field if non-nil, zero value otherwise.

### GetExpiryDateOk

`func (o *CloudSnapshot) GetExpiryDateOk() (*string, bool)`

GetExpiryDateOk returns a tuple with the ExpiryDate field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetExpiryDate

`func (o *CloudSnapshot) SetExpiryDate(v string)`

SetExpiryDate sets ExpiryDate field to given value.

### HasExpiryDate

`func (o *CloudSnapshot) HasExpiryDate() bool`

HasExpiryDate returns a boolean if a field has been set.

### GetExpiryDateTimestamp

`func (o *CloudSnapshot) GetExpiryDateTimestamp() int64`

GetExpiryDateTimestamp returns the ExpiryDateTimestamp field if non-nil, zero value otherwise.

### GetExpiryDateTimestampOk

`func (o *CloudSnapshot) GetExpiryDateTimestampOk() (*int64, bool)`

GetExpiryDateTimestampOk returns a tuple with the ExpiryDateTimestamp field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetExpiryDateTimestamp

`func (o *CloudSnapshot) SetExpiryDateTimestamp(v int64)`

SetExpiryDateTimestamp sets ExpiryDateTimestamp field to given value.

### HasExpiryDateTimestamp

`func (o *CloudSnapshot) HasExpiryDateTimestamp() bool`

HasExpiryDateTimestamp returns a boolean if a field has been set.

### GetState

`func (o *CloudSnapshot) GetState() string`

GetState returns the State field if non-nil, zero value otherwise.

### GetStateOk

`func (o *CloudSnapshot) GetStateOk() (*string, bool)`

GetStateOk returns a tuple with the State field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetState

`func (o *CloudSnapshot) SetState(v string)`

SetState sets State field to given value.

### HasState

`func (o *CloudSnapshot) HasState() bool`

HasState returns a boolean if a field has been set.

### GetCloudProviderId

`func (o *CloudSnapshot) GetCloudProviderId() string`

GetCloudProviderId returns the CloudProviderId field if non-nil, zero value otherwise.

### GetCloudProviderIdOk

`func (o *CloudSnapshot) GetCloudProviderIdOk() (*string, bool)`

GetCloudProviderIdOk returns a tuple with the CloudProviderId field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetCloudProviderId

`func (o *CloudSnapshot) SetCloudProviderId(v string)`

SetCloudProviderId sets CloudProviderId field to given value.

### HasCloudProviderId

`func (o *CloudSnapshot) HasCloudProviderId() bool`

HasCloudProviderId returns a boolean if a field has been set.

### GetCapacityGb

`func (o *CloudSnapshot) GetCapacityGb() float64`

GetCapacityGb returns the CapacityGb field if non-nil, zero value otherwise.

### GetCapacityGbOk

`func (o *CloudSnapshot) GetCapacityGbOk() (*float64, bool)`

GetCapacityGbOk returns a tuple with the CapacityGb field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetCapacityGb

`func (o *CloudSnapshot) SetCapacityGb(v float64)`

SetCapacityGb sets CapacityGb field to given value.

### HasCapacityGb

`func (o *CloudSnapshot) HasCapacityGb() bool`

HasCapacityGb returns a boolean if a field has been set.

### GetProtectedPercent

`func (o *CloudSnapshot) GetProtectedPercent() int64`

GetProtectedPercent returns the ProtectedPercent field if non-nil, zero value otherwise.

### GetProtectedPercentOk

`func (o *CloudSnapshot) GetProtectedPercentOk() (*int64, bool)`

GetProtectedPercentOk returns a tuple with the ProtectedPercent field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetProtectedPercent

`func (o *CloudSnapshot) SetProtectedPercent(v int64)`

SetProtectedPercent sets ProtectedPercent field to given value.

### HasProtectedPercent

`func (o *CloudSnapshot) HasProtectedPercent() bool`

HasProtectedPercent returns a boolean if a field has been set.

### GetStorageGroupId

`func (o *CloudSnapshot) GetStorageGroupId() string`

GetStorageGroupId returns the StorageGroupId field if non-nil, zero value otherwise.

### GetStorageGroupIdOk

`func (o *CloudSnapshot) GetStorageGroupIdOk() (*string, bool)`

GetStorageGroupIdOk returns a tuple with the StorageGroupId field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetStorageGroupId

`func (o *CloudSnapshot) SetStorageGroupId(v string)`

SetStorageGroupId sets StorageGroupId field to given value.

### HasStorageGroupId

`func (o *CloudSnapshot) HasStorageGroupId() bool`

HasStorageGroupId returns a boolean if a field has been set.

### GetStorageGroupUuid

`func (o *CloudSnapshot) GetStorageGroupUuid() string`

GetStorageGroupUuid returns the StorageGroupUuid field if non-nil, zero value otherwise.

### GetStorageGroupUuidOk

`func (o *CloudSnapshot) GetStorageGroupUuidOk() (*string, bool)`

GetStorageGroupUuidOk returns a tuple with the StorageGroupUuid field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetStorageGroupUuid

`func (o *CloudSnapshot) SetStorageGroupUuid(v string)`

SetStorageGroupUuid sets StorageGroupUuid field to given value.

### HasStorageGroupUuid

`func (o *CloudSnapshot) HasStorageGroupUuid() bool`

HasStorageGroupUuid returns a boolean if a field has been set.

### GetNumberOfVolumes

`func (o *CloudSnapshot) GetNumberOfVolumes() int32`

GetNumberOfVolumes returns the NumberOfVolumes field if non-nil, zero value otherwise.

### GetNumberOfVolumesOk

`func (o *CloudSnapshot) GetNumberOfVolumesOk() (*int32, bool)`

GetNumberOfVolumesOk returns a tuple with the NumberOfVolumes field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetNumberOfVolumes

`func (o *CloudSnapshot) SetNumberOfVolumes(v int32)`

SetNumberOfVolumes sets NumberOfVolumes field to given value.

### HasNumberOfVolumes

`func (o *CloudSnapshot) HasNumberOfVolumes() bool`

HasNumberOfVolumes returns a boolean if a field has been set.

### GetEncryptionEnabled

`func (o *CloudSnapshot) GetEncryptionEnabled() bool`

GetEncryptionEnabled returns the EncryptionEnabled field if non-nil, zero value otherwise.

### GetEncryptionEnabledOk

`func (o *CloudSnapshot) GetEncryptionEnabledOk() (*bool, bool)`

GetEncryptionEnabledOk returns a tuple with the EncryptionEnabled field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetEncryptionEnabled

`func (o *CloudSnapshot) SetEncryptionEnabled(v bool)`

SetEncryptionEnabled sets EncryptionEnabled field to given value.

### HasEncryptionEnabled

`func (o *CloudSnapshot) HasEncryptionEnabled() bool`

HasEncryptionEnabled returns a boolean if a field has been set.

### GetCompressionEnabled

`func (o *CloudSnapshot) GetCompressionEnabled() bool`

GetCompressionEnabled returns the CompressionEnabled field if non-nil, zero value otherwise.

### GetCompressionEnabledOk

`func (o *CloudSnapshot) GetCompressionEnabledOk() (*bool, bool)`

GetCompressionEnabledOk returns a tuple with the CompressionEnabled field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetCompressionEnabled

`func (o *CloudSnapshot) SetCompressionEnabled(v bool)`

SetCompressionEnabled sets CompressionEnabled field to given value.

### HasCompressionEnabled

`func (o *CloudSnapshot) HasCompressionEnabled() bool`

HasCompressionEnabled returns a boolean if a field has been set.

### GetOrphaned

`func (o *CloudSnapshot) GetOrphaned() bool`

GetOrphaned returns the Orphaned field if non-nil, zero value otherwise.

### GetOrphanedOk

`func (o *CloudSnapshot) GetOrphanedOk() (*bool, bool)`

GetOrphanedOk returns a tuple with the Orphaned field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetOrphaned

`func (o *CloudSnapshot) SetOrphaned(v bool)`

SetOrphaned sets Orphaned field to given value.

### HasOrphaned

`func (o *CloudSnapshot) HasOrphaned() bool`

HasOrphaned returns a boolean if a field has been set.

### GetRecoveredStorageGroupInfos

`func (o *CloudSnapshot) GetRecoveredStorageGroupInfos() []StorageGroupInfo`

GetRecoveredStorageGroupInfos returns the RecoveredStorageGroupInfos field if non-nil, zero value otherwise.

### GetRecoveredStorageGroupInfosOk

`func (o *CloudSnapshot) GetRecoveredStorageGroupInfosOk() (*[]StorageGroupInfo, bool)`

GetRecoveredStorageGroupInfosOk returns a tuple with the RecoveredStorageGroupInfos field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetRecoveredStorageGroupInfos

`func (o *CloudSnapshot) SetRecoveredStorageGroupInfos(v []StorageGroupInfo)`

SetRecoveredStorageGroupInfos sets RecoveredStorageGroupInfos field to given value.

### HasRecoveredStorageGroupInfos

`func (o *CloudSnapshot) HasRecoveredStorageGroupInfos() bool`

HasRecoveredStorageGroupInfos returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


