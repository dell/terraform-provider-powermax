# EnvironmentSetup

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ExecutionOption** | Pointer to **string** |  | [optional] [default to "SYNCHRONOUS"]
**OtherArrayId** | **string** | The name of the target System with which migrations will happen. | 

## Methods

### NewEnvironmentSetup

`func NewEnvironmentSetup(otherArrayId string, ) *EnvironmentSetup`

NewEnvironmentSetup instantiates a new EnvironmentSetup object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewEnvironmentSetupWithDefaults

`func NewEnvironmentSetupWithDefaults() *EnvironmentSetup`

NewEnvironmentSetupWithDefaults instantiates a new EnvironmentSetup object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetExecutionOption

`func (o *EnvironmentSetup) GetExecutionOption() string`

GetExecutionOption returns the ExecutionOption field if non-nil, zero value otherwise.

### GetExecutionOptionOk

`func (o *EnvironmentSetup) GetExecutionOptionOk() (*string, bool)`

GetExecutionOptionOk returns a tuple with the ExecutionOption field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetExecutionOption

`func (o *EnvironmentSetup) SetExecutionOption(v string)`

SetExecutionOption sets ExecutionOption field to given value.

### HasExecutionOption

`func (o *EnvironmentSetup) HasExecutionOption() bool`

HasExecutionOption returns a boolean if a field has been set.

### GetOtherArrayId

`func (o *EnvironmentSetup) GetOtherArrayId() string`

GetOtherArrayId returns the OtherArrayId field if non-nil, zero value otherwise.

### GetOtherArrayIdOk

`func (o *EnvironmentSetup) GetOtherArrayIdOk() (*string, bool)`

GetOtherArrayIdOk returns a tuple with the OtherArrayId field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetOtherArrayId

`func (o *EnvironmentSetup) SetOtherArrayId(v string)`

SetOtherArrayId sets OtherArrayId field to given value.



[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


