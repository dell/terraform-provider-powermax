# EditCloudSystemDnsServerActionParam

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**EditCloudSystemDnsServerIpAddress** | Pointer to [**EditCloudSystemDnsServerIpAddressParam**](EditCloudSystemDnsServerIpAddressParam.md) |  | [optional] 

## Methods

### NewEditCloudSystemDnsServerActionParam

`func NewEditCloudSystemDnsServerActionParam() *EditCloudSystemDnsServerActionParam`

NewEditCloudSystemDnsServerActionParam instantiates a new EditCloudSystemDnsServerActionParam object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewEditCloudSystemDnsServerActionParamWithDefaults

`func NewEditCloudSystemDnsServerActionParamWithDefaults() *EditCloudSystemDnsServerActionParam`

NewEditCloudSystemDnsServerActionParamWithDefaults instantiates a new EditCloudSystemDnsServerActionParam object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetEditCloudSystemDnsServerIpAddress

`func (o *EditCloudSystemDnsServerActionParam) GetEditCloudSystemDnsServerIpAddress() EditCloudSystemDnsServerIpAddressParam`

GetEditCloudSystemDnsServerIpAddress returns the EditCloudSystemDnsServerIpAddress field if non-nil, zero value otherwise.

### GetEditCloudSystemDnsServerIpAddressOk

`func (o *EditCloudSystemDnsServerActionParam) GetEditCloudSystemDnsServerIpAddressOk() (*EditCloudSystemDnsServerIpAddressParam, bool)`

GetEditCloudSystemDnsServerIpAddressOk returns a tuple with the EditCloudSystemDnsServerIpAddress field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetEditCloudSystemDnsServerIpAddress

`func (o *EditCloudSystemDnsServerActionParam) SetEditCloudSystemDnsServerIpAddress(v EditCloudSystemDnsServerIpAddressParam)`

SetEditCloudSystemDnsServerIpAddress sets EditCloudSystemDnsServerIpAddress field to given value.

### HasEditCloudSystemDnsServerIpAddress

`func (o *EditCloudSystemDnsServerActionParam) HasEditCloudSystemDnsServerIpAddress() bool`

HasEditCloudSystemDnsServerIpAddress returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


