# CloudStorageGroupList

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**CloudStorageGroupInfos** | Pointer to [**[]CloudStorageGroupInfo**](CloudStorageGroupInfo.md) | The collection of cloud storage group Details | [optional] 

## Methods

### NewCloudStorageGroupList

`func NewCloudStorageGroupList() *CloudStorageGroupList`

NewCloudStorageGroupList instantiates a new CloudStorageGroupList object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewCloudStorageGroupListWithDefaults

`func NewCloudStorageGroupListWithDefaults() *CloudStorageGroupList`

NewCloudStorageGroupListWithDefaults instantiates a new CloudStorageGroupList object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetCloudStorageGroupInfos

`func (o *CloudStorageGroupList) GetCloudStorageGroupInfos() []CloudStorageGroupInfo`

GetCloudStorageGroupInfos returns the CloudStorageGroupInfos field if non-nil, zero value otherwise.

### GetCloudStorageGroupInfosOk

`func (o *CloudStorageGroupList) GetCloudStorageGroupInfosOk() (*[]CloudStorageGroupInfo, bool)`

GetCloudStorageGroupInfosOk returns a tuple with the CloudStorageGroupInfos field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetCloudStorageGroupInfos

`func (o *CloudStorageGroupList) SetCloudStorageGroupInfos(v []CloudStorageGroupInfo)`

SetCloudStorageGroupInfos sets CloudStorageGroupInfos field to given value.

### HasCloudStorageGroupInfos

`func (o *CloudStorageGroupList) HasCloudStorageGroupInfos() bool`

HasCloudStorageGroupInfos returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


