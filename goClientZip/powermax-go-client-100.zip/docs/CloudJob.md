# CloudJob

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**CloudJobId** | **string** | The ID of the Cloud Job | 
**CloudSnapshotName** | Pointer to **string** | The Name of the Cloud Snapshot | [optional] 
**CloudSnapshotId** | Pointer to **string** | The id of the Cloud Snapshot | [optional] 
**CloudProviderId** | Pointer to **string** | The Name of the Cloud Provider | [optional] 
**CloudProviderUuid** | Pointer to **string** | The uuid of the Cloud Provider | [optional] 
**StorageGroupId** | Pointer to **string** | The Name of the associated Storage Group | [optional] 
**StorageGroupUuid** | Pointer to **string** | The UUID of the associated Storage Group | [optional] 
**RecoveredStorageGroupId** | Pointer to **string** | The Name of the recovered Storage Group (only applied when the Cloud Job Type is Recover) | [optional] 
**RecoveredStorageGroupUuid** | Pointer to **string** | The UUID of the recovered Storage Group (only applied when the Cloud Job Type is Recover) | [optional] 
**Type** | Pointer to **string** | The Cloud Job Type [Protect, Delete, Recover] | [optional] 
**State** | Pointer to **string** | The Cloud Job State [Queued, Running, Completed, Paused, Unknown, Failed,                                 Resumed, Stopped, Cancelling, Cancelled] | [optional] 
**StartDateMilliseconds** | Pointer to **int64** | The Cloud Job Start Date in milliseconds from Epoch | [optional] 
**StartDate** | Pointer to **string** | The Cloud Job Start Date in UTC Date format | [optional] 
**CompletedDateMilliseconds** | Pointer to **int64** | The Cloud Job Completed Date in milliseconds from Epoch | [optional] 
**CompletedDate** | Pointer to **string** | The Cloud Job Start Date in UTC Date format | [optional] 
**NumOfRuns** | Pointer to **int32** | The Netmask Prefix Number of the Cloud System Route | [optional] 
**FailureReason** | Pointer to **string** | The Reason the job failed if applicable | [optional] 

## Methods

### NewCloudJob

`func NewCloudJob(cloudJobId string, ) *CloudJob`

NewCloudJob instantiates a new CloudJob object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewCloudJobWithDefaults

`func NewCloudJobWithDefaults() *CloudJob`

NewCloudJobWithDefaults instantiates a new CloudJob object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetCloudJobId

`func (o *CloudJob) GetCloudJobId() string`

GetCloudJobId returns the CloudJobId field if non-nil, zero value otherwise.

### GetCloudJobIdOk

`func (o *CloudJob) GetCloudJobIdOk() (*string, bool)`

GetCloudJobIdOk returns a tuple with the CloudJobId field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetCloudJobId

`func (o *CloudJob) SetCloudJobId(v string)`

SetCloudJobId sets CloudJobId field to given value.


### GetCloudSnapshotName

`func (o *CloudJob) GetCloudSnapshotName() string`

GetCloudSnapshotName returns the CloudSnapshotName field if non-nil, zero value otherwise.

### GetCloudSnapshotNameOk

`func (o *CloudJob) GetCloudSnapshotNameOk() (*string, bool)`

GetCloudSnapshotNameOk returns a tuple with the CloudSnapshotName field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetCloudSnapshotName

`func (o *CloudJob) SetCloudSnapshotName(v string)`

SetCloudSnapshotName sets CloudSnapshotName field to given value.

### HasCloudSnapshotName

`func (o *CloudJob) HasCloudSnapshotName() bool`

HasCloudSnapshotName returns a boolean if a field has been set.

### GetCloudSnapshotId

`func (o *CloudJob) GetCloudSnapshotId() string`

GetCloudSnapshotId returns the CloudSnapshotId field if non-nil, zero value otherwise.

### GetCloudSnapshotIdOk

`func (o *CloudJob) GetCloudSnapshotIdOk() (*string, bool)`

GetCloudSnapshotIdOk returns a tuple with the CloudSnapshotId field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetCloudSnapshotId

`func (o *CloudJob) SetCloudSnapshotId(v string)`

SetCloudSnapshotId sets CloudSnapshotId field to given value.

### HasCloudSnapshotId

`func (o *CloudJob) HasCloudSnapshotId() bool`

HasCloudSnapshotId returns a boolean if a field has been set.

### GetCloudProviderId

`func (o *CloudJob) GetCloudProviderId() string`

GetCloudProviderId returns the CloudProviderId field if non-nil, zero value otherwise.

### GetCloudProviderIdOk

`func (o *CloudJob) GetCloudProviderIdOk() (*string, bool)`

GetCloudProviderIdOk returns a tuple with the CloudProviderId field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetCloudProviderId

`func (o *CloudJob) SetCloudProviderId(v string)`

SetCloudProviderId sets CloudProviderId field to given value.

### HasCloudProviderId

`func (o *CloudJob) HasCloudProviderId() bool`

HasCloudProviderId returns a boolean if a field has been set.

### GetCloudProviderUuid

`func (o *CloudJob) GetCloudProviderUuid() string`

GetCloudProviderUuid returns the CloudProviderUuid field if non-nil, zero value otherwise.

### GetCloudProviderUuidOk

`func (o *CloudJob) GetCloudProviderUuidOk() (*string, bool)`

GetCloudProviderUuidOk returns a tuple with the CloudProviderUuid field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetCloudProviderUuid

`func (o *CloudJob) SetCloudProviderUuid(v string)`

SetCloudProviderUuid sets CloudProviderUuid field to given value.

### HasCloudProviderUuid

`func (o *CloudJob) HasCloudProviderUuid() bool`

HasCloudProviderUuid returns a boolean if a field has been set.

### GetStorageGroupId

`func (o *CloudJob) GetStorageGroupId() string`

GetStorageGroupId returns the StorageGroupId field if non-nil, zero value otherwise.

### GetStorageGroupIdOk

`func (o *CloudJob) GetStorageGroupIdOk() (*string, bool)`

GetStorageGroupIdOk returns a tuple with the StorageGroupId field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetStorageGroupId

`func (o *CloudJob) SetStorageGroupId(v string)`

SetStorageGroupId sets StorageGroupId field to given value.

### HasStorageGroupId

`func (o *CloudJob) HasStorageGroupId() bool`

HasStorageGroupId returns a boolean if a field has been set.

### GetStorageGroupUuid

`func (o *CloudJob) GetStorageGroupUuid() string`

GetStorageGroupUuid returns the StorageGroupUuid field if non-nil, zero value otherwise.

### GetStorageGroupUuidOk

`func (o *CloudJob) GetStorageGroupUuidOk() (*string, bool)`

GetStorageGroupUuidOk returns a tuple with the StorageGroupUuid field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetStorageGroupUuid

`func (o *CloudJob) SetStorageGroupUuid(v string)`

SetStorageGroupUuid sets StorageGroupUuid field to given value.

### HasStorageGroupUuid

`func (o *CloudJob) HasStorageGroupUuid() bool`

HasStorageGroupUuid returns a boolean if a field has been set.

### GetRecoveredStorageGroupId

`func (o *CloudJob) GetRecoveredStorageGroupId() string`

GetRecoveredStorageGroupId returns the RecoveredStorageGroupId field if non-nil, zero value otherwise.

### GetRecoveredStorageGroupIdOk

`func (o *CloudJob) GetRecoveredStorageGroupIdOk() (*string, bool)`

GetRecoveredStorageGroupIdOk returns a tuple with the RecoveredStorageGroupId field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetRecoveredStorageGroupId

`func (o *CloudJob) SetRecoveredStorageGroupId(v string)`

SetRecoveredStorageGroupId sets RecoveredStorageGroupId field to given value.

### HasRecoveredStorageGroupId

`func (o *CloudJob) HasRecoveredStorageGroupId() bool`

HasRecoveredStorageGroupId returns a boolean if a field has been set.

### GetRecoveredStorageGroupUuid

`func (o *CloudJob) GetRecoveredStorageGroupUuid() string`

GetRecoveredStorageGroupUuid returns the RecoveredStorageGroupUuid field if non-nil, zero value otherwise.

### GetRecoveredStorageGroupUuidOk

`func (o *CloudJob) GetRecoveredStorageGroupUuidOk() (*string, bool)`

GetRecoveredStorageGroupUuidOk returns a tuple with the RecoveredStorageGroupUuid field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetRecoveredStorageGroupUuid

`func (o *CloudJob) SetRecoveredStorageGroupUuid(v string)`

SetRecoveredStorageGroupUuid sets RecoveredStorageGroupUuid field to given value.

### HasRecoveredStorageGroupUuid

`func (o *CloudJob) HasRecoveredStorageGroupUuid() bool`

HasRecoveredStorageGroupUuid returns a boolean if a field has been set.

### GetType

`func (o *CloudJob) GetType() string`

GetType returns the Type field if non-nil, zero value otherwise.

### GetTypeOk

`func (o *CloudJob) GetTypeOk() (*string, bool)`

GetTypeOk returns a tuple with the Type field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetType

`func (o *CloudJob) SetType(v string)`

SetType sets Type field to given value.

### HasType

`func (o *CloudJob) HasType() bool`

HasType returns a boolean if a field has been set.

### GetState

`func (o *CloudJob) GetState() string`

GetState returns the State field if non-nil, zero value otherwise.

### GetStateOk

`func (o *CloudJob) GetStateOk() (*string, bool)`

GetStateOk returns a tuple with the State field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetState

`func (o *CloudJob) SetState(v string)`

SetState sets State field to given value.

### HasState

`func (o *CloudJob) HasState() bool`

HasState returns a boolean if a field has been set.

### GetStartDateMilliseconds

`func (o *CloudJob) GetStartDateMilliseconds() int64`

GetStartDateMilliseconds returns the StartDateMilliseconds field if non-nil, zero value otherwise.

### GetStartDateMillisecondsOk

`func (o *CloudJob) GetStartDateMillisecondsOk() (*int64, bool)`

GetStartDateMillisecondsOk returns a tuple with the StartDateMilliseconds field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetStartDateMilliseconds

`func (o *CloudJob) SetStartDateMilliseconds(v int64)`

SetStartDateMilliseconds sets StartDateMilliseconds field to given value.

### HasStartDateMilliseconds

`func (o *CloudJob) HasStartDateMilliseconds() bool`

HasStartDateMilliseconds returns a boolean if a field has been set.

### GetStartDate

`func (o *CloudJob) GetStartDate() string`

GetStartDate returns the StartDate field if non-nil, zero value otherwise.

### GetStartDateOk

`func (o *CloudJob) GetStartDateOk() (*string, bool)`

GetStartDateOk returns a tuple with the StartDate field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetStartDate

`func (o *CloudJob) SetStartDate(v string)`

SetStartDate sets StartDate field to given value.

### HasStartDate

`func (o *CloudJob) HasStartDate() bool`

HasStartDate returns a boolean if a field has been set.

### GetCompletedDateMilliseconds

`func (o *CloudJob) GetCompletedDateMilliseconds() int64`

GetCompletedDateMilliseconds returns the CompletedDateMilliseconds field if non-nil, zero value otherwise.

### GetCompletedDateMillisecondsOk

`func (o *CloudJob) GetCompletedDateMillisecondsOk() (*int64, bool)`

GetCompletedDateMillisecondsOk returns a tuple with the CompletedDateMilliseconds field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetCompletedDateMilliseconds

`func (o *CloudJob) SetCompletedDateMilliseconds(v int64)`

SetCompletedDateMilliseconds sets CompletedDateMilliseconds field to given value.

### HasCompletedDateMilliseconds

`func (o *CloudJob) HasCompletedDateMilliseconds() bool`

HasCompletedDateMilliseconds returns a boolean if a field has been set.

### GetCompletedDate

`func (o *CloudJob) GetCompletedDate() string`

GetCompletedDate returns the CompletedDate field if non-nil, zero value otherwise.

### GetCompletedDateOk

`func (o *CloudJob) GetCompletedDateOk() (*string, bool)`

GetCompletedDateOk returns a tuple with the CompletedDate field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetCompletedDate

`func (o *CloudJob) SetCompletedDate(v string)`

SetCompletedDate sets CompletedDate field to given value.

### HasCompletedDate

`func (o *CloudJob) HasCompletedDate() bool`

HasCompletedDate returns a boolean if a field has been set.

### GetNumOfRuns

`func (o *CloudJob) GetNumOfRuns() int32`

GetNumOfRuns returns the NumOfRuns field if non-nil, zero value otherwise.

### GetNumOfRunsOk

`func (o *CloudJob) GetNumOfRunsOk() (*int32, bool)`

GetNumOfRunsOk returns a tuple with the NumOfRuns field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetNumOfRuns

`func (o *CloudJob) SetNumOfRuns(v int32)`

SetNumOfRuns sets NumOfRuns field to given value.

### HasNumOfRuns

`func (o *CloudJob) HasNumOfRuns() bool`

HasNumOfRuns returns a boolean if a field has been set.

### GetFailureReason

`func (o *CloudJob) GetFailureReason() string`

GetFailureReason returns the FailureReason field if non-nil, zero value otherwise.

### GetFailureReasonOk

`func (o *CloudJob) GetFailureReasonOk() (*string, bool)`

GetFailureReasonOk returns a tuple with the FailureReason field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetFailureReason

`func (o *CloudJob) SetFailureReason(v string)`

SetFailureReason sets FailureReason field to given value.

### HasFailureReason

`func (o *CloudJob) HasFailureReason() bool`

HasFailureReason returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


