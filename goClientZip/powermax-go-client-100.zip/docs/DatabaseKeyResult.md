# DatabaseKeyResult

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**DatabaseInfo** | Pointer to [**[]DatabaseInfo**](DatabaseInfo.md) | databaseInfo | [optional] 

## Methods

### NewDatabaseKeyResult

`func NewDatabaseKeyResult() *DatabaseKeyResult`

NewDatabaseKeyResult instantiates a new DatabaseKeyResult object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewDatabaseKeyResultWithDefaults

`func NewDatabaseKeyResultWithDefaults() *DatabaseKeyResult`

NewDatabaseKeyResultWithDefaults instantiates a new DatabaseKeyResult object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetDatabaseInfo

`func (o *DatabaseKeyResult) GetDatabaseInfo() []DatabaseInfo`

GetDatabaseInfo returns the DatabaseInfo field if non-nil, zero value otherwise.

### GetDatabaseInfoOk

`func (o *DatabaseKeyResult) GetDatabaseInfoOk() (*[]DatabaseInfo, bool)`

GetDatabaseInfoOk returns a tuple with the DatabaseInfo field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetDatabaseInfo

`func (o *DatabaseKeyResult) SetDatabaseInfo(v []DatabaseInfo)`

SetDatabaseInfo sets DatabaseInfo field to given value.

### HasDatabaseInfo

`func (o *DatabaseKeyResult) HasDatabaseInfo() bool`

HasDatabaseInfo returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


