# IoDetails

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ActualValues** | Pointer to **[]float64** | Rate weighted total IOPS or MBPS in buckets for a given storage group | [optional] 
**PlannedValues** | Pointer to **[]float64** | Total planned IOPS or MBPS in buckets for a given storage group | [optional] 
**EffectiveHostIoLimitValues** | Pointer to **[]float64** | Effective Host I/O limits (IOPS or MBPS) in buckets for a given storage group if limits are applied.                         For standalone groups, the value will be static across all the 42 buckets.                         For a child storage group with limits but no limits on the parent, the value will be static across all the 42 buckets.                         For a child storage group with no direct limits but limits set on the parent, the limit of any given child would be the parent limit minus whatever the siblings are using.                         For a child storage group with direct limits and limits on the parent, the limit of any given child would be the more limiting of the parent limit minus whatever the siblings are using, or the child storage groups own limit. | [optional] 
**HostIoLimit** | Pointer to **int64** | Host I/O limits (IOPS or MBPS) set for a given storage group. | [optional] 
**RecommendedHostIoLimit** | Pointer to **float64** | Host I/O limits (IOPS or MBPS) recommendation based on the current I/O running for a given storage group. | [optional] 

## Methods

### NewIoDetails

`func NewIoDetails() *IoDetails`

NewIoDetails instantiates a new IoDetails object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewIoDetailsWithDefaults

`func NewIoDetailsWithDefaults() *IoDetails`

NewIoDetailsWithDefaults instantiates a new IoDetails object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetActualValues

`func (o *IoDetails) GetActualValues() []float64`

GetActualValues returns the ActualValues field if non-nil, zero value otherwise.

### GetActualValuesOk

`func (o *IoDetails) GetActualValuesOk() (*[]float64, bool)`

GetActualValuesOk returns a tuple with the ActualValues field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetActualValues

`func (o *IoDetails) SetActualValues(v []float64)`

SetActualValues sets ActualValues field to given value.

### HasActualValues

`func (o *IoDetails) HasActualValues() bool`

HasActualValues returns a boolean if a field has been set.

### GetPlannedValues

`func (o *IoDetails) GetPlannedValues() []float64`

GetPlannedValues returns the PlannedValues field if non-nil, zero value otherwise.

### GetPlannedValuesOk

`func (o *IoDetails) GetPlannedValuesOk() (*[]float64, bool)`

GetPlannedValuesOk returns a tuple with the PlannedValues field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetPlannedValues

`func (o *IoDetails) SetPlannedValues(v []float64)`

SetPlannedValues sets PlannedValues field to given value.

### HasPlannedValues

`func (o *IoDetails) HasPlannedValues() bool`

HasPlannedValues returns a boolean if a field has been set.

### GetEffectiveHostIoLimitValues

`func (o *IoDetails) GetEffectiveHostIoLimitValues() []float64`

GetEffectiveHostIoLimitValues returns the EffectiveHostIoLimitValues field if non-nil, zero value otherwise.

### GetEffectiveHostIoLimitValuesOk

`func (o *IoDetails) GetEffectiveHostIoLimitValuesOk() (*[]float64, bool)`

GetEffectiveHostIoLimitValuesOk returns a tuple with the EffectiveHostIoLimitValues field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetEffectiveHostIoLimitValues

`func (o *IoDetails) SetEffectiveHostIoLimitValues(v []float64)`

SetEffectiveHostIoLimitValues sets EffectiveHostIoLimitValues field to given value.

### HasEffectiveHostIoLimitValues

`func (o *IoDetails) HasEffectiveHostIoLimitValues() bool`

HasEffectiveHostIoLimitValues returns a boolean if a field has been set.

### GetHostIoLimit

`func (o *IoDetails) GetHostIoLimit() int64`

GetHostIoLimit returns the HostIoLimit field if non-nil, zero value otherwise.

### GetHostIoLimitOk

`func (o *IoDetails) GetHostIoLimitOk() (*int64, bool)`

GetHostIoLimitOk returns a tuple with the HostIoLimit field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetHostIoLimit

`func (o *IoDetails) SetHostIoLimit(v int64)`

SetHostIoLimit sets HostIoLimit field to given value.

### HasHostIoLimit

`func (o *IoDetails) HasHostIoLimit() bool`

HasHostIoLimit returns a boolean if a field has been set.

### GetRecommendedHostIoLimit

`func (o *IoDetails) GetRecommendedHostIoLimit() float64`

GetRecommendedHostIoLimit returns the RecommendedHostIoLimit field if non-nil, zero value otherwise.

### GetRecommendedHostIoLimitOk

`func (o *IoDetails) GetRecommendedHostIoLimitOk() (*float64, bool)`

GetRecommendedHostIoLimitOk returns a tuple with the RecommendedHostIoLimit field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetRecommendedHostIoLimit

`func (o *IoDetails) SetRecommendedHostIoLimit(v float64)`

SetRecommendedHostIoLimit sets RecommendedHostIoLimit field to given value.

### HasRecommendedHostIoLimit

`func (o *IoDetails) HasRecommendedHostIoLimit() bool`

HasRecommendedHostIoLimit returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


