# HostIOLimit

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**HostIoLimitMbSec** | Pointer to **string** | The MBs per Second Host IO limit for the storage group | [optional] 
**HostIoLimitIoSec** | Pointer to **string** | The IOs per Second Host IO limit for the storage group | [optional] 
**DynamicDistribution** | Pointer to **string** | The dynamic distribution type which can be \&quot;never\&quot;,\&quot;always\&quot; or \&quot;on_failure\&quot; | [optional] 

## Methods

### NewHostIOLimit

`func NewHostIOLimit() *HostIOLimit`

NewHostIOLimit instantiates a new HostIOLimit object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewHostIOLimitWithDefaults

`func NewHostIOLimitWithDefaults() *HostIOLimit`

NewHostIOLimitWithDefaults instantiates a new HostIOLimit object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetHostIoLimitMbSec

`func (o *HostIOLimit) GetHostIoLimitMbSec() string`

GetHostIoLimitMbSec returns the HostIoLimitMbSec field if non-nil, zero value otherwise.

### GetHostIoLimitMbSecOk

`func (o *HostIOLimit) GetHostIoLimitMbSecOk() (*string, bool)`

GetHostIoLimitMbSecOk returns a tuple with the HostIoLimitMbSec field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetHostIoLimitMbSec

`func (o *HostIOLimit) SetHostIoLimitMbSec(v string)`

SetHostIoLimitMbSec sets HostIoLimitMbSec field to given value.

### HasHostIoLimitMbSec

`func (o *HostIOLimit) HasHostIoLimitMbSec() bool`

HasHostIoLimitMbSec returns a boolean if a field has been set.

### GetHostIoLimitIoSec

`func (o *HostIOLimit) GetHostIoLimitIoSec() string`

GetHostIoLimitIoSec returns the HostIoLimitIoSec field if non-nil, zero value otherwise.

### GetHostIoLimitIoSecOk

`func (o *HostIOLimit) GetHostIoLimitIoSecOk() (*string, bool)`

GetHostIoLimitIoSecOk returns a tuple with the HostIoLimitIoSec field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetHostIoLimitIoSec

`func (o *HostIOLimit) SetHostIoLimitIoSec(v string)`

SetHostIoLimitIoSec sets HostIoLimitIoSec field to given value.

### HasHostIoLimitIoSec

`func (o *HostIOLimit) HasHostIoLimitIoSec() bool`

HasHostIoLimitIoSec returns a boolean if a field has been set.

### GetDynamicDistribution

`func (o *HostIOLimit) GetDynamicDistribution() string`

GetDynamicDistribution returns the DynamicDistribution field if non-nil, zero value otherwise.

### GetDynamicDistributionOk

`func (o *HostIOLimit) GetDynamicDistributionOk() (*string, bool)`

GetDynamicDistributionOk returns a tuple with the DynamicDistribution field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetDynamicDistribution

`func (o *HostIOLimit) SetDynamicDistribution(v string)`

SetDynamicDistribution sets DynamicDistribution field to given value.

### HasDynamicDistribution

`func (o *HostIOLimit) HasDynamicDistribution() bool`

HasDynamicDistribution returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


