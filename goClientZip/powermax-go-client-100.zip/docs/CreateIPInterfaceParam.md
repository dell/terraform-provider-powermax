# CreateIPInterfaceParam

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ExecutionOption** | Pointer to **string** |  | [optional] [default to "SYNCHRONOUS"]
**IpAddress** | **string** | ip_address | 
**DefaultGateway** | Pointer to **string** | default_gateway | [optional] 
**NetworkId** | Pointer to **int64** | network_id | [optional] 
**VlanId** | Pointer to **int64** | vlan_id | [optional] 
**IpPrefixLength** | **int32** | ip_prefix_length | 
**Mtu** | **int64** | mtu | 
**EndpointDirector** | Pointer to **string** | endpoint_director | [optional] 
**IscsiTargetDirector** | Pointer to **string** | iscsi_target_director | [optional] 
**EndpointPort** | Pointer to **int32** | endpoint_port | [optional] 
**IscsiTargetPort** | Pointer to **int32** | iscsi_target_port | [optional] 
**CdcDiscoverType** | Pointer to **string** | cdc_Discover_Type   Enumeration values: * **auto_discover_cdc_ip** * **advertise_ddc_ip** * **auto_discover_disabled** * **manual_cdc_configuration**  | [optional] 
**CdcIpAddress** | Pointer to **string** | cdc_ip_address | [optional] 
**CdcPortNumber** | Pointer to **int32** | cdc_port_number | [optional] 

## Methods

### NewCreateIPInterfaceParam

`func NewCreateIPInterfaceParam(ipAddress string, ipPrefixLength int32, mtu int64, ) *CreateIPInterfaceParam`

NewCreateIPInterfaceParam instantiates a new CreateIPInterfaceParam object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewCreateIPInterfaceParamWithDefaults

`func NewCreateIPInterfaceParamWithDefaults() *CreateIPInterfaceParam`

NewCreateIPInterfaceParamWithDefaults instantiates a new CreateIPInterfaceParam object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetExecutionOption

`func (o *CreateIPInterfaceParam) GetExecutionOption() string`

GetExecutionOption returns the ExecutionOption field if non-nil, zero value otherwise.

### GetExecutionOptionOk

`func (o *CreateIPInterfaceParam) GetExecutionOptionOk() (*string, bool)`

GetExecutionOptionOk returns a tuple with the ExecutionOption field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetExecutionOption

`func (o *CreateIPInterfaceParam) SetExecutionOption(v string)`

SetExecutionOption sets ExecutionOption field to given value.

### HasExecutionOption

`func (o *CreateIPInterfaceParam) HasExecutionOption() bool`

HasExecutionOption returns a boolean if a field has been set.

### GetIpAddress

`func (o *CreateIPInterfaceParam) GetIpAddress() string`

GetIpAddress returns the IpAddress field if non-nil, zero value otherwise.

### GetIpAddressOk

`func (o *CreateIPInterfaceParam) GetIpAddressOk() (*string, bool)`

GetIpAddressOk returns a tuple with the IpAddress field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetIpAddress

`func (o *CreateIPInterfaceParam) SetIpAddress(v string)`

SetIpAddress sets IpAddress field to given value.


### GetDefaultGateway

`func (o *CreateIPInterfaceParam) GetDefaultGateway() string`

GetDefaultGateway returns the DefaultGateway field if non-nil, zero value otherwise.

### GetDefaultGatewayOk

`func (o *CreateIPInterfaceParam) GetDefaultGatewayOk() (*string, bool)`

GetDefaultGatewayOk returns a tuple with the DefaultGateway field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetDefaultGateway

`func (o *CreateIPInterfaceParam) SetDefaultGateway(v string)`

SetDefaultGateway sets DefaultGateway field to given value.

### HasDefaultGateway

`func (o *CreateIPInterfaceParam) HasDefaultGateway() bool`

HasDefaultGateway returns a boolean if a field has been set.

### GetNetworkId

`func (o *CreateIPInterfaceParam) GetNetworkId() int64`

GetNetworkId returns the NetworkId field if non-nil, zero value otherwise.

### GetNetworkIdOk

`func (o *CreateIPInterfaceParam) GetNetworkIdOk() (*int64, bool)`

GetNetworkIdOk returns a tuple with the NetworkId field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetNetworkId

`func (o *CreateIPInterfaceParam) SetNetworkId(v int64)`

SetNetworkId sets NetworkId field to given value.

### HasNetworkId

`func (o *CreateIPInterfaceParam) HasNetworkId() bool`

HasNetworkId returns a boolean if a field has been set.

### GetVlanId

`func (o *CreateIPInterfaceParam) GetVlanId() int64`

GetVlanId returns the VlanId field if non-nil, zero value otherwise.

### GetVlanIdOk

`func (o *CreateIPInterfaceParam) GetVlanIdOk() (*int64, bool)`

GetVlanIdOk returns a tuple with the VlanId field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetVlanId

`func (o *CreateIPInterfaceParam) SetVlanId(v int64)`

SetVlanId sets VlanId field to given value.

### HasVlanId

`func (o *CreateIPInterfaceParam) HasVlanId() bool`

HasVlanId returns a boolean if a field has been set.

### GetIpPrefixLength

`func (o *CreateIPInterfaceParam) GetIpPrefixLength() int32`

GetIpPrefixLength returns the IpPrefixLength field if non-nil, zero value otherwise.

### GetIpPrefixLengthOk

`func (o *CreateIPInterfaceParam) GetIpPrefixLengthOk() (*int32, bool)`

GetIpPrefixLengthOk returns a tuple with the IpPrefixLength field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetIpPrefixLength

`func (o *CreateIPInterfaceParam) SetIpPrefixLength(v int32)`

SetIpPrefixLength sets IpPrefixLength field to given value.


### GetMtu

`func (o *CreateIPInterfaceParam) GetMtu() int64`

GetMtu returns the Mtu field if non-nil, zero value otherwise.

### GetMtuOk

`func (o *CreateIPInterfaceParam) GetMtuOk() (*int64, bool)`

GetMtuOk returns a tuple with the Mtu field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetMtu

`func (o *CreateIPInterfaceParam) SetMtu(v int64)`

SetMtu sets Mtu field to given value.


### GetEndpointDirector

`func (o *CreateIPInterfaceParam) GetEndpointDirector() string`

GetEndpointDirector returns the EndpointDirector field if non-nil, zero value otherwise.

### GetEndpointDirectorOk

`func (o *CreateIPInterfaceParam) GetEndpointDirectorOk() (*string, bool)`

GetEndpointDirectorOk returns a tuple with the EndpointDirector field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetEndpointDirector

`func (o *CreateIPInterfaceParam) SetEndpointDirector(v string)`

SetEndpointDirector sets EndpointDirector field to given value.

### HasEndpointDirector

`func (o *CreateIPInterfaceParam) HasEndpointDirector() bool`

HasEndpointDirector returns a boolean if a field has been set.

### GetIscsiTargetDirector

`func (o *CreateIPInterfaceParam) GetIscsiTargetDirector() string`

GetIscsiTargetDirector returns the IscsiTargetDirector field if non-nil, zero value otherwise.

### GetIscsiTargetDirectorOk

`func (o *CreateIPInterfaceParam) GetIscsiTargetDirectorOk() (*string, bool)`

GetIscsiTargetDirectorOk returns a tuple with the IscsiTargetDirector field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetIscsiTargetDirector

`func (o *CreateIPInterfaceParam) SetIscsiTargetDirector(v string)`

SetIscsiTargetDirector sets IscsiTargetDirector field to given value.

### HasIscsiTargetDirector

`func (o *CreateIPInterfaceParam) HasIscsiTargetDirector() bool`

HasIscsiTargetDirector returns a boolean if a field has been set.

### GetEndpointPort

`func (o *CreateIPInterfaceParam) GetEndpointPort() int32`

GetEndpointPort returns the EndpointPort field if non-nil, zero value otherwise.

### GetEndpointPortOk

`func (o *CreateIPInterfaceParam) GetEndpointPortOk() (*int32, bool)`

GetEndpointPortOk returns a tuple with the EndpointPort field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetEndpointPort

`func (o *CreateIPInterfaceParam) SetEndpointPort(v int32)`

SetEndpointPort sets EndpointPort field to given value.

### HasEndpointPort

`func (o *CreateIPInterfaceParam) HasEndpointPort() bool`

HasEndpointPort returns a boolean if a field has been set.

### GetIscsiTargetPort

`func (o *CreateIPInterfaceParam) GetIscsiTargetPort() int32`

GetIscsiTargetPort returns the IscsiTargetPort field if non-nil, zero value otherwise.

### GetIscsiTargetPortOk

`func (o *CreateIPInterfaceParam) GetIscsiTargetPortOk() (*int32, bool)`

GetIscsiTargetPortOk returns a tuple with the IscsiTargetPort field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetIscsiTargetPort

`func (o *CreateIPInterfaceParam) SetIscsiTargetPort(v int32)`

SetIscsiTargetPort sets IscsiTargetPort field to given value.

### HasIscsiTargetPort

`func (o *CreateIPInterfaceParam) HasIscsiTargetPort() bool`

HasIscsiTargetPort returns a boolean if a field has been set.

### GetCdcDiscoverType

`func (o *CreateIPInterfaceParam) GetCdcDiscoverType() string`

GetCdcDiscoverType returns the CdcDiscoverType field if non-nil, zero value otherwise.

### GetCdcDiscoverTypeOk

`func (o *CreateIPInterfaceParam) GetCdcDiscoverTypeOk() (*string, bool)`

GetCdcDiscoverTypeOk returns a tuple with the CdcDiscoverType field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetCdcDiscoverType

`func (o *CreateIPInterfaceParam) SetCdcDiscoverType(v string)`

SetCdcDiscoverType sets CdcDiscoverType field to given value.

### HasCdcDiscoverType

`func (o *CreateIPInterfaceParam) HasCdcDiscoverType() bool`

HasCdcDiscoverType returns a boolean if a field has been set.

### GetCdcIpAddress

`func (o *CreateIPInterfaceParam) GetCdcIpAddress() string`

GetCdcIpAddress returns the CdcIpAddress field if non-nil, zero value otherwise.

### GetCdcIpAddressOk

`func (o *CreateIPInterfaceParam) GetCdcIpAddressOk() (*string, bool)`

GetCdcIpAddressOk returns a tuple with the CdcIpAddress field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetCdcIpAddress

`func (o *CreateIPInterfaceParam) SetCdcIpAddress(v string)`

SetCdcIpAddress sets CdcIpAddress field to given value.

### HasCdcIpAddress

`func (o *CreateIPInterfaceParam) HasCdcIpAddress() bool`

HasCdcIpAddress returns a boolean if a field has been set.

### GetCdcPortNumber

`func (o *CreateIPInterfaceParam) GetCdcPortNumber() int32`

GetCdcPortNumber returns the CdcPortNumber field if non-nil, zero value otherwise.

### GetCdcPortNumberOk

`func (o *CreateIPInterfaceParam) GetCdcPortNumberOk() (*int32, bool)`

GetCdcPortNumberOk returns a tuple with the CdcPortNumber field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetCdcPortNumber

`func (o *CreateIPInterfaceParam) SetCdcPortNumber(v int32)`

SetCdcPortNumber sets CdcPortNumber field to given value.

### HasCdcPortNumber

`func (o *CreateIPInterfaceParam) HasCdcPortNumber() bool`

HasCdcPortNumber returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


