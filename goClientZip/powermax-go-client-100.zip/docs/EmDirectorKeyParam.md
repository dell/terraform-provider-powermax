# EmDirectorKeyParam

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**SystemId** | **string** | &lt;p&gt;The array ID.&lt;/p&gt; | 

## Methods

### NewEmDirectorKeyParam

`func NewEmDirectorKeyParam(systemId string, ) *EmDirectorKeyParam`

NewEmDirectorKeyParam instantiates a new EmDirectorKeyParam object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewEmDirectorKeyParamWithDefaults

`func NewEmDirectorKeyParamWithDefaults() *EmDirectorKeyParam`

NewEmDirectorKeyParamWithDefaults instantiates a new EmDirectorKeyParam object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetSystemId

`func (o *EmDirectorKeyParam) GetSystemId() string`

GetSystemId returns the SystemId field if non-nil, zero value otherwise.

### GetSystemIdOk

`func (o *EmDirectorKeyParam) GetSystemIdOk() (*string, bool)`

GetSystemIdOk returns a tuple with the SystemId field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetSystemId

`func (o *EmDirectorKeyParam) SetSystemId(v string)`

SetSystemId sets SystemId field to given value.



[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


