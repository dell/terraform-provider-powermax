# EditVasaProviderActionParam

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**EditVasaProviderIpaddressParam** | Pointer to [**EditVasaProviderIpaddressParam**](EditVasaProviderIpaddressParam.md) |  | [optional] 

## Methods

### NewEditVasaProviderActionParam

`func NewEditVasaProviderActionParam() *EditVasaProviderActionParam`

NewEditVasaProviderActionParam instantiates a new EditVasaProviderActionParam object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewEditVasaProviderActionParamWithDefaults

`func NewEditVasaProviderActionParamWithDefaults() *EditVasaProviderActionParam`

NewEditVasaProviderActionParamWithDefaults instantiates a new EditVasaProviderActionParam object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetEditVasaProviderIpaddressParam

`func (o *EditVasaProviderActionParam) GetEditVasaProviderIpaddressParam() EditVasaProviderIpaddressParam`

GetEditVasaProviderIpaddressParam returns the EditVasaProviderIpaddressParam field if non-nil, zero value otherwise.

### GetEditVasaProviderIpaddressParamOk

`func (o *EditVasaProviderActionParam) GetEditVasaProviderIpaddressParamOk() (*EditVasaProviderIpaddressParam, bool)`

GetEditVasaProviderIpaddressParamOk returns a tuple with the EditVasaProviderIpaddressParam field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetEditVasaProviderIpaddressParam

`func (o *EditVasaProviderActionParam) SetEditVasaProviderIpaddressParam(v EditVasaProviderIpaddressParam)`

SetEditVasaProviderIpaddressParam sets EditVasaProviderIpaddressParam field to given value.

### HasEditVasaProviderIpaddressParam

`func (o *EditVasaProviderActionParam) HasEditVasaProviderIpaddressParam() bool`

HasEditVasaProviderIpaddressParam returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


