# InitiatorSetFlagsParam

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**InitiatorFlags** | [**InitiatorFlags**](InitiatorFlags.md) |  | 

## Methods

### NewInitiatorSetFlagsParam

`func NewInitiatorSetFlagsParam(initiatorFlags InitiatorFlags, ) *InitiatorSetFlagsParam`

NewInitiatorSetFlagsParam instantiates a new InitiatorSetFlagsParam object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewInitiatorSetFlagsParamWithDefaults

`func NewInitiatorSetFlagsParamWithDefaults() *InitiatorSetFlagsParam`

NewInitiatorSetFlagsParamWithDefaults instantiates a new InitiatorSetFlagsParam object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetInitiatorFlags

`func (o *InitiatorSetFlagsParam) GetInitiatorFlags() InitiatorFlags`

GetInitiatorFlags returns the InitiatorFlags field if non-nil, zero value otherwise.

### GetInitiatorFlagsOk

`func (o *InitiatorSetFlagsParam) GetInitiatorFlagsOk() (*InitiatorFlags, bool)`

GetInitiatorFlagsOk returns a tuple with the InitiatorFlags field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetInitiatorFlags

`func (o *InitiatorSetFlagsParam) SetInitiatorFlags(v InitiatorFlags)`

SetInitiatorFlags sets InitiatorFlags field to given value.



[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


