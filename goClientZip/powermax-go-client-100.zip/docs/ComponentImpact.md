# ComponentImpact

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Current** | Pointer to **float64** | Performance impact based on current performance statistics | [optional] 
**Reserved** | Pointer to **float64** |                          Performance impact based on current performance statistics plus reserved performance                         capacity (for example, jobs in job list)                      | [optional] 
**Updated** | Pointer to **float64** | Performance impact based on current performance statistics plus new request (plus reserved performance, if applicable) | [optional] 
**Error** | Pointer to **string** | Error or warning, if unable to calculate performance impact | [optional] 

## Methods

### NewComponentImpact

`func NewComponentImpact() *ComponentImpact`

NewComponentImpact instantiates a new ComponentImpact object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewComponentImpactWithDefaults

`func NewComponentImpactWithDefaults() *ComponentImpact`

NewComponentImpactWithDefaults instantiates a new ComponentImpact object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetCurrent

`func (o *ComponentImpact) GetCurrent() float64`

GetCurrent returns the Current field if non-nil, zero value otherwise.

### GetCurrentOk

`func (o *ComponentImpact) GetCurrentOk() (*float64, bool)`

GetCurrentOk returns a tuple with the Current field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetCurrent

`func (o *ComponentImpact) SetCurrent(v float64)`

SetCurrent sets Current field to given value.

### HasCurrent

`func (o *ComponentImpact) HasCurrent() bool`

HasCurrent returns a boolean if a field has been set.

### GetReserved

`func (o *ComponentImpact) GetReserved() float64`

GetReserved returns the Reserved field if non-nil, zero value otherwise.

### GetReservedOk

`func (o *ComponentImpact) GetReservedOk() (*float64, bool)`

GetReservedOk returns a tuple with the Reserved field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetReserved

`func (o *ComponentImpact) SetReserved(v float64)`

SetReserved sets Reserved field to given value.

### HasReserved

`func (o *ComponentImpact) HasReserved() bool`

HasReserved returns a boolean if a field has been set.

### GetUpdated

`func (o *ComponentImpact) GetUpdated() float64`

GetUpdated returns the Updated field if non-nil, zero value otherwise.

### GetUpdatedOk

`func (o *ComponentImpact) GetUpdatedOk() (*float64, bool)`

GetUpdatedOk returns a tuple with the Updated field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetUpdated

`func (o *ComponentImpact) SetUpdated(v float64)`

SetUpdated sets Updated field to given value.

### HasUpdated

`func (o *ComponentImpact) HasUpdated() bool`

HasUpdated returns a boolean if a field has been set.

### GetError

`func (o *ComponentImpact) GetError() string`

GetError returns the Error field if non-nil, zero value otherwise.

### GetErrorOk

`func (o *ComponentImpact) GetErrorOk() (*string, bool)`

GetErrorOk returns a tuple with the Error field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetError

`func (o *ComponentImpact) SetError(v string)`

SetError sets Error field to given value.

### HasError

`func (o *ComponentImpact) HasError() bool`

HasError returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


