# CloudSnapshotInfo

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**CloudSnapshotId** | Pointer to **string** | The Id of the cloud snapshot | [optional] 
**SnapshotName** | Pointer to **string** | The Name of the snapshot | [optional] 
**CreationDate** | Pointer to **string** | The date Time the snapshot was created | [optional] 
**CreationDateTimestamp** | Pointer to **int64** | The Timestamp the snapshot was created | [optional] 

## Methods

### NewCloudSnapshotInfo

`func NewCloudSnapshotInfo() *CloudSnapshotInfo`

NewCloudSnapshotInfo instantiates a new CloudSnapshotInfo object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewCloudSnapshotInfoWithDefaults

`func NewCloudSnapshotInfoWithDefaults() *CloudSnapshotInfo`

NewCloudSnapshotInfoWithDefaults instantiates a new CloudSnapshotInfo object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetCloudSnapshotId

`func (o *CloudSnapshotInfo) GetCloudSnapshotId() string`

GetCloudSnapshotId returns the CloudSnapshotId field if non-nil, zero value otherwise.

### GetCloudSnapshotIdOk

`func (o *CloudSnapshotInfo) GetCloudSnapshotIdOk() (*string, bool)`

GetCloudSnapshotIdOk returns a tuple with the CloudSnapshotId field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetCloudSnapshotId

`func (o *CloudSnapshotInfo) SetCloudSnapshotId(v string)`

SetCloudSnapshotId sets CloudSnapshotId field to given value.

### HasCloudSnapshotId

`func (o *CloudSnapshotInfo) HasCloudSnapshotId() bool`

HasCloudSnapshotId returns a boolean if a field has been set.

### GetSnapshotName

`func (o *CloudSnapshotInfo) GetSnapshotName() string`

GetSnapshotName returns the SnapshotName field if non-nil, zero value otherwise.

### GetSnapshotNameOk

`func (o *CloudSnapshotInfo) GetSnapshotNameOk() (*string, bool)`

GetSnapshotNameOk returns a tuple with the SnapshotName field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetSnapshotName

`func (o *CloudSnapshotInfo) SetSnapshotName(v string)`

SetSnapshotName sets SnapshotName field to given value.

### HasSnapshotName

`func (o *CloudSnapshotInfo) HasSnapshotName() bool`

HasSnapshotName returns a boolean if a field has been set.

### GetCreationDate

`func (o *CloudSnapshotInfo) GetCreationDate() string`

GetCreationDate returns the CreationDate field if non-nil, zero value otherwise.

### GetCreationDateOk

`func (o *CloudSnapshotInfo) GetCreationDateOk() (*string, bool)`

GetCreationDateOk returns a tuple with the CreationDate field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetCreationDate

`func (o *CloudSnapshotInfo) SetCreationDate(v string)`

SetCreationDate sets CreationDate field to given value.

### HasCreationDate

`func (o *CloudSnapshotInfo) HasCreationDate() bool`

HasCreationDate returns a boolean if a field has been set.

### GetCreationDateTimestamp

`func (o *CloudSnapshotInfo) GetCreationDateTimestamp() int64`

GetCreationDateTimestamp returns the CreationDateTimestamp field if non-nil, zero value otherwise.

### GetCreationDateTimestampOk

`func (o *CloudSnapshotInfo) GetCreationDateTimestampOk() (*int64, bool)`

GetCreationDateTimestampOk returns a tuple with the CreationDateTimestamp field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetCreationDateTimestamp

`func (o *CloudSnapshotInfo) SetCreationDateTimestamp(v int64)`

SetCreationDateTimestamp sets CreationDateTimestamp field to given value.

### HasCreationDateTimestamp

`func (o *CloudSnapshotInfo) HasCreationDateTimestamp() bool`

HasCreationDateTimestamp returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


