# EventsPoolModifyArguments

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Name** | Pointer to **string** |  Name of the eventspool | [optional] 
**EventsPublisherServers** | Pointer to **[]string** |                          Network identifier of the File Event Service servers. (fully qualified domain name or ip addresses).                         You can set at max 5 File Event Service Servers per Events Pool.                      | [optional] 
**PreEvents** | Pointer to [**PreEventsList**](PreEventsList.md) |  | [optional] 
**PostEvents** | Pointer to [**PostEventsList**](PostEventsList.md) |  | [optional] 
**PostErrorEvents** | Pointer to [**PostErrorEventsList**](PostErrorEventsList.md) |  | [optional] 
**Override** | Pointer to **bool** |                          In the context of a replication, tell if the eventsPublisherServers list has been overridden when this object is in destination mode                      | [optional] 

## Methods

### NewEventsPoolModifyArguments

`func NewEventsPoolModifyArguments() *EventsPoolModifyArguments`

NewEventsPoolModifyArguments instantiates a new EventsPoolModifyArguments object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewEventsPoolModifyArgumentsWithDefaults

`func NewEventsPoolModifyArgumentsWithDefaults() *EventsPoolModifyArguments`

NewEventsPoolModifyArgumentsWithDefaults instantiates a new EventsPoolModifyArguments object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetName

`func (o *EventsPoolModifyArguments) GetName() string`

GetName returns the Name field if non-nil, zero value otherwise.

### GetNameOk

`func (o *EventsPoolModifyArguments) GetNameOk() (*string, bool)`

GetNameOk returns a tuple with the Name field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetName

`func (o *EventsPoolModifyArguments) SetName(v string)`

SetName sets Name field to given value.

### HasName

`func (o *EventsPoolModifyArguments) HasName() bool`

HasName returns a boolean if a field has been set.

### GetEventsPublisherServers

`func (o *EventsPoolModifyArguments) GetEventsPublisherServers() []string`

GetEventsPublisherServers returns the EventsPublisherServers field if non-nil, zero value otherwise.

### GetEventsPublisherServersOk

`func (o *EventsPoolModifyArguments) GetEventsPublisherServersOk() (*[]string, bool)`

GetEventsPublisherServersOk returns a tuple with the EventsPublisherServers field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetEventsPublisherServers

`func (o *EventsPoolModifyArguments) SetEventsPublisherServers(v []string)`

SetEventsPublisherServers sets EventsPublisherServers field to given value.

### HasEventsPublisherServers

`func (o *EventsPoolModifyArguments) HasEventsPublisherServers() bool`

HasEventsPublisherServers returns a boolean if a field has been set.

### GetPreEvents

`func (o *EventsPoolModifyArguments) GetPreEvents() PreEventsList`

GetPreEvents returns the PreEvents field if non-nil, zero value otherwise.

### GetPreEventsOk

`func (o *EventsPoolModifyArguments) GetPreEventsOk() (*PreEventsList, bool)`

GetPreEventsOk returns a tuple with the PreEvents field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetPreEvents

`func (o *EventsPoolModifyArguments) SetPreEvents(v PreEventsList)`

SetPreEvents sets PreEvents field to given value.

### HasPreEvents

`func (o *EventsPoolModifyArguments) HasPreEvents() bool`

HasPreEvents returns a boolean if a field has been set.

### GetPostEvents

`func (o *EventsPoolModifyArguments) GetPostEvents() PostEventsList`

GetPostEvents returns the PostEvents field if non-nil, zero value otherwise.

### GetPostEventsOk

`func (o *EventsPoolModifyArguments) GetPostEventsOk() (*PostEventsList, bool)`

GetPostEventsOk returns a tuple with the PostEvents field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetPostEvents

`func (o *EventsPoolModifyArguments) SetPostEvents(v PostEventsList)`

SetPostEvents sets PostEvents field to given value.

### HasPostEvents

`func (o *EventsPoolModifyArguments) HasPostEvents() bool`

HasPostEvents returns a boolean if a field has been set.

### GetPostErrorEvents

`func (o *EventsPoolModifyArguments) GetPostErrorEvents() PostErrorEventsList`

GetPostErrorEvents returns the PostErrorEvents field if non-nil, zero value otherwise.

### GetPostErrorEventsOk

`func (o *EventsPoolModifyArguments) GetPostErrorEventsOk() (*PostErrorEventsList, bool)`

GetPostErrorEventsOk returns a tuple with the PostErrorEvents field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetPostErrorEvents

`func (o *EventsPoolModifyArguments) SetPostErrorEvents(v PostErrorEventsList)`

SetPostErrorEvents sets PostErrorEvents field to given value.

### HasPostErrorEvents

`func (o *EventsPoolModifyArguments) HasPostErrorEvents() bool`

HasPostErrorEvents returns a boolean if a field has been set.

### GetOverride

`func (o *EventsPoolModifyArguments) GetOverride() bool`

GetOverride returns the Override field if non-nil, zero value otherwise.

### GetOverrideOk

`func (o *EventsPoolModifyArguments) GetOverrideOk() (*bool, bool)`

GetOverrideOk returns a tuple with the Override field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetOverride

`func (o *EventsPoolModifyArguments) SetOverride(v bool)`

SetOverride sets Override field to given value.

### HasOverride

`func (o *EventsPoolModifyArguments) HasOverride() bool`

HasOverride returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


