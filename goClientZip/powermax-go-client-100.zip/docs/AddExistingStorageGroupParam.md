# AddExistingStorageGroupParam

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**StorageGroupId** | Pointer to **[]string** | The Storage Group Name | [optional] 
**EnableComplianceAlerts** | Pointer to **bool** | Optional setting to enable Compliance Alerts on the Storage Group(s) being added                                 that have the following characteristics:                                 Parent Storage Group is in a masking view or specified Storage Group is in a                                 masking view                                 Service level other than Optimized and None,                                 Contains non Gatekeepers volumes. | [optional] [default to false]

## Methods

### NewAddExistingStorageGroupParam

`func NewAddExistingStorageGroupParam() *AddExistingStorageGroupParam`

NewAddExistingStorageGroupParam instantiates a new AddExistingStorageGroupParam object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewAddExistingStorageGroupParamWithDefaults

`func NewAddExistingStorageGroupParamWithDefaults() *AddExistingStorageGroupParam`

NewAddExistingStorageGroupParamWithDefaults instantiates a new AddExistingStorageGroupParam object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetStorageGroupId

`func (o *AddExistingStorageGroupParam) GetStorageGroupId() []string`

GetStorageGroupId returns the StorageGroupId field if non-nil, zero value otherwise.

### GetStorageGroupIdOk

`func (o *AddExistingStorageGroupParam) GetStorageGroupIdOk() (*[]string, bool)`

GetStorageGroupIdOk returns a tuple with the StorageGroupId field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetStorageGroupId

`func (o *AddExistingStorageGroupParam) SetStorageGroupId(v []string)`

SetStorageGroupId sets StorageGroupId field to given value.

### HasStorageGroupId

`func (o *AddExistingStorageGroupParam) HasStorageGroupId() bool`

HasStorageGroupId returns a boolean if a field has been set.

### GetEnableComplianceAlerts

`func (o *AddExistingStorageGroupParam) GetEnableComplianceAlerts() bool`

GetEnableComplianceAlerts returns the EnableComplianceAlerts field if non-nil, zero value otherwise.

### GetEnableComplianceAlertsOk

`func (o *AddExistingStorageGroupParam) GetEnableComplianceAlertsOk() (*bool, bool)`

GetEnableComplianceAlertsOk returns a tuple with the EnableComplianceAlerts field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetEnableComplianceAlerts

`func (o *AddExistingStorageGroupParam) SetEnableComplianceAlerts(v bool)`

SetEnableComplianceAlerts sets EnableComplianceAlerts field to given value.

### HasEnableComplianceAlerts

`func (o *AddExistingStorageGroupParam) HasEnableComplianceAlerts() bool`

HasEnableComplianceAlerts returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


