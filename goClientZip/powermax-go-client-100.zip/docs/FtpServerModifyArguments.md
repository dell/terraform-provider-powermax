# FtpServerModifyArguments

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**FtpEnabled** | Pointer to **bool** |                          Indicates whether the FTP server is enabled on the NAS server specified in the nasServer attribute. Values are:                         - true - FTP server is enabled on the specified NAS server.                         - false - FTP server is disabled on the specified NAS server.                      | [optional] 
**SftpEnabled** | Pointer to **bool** |                          Indicates whether the SFTP server is enabled on the NAS server specified in the nasServer attribute. Values are:                         - true - SFTP server is enabled on the specified NAS server.                         - false - SFTP server is disabled on the specified NAS server.                      | [optional] 
**SmbAuthenticationEnabled** | Pointer to **bool** |                          Indicates whether FTP and SFTP clients can be authenticated using a SMB user name.                         These user names are defined in a Windows domain controller, and their formats are \&quot;user(at)domain\&quot; or domain(slash)user.                         Values are:                         - true - SMB user names are accepted for authentication.                         - false - SMB user names are not accepted for authentication.                      | [optional] 
**UnixAuthentication** | Pointer to **bool** |                          Indicates whether FTP and SFTP clients can be authenticated using a Unix user name.                         Unix user names are defined in LDAP or NIS servers or in local passwd file.                         Values are:                         - true - Unix user names are accepted for authentication.                         - false - Unix user names are not accepted for authentication.                      | [optional] 
**AnonymousAuthentication** | Pointer to **bool** |                          Indicates whether FTP clients can be authenticated anonymously.                         Values are:                         - true - Anonymous user name is accepted.                         - false - Anonymous user name is not accepted.                      | [optional] 
**HomedirLimit** | Pointer to **bool** |                          Indicates whether an FTP or SFTP user access is limited to his home directory. Values are:                         - true - An FTP or SFTP user can access his or her own home directory only.                         - false - FTP and SFTP users can access any NAS server directory, according to NAS server permissions.                      | [optional] 
**DefaultHomedir** | Pointer to **string** |                          (Applies when the value of HomedirLimit is false.)                         Default directory of FTP and SFTP clients who have a home directory that is not defined or accessible.                         This parameter is an absolute path relative to the root of the NAS server.                      | [optional] 
**WelcomeMsg** | Pointer to **string** |                          Welcome message displayed on the console of FTP and SFTP clients before their authentication.                      | [optional] 
**MessageOfTheDay** | Pointer to **string** |                          Message of the day displayed on the console of FTP clients after their authentication.                       | [optional] 
**AuditEnabled** | Pointer to **bool** |                          Indicates whether the activity of FTP and SFTP clients is tracked in audit files. Values are:                         - true - FTP/SFTP activity is tracked.                         - false - FTP/SFTP activity is not tracked.                      | [optional] 
**AuditDir** | Pointer to **string** |                          (Applies when the value of AuditEnabled is true.)                         Directory of FTP/SFTP audit files.                         This parameter is an absolute path relative to the root of the NAS server.                         This directory cannot be located on the root file system.                      | [optional] 
**AuditMaxSize** | Pointer to **int32** |                          (Applies when the value of AuditEnabled is true.)                         Maximum size of FTP/SFTP audit files, in bytes.                         The maximum value for this setting is 1GB if the audit directory belongs to a user file system of the NAS server.                         If it belongs to the config file system, the maximum value is 1MB.                         The minimum value is 8kB on any file system.                         When the audit file size reaches this value, the file is closed and renamed with an index. A new audit file is then created (files rotation).                         Up to 4 renamed audit files are kept. the oldest files are deleted.                      | [optional] 
**HostsList** | Pointer to **[]string** |                          Allowed or denied hosts, depending on the value of the AllowHosts attribute.                         A host is defined using its IP address.                         Subnets using CIDR notation are also supported.                         - If allowed hosts exist, only those hosts and no others can connect to the NAS server through FTP or SFTP.                         - If denied hosts exist, they always have access denied to the NAS server through FTP or SFTP.                         - If the list is empty, there is no restriction to NAS server access through FTP or SFTP based on the host IP.                      | [optional] 
**UsersList** | Pointer to **[]string** |                          Allowed or denied users, depending on the value of the AllowUsers attribute.                         - If allowed users exist, only those users and no others can connect to the NAS server through FTP or SFTP.                         - If denied users exist, they have always access denied to the NAS server through FTP or SFTP.                         - If the list is empty, there is no restriction to the NAS server access through FTP or SFTP based on the user name.                      | [optional] 
**GroupsList** | Pointer to **[]string** |                          Allowed or denied user groups, depending on the value of the AllowGroups attribute.                         - If allowed groups exist, only users who are members of these groups and no others can connect to the NAS server through FTP or SFTP.                         - If denied groups exist, all users who are members of those groups have always access denied to the NAS server through FTP or SFTP.                         - If the list is empty, there is no restriction to the NAS server access through FTP or SFTP based on the user group.                      | [optional] 
**AllowHosts** | Pointer to **bool** |                          Indicates whether the hostsList attribute contains allowed or denied hosts. Values are:                         true - hostsList contains allowed hosts.                         false - hostsList contains denied hosts.                         Note the hostsList must be empty to be able to change the value of this property.                      | [optional] 
**AllowUsers** | Pointer to **bool** |                          Indicates whether the usersList attribute contains allowed or denied users. Values are:                         - true - usersList contains allowed users.                         - false - usersList contains denied users.                         Note the usersList must be empty to be able to change the value of this property.                      | [optional] 
**AllowGroups** | Pointer to **bool** |                          Indicates whether the groupsList attribute contains allowed or denied user groups. Values are:                         - true - groupsList contains allowed user groups.                         - false - groupsList contains denied user groups.                         Note the groupsList must be empty to be able to change the value of this property.                      | [optional] 

## Methods

### NewFtpServerModifyArguments

`func NewFtpServerModifyArguments() *FtpServerModifyArguments`

NewFtpServerModifyArguments instantiates a new FtpServerModifyArguments object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewFtpServerModifyArgumentsWithDefaults

`func NewFtpServerModifyArgumentsWithDefaults() *FtpServerModifyArguments`

NewFtpServerModifyArgumentsWithDefaults instantiates a new FtpServerModifyArguments object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetFtpEnabled

`func (o *FtpServerModifyArguments) GetFtpEnabled() bool`

GetFtpEnabled returns the FtpEnabled field if non-nil, zero value otherwise.

### GetFtpEnabledOk

`func (o *FtpServerModifyArguments) GetFtpEnabledOk() (*bool, bool)`

GetFtpEnabledOk returns a tuple with the FtpEnabled field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetFtpEnabled

`func (o *FtpServerModifyArguments) SetFtpEnabled(v bool)`

SetFtpEnabled sets FtpEnabled field to given value.

### HasFtpEnabled

`func (o *FtpServerModifyArguments) HasFtpEnabled() bool`

HasFtpEnabled returns a boolean if a field has been set.

### GetSftpEnabled

`func (o *FtpServerModifyArguments) GetSftpEnabled() bool`

GetSftpEnabled returns the SftpEnabled field if non-nil, zero value otherwise.

### GetSftpEnabledOk

`func (o *FtpServerModifyArguments) GetSftpEnabledOk() (*bool, bool)`

GetSftpEnabledOk returns a tuple with the SftpEnabled field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetSftpEnabled

`func (o *FtpServerModifyArguments) SetSftpEnabled(v bool)`

SetSftpEnabled sets SftpEnabled field to given value.

### HasSftpEnabled

`func (o *FtpServerModifyArguments) HasSftpEnabled() bool`

HasSftpEnabled returns a boolean if a field has been set.

### GetSmbAuthenticationEnabled

`func (o *FtpServerModifyArguments) GetSmbAuthenticationEnabled() bool`

GetSmbAuthenticationEnabled returns the SmbAuthenticationEnabled field if non-nil, zero value otherwise.

### GetSmbAuthenticationEnabledOk

`func (o *FtpServerModifyArguments) GetSmbAuthenticationEnabledOk() (*bool, bool)`

GetSmbAuthenticationEnabledOk returns a tuple with the SmbAuthenticationEnabled field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetSmbAuthenticationEnabled

`func (o *FtpServerModifyArguments) SetSmbAuthenticationEnabled(v bool)`

SetSmbAuthenticationEnabled sets SmbAuthenticationEnabled field to given value.

### HasSmbAuthenticationEnabled

`func (o *FtpServerModifyArguments) HasSmbAuthenticationEnabled() bool`

HasSmbAuthenticationEnabled returns a boolean if a field has been set.

### GetUnixAuthentication

`func (o *FtpServerModifyArguments) GetUnixAuthentication() bool`

GetUnixAuthentication returns the UnixAuthentication field if non-nil, zero value otherwise.

### GetUnixAuthenticationOk

`func (o *FtpServerModifyArguments) GetUnixAuthenticationOk() (*bool, bool)`

GetUnixAuthenticationOk returns a tuple with the UnixAuthentication field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetUnixAuthentication

`func (o *FtpServerModifyArguments) SetUnixAuthentication(v bool)`

SetUnixAuthentication sets UnixAuthentication field to given value.

### HasUnixAuthentication

`func (o *FtpServerModifyArguments) HasUnixAuthentication() bool`

HasUnixAuthentication returns a boolean if a field has been set.

### GetAnonymousAuthentication

`func (o *FtpServerModifyArguments) GetAnonymousAuthentication() bool`

GetAnonymousAuthentication returns the AnonymousAuthentication field if non-nil, zero value otherwise.

### GetAnonymousAuthenticationOk

`func (o *FtpServerModifyArguments) GetAnonymousAuthenticationOk() (*bool, bool)`

GetAnonymousAuthenticationOk returns a tuple with the AnonymousAuthentication field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetAnonymousAuthentication

`func (o *FtpServerModifyArguments) SetAnonymousAuthentication(v bool)`

SetAnonymousAuthentication sets AnonymousAuthentication field to given value.

### HasAnonymousAuthentication

`func (o *FtpServerModifyArguments) HasAnonymousAuthentication() bool`

HasAnonymousAuthentication returns a boolean if a field has been set.

### GetHomedirLimit

`func (o *FtpServerModifyArguments) GetHomedirLimit() bool`

GetHomedirLimit returns the HomedirLimit field if non-nil, zero value otherwise.

### GetHomedirLimitOk

`func (o *FtpServerModifyArguments) GetHomedirLimitOk() (*bool, bool)`

GetHomedirLimitOk returns a tuple with the HomedirLimit field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetHomedirLimit

`func (o *FtpServerModifyArguments) SetHomedirLimit(v bool)`

SetHomedirLimit sets HomedirLimit field to given value.

### HasHomedirLimit

`func (o *FtpServerModifyArguments) HasHomedirLimit() bool`

HasHomedirLimit returns a boolean if a field has been set.

### GetDefaultHomedir

`func (o *FtpServerModifyArguments) GetDefaultHomedir() string`

GetDefaultHomedir returns the DefaultHomedir field if non-nil, zero value otherwise.

### GetDefaultHomedirOk

`func (o *FtpServerModifyArguments) GetDefaultHomedirOk() (*string, bool)`

GetDefaultHomedirOk returns a tuple with the DefaultHomedir field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetDefaultHomedir

`func (o *FtpServerModifyArguments) SetDefaultHomedir(v string)`

SetDefaultHomedir sets DefaultHomedir field to given value.

### HasDefaultHomedir

`func (o *FtpServerModifyArguments) HasDefaultHomedir() bool`

HasDefaultHomedir returns a boolean if a field has been set.

### GetWelcomeMsg

`func (o *FtpServerModifyArguments) GetWelcomeMsg() string`

GetWelcomeMsg returns the WelcomeMsg field if non-nil, zero value otherwise.

### GetWelcomeMsgOk

`func (o *FtpServerModifyArguments) GetWelcomeMsgOk() (*string, bool)`

GetWelcomeMsgOk returns a tuple with the WelcomeMsg field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetWelcomeMsg

`func (o *FtpServerModifyArguments) SetWelcomeMsg(v string)`

SetWelcomeMsg sets WelcomeMsg field to given value.

### HasWelcomeMsg

`func (o *FtpServerModifyArguments) HasWelcomeMsg() bool`

HasWelcomeMsg returns a boolean if a field has been set.

### GetMessageOfTheDay

`func (o *FtpServerModifyArguments) GetMessageOfTheDay() string`

GetMessageOfTheDay returns the MessageOfTheDay field if non-nil, zero value otherwise.

### GetMessageOfTheDayOk

`func (o *FtpServerModifyArguments) GetMessageOfTheDayOk() (*string, bool)`

GetMessageOfTheDayOk returns a tuple with the MessageOfTheDay field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetMessageOfTheDay

`func (o *FtpServerModifyArguments) SetMessageOfTheDay(v string)`

SetMessageOfTheDay sets MessageOfTheDay field to given value.

### HasMessageOfTheDay

`func (o *FtpServerModifyArguments) HasMessageOfTheDay() bool`

HasMessageOfTheDay returns a boolean if a field has been set.

### GetAuditEnabled

`func (o *FtpServerModifyArguments) GetAuditEnabled() bool`

GetAuditEnabled returns the AuditEnabled field if non-nil, zero value otherwise.

### GetAuditEnabledOk

`func (o *FtpServerModifyArguments) GetAuditEnabledOk() (*bool, bool)`

GetAuditEnabledOk returns a tuple with the AuditEnabled field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetAuditEnabled

`func (o *FtpServerModifyArguments) SetAuditEnabled(v bool)`

SetAuditEnabled sets AuditEnabled field to given value.

### HasAuditEnabled

`func (o *FtpServerModifyArguments) HasAuditEnabled() bool`

HasAuditEnabled returns a boolean if a field has been set.

### GetAuditDir

`func (o *FtpServerModifyArguments) GetAuditDir() string`

GetAuditDir returns the AuditDir field if non-nil, zero value otherwise.

### GetAuditDirOk

`func (o *FtpServerModifyArguments) GetAuditDirOk() (*string, bool)`

GetAuditDirOk returns a tuple with the AuditDir field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetAuditDir

`func (o *FtpServerModifyArguments) SetAuditDir(v string)`

SetAuditDir sets AuditDir field to given value.

### HasAuditDir

`func (o *FtpServerModifyArguments) HasAuditDir() bool`

HasAuditDir returns a boolean if a field has been set.

### GetAuditMaxSize

`func (o *FtpServerModifyArguments) GetAuditMaxSize() int32`

GetAuditMaxSize returns the AuditMaxSize field if non-nil, zero value otherwise.

### GetAuditMaxSizeOk

`func (o *FtpServerModifyArguments) GetAuditMaxSizeOk() (*int32, bool)`

GetAuditMaxSizeOk returns a tuple with the AuditMaxSize field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetAuditMaxSize

`func (o *FtpServerModifyArguments) SetAuditMaxSize(v int32)`

SetAuditMaxSize sets AuditMaxSize field to given value.

### HasAuditMaxSize

`func (o *FtpServerModifyArguments) HasAuditMaxSize() bool`

HasAuditMaxSize returns a boolean if a field has been set.

### GetHostsList

`func (o *FtpServerModifyArguments) GetHostsList() []string`

GetHostsList returns the HostsList field if non-nil, zero value otherwise.

### GetHostsListOk

`func (o *FtpServerModifyArguments) GetHostsListOk() (*[]string, bool)`

GetHostsListOk returns a tuple with the HostsList field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetHostsList

`func (o *FtpServerModifyArguments) SetHostsList(v []string)`

SetHostsList sets HostsList field to given value.

### HasHostsList

`func (o *FtpServerModifyArguments) HasHostsList() bool`

HasHostsList returns a boolean if a field has been set.

### GetUsersList

`func (o *FtpServerModifyArguments) GetUsersList() []string`

GetUsersList returns the UsersList field if non-nil, zero value otherwise.

### GetUsersListOk

`func (o *FtpServerModifyArguments) GetUsersListOk() (*[]string, bool)`

GetUsersListOk returns a tuple with the UsersList field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetUsersList

`func (o *FtpServerModifyArguments) SetUsersList(v []string)`

SetUsersList sets UsersList field to given value.

### HasUsersList

`func (o *FtpServerModifyArguments) HasUsersList() bool`

HasUsersList returns a boolean if a field has been set.

### GetGroupsList

`func (o *FtpServerModifyArguments) GetGroupsList() []string`

GetGroupsList returns the GroupsList field if non-nil, zero value otherwise.

### GetGroupsListOk

`func (o *FtpServerModifyArguments) GetGroupsListOk() (*[]string, bool)`

GetGroupsListOk returns a tuple with the GroupsList field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetGroupsList

`func (o *FtpServerModifyArguments) SetGroupsList(v []string)`

SetGroupsList sets GroupsList field to given value.

### HasGroupsList

`func (o *FtpServerModifyArguments) HasGroupsList() bool`

HasGroupsList returns a boolean if a field has been set.

### GetAllowHosts

`func (o *FtpServerModifyArguments) GetAllowHosts() bool`

GetAllowHosts returns the AllowHosts field if non-nil, zero value otherwise.

### GetAllowHostsOk

`func (o *FtpServerModifyArguments) GetAllowHostsOk() (*bool, bool)`

GetAllowHostsOk returns a tuple with the AllowHosts field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetAllowHosts

`func (o *FtpServerModifyArguments) SetAllowHosts(v bool)`

SetAllowHosts sets AllowHosts field to given value.

### HasAllowHosts

`func (o *FtpServerModifyArguments) HasAllowHosts() bool`

HasAllowHosts returns a boolean if a field has been set.

### GetAllowUsers

`func (o *FtpServerModifyArguments) GetAllowUsers() bool`

GetAllowUsers returns the AllowUsers field if non-nil, zero value otherwise.

### GetAllowUsersOk

`func (o *FtpServerModifyArguments) GetAllowUsersOk() (*bool, bool)`

GetAllowUsersOk returns a tuple with the AllowUsers field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetAllowUsers

`func (o *FtpServerModifyArguments) SetAllowUsers(v bool)`

SetAllowUsers sets AllowUsers field to given value.

### HasAllowUsers

`func (o *FtpServerModifyArguments) HasAllowUsers() bool`

HasAllowUsers returns a boolean if a field has been set.

### GetAllowGroups

`func (o *FtpServerModifyArguments) GetAllowGroups() bool`

GetAllowGroups returns the AllowGroups field if non-nil, zero value otherwise.

### GetAllowGroupsOk

`func (o *FtpServerModifyArguments) GetAllowGroupsOk() (*bool, bool)`

GetAllowGroupsOk returns a tuple with the AllowGroups field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetAllowGroups

`func (o *FtpServerModifyArguments) SetAllowGroups(v bool)`

SetAllowGroups sets AllowGroups field to given value.

### HasAllowGroups

`func (o *FtpServerModifyArguments) HasAllowGroups() bool`

HasAllowGroups returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


