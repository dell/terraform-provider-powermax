# HostFlags

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**VolumeSetAddressing** | [**VolumeSetAddressing**](VolumeSetAddressing.md) |  | 
**DisableQResetOnUa** | [**DisableQResetOnUa**](DisableQResetOnUa.md) |  | 
**EnvironSet** | [**EnvironSet**](EnvironSet.md) |  | 
**AvoidResetBroadcast** | [**AvoidResetBroadcast**](AvoidResetBroadcast.md) |  | 
**Openvms** | [**Openvms**](Openvms.md) |  | 
**Scsi3** | [**Scsi3**](Scsi3.md) |  | 
**Spc2ProtocolVersion** | [**Spc2ProtocolVersion**](Spc2ProtocolVersion.md) |  | 
**ScsiSupport1** | [**ScsiSupport1**](ScsiSupport1.md) |  | 
**ConsistentLun** | **bool** | Consistent LUNs flag | 

## Methods

### NewHostFlags

`func NewHostFlags(volumeSetAddressing VolumeSetAddressing, disableQResetOnUa DisableQResetOnUa, environSet EnvironSet, avoidResetBroadcast AvoidResetBroadcast, openvms Openvms, scsi3 Scsi3, spc2ProtocolVersion Spc2ProtocolVersion, scsiSupport1 ScsiSupport1, consistentLun bool, ) *HostFlags`

NewHostFlags instantiates a new HostFlags object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewHostFlagsWithDefaults

`func NewHostFlagsWithDefaults() *HostFlags`

NewHostFlagsWithDefaults instantiates a new HostFlags object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetVolumeSetAddressing

`func (o *HostFlags) GetVolumeSetAddressing() VolumeSetAddressing`

GetVolumeSetAddressing returns the VolumeSetAddressing field if non-nil, zero value otherwise.

### GetVolumeSetAddressingOk

`func (o *HostFlags) GetVolumeSetAddressingOk() (*VolumeSetAddressing, bool)`

GetVolumeSetAddressingOk returns a tuple with the VolumeSetAddressing field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetVolumeSetAddressing

`func (o *HostFlags) SetVolumeSetAddressing(v VolumeSetAddressing)`

SetVolumeSetAddressing sets VolumeSetAddressing field to given value.


### GetDisableQResetOnUa

`func (o *HostFlags) GetDisableQResetOnUa() DisableQResetOnUa`

GetDisableQResetOnUa returns the DisableQResetOnUa field if non-nil, zero value otherwise.

### GetDisableQResetOnUaOk

`func (o *HostFlags) GetDisableQResetOnUaOk() (*DisableQResetOnUa, bool)`

GetDisableQResetOnUaOk returns a tuple with the DisableQResetOnUa field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetDisableQResetOnUa

`func (o *HostFlags) SetDisableQResetOnUa(v DisableQResetOnUa)`

SetDisableQResetOnUa sets DisableQResetOnUa field to given value.


### GetEnvironSet

`func (o *HostFlags) GetEnvironSet() EnvironSet`

GetEnvironSet returns the EnvironSet field if non-nil, zero value otherwise.

### GetEnvironSetOk

`func (o *HostFlags) GetEnvironSetOk() (*EnvironSet, bool)`

GetEnvironSetOk returns a tuple with the EnvironSet field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetEnvironSet

`func (o *HostFlags) SetEnvironSet(v EnvironSet)`

SetEnvironSet sets EnvironSet field to given value.


### GetAvoidResetBroadcast

`func (o *HostFlags) GetAvoidResetBroadcast() AvoidResetBroadcast`

GetAvoidResetBroadcast returns the AvoidResetBroadcast field if non-nil, zero value otherwise.

### GetAvoidResetBroadcastOk

`func (o *HostFlags) GetAvoidResetBroadcastOk() (*AvoidResetBroadcast, bool)`

GetAvoidResetBroadcastOk returns a tuple with the AvoidResetBroadcast field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetAvoidResetBroadcast

`func (o *HostFlags) SetAvoidResetBroadcast(v AvoidResetBroadcast)`

SetAvoidResetBroadcast sets AvoidResetBroadcast field to given value.


### GetOpenvms

`func (o *HostFlags) GetOpenvms() Openvms`

GetOpenvms returns the Openvms field if non-nil, zero value otherwise.

### GetOpenvmsOk

`func (o *HostFlags) GetOpenvmsOk() (*Openvms, bool)`

GetOpenvmsOk returns a tuple with the Openvms field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetOpenvms

`func (o *HostFlags) SetOpenvms(v Openvms)`

SetOpenvms sets Openvms field to given value.


### GetScsi3

`func (o *HostFlags) GetScsi3() Scsi3`

GetScsi3 returns the Scsi3 field if non-nil, zero value otherwise.

### GetScsi3Ok

`func (o *HostFlags) GetScsi3Ok() (*Scsi3, bool)`

GetScsi3Ok returns a tuple with the Scsi3 field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetScsi3

`func (o *HostFlags) SetScsi3(v Scsi3)`

SetScsi3 sets Scsi3 field to given value.


### GetSpc2ProtocolVersion

`func (o *HostFlags) GetSpc2ProtocolVersion() Spc2ProtocolVersion`

GetSpc2ProtocolVersion returns the Spc2ProtocolVersion field if non-nil, zero value otherwise.

### GetSpc2ProtocolVersionOk

`func (o *HostFlags) GetSpc2ProtocolVersionOk() (*Spc2ProtocolVersion, bool)`

GetSpc2ProtocolVersionOk returns a tuple with the Spc2ProtocolVersion field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetSpc2ProtocolVersion

`func (o *HostFlags) SetSpc2ProtocolVersion(v Spc2ProtocolVersion)`

SetSpc2ProtocolVersion sets Spc2ProtocolVersion field to given value.


### GetScsiSupport1

`func (o *HostFlags) GetScsiSupport1() ScsiSupport1`

GetScsiSupport1 returns the ScsiSupport1 field if non-nil, zero value otherwise.

### GetScsiSupport1Ok

`func (o *HostFlags) GetScsiSupport1Ok() (*ScsiSupport1, bool)`

GetScsiSupport1Ok returns a tuple with the ScsiSupport1 field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetScsiSupport1

`func (o *HostFlags) SetScsiSupport1(v ScsiSupport1)`

SetScsiSupport1 sets ScsiSupport1 field to given value.


### GetConsistentLun

`func (o *HostFlags) GetConsistentLun() bool`

GetConsistentLun returns the ConsistentLun field if non-nil, zero value otherwise.

### GetConsistentLunOk

`func (o *HostFlags) GetConsistentLunOk() (*bool, bool)`

GetConsistentLunOk returns a tuple with the ConsistentLun field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetConsistentLun

`func (o *HostFlags) SetConsistentLun(v bool)`

SetConsistentLun sets ConsistentLun field to given value.



[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


