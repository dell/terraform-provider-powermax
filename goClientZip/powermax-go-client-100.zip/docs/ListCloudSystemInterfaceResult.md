# ListCloudSystemInterfaceResult

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**InterfaceId** | Pointer to **[]string** | interface_id | [optional] 

## Methods

### NewListCloudSystemInterfaceResult

`func NewListCloudSystemInterfaceResult() *ListCloudSystemInterfaceResult`

NewListCloudSystemInterfaceResult instantiates a new ListCloudSystemInterfaceResult object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewListCloudSystemInterfaceResultWithDefaults

`func NewListCloudSystemInterfaceResultWithDefaults() *ListCloudSystemInterfaceResult`

NewListCloudSystemInterfaceResultWithDefaults instantiates a new ListCloudSystemInterfaceResult object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetInterfaceId

`func (o *ListCloudSystemInterfaceResult) GetInterfaceId() []string`

GetInterfaceId returns the InterfaceId field if non-nil, zero value otherwise.

### GetInterfaceIdOk

`func (o *ListCloudSystemInterfaceResult) GetInterfaceIdOk() (*[]string, bool)`

GetInterfaceIdOk returns a tuple with the InterfaceId field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetInterfaceId

`func (o *ListCloudSystemInterfaceResult) SetInterfaceId(v []string)`

SetInterfaceId sets InterfaceId field to given value.

### HasInterfaceId

`func (o *ListCloudSystemInterfaceResult) HasInterfaceId() bool`

HasInterfaceId returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


