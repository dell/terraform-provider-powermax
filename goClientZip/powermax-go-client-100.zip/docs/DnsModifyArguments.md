# DnsModifyArguments

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Domain** | Pointer to **string** |                          Mandatory name of the DNS domain, where Nas Server does host names lookup when FQDN is not specified in the request.                      | [optional] 
**Addresses** | Pointer to **[]string** |                          The list of DNS server IP addresses.                      | [optional] 
**Transport** | Pointer to **string** |                          Transport used when connecting to the DNS Server                         - 0 - UDP &#x3D;&gt; DNS uses the UDP protocol (default)                         - 1 - TCP &#x3D;&gt; DNS uses the TCP protocol                        Enumeration values: * **UDP** * **TCP**  | [optional] 
**Override** | Pointer to **bool** |                          In the context of a replication, tell if the addresses list must be overriden when this object is in destination mode                      | [optional] 

## Methods

### NewDnsModifyArguments

`func NewDnsModifyArguments() *DnsModifyArguments`

NewDnsModifyArguments instantiates a new DnsModifyArguments object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewDnsModifyArgumentsWithDefaults

`func NewDnsModifyArgumentsWithDefaults() *DnsModifyArguments`

NewDnsModifyArgumentsWithDefaults instantiates a new DnsModifyArguments object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetDomain

`func (o *DnsModifyArguments) GetDomain() string`

GetDomain returns the Domain field if non-nil, zero value otherwise.

### GetDomainOk

`func (o *DnsModifyArguments) GetDomainOk() (*string, bool)`

GetDomainOk returns a tuple with the Domain field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetDomain

`func (o *DnsModifyArguments) SetDomain(v string)`

SetDomain sets Domain field to given value.

### HasDomain

`func (o *DnsModifyArguments) HasDomain() bool`

HasDomain returns a boolean if a field has been set.

### GetAddresses

`func (o *DnsModifyArguments) GetAddresses() []string`

GetAddresses returns the Addresses field if non-nil, zero value otherwise.

### GetAddressesOk

`func (o *DnsModifyArguments) GetAddressesOk() (*[]string, bool)`

GetAddressesOk returns a tuple with the Addresses field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetAddresses

`func (o *DnsModifyArguments) SetAddresses(v []string)`

SetAddresses sets Addresses field to given value.

### HasAddresses

`func (o *DnsModifyArguments) HasAddresses() bool`

HasAddresses returns a boolean if a field has been set.

### GetTransport

`func (o *DnsModifyArguments) GetTransport() string`

GetTransport returns the Transport field if non-nil, zero value otherwise.

### GetTransportOk

`func (o *DnsModifyArguments) GetTransportOk() (*string, bool)`

GetTransportOk returns a tuple with the Transport field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetTransport

`func (o *DnsModifyArguments) SetTransport(v string)`

SetTransport sets Transport field to given value.

### HasTransport

`func (o *DnsModifyArguments) HasTransport() bool`

HasTransport returns a boolean if a field has been set.

### GetOverride

`func (o *DnsModifyArguments) GetOverride() bool`

GetOverride returns the Override field if non-nil, zero value otherwise.

### GetOverrideOk

`func (o *DnsModifyArguments) GetOverrideOk() (*bool, bool)`

GetOverrideOk returns a tuple with the Override field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetOverride

`func (o *DnsModifyArguments) SetOverride(v bool)`

SetOverride sets Override field to given value.

### HasOverride

`func (o *DnsModifyArguments) HasOverride() bool`

HasOverride returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


