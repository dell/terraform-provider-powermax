# DatabaseParam

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**StartDate** | **int64** | Starting date in millisecond. | 
**EndDate** | **int64** | Ending date in millisecond. | 
**SymmetrixId** | **string** | &lt;p&gt;The Symmetrix array ID.&lt;/p&gt; | 
**DatabaseId** | **string** | databaseId | 
**DataFormat** | Pointer to **string** | &lt;p&gt;Data Format (Average or Maximum).&lt;/p&gt;   Enumeration values: * **Average** * **Maximum**  | [optional] 
**Metrics** | **[]string** | metrics   Enumeration values: * **AvgReadResponseTime6** - Read Response time 14 to 32. * **AvgReadResponseTime7** - Read Response Over 32. * **AvgWriteResponseTime6** - Write Response Time 14 to 32. * **AvgWriteResponseTime7** - Write Response Time Over 32. * **ReadResponseTimeCount1** - Read Response time Count 0 to 1. * **ReadResponseTimeCount2** - Read Response time Count 1 to 3. * **ReadResponseTimeCount3** - Read Response time Count 3 to 5. * **ReadResponseTimeCount4** - Read Response time Count 5 to 8. * **ReadResponseTimeCount5** - Read Response time Count 8 to 14. * **ReadResponseTimeCount6** - Read Response time Count 14 to 32. * **ReadResponseTimeCount7** - Read Response time Count Over 32. * **WriteResponseTimeCount1** - Write Response time Count 0 to 1. * **WriteResponseTimeCount2** - Write Response time Count 1 to 3. * **WriteResponseTimeCount3** - Write Response time Count 3 to 5. * **WriteResponseTimeCount4** - Write Response time Count 5 to 8. * **WriteResponseTimeCount5** - \&quot;Write Response time Count 8 to 14. * **WriteResponseTimeCount6** - Write Response time Count 14 to 32 * **WriteResponseTimeCount7** - Write Response time Count Over 32. * **Skew** - Skew. * **HostIOs** - The number of host operations performed each second by the group. * **HostReads** - The number of host read operations performed each second by the group. * **HostWrites** - The number of host write operations performed each second by the group. * **HostHits** - The number of host read/write operations performed each second by the group that were immediately satisfied from cache. * **HostReadHits** - The number of host read operations performed each second by the group that were immediately satisfied from cache. * **HostWriteHits** - The number of host write operations performed each second by the group that were immediately satisfied from cache. * **HostMisses** - The number of host read/write operations performed each second by the group that could not be satisfied from cache. * **HostReadMisses** - The number of host read operations performed each second by the group that were not satisfied from cache. * **HostWriteMisses** - The number of host write operations performed each second by the group that were not satisfied from cache. * **HostMBs** - Cumulative number of host MBs read/writes per second by the group. * **HostMBReads** - The cumulative number of host MBs read per second by the group. * **HostMBWritten** - The cumulative number of host MBs written per second by the group. * **BEReqs** - The number of read/write requests each second performed by the disk directors to cache. * **BEReadReqs** - The number of read requests each second performed by the disk directors to cache. * **BEWriteReqs** - The number of write requests each second performed by the disk directors to cache. * **ReadResponseTime** - The average time that it took the Symmetrix to serve one read IO for this group. * **WriteResponseTime** - The average time that it took the Symmetrix to serve one write IO for this group. * **ReadMissResponseTime** - The average time that it took the Symmetrix to serve one read miss IO for this group. * **WriteMissResponseTime** - The average time that it took the Symmetrix to serve one write miss IO for this group. * **RDFS_WriteResponseTime** - A summary of the read, write, and average response times for the selected SRDF/S group. * **PercentRead** - The percent of IO operations that were reads. * **PercentWrite** - The percent of IO operations that were writes. * **PercentReadHit** - The percent of read operations, performed by the group, that were immediately satisfied by cache. * **PercentWriteHit** - The percent of write operations, performed by the group, that were immediately satisfied by cache. * **PercentReadMiss** - The percent of read miss operations performed each second by the group. A miss occurs when the requested read data is not found in cache. * **PercentWriteMiss** - The percent of write miss operations performed each second by the group. A miss occurs when the write operation had to wait while data was destaged from cache to the disks. * **WPCount** - The number of tracks currently in write pending mode for the group * **SeqIOs** - The number of IO operations performed each second that were sequential. * **SeqReads** - The number of read IO operations performed each second that were sequential. * **SeqWrites** - The number of write IO operations performed each second that were sequential. * **SeqReadHits** - The number of sequential read operations performed each second by the group that were immediately satisfied from cache. * **SeqReadMisses** - The number of sequential read operations performed each second by the group that were misses. * **SeqWriteHits** - The number of sequential write operations performed each second by the group that were immediately satisfied from cache. * **SeqWriteMisses** - The number of sequential write operations performed each second by the group that were misses. * **RandomIOs** - The number of IOs from a host not identified as part of a sequential stream. * **RandomReads** - The number of read IO commands from a host not identified as part of a sequential stream. * **RandomWrites** - The number of write IO commands from a host not identified as part of a sequential stream. * **RandomReadHits** - The number of random read IOs that were satisfied from the cache. * **RandomWriteHits** - The number of random write IOs that were immediately placed in cache because space was available. * **RandomReadMisses** - The number of random read IOs that were misses. * **RandomWriteMisses** - The number of random write IOs that were misses. * **AvgIOSize** - Calculated value: (HA Kbytes transferred per sec/total IOs per sec) * **AvgReadSize** - Calculated value: (Kbytes read per sec/total reads per sec) * **AvgWriteSize** - Calculated value: (Kbytes written per sec/total writes per sec) * **MaxWPThreshold** - The maximum number of write-pending slots available for the group. * **BEMBTransferred** - The number of MBs read per second + MBs written per second. * **BEMBReads** - The number of MBs read by the disk directors from the disk each second. * **BEMBWritten** - The number of MBs written to the disk from the disk director each second. * **BEPrefetchedTrackss** - The total prefetched tracks each second from the disk directors to the cache. * **BEPrefetchedTrackUsed** - The number of prefetched tracks used each second from the disk directors to the cache. * **BEReadRequestTime** - The average time it takes to make a request by the disk directors to the cache. * **BEDiskReadResponseTime** - The average time it takes cache to respond to a read request by the disk directors. * **BEReadTaskTime** - The time from the point when the HA puts the read request on the queue and the DA picks it up - can be considered queue time. * **PercentHit** - The percent of IO operations that were immediately satisfied from cache. * **PercentMisses** - The percent of IO operations that were misses. * **ResponseTime** - The average response time for the reads and writes. * **AllocatedCapacity** - The capacity in GBs of this group. * **BlockSize** - The block size in KBs of the devices in this group. * **BEPrefetchedMBs** - The number of MBs prefetched from disk to cache in a second. * **IODensity** - The number of back-end requests per GB of disk. * **AvgOptimizedReadMissSize** - AvgOptimizedReadMissSize. * **XtremSWCacheIOs** - The number of IOs per second received in the XtremSW Cache. * **PercentXtremSWCacheReadHit** - The percent of total XtremSW Cache read IO operations performed each second by all of the Symmetrix volumes that were served by the XtremSW Cache cache. * **XtremSWCacheMBs** - Cumulative number of host MBs read and written by the StremSW Cache per second. * **XtremSWCacheResponseTime** - The average time it took the XtremSW cache to serve one IO. * **OptimizedReadMisses** - Number of read requests each second performed directly from disks bypassing the cache. * **OptimizedMBReadMisss** - Number of host MBs read each second directly from disks bypassing the cache. * **WritePacedDelay** - The total delay in milliseconds that the RDF directors impose on RDF devices in order to better serve remote IOs. * **AvgWritePacedDelay** - The average time in milliseconds that host writes on RDF devices are delayed by the RDF directors. * **DatabaseName** - Database Name * **DatabaseHostName** - Database Host Name * **InfoAlertCount** - Number of active performance alerts, information severity * **WarningAlertCount** - Number of active performance alerts, warning severity * **CriticalAlertCount** - Number of active performance alerts,cCritical severity * **BEPercentReads** - BE % Reads * **BEPercentWrites** - BE % Writess * **PercentRandomIO** - % Random IO * **PercentRandomReadHit** - % Random Read Hit * **PercentRandomWriteMiss** - % Random Write Miss * **PercentRandomReads** - % Random Reads * **PercentRandomWriteHit** - % Random Write Hit * **PercentSeqIO** - % Sequential IO * **PercentSeqWrites** - % Seq Writes * **PercentSeqReadHit** - % Seq Read Hit * **PercentSeqReadMiss** - % Seq Read Miss * **PercentSeqWriteHit** - % Seq Write Hit * **PercentSeqWriteMiss** - % Seq Write Miss * **RdfMBRead** - RDF MBs Read/sec * **RdfMBWritten** - RDF MBs Written/sec * **RdfReadHits** - RDF Read Hits/sec * **RdfReads** - RDF Reads/sec * **RdfResponseTime** - RDF Response Time (ms) * **RDFRewrites** - RDF Rewrites/sec * **RdfWrites** - RDF Writes/sec * **PercentRandomReadMiss** - 100 * (random read misses per sec/total ios per sec). * **PercentRandomWrites** - (Random Writes per sec / Host IOs per sec) * 100. * **PercentSeqRead** - 100 * (seq reads per sec/total ios per sec).  | 

## Methods

### NewDatabaseParam

`func NewDatabaseParam(startDate int64, endDate int64, symmetrixId string, databaseId string, metrics []string, ) *DatabaseParam`

NewDatabaseParam instantiates a new DatabaseParam object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewDatabaseParamWithDefaults

`func NewDatabaseParamWithDefaults() *DatabaseParam`

NewDatabaseParamWithDefaults instantiates a new DatabaseParam object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetStartDate

`func (o *DatabaseParam) GetStartDate() int64`

GetStartDate returns the StartDate field if non-nil, zero value otherwise.

### GetStartDateOk

`func (o *DatabaseParam) GetStartDateOk() (*int64, bool)`

GetStartDateOk returns a tuple with the StartDate field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetStartDate

`func (o *DatabaseParam) SetStartDate(v int64)`

SetStartDate sets StartDate field to given value.


### GetEndDate

`func (o *DatabaseParam) GetEndDate() int64`

GetEndDate returns the EndDate field if non-nil, zero value otherwise.

### GetEndDateOk

`func (o *DatabaseParam) GetEndDateOk() (*int64, bool)`

GetEndDateOk returns a tuple with the EndDate field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetEndDate

`func (o *DatabaseParam) SetEndDate(v int64)`

SetEndDate sets EndDate field to given value.


### GetSymmetrixId

`func (o *DatabaseParam) GetSymmetrixId() string`

GetSymmetrixId returns the SymmetrixId field if non-nil, zero value otherwise.

### GetSymmetrixIdOk

`func (o *DatabaseParam) GetSymmetrixIdOk() (*string, bool)`

GetSymmetrixIdOk returns a tuple with the SymmetrixId field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetSymmetrixId

`func (o *DatabaseParam) SetSymmetrixId(v string)`

SetSymmetrixId sets SymmetrixId field to given value.


### GetDatabaseId

`func (o *DatabaseParam) GetDatabaseId() string`

GetDatabaseId returns the DatabaseId field if non-nil, zero value otherwise.

### GetDatabaseIdOk

`func (o *DatabaseParam) GetDatabaseIdOk() (*string, bool)`

GetDatabaseIdOk returns a tuple with the DatabaseId field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetDatabaseId

`func (o *DatabaseParam) SetDatabaseId(v string)`

SetDatabaseId sets DatabaseId field to given value.


### GetDataFormat

`func (o *DatabaseParam) GetDataFormat() string`

GetDataFormat returns the DataFormat field if non-nil, zero value otherwise.

### GetDataFormatOk

`func (o *DatabaseParam) GetDataFormatOk() (*string, bool)`

GetDataFormatOk returns a tuple with the DataFormat field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetDataFormat

`func (o *DatabaseParam) SetDataFormat(v string)`

SetDataFormat sets DataFormat field to given value.

### HasDataFormat

`func (o *DatabaseParam) HasDataFormat() bool`

HasDataFormat returns a boolean if a field has been set.

### GetMetrics

`func (o *DatabaseParam) GetMetrics() []string`

GetMetrics returns the Metrics field if non-nil, zero value otherwise.

### GetMetricsOk

`func (o *DatabaseParam) GetMetricsOk() (*[]string, bool)`

GetMetricsOk returns a tuple with the Metrics field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetMetrics

`func (o *DatabaseParam) SetMetrics(v []string)`

SetMetrics sets Metrics field to given value.



[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


