# EditAlertParam

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ExecutionOption** | Pointer to **string** |  | [optional] [default to "SYNCHRONOUS"]
**EditAlertActionParam** | **string** | editAlertActionParam   Enumeration values: * **ACKNOWLEDGE**  | 

## Methods

### NewEditAlertParam

`func NewEditAlertParam(editAlertActionParam string, ) *EditAlertParam`

NewEditAlertParam instantiates a new EditAlertParam object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewEditAlertParamWithDefaults

`func NewEditAlertParamWithDefaults() *EditAlertParam`

NewEditAlertParamWithDefaults instantiates a new EditAlertParam object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetExecutionOption

`func (o *EditAlertParam) GetExecutionOption() string`

GetExecutionOption returns the ExecutionOption field if non-nil, zero value otherwise.

### GetExecutionOptionOk

`func (o *EditAlertParam) GetExecutionOptionOk() (*string, bool)`

GetExecutionOptionOk returns a tuple with the ExecutionOption field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetExecutionOption

`func (o *EditAlertParam) SetExecutionOption(v string)`

SetExecutionOption sets ExecutionOption field to given value.

### HasExecutionOption

`func (o *EditAlertParam) HasExecutionOption() bool`

HasExecutionOption returns a boolean if a field has been set.

### GetEditAlertActionParam

`func (o *EditAlertParam) GetEditAlertActionParam() string`

GetEditAlertActionParam returns the EditAlertActionParam field if non-nil, zero value otherwise.

### GetEditAlertActionParamOk

`func (o *EditAlertParam) GetEditAlertActionParamOk() (*string, bool)`

GetEditAlertActionParamOk returns a tuple with the EditAlertActionParam field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetEditAlertActionParam

`func (o *EditAlertParam) SetEditAlertActionParam(v string)`

SetEditAlertActionParam sets EditAlertActionParam field to given value.



[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


