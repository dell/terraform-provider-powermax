# FeEmulationKeyResult

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**FeEmulationInfo** | Pointer to [**[]FeEmulationInfo**](FeEmulationInfo.md) | feEmulationInfo | [optional] 

## Methods

### NewFeEmulationKeyResult

`func NewFeEmulationKeyResult() *FeEmulationKeyResult`

NewFeEmulationKeyResult instantiates a new FeEmulationKeyResult object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewFeEmulationKeyResultWithDefaults

`func NewFeEmulationKeyResultWithDefaults() *FeEmulationKeyResult`

NewFeEmulationKeyResultWithDefaults instantiates a new FeEmulationKeyResult object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetFeEmulationInfo

`func (o *FeEmulationKeyResult) GetFeEmulationInfo() []FeEmulationInfo`

GetFeEmulationInfo returns the FeEmulationInfo field if non-nil, zero value otherwise.

### GetFeEmulationInfoOk

`func (o *FeEmulationKeyResult) GetFeEmulationInfoOk() (*[]FeEmulationInfo, bool)`

GetFeEmulationInfoOk returns a tuple with the FeEmulationInfo field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetFeEmulationInfo

`func (o *FeEmulationKeyResult) SetFeEmulationInfo(v []FeEmulationInfo)`

SetFeEmulationInfo sets FeEmulationInfo field to given value.

### HasFeEmulationInfo

`func (o *FeEmulationKeyResult) HasFeEmulationInfo() bool`

HasFeEmulationInfo returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


