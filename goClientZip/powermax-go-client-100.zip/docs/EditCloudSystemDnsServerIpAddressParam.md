# EditCloudSystemDnsServerIpAddressParam

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**IpAddress** | **string** | The IP Address of the DNS Server | 

## Methods

### NewEditCloudSystemDnsServerIpAddressParam

`func NewEditCloudSystemDnsServerIpAddressParam(ipAddress string, ) *EditCloudSystemDnsServerIpAddressParam`

NewEditCloudSystemDnsServerIpAddressParam instantiates a new EditCloudSystemDnsServerIpAddressParam object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewEditCloudSystemDnsServerIpAddressParamWithDefaults

`func NewEditCloudSystemDnsServerIpAddressParamWithDefaults() *EditCloudSystemDnsServerIpAddressParam`

NewEditCloudSystemDnsServerIpAddressParamWithDefaults instantiates a new EditCloudSystemDnsServerIpAddressParam object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetIpAddress

`func (o *EditCloudSystemDnsServerIpAddressParam) GetIpAddress() string`

GetIpAddress returns the IpAddress field if non-nil, zero value otherwise.

### GetIpAddressOk

`func (o *EditCloudSystemDnsServerIpAddressParam) GetIpAddressOk() (*string, bool)`

GetIpAddressOk returns a tuple with the IpAddress field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetIpAddress

`func (o *EditCloudSystemDnsServerIpAddressParam) SetIpAddress(v string)`

SetIpAddress sets IpAddress field to given value.



[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


