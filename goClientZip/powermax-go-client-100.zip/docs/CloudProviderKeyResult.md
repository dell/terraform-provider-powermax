# CloudProviderKeyResult

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**CloudProviderInfo** | Pointer to [**[]CloudProviderInfo**](CloudProviderInfo.md) | cloudProviderInfo | [optional] 

## Methods

### NewCloudProviderKeyResult

`func NewCloudProviderKeyResult() *CloudProviderKeyResult`

NewCloudProviderKeyResult instantiates a new CloudProviderKeyResult object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewCloudProviderKeyResultWithDefaults

`func NewCloudProviderKeyResultWithDefaults() *CloudProviderKeyResult`

NewCloudProviderKeyResultWithDefaults instantiates a new CloudProviderKeyResult object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetCloudProviderInfo

`func (o *CloudProviderKeyResult) GetCloudProviderInfo() []CloudProviderInfo`

GetCloudProviderInfo returns the CloudProviderInfo field if non-nil, zero value otherwise.

### GetCloudProviderInfoOk

`func (o *CloudProviderKeyResult) GetCloudProviderInfoOk() (*[]CloudProviderInfo, bool)`

GetCloudProviderInfoOk returns a tuple with the CloudProviderInfo field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetCloudProviderInfo

`func (o *CloudProviderKeyResult) SetCloudProviderInfo(v []CloudProviderInfo)`

SetCloudProviderInfo sets CloudProviderInfo field to given value.

### HasCloudProviderInfo

`func (o *CloudProviderKeyResult) HasCloudProviderInfo() bool`

HasCloudProviderInfo returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


