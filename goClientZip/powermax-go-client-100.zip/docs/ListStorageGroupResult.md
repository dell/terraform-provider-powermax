# ListStorageGroupResult

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**StorageGroupId** | Pointer to **[]string** | storageGroupId | [optional] 

## Methods

### NewListStorageGroupResult

`func NewListStorageGroupResult() *ListStorageGroupResult`

NewListStorageGroupResult instantiates a new ListStorageGroupResult object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewListStorageGroupResultWithDefaults

`func NewListStorageGroupResultWithDefaults() *ListStorageGroupResult`

NewListStorageGroupResultWithDefaults instantiates a new ListStorageGroupResult object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetStorageGroupId

`func (o *ListStorageGroupResult) GetStorageGroupId() []string`

GetStorageGroupId returns the StorageGroupId field if non-nil, zero value otherwise.

### GetStorageGroupIdOk

`func (o *ListStorageGroupResult) GetStorageGroupIdOk() (*[]string, bool)`

GetStorageGroupIdOk returns a tuple with the StorageGroupId field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetStorageGroupId

`func (o *ListStorageGroupResult) SetStorageGroupId(v []string)`

SetStorageGroupId sets StorageGroupId field to given value.

### HasStorageGroupId

`func (o *ListStorageGroupResult) HasStorageGroupId() bool`

HasStorageGroupId returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


