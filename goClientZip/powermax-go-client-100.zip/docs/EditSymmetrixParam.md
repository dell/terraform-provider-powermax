# EditSymmetrixParam

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ExecutionOption** | Pointer to **string** |  | [optional] [default to "SYNCHRONOUS"]
**EditSymmetrixActionParam** | [**EditSymmetrixActionParam**](EditSymmetrixActionParam.md) |  | 

## Methods

### NewEditSymmetrixParam

`func NewEditSymmetrixParam(editSymmetrixActionParam EditSymmetrixActionParam, ) *EditSymmetrixParam`

NewEditSymmetrixParam instantiates a new EditSymmetrixParam object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewEditSymmetrixParamWithDefaults

`func NewEditSymmetrixParamWithDefaults() *EditSymmetrixParam`

NewEditSymmetrixParamWithDefaults instantiates a new EditSymmetrixParam object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetExecutionOption

`func (o *EditSymmetrixParam) GetExecutionOption() string`

GetExecutionOption returns the ExecutionOption field if non-nil, zero value otherwise.

### GetExecutionOptionOk

`func (o *EditSymmetrixParam) GetExecutionOptionOk() (*string, bool)`

GetExecutionOptionOk returns a tuple with the ExecutionOption field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetExecutionOption

`func (o *EditSymmetrixParam) SetExecutionOption(v string)`

SetExecutionOption sets ExecutionOption field to given value.

### HasExecutionOption

`func (o *EditSymmetrixParam) HasExecutionOption() bool`

HasExecutionOption returns a boolean if a field has been set.

### GetEditSymmetrixActionParam

`func (o *EditSymmetrixParam) GetEditSymmetrixActionParam() EditSymmetrixActionParam`

GetEditSymmetrixActionParam returns the EditSymmetrixActionParam field if non-nil, zero value otherwise.

### GetEditSymmetrixActionParamOk

`func (o *EditSymmetrixParam) GetEditSymmetrixActionParamOk() (*EditSymmetrixActionParam, bool)`

GetEditSymmetrixActionParamOk returns a tuple with the EditSymmetrixActionParam field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetEditSymmetrixActionParam

`func (o *EditSymmetrixParam) SetEditSymmetrixActionParam(v EditSymmetrixActionParam)`

SetEditSymmetrixActionParam sets EditSymmetrixActionParam field to given value.



[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


