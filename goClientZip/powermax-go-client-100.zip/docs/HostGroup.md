# HostGroup

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**HostGroupId** | **string** | Host group name | 
**NumOfMaskingViews** | Pointer to **int64** | Number of masking views associated with the host group | [optional] 
**NumOfHosts** | Pointer to **int32** | Number of host associated with the host group | [optional] 
**NumOfInitiators** | Pointer to **int32** | Number of initiators associated with the host group | [optional] 
**PortFlagsOverride** | Pointer to **bool** | States whether port flags override is enabled on the host group | [optional] 
**ConsistentLun** | Pointer to **bool** | States whether consistent LUNs is enabled on the host group | [optional] 
**EnabledFlags** | Pointer to **string** | Flags enabled on the host group | [optional] 
**DisabledFlags** | Pointer to **string** | Flags disabled on the host group | [optional] 
**Type** | Pointer to **string** | Host group type | [optional] 
**Host** | Pointer to [**[]HostSummary**](HostSummary.md) | Host associated with the host group | [optional] 
**Maskingview** | Pointer to **[]string** | Masking view associated with the host group | [optional] 

## Methods

### NewHostGroup

`func NewHostGroup(hostGroupId string, ) *HostGroup`

NewHostGroup instantiates a new HostGroup object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewHostGroupWithDefaults

`func NewHostGroupWithDefaults() *HostGroup`

NewHostGroupWithDefaults instantiates a new HostGroup object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetHostGroupId

`func (o *HostGroup) GetHostGroupId() string`

GetHostGroupId returns the HostGroupId field if non-nil, zero value otherwise.

### GetHostGroupIdOk

`func (o *HostGroup) GetHostGroupIdOk() (*string, bool)`

GetHostGroupIdOk returns a tuple with the HostGroupId field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetHostGroupId

`func (o *HostGroup) SetHostGroupId(v string)`

SetHostGroupId sets HostGroupId field to given value.


### GetNumOfMaskingViews

`func (o *HostGroup) GetNumOfMaskingViews() int64`

GetNumOfMaskingViews returns the NumOfMaskingViews field if non-nil, zero value otherwise.

### GetNumOfMaskingViewsOk

`func (o *HostGroup) GetNumOfMaskingViewsOk() (*int64, bool)`

GetNumOfMaskingViewsOk returns a tuple with the NumOfMaskingViews field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetNumOfMaskingViews

`func (o *HostGroup) SetNumOfMaskingViews(v int64)`

SetNumOfMaskingViews sets NumOfMaskingViews field to given value.

### HasNumOfMaskingViews

`func (o *HostGroup) HasNumOfMaskingViews() bool`

HasNumOfMaskingViews returns a boolean if a field has been set.

### GetNumOfHosts

`func (o *HostGroup) GetNumOfHosts() int32`

GetNumOfHosts returns the NumOfHosts field if non-nil, zero value otherwise.

### GetNumOfHostsOk

`func (o *HostGroup) GetNumOfHostsOk() (*int32, bool)`

GetNumOfHostsOk returns a tuple with the NumOfHosts field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetNumOfHosts

`func (o *HostGroup) SetNumOfHosts(v int32)`

SetNumOfHosts sets NumOfHosts field to given value.

### HasNumOfHosts

`func (o *HostGroup) HasNumOfHosts() bool`

HasNumOfHosts returns a boolean if a field has been set.

### GetNumOfInitiators

`func (o *HostGroup) GetNumOfInitiators() int32`

GetNumOfInitiators returns the NumOfInitiators field if non-nil, zero value otherwise.

### GetNumOfInitiatorsOk

`func (o *HostGroup) GetNumOfInitiatorsOk() (*int32, bool)`

GetNumOfInitiatorsOk returns a tuple with the NumOfInitiators field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetNumOfInitiators

`func (o *HostGroup) SetNumOfInitiators(v int32)`

SetNumOfInitiators sets NumOfInitiators field to given value.

### HasNumOfInitiators

`func (o *HostGroup) HasNumOfInitiators() bool`

HasNumOfInitiators returns a boolean if a field has been set.

### GetPortFlagsOverride

`func (o *HostGroup) GetPortFlagsOverride() bool`

GetPortFlagsOverride returns the PortFlagsOverride field if non-nil, zero value otherwise.

### GetPortFlagsOverrideOk

`func (o *HostGroup) GetPortFlagsOverrideOk() (*bool, bool)`

GetPortFlagsOverrideOk returns a tuple with the PortFlagsOverride field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetPortFlagsOverride

`func (o *HostGroup) SetPortFlagsOverride(v bool)`

SetPortFlagsOverride sets PortFlagsOverride field to given value.

### HasPortFlagsOverride

`func (o *HostGroup) HasPortFlagsOverride() bool`

HasPortFlagsOverride returns a boolean if a field has been set.

### GetConsistentLun

`func (o *HostGroup) GetConsistentLun() bool`

GetConsistentLun returns the ConsistentLun field if non-nil, zero value otherwise.

### GetConsistentLunOk

`func (o *HostGroup) GetConsistentLunOk() (*bool, bool)`

GetConsistentLunOk returns a tuple with the ConsistentLun field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetConsistentLun

`func (o *HostGroup) SetConsistentLun(v bool)`

SetConsistentLun sets ConsistentLun field to given value.

### HasConsistentLun

`func (o *HostGroup) HasConsistentLun() bool`

HasConsistentLun returns a boolean if a field has been set.

### GetEnabledFlags

`func (o *HostGroup) GetEnabledFlags() string`

GetEnabledFlags returns the EnabledFlags field if non-nil, zero value otherwise.

### GetEnabledFlagsOk

`func (o *HostGroup) GetEnabledFlagsOk() (*string, bool)`

GetEnabledFlagsOk returns a tuple with the EnabledFlags field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetEnabledFlags

`func (o *HostGroup) SetEnabledFlags(v string)`

SetEnabledFlags sets EnabledFlags field to given value.

### HasEnabledFlags

`func (o *HostGroup) HasEnabledFlags() bool`

HasEnabledFlags returns a boolean if a field has been set.

### GetDisabledFlags

`func (o *HostGroup) GetDisabledFlags() string`

GetDisabledFlags returns the DisabledFlags field if non-nil, zero value otherwise.

### GetDisabledFlagsOk

`func (o *HostGroup) GetDisabledFlagsOk() (*string, bool)`

GetDisabledFlagsOk returns a tuple with the DisabledFlags field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetDisabledFlags

`func (o *HostGroup) SetDisabledFlags(v string)`

SetDisabledFlags sets DisabledFlags field to given value.

### HasDisabledFlags

`func (o *HostGroup) HasDisabledFlags() bool`

HasDisabledFlags returns a boolean if a field has been set.

### GetType

`func (o *HostGroup) GetType() string`

GetType returns the Type field if non-nil, zero value otherwise.

### GetTypeOk

`func (o *HostGroup) GetTypeOk() (*string, bool)`

GetTypeOk returns a tuple with the Type field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetType

`func (o *HostGroup) SetType(v string)`

SetType sets Type field to given value.

### HasType

`func (o *HostGroup) HasType() bool`

HasType returns a boolean if a field has been set.

### GetHost

`func (o *HostGroup) GetHost() []HostSummary`

GetHost returns the Host field if non-nil, zero value otherwise.

### GetHostOk

`func (o *HostGroup) GetHostOk() (*[]HostSummary, bool)`

GetHostOk returns a tuple with the Host field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetHost

`func (o *HostGroup) SetHost(v []HostSummary)`

SetHost sets Host field to given value.

### HasHost

`func (o *HostGroup) HasHost() bool`

HasHost returns a boolean if a field has been set.

### GetMaskingview

`func (o *HostGroup) GetMaskingview() []string`

GetMaskingview returns the Maskingview field if non-nil, zero value otherwise.

### GetMaskingviewOk

`func (o *HostGroup) GetMaskingviewOk() (*[]string, bool)`

GetMaskingviewOk returns a tuple with the Maskingview field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetMaskingview

`func (o *HostGroup) SetMaskingview(v []string)`

SetMaskingview sets Maskingview field to given value.

### HasMaskingview

`func (o *HostGroup) HasMaskingview() bool`

HasMaskingview returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


