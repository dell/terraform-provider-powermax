# ListDirectors

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**DirectorId** | Pointer to **[]string** | The Directors List | [optional] 

## Methods

### NewListDirectors

`func NewListDirectors() *ListDirectors`

NewListDirectors instantiates a new ListDirectors object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewListDirectorsWithDefaults

`func NewListDirectorsWithDefaults() *ListDirectors`

NewListDirectorsWithDefaults instantiates a new ListDirectors object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetDirectorId

`func (o *ListDirectors) GetDirectorId() []string`

GetDirectorId returns the DirectorId field if non-nil, zero value otherwise.

### GetDirectorIdOk

`func (o *ListDirectors) GetDirectorIdOk() (*[]string, bool)`

GetDirectorIdOk returns a tuple with the DirectorId field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetDirectorId

`func (o *ListDirectors) SetDirectorId(v []string)`

SetDirectorId sets DirectorId field to given value.

### HasDirectorId

`func (o *ListDirectors) HasDirectorId() bool`

HasDirectorId returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


