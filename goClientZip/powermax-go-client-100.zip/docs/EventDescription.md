# EventDescription

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**EventType** | **string** | Type of compliance event.   Enumeration values: * **InitialComplianceState** - Initial state for the storage group. * **ComplianceStateChange** - Compliance state for the storage group has changed. * **OneTimeExclusion** - System or storage group one time exclusion has been set for the storage group. * **RecurringExclusion** - System level recurring exclusion buckets have been set for the storage group. * **ServiceLevelChange** - Service Level for the storage group changed. * **SrpChange** - Storage Resource Pool for the storage group changed. * **WorkloadTypeChange** - Workload type for the storage group changed. * **MissingData** - Performance data for the storage group is not available.  | 
**Message** | **string** | Detailed message describing the event. | 

## Methods

### NewEventDescription

`func NewEventDescription(eventType string, message string, ) *EventDescription`

NewEventDescription instantiates a new EventDescription object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewEventDescriptionWithDefaults

`func NewEventDescriptionWithDefaults() *EventDescription`

NewEventDescriptionWithDefaults instantiates a new EventDescription object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetEventType

`func (o *EventDescription) GetEventType() string`

GetEventType returns the EventType field if non-nil, zero value otherwise.

### GetEventTypeOk

`func (o *EventDescription) GetEventTypeOk() (*string, bool)`

GetEventTypeOk returns a tuple with the EventType field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetEventType

`func (o *EventDescription) SetEventType(v string)`

SetEventType sets EventType field to given value.


### GetMessage

`func (o *EventDescription) GetMessage() string`

GetMessage returns the Message field if non-nil, zero value otherwise.

### GetMessageOk

`func (o *EventDescription) GetMessageOk() (*string, bool)`

GetMessageOk returns a tuple with the Message field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetMessage

`func (o *EventDescription) SetMessage(v string)`

SetMessage sets Message field to given value.



[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


