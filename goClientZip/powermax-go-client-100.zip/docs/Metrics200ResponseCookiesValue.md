# Metrics200ResponseCookiesValue

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Name** | Pointer to **string** |  | [optional] 
**Value** | Pointer to **string** |  | [optional] 
**Version** | Pointer to **int32** |  | [optional] 
**Path** | Pointer to **string** |  | [optional] 
**Domain** | Pointer to **string** |  | [optional] 
**Comment** | Pointer to **string** |  | [optional] 
**MaxAge** | Pointer to **int32** |  | [optional] 
**Expiry** | Pointer to **time.Time** |  | [optional] 
**Secure** | Pointer to **bool** |  | [optional] 
**HttpOnly** | Pointer to **bool** |  | [optional] 

## Methods

### NewMetrics200ResponseCookiesValue

`func NewMetrics200ResponseCookiesValue() *Metrics200ResponseCookiesValue`

NewMetrics200ResponseCookiesValue instantiates a new Metrics200ResponseCookiesValue object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewMetrics200ResponseCookiesValueWithDefaults

`func NewMetrics200ResponseCookiesValueWithDefaults() *Metrics200ResponseCookiesValue`

NewMetrics200ResponseCookiesValueWithDefaults instantiates a new Metrics200ResponseCookiesValue object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetName

`func (o *Metrics200ResponseCookiesValue) GetName() string`

GetName returns the Name field if non-nil, zero value otherwise.

### GetNameOk

`func (o *Metrics200ResponseCookiesValue) GetNameOk() (*string, bool)`

GetNameOk returns a tuple with the Name field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetName

`func (o *Metrics200ResponseCookiesValue) SetName(v string)`

SetName sets Name field to given value.

### HasName

`func (o *Metrics200ResponseCookiesValue) HasName() bool`

HasName returns a boolean if a field has been set.

### GetValue

`func (o *Metrics200ResponseCookiesValue) GetValue() string`

GetValue returns the Value field if non-nil, zero value otherwise.

### GetValueOk

`func (o *Metrics200ResponseCookiesValue) GetValueOk() (*string, bool)`

GetValueOk returns a tuple with the Value field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetValue

`func (o *Metrics200ResponseCookiesValue) SetValue(v string)`

SetValue sets Value field to given value.

### HasValue

`func (o *Metrics200ResponseCookiesValue) HasValue() bool`

HasValue returns a boolean if a field has been set.

### GetVersion

`func (o *Metrics200ResponseCookiesValue) GetVersion() int32`

GetVersion returns the Version field if non-nil, zero value otherwise.

### GetVersionOk

`func (o *Metrics200ResponseCookiesValue) GetVersionOk() (*int32, bool)`

GetVersionOk returns a tuple with the Version field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetVersion

`func (o *Metrics200ResponseCookiesValue) SetVersion(v int32)`

SetVersion sets Version field to given value.

### HasVersion

`func (o *Metrics200ResponseCookiesValue) HasVersion() bool`

HasVersion returns a boolean if a field has been set.

### GetPath

`func (o *Metrics200ResponseCookiesValue) GetPath() string`

GetPath returns the Path field if non-nil, zero value otherwise.

### GetPathOk

`func (o *Metrics200ResponseCookiesValue) GetPathOk() (*string, bool)`

GetPathOk returns a tuple with the Path field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetPath

`func (o *Metrics200ResponseCookiesValue) SetPath(v string)`

SetPath sets Path field to given value.

### HasPath

`func (o *Metrics200ResponseCookiesValue) HasPath() bool`

HasPath returns a boolean if a field has been set.

### GetDomain

`func (o *Metrics200ResponseCookiesValue) GetDomain() string`

GetDomain returns the Domain field if non-nil, zero value otherwise.

### GetDomainOk

`func (o *Metrics200ResponseCookiesValue) GetDomainOk() (*string, bool)`

GetDomainOk returns a tuple with the Domain field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetDomain

`func (o *Metrics200ResponseCookiesValue) SetDomain(v string)`

SetDomain sets Domain field to given value.

### HasDomain

`func (o *Metrics200ResponseCookiesValue) HasDomain() bool`

HasDomain returns a boolean if a field has been set.

### GetComment

`func (o *Metrics200ResponseCookiesValue) GetComment() string`

GetComment returns the Comment field if non-nil, zero value otherwise.

### GetCommentOk

`func (o *Metrics200ResponseCookiesValue) GetCommentOk() (*string, bool)`

GetCommentOk returns a tuple with the Comment field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetComment

`func (o *Metrics200ResponseCookiesValue) SetComment(v string)`

SetComment sets Comment field to given value.

### HasComment

`func (o *Metrics200ResponseCookiesValue) HasComment() bool`

HasComment returns a boolean if a field has been set.

### GetMaxAge

`func (o *Metrics200ResponseCookiesValue) GetMaxAge() int32`

GetMaxAge returns the MaxAge field if non-nil, zero value otherwise.

### GetMaxAgeOk

`func (o *Metrics200ResponseCookiesValue) GetMaxAgeOk() (*int32, bool)`

GetMaxAgeOk returns a tuple with the MaxAge field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetMaxAge

`func (o *Metrics200ResponseCookiesValue) SetMaxAge(v int32)`

SetMaxAge sets MaxAge field to given value.

### HasMaxAge

`func (o *Metrics200ResponseCookiesValue) HasMaxAge() bool`

HasMaxAge returns a boolean if a field has been set.

### GetExpiry

`func (o *Metrics200ResponseCookiesValue) GetExpiry() time.Time`

GetExpiry returns the Expiry field if non-nil, zero value otherwise.

### GetExpiryOk

`func (o *Metrics200ResponseCookiesValue) GetExpiryOk() (*time.Time, bool)`

GetExpiryOk returns a tuple with the Expiry field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetExpiry

`func (o *Metrics200ResponseCookiesValue) SetExpiry(v time.Time)`

SetExpiry sets Expiry field to given value.

### HasExpiry

`func (o *Metrics200ResponseCookiesValue) HasExpiry() bool`

HasExpiry returns a boolean if a field has been set.

### GetSecure

`func (o *Metrics200ResponseCookiesValue) GetSecure() bool`

GetSecure returns the Secure field if non-nil, zero value otherwise.

### GetSecureOk

`func (o *Metrics200ResponseCookiesValue) GetSecureOk() (*bool, bool)`

GetSecureOk returns a tuple with the Secure field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetSecure

`func (o *Metrics200ResponseCookiesValue) SetSecure(v bool)`

SetSecure sets Secure field to given value.

### HasSecure

`func (o *Metrics200ResponseCookiesValue) HasSecure() bool`

HasSecure returns a boolean if a field has been set.

### GetHttpOnly

`func (o *Metrics200ResponseCookiesValue) GetHttpOnly() bool`

GetHttpOnly returns the HttpOnly field if non-nil, zero value otherwise.

### GetHttpOnlyOk

`func (o *Metrics200ResponseCookiesValue) GetHttpOnlyOk() (*bool, bool)`

GetHttpOnlyOk returns a tuple with the HttpOnly field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetHttpOnly

`func (o *Metrics200ResponseCookiesValue) SetHttpOnly(v bool)`

SetHttpOnly sets HttpOnly field to given value.

### HasHttpOnly

`func (o *Metrics200ResponseCookiesValue) HasHttpOnly() bool`

HasHttpOnly returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


