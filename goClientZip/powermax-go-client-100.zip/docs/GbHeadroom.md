# GbHeadroom

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**SrpId** | Pointer to **string** | srpId | [optional] 
**ServiceLevelId** | Pointer to **string** | serviceLevelId | [optional] 
**WorkloadId** | Pointer to **string** | workloadId | [optional] 
**Emulation** | Pointer to **string** | emulation | [optional] 
**Capacity** | Pointer to **float64** | capacity | [optional] 

## Methods

### NewGbHeadroom

`func NewGbHeadroom() *GbHeadroom`

NewGbHeadroom instantiates a new GbHeadroom object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewGbHeadroomWithDefaults

`func NewGbHeadroomWithDefaults() *GbHeadroom`

NewGbHeadroomWithDefaults instantiates a new GbHeadroom object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetSrpId

`func (o *GbHeadroom) GetSrpId() string`

GetSrpId returns the SrpId field if non-nil, zero value otherwise.

### GetSrpIdOk

`func (o *GbHeadroom) GetSrpIdOk() (*string, bool)`

GetSrpIdOk returns a tuple with the SrpId field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetSrpId

`func (o *GbHeadroom) SetSrpId(v string)`

SetSrpId sets SrpId field to given value.

### HasSrpId

`func (o *GbHeadroom) HasSrpId() bool`

HasSrpId returns a boolean if a field has been set.

### GetServiceLevelId

`func (o *GbHeadroom) GetServiceLevelId() string`

GetServiceLevelId returns the ServiceLevelId field if non-nil, zero value otherwise.

### GetServiceLevelIdOk

`func (o *GbHeadroom) GetServiceLevelIdOk() (*string, bool)`

GetServiceLevelIdOk returns a tuple with the ServiceLevelId field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetServiceLevelId

`func (o *GbHeadroom) SetServiceLevelId(v string)`

SetServiceLevelId sets ServiceLevelId field to given value.

### HasServiceLevelId

`func (o *GbHeadroom) HasServiceLevelId() bool`

HasServiceLevelId returns a boolean if a field has been set.

### GetWorkloadId

`func (o *GbHeadroom) GetWorkloadId() string`

GetWorkloadId returns the WorkloadId field if non-nil, zero value otherwise.

### GetWorkloadIdOk

`func (o *GbHeadroom) GetWorkloadIdOk() (*string, bool)`

GetWorkloadIdOk returns a tuple with the WorkloadId field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetWorkloadId

`func (o *GbHeadroom) SetWorkloadId(v string)`

SetWorkloadId sets WorkloadId field to given value.

### HasWorkloadId

`func (o *GbHeadroom) HasWorkloadId() bool`

HasWorkloadId returns a boolean if a field has been set.

### GetEmulation

`func (o *GbHeadroom) GetEmulation() string`

GetEmulation returns the Emulation field if non-nil, zero value otherwise.

### GetEmulationOk

`func (o *GbHeadroom) GetEmulationOk() (*string, bool)`

GetEmulationOk returns a tuple with the Emulation field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetEmulation

`func (o *GbHeadroom) SetEmulation(v string)`

SetEmulation sets Emulation field to given value.

### HasEmulation

`func (o *GbHeadroom) HasEmulation() bool`

HasEmulation returns a boolean if a field has been set.

### GetCapacity

`func (o *GbHeadroom) GetCapacity() float64`

GetCapacity returns the Capacity field if non-nil, zero value otherwise.

### GetCapacityOk

`func (o *GbHeadroom) GetCapacityOk() (*float64, bool)`

GetCapacityOk returns a tuple with the Capacity field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetCapacity

`func (o *GbHeadroom) SetCapacity(v float64)`

SetCapacity sets Capacity field to given value.

### HasCapacity

`func (o *GbHeadroom) HasCapacity() bool`

HasCapacity returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


