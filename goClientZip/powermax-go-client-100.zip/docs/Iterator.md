# Iterator

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ResultList** | [**ResultList**](ResultList.md) |  | 
**Id** | Pointer to **string** | id | [optional] 
**Count** | Pointer to **int32** | count | [optional] 
**ExpirationTime** | Pointer to **int64** | expirationTime | [optional] 
**MaxPageSize** | Pointer to **int32** | maxPageSize | [optional] 
**WarningMessage** | Pointer to **string** | warningMessage | [optional] 

## Methods

### NewIterator

`func NewIterator(resultList ResultList, ) *Iterator`

NewIterator instantiates a new Iterator object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewIteratorWithDefaults

`func NewIteratorWithDefaults() *Iterator`

NewIteratorWithDefaults instantiates a new Iterator object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetResultList

`func (o *Iterator) GetResultList() ResultList`

GetResultList returns the ResultList field if non-nil, zero value otherwise.

### GetResultListOk

`func (o *Iterator) GetResultListOk() (*ResultList, bool)`

GetResultListOk returns a tuple with the ResultList field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetResultList

`func (o *Iterator) SetResultList(v ResultList)`

SetResultList sets ResultList field to given value.


### GetId

`func (o *Iterator) GetId() string`

GetId returns the Id field if non-nil, zero value otherwise.

### GetIdOk

`func (o *Iterator) GetIdOk() (*string, bool)`

GetIdOk returns a tuple with the Id field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetId

`func (o *Iterator) SetId(v string)`

SetId sets Id field to given value.

### HasId

`func (o *Iterator) HasId() bool`

HasId returns a boolean if a field has been set.

### GetCount

`func (o *Iterator) GetCount() int32`

GetCount returns the Count field if non-nil, zero value otherwise.

### GetCountOk

`func (o *Iterator) GetCountOk() (*int32, bool)`

GetCountOk returns a tuple with the Count field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetCount

`func (o *Iterator) SetCount(v int32)`

SetCount sets Count field to given value.

### HasCount

`func (o *Iterator) HasCount() bool`

HasCount returns a boolean if a field has been set.

### GetExpirationTime

`func (o *Iterator) GetExpirationTime() int64`

GetExpirationTime returns the ExpirationTime field if non-nil, zero value otherwise.

### GetExpirationTimeOk

`func (o *Iterator) GetExpirationTimeOk() (*int64, bool)`

GetExpirationTimeOk returns a tuple with the ExpirationTime field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetExpirationTime

`func (o *Iterator) SetExpirationTime(v int64)`

SetExpirationTime sets ExpirationTime field to given value.

### HasExpirationTime

`func (o *Iterator) HasExpirationTime() bool`

HasExpirationTime returns a boolean if a field has been set.

### GetMaxPageSize

`func (o *Iterator) GetMaxPageSize() int32`

GetMaxPageSize returns the MaxPageSize field if non-nil, zero value otherwise.

### GetMaxPageSizeOk

`func (o *Iterator) GetMaxPageSizeOk() (*int32, bool)`

GetMaxPageSizeOk returns a tuple with the MaxPageSize field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetMaxPageSize

`func (o *Iterator) SetMaxPageSize(v int32)`

SetMaxPageSize sets MaxPageSize field to given value.

### HasMaxPageSize

`func (o *Iterator) HasMaxPageSize() bool`

HasMaxPageSize returns a boolean if a field has been set.

### GetWarningMessage

`func (o *Iterator) GetWarningMessage() string`

GetWarningMessage returns the WarningMessage field if non-nil, zero value otherwise.

### GetWarningMessageOk

`func (o *Iterator) GetWarningMessageOk() (*string, bool)`

GetWarningMessageOk returns a tuple with the WarningMessage field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetWarningMessage

`func (o *Iterator) SetWarningMessage(v string)`

SetWarningMessage sets WarningMessage field to given value.

### HasWarningMessage

`func (o *Iterator) HasWarningMessage() bool`

HasWarningMessage returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


