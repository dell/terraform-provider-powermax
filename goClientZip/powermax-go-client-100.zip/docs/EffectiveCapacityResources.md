# EffectiveCapacityResources

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**UsedTb** | Pointer to **float64** | Used capacity in TB | [optional] 
**TotalTb** | Pointer to **float64** | Total capacity in TB | [optional] 
**FreeTb** | Pointer to **float64** | Free capacity in TB | [optional] 

## Methods

### NewEffectiveCapacityResources

`func NewEffectiveCapacityResources() *EffectiveCapacityResources`

NewEffectiveCapacityResources instantiates a new EffectiveCapacityResources object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewEffectiveCapacityResourcesWithDefaults

`func NewEffectiveCapacityResourcesWithDefaults() *EffectiveCapacityResources`

NewEffectiveCapacityResourcesWithDefaults instantiates a new EffectiveCapacityResources object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetUsedTb

`func (o *EffectiveCapacityResources) GetUsedTb() float64`

GetUsedTb returns the UsedTb field if non-nil, zero value otherwise.

### GetUsedTbOk

`func (o *EffectiveCapacityResources) GetUsedTbOk() (*float64, bool)`

GetUsedTbOk returns a tuple with the UsedTb field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetUsedTb

`func (o *EffectiveCapacityResources) SetUsedTb(v float64)`

SetUsedTb sets UsedTb field to given value.

### HasUsedTb

`func (o *EffectiveCapacityResources) HasUsedTb() bool`

HasUsedTb returns a boolean if a field has been set.

### GetTotalTb

`func (o *EffectiveCapacityResources) GetTotalTb() float64`

GetTotalTb returns the TotalTb field if non-nil, zero value otherwise.

### GetTotalTbOk

`func (o *EffectiveCapacityResources) GetTotalTbOk() (*float64, bool)`

GetTotalTbOk returns a tuple with the TotalTb field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetTotalTb

`func (o *EffectiveCapacityResources) SetTotalTb(v float64)`

SetTotalTb sets TotalTb field to given value.

### HasTotalTb

`func (o *EffectiveCapacityResources) HasTotalTb() bool`

HasTotalTb returns a boolean if a field has been set.

### GetFreeTb

`func (o *EffectiveCapacityResources) GetFreeTb() float64`

GetFreeTb returns the FreeTb field if non-nil, zero value otherwise.

### GetFreeTbOk

`func (o *EffectiveCapacityResources) GetFreeTbOk() (*float64, bool)`

GetFreeTbOk returns a tuple with the FreeTb field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetFreeTb

`func (o *EffectiveCapacityResources) SetFreeTb(v float64)`

SetFreeTb sets FreeTb field to given value.

### HasFreeTb

`func (o *EffectiveCapacityResources) HasFreeTb() bool`

HasFreeTb returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


