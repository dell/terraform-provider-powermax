# CloudSystemTeam

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**TeamId** | **string** | The ID of the Cloud System Route | 
**State** | Pointer to **string** | The IP Address of the NIC Team | [optional] 
**IpAddress** | Pointer to **string** | The IP Address of the NIC Team | [optional] 
**Prefix** | Pointer to **int32** | The Netmask Prefix Number of the NIC Team | [optional] 
**MacAddresss** | Pointer to **string** | The MAC address of the default interface in the NIC Team | [optional] 
**Mtu** | Pointer to **int32** | The MTU Speed of the default interface in the NIC Team | [optional] 
**NumOfRoutes** | Pointer to **int32** | The number of routes associated with the default interface in the NIC Team | [optional] 
**Type** | Pointer to **string** | The default interface type in the NIC Team | [optional] 
**IpSource** | Pointer to **string** | The IP Source of the default interface in the NIC Team | [optional] 

## Methods

### NewCloudSystemTeam

`func NewCloudSystemTeam(teamId string, ) *CloudSystemTeam`

NewCloudSystemTeam instantiates a new CloudSystemTeam object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewCloudSystemTeamWithDefaults

`func NewCloudSystemTeamWithDefaults() *CloudSystemTeam`

NewCloudSystemTeamWithDefaults instantiates a new CloudSystemTeam object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetTeamId

`func (o *CloudSystemTeam) GetTeamId() string`

GetTeamId returns the TeamId field if non-nil, zero value otherwise.

### GetTeamIdOk

`func (o *CloudSystemTeam) GetTeamIdOk() (*string, bool)`

GetTeamIdOk returns a tuple with the TeamId field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetTeamId

`func (o *CloudSystemTeam) SetTeamId(v string)`

SetTeamId sets TeamId field to given value.


### GetState

`func (o *CloudSystemTeam) GetState() string`

GetState returns the State field if non-nil, zero value otherwise.

### GetStateOk

`func (o *CloudSystemTeam) GetStateOk() (*string, bool)`

GetStateOk returns a tuple with the State field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetState

`func (o *CloudSystemTeam) SetState(v string)`

SetState sets State field to given value.

### HasState

`func (o *CloudSystemTeam) HasState() bool`

HasState returns a boolean if a field has been set.

### GetIpAddress

`func (o *CloudSystemTeam) GetIpAddress() string`

GetIpAddress returns the IpAddress field if non-nil, zero value otherwise.

### GetIpAddressOk

`func (o *CloudSystemTeam) GetIpAddressOk() (*string, bool)`

GetIpAddressOk returns a tuple with the IpAddress field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetIpAddress

`func (o *CloudSystemTeam) SetIpAddress(v string)`

SetIpAddress sets IpAddress field to given value.

### HasIpAddress

`func (o *CloudSystemTeam) HasIpAddress() bool`

HasIpAddress returns a boolean if a field has been set.

### GetPrefix

`func (o *CloudSystemTeam) GetPrefix() int32`

GetPrefix returns the Prefix field if non-nil, zero value otherwise.

### GetPrefixOk

`func (o *CloudSystemTeam) GetPrefixOk() (*int32, bool)`

GetPrefixOk returns a tuple with the Prefix field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetPrefix

`func (o *CloudSystemTeam) SetPrefix(v int32)`

SetPrefix sets Prefix field to given value.

### HasPrefix

`func (o *CloudSystemTeam) HasPrefix() bool`

HasPrefix returns a boolean if a field has been set.

### GetMacAddresss

`func (o *CloudSystemTeam) GetMacAddresss() string`

GetMacAddresss returns the MacAddresss field if non-nil, zero value otherwise.

### GetMacAddresssOk

`func (o *CloudSystemTeam) GetMacAddresssOk() (*string, bool)`

GetMacAddresssOk returns a tuple with the MacAddresss field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetMacAddresss

`func (o *CloudSystemTeam) SetMacAddresss(v string)`

SetMacAddresss sets MacAddresss field to given value.

### HasMacAddresss

`func (o *CloudSystemTeam) HasMacAddresss() bool`

HasMacAddresss returns a boolean if a field has been set.

### GetMtu

`func (o *CloudSystemTeam) GetMtu() int32`

GetMtu returns the Mtu field if non-nil, zero value otherwise.

### GetMtuOk

`func (o *CloudSystemTeam) GetMtuOk() (*int32, bool)`

GetMtuOk returns a tuple with the Mtu field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetMtu

`func (o *CloudSystemTeam) SetMtu(v int32)`

SetMtu sets Mtu field to given value.

### HasMtu

`func (o *CloudSystemTeam) HasMtu() bool`

HasMtu returns a boolean if a field has been set.

### GetNumOfRoutes

`func (o *CloudSystemTeam) GetNumOfRoutes() int32`

GetNumOfRoutes returns the NumOfRoutes field if non-nil, zero value otherwise.

### GetNumOfRoutesOk

`func (o *CloudSystemTeam) GetNumOfRoutesOk() (*int32, bool)`

GetNumOfRoutesOk returns a tuple with the NumOfRoutes field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetNumOfRoutes

`func (o *CloudSystemTeam) SetNumOfRoutes(v int32)`

SetNumOfRoutes sets NumOfRoutes field to given value.

### HasNumOfRoutes

`func (o *CloudSystemTeam) HasNumOfRoutes() bool`

HasNumOfRoutes returns a boolean if a field has been set.

### GetType

`func (o *CloudSystemTeam) GetType() string`

GetType returns the Type field if non-nil, zero value otherwise.

### GetTypeOk

`func (o *CloudSystemTeam) GetTypeOk() (*string, bool)`

GetTypeOk returns a tuple with the Type field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetType

`func (o *CloudSystemTeam) SetType(v string)`

SetType sets Type field to given value.

### HasType

`func (o *CloudSystemTeam) HasType() bool`

HasType returns a boolean if a field has been set.

### GetIpSource

`func (o *CloudSystemTeam) GetIpSource() string`

GetIpSource returns the IpSource field if non-nil, zero value otherwise.

### GetIpSourceOk

`func (o *CloudSystemTeam) GetIpSourceOk() (*string, bool)`

GetIpSourceOk returns a tuple with the IpSource field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetIpSource

`func (o *CloudSystemTeam) SetIpSource(v string)`

SetIpSource sets IpSource field to given value.

### HasIpSource

`func (o *CloudSystemTeam) HasIpSource() bool`

HasIpSource returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


