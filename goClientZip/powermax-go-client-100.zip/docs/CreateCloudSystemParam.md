# CreateCloudSystemParam

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ExecutionOption** | Pointer to **string** |  | [optional] [default to "SYNCHRONOUS"]
**SetupCloudSystemInterface** | Pointer to [**SetupCloudSystemInterfaceParam**](SetupCloudSystemInterfaceParam.md) |  | [optional] 
**CreateCloudSystemDnsServer** | Pointer to [**CreateCloudSystemDnsServerParam**](CreateCloudSystemDnsServerParam.md) |  | [optional] 
**CreateCloudSystemRoute** | Pointer to [**CreateCloudSystemRouteParam**](CreateCloudSystemRouteParam.md) |  | [optional] 
**EditBandwidthLimit** | Pointer to [**EditBandwidthLimitParam**](EditBandwidthLimitParam.md) |  | [optional] 

## Methods

### NewCreateCloudSystemParam

`func NewCreateCloudSystemParam() *CreateCloudSystemParam`

NewCreateCloudSystemParam instantiates a new CreateCloudSystemParam object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewCreateCloudSystemParamWithDefaults

`func NewCreateCloudSystemParamWithDefaults() *CreateCloudSystemParam`

NewCreateCloudSystemParamWithDefaults instantiates a new CreateCloudSystemParam object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetExecutionOption

`func (o *CreateCloudSystemParam) GetExecutionOption() string`

GetExecutionOption returns the ExecutionOption field if non-nil, zero value otherwise.

### GetExecutionOptionOk

`func (o *CreateCloudSystemParam) GetExecutionOptionOk() (*string, bool)`

GetExecutionOptionOk returns a tuple with the ExecutionOption field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetExecutionOption

`func (o *CreateCloudSystemParam) SetExecutionOption(v string)`

SetExecutionOption sets ExecutionOption field to given value.

### HasExecutionOption

`func (o *CreateCloudSystemParam) HasExecutionOption() bool`

HasExecutionOption returns a boolean if a field has been set.

### GetSetupCloudSystemInterface

`func (o *CreateCloudSystemParam) GetSetupCloudSystemInterface() SetupCloudSystemInterfaceParam`

GetSetupCloudSystemInterface returns the SetupCloudSystemInterface field if non-nil, zero value otherwise.

### GetSetupCloudSystemInterfaceOk

`func (o *CreateCloudSystemParam) GetSetupCloudSystemInterfaceOk() (*SetupCloudSystemInterfaceParam, bool)`

GetSetupCloudSystemInterfaceOk returns a tuple with the SetupCloudSystemInterface field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetSetupCloudSystemInterface

`func (o *CreateCloudSystemParam) SetSetupCloudSystemInterface(v SetupCloudSystemInterfaceParam)`

SetSetupCloudSystemInterface sets SetupCloudSystemInterface field to given value.

### HasSetupCloudSystemInterface

`func (o *CreateCloudSystemParam) HasSetupCloudSystemInterface() bool`

HasSetupCloudSystemInterface returns a boolean if a field has been set.

### GetCreateCloudSystemDnsServer

`func (o *CreateCloudSystemParam) GetCreateCloudSystemDnsServer() CreateCloudSystemDnsServerParam`

GetCreateCloudSystemDnsServer returns the CreateCloudSystemDnsServer field if non-nil, zero value otherwise.

### GetCreateCloudSystemDnsServerOk

`func (o *CreateCloudSystemParam) GetCreateCloudSystemDnsServerOk() (*CreateCloudSystemDnsServerParam, bool)`

GetCreateCloudSystemDnsServerOk returns a tuple with the CreateCloudSystemDnsServer field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetCreateCloudSystemDnsServer

`func (o *CreateCloudSystemParam) SetCreateCloudSystemDnsServer(v CreateCloudSystemDnsServerParam)`

SetCreateCloudSystemDnsServer sets CreateCloudSystemDnsServer field to given value.

### HasCreateCloudSystemDnsServer

`func (o *CreateCloudSystemParam) HasCreateCloudSystemDnsServer() bool`

HasCreateCloudSystemDnsServer returns a boolean if a field has been set.

### GetCreateCloudSystemRoute

`func (o *CreateCloudSystemParam) GetCreateCloudSystemRoute() CreateCloudSystemRouteParam`

GetCreateCloudSystemRoute returns the CreateCloudSystemRoute field if non-nil, zero value otherwise.

### GetCreateCloudSystemRouteOk

`func (o *CreateCloudSystemParam) GetCreateCloudSystemRouteOk() (*CreateCloudSystemRouteParam, bool)`

GetCreateCloudSystemRouteOk returns a tuple with the CreateCloudSystemRoute field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetCreateCloudSystemRoute

`func (o *CreateCloudSystemParam) SetCreateCloudSystemRoute(v CreateCloudSystemRouteParam)`

SetCreateCloudSystemRoute sets CreateCloudSystemRoute field to given value.

### HasCreateCloudSystemRoute

`func (o *CreateCloudSystemParam) HasCreateCloudSystemRoute() bool`

HasCreateCloudSystemRoute returns a boolean if a field has been set.

### GetEditBandwidthLimit

`func (o *CreateCloudSystemParam) GetEditBandwidthLimit() EditBandwidthLimitParam`

GetEditBandwidthLimit returns the EditBandwidthLimit field if non-nil, zero value otherwise.

### GetEditBandwidthLimitOk

`func (o *CreateCloudSystemParam) GetEditBandwidthLimitOk() (*EditBandwidthLimitParam, bool)`

GetEditBandwidthLimitOk returns a tuple with the EditBandwidthLimit field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetEditBandwidthLimit

`func (o *CreateCloudSystemParam) SetEditBandwidthLimit(v EditBandwidthLimitParam)`

SetEditBandwidthLimit sets EditBandwidthLimit field to given value.

### HasEditBandwidthLimit

`func (o *CreateCloudSystemParam) HasEditBandwidthLimit() bool`

HasEditBandwidthLimit returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


