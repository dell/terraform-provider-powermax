# CreateMigration

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ExecutionOption** | Pointer to **string** |  | [optional] [default to "SYNCHRONOUS"]
**Action** | **string** | The action to be performed.   Enumeration values: * **CreateStorageGroupMigration** * **CreateSANMigration**  | 
**CreateStorageGroupMigrationParam** | Pointer to [**CreateStorageGroupMigration**](CreateStorageGroupMigration.md) |  | [optional] 
**CreateSanMigrationParam** | Pointer to [**CreateSANMigration**](CreateSANMigration.md) |  | [optional] 

## Methods

### NewCreateMigration

`func NewCreateMigration(action string, ) *CreateMigration`

NewCreateMigration instantiates a new CreateMigration object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewCreateMigrationWithDefaults

`func NewCreateMigrationWithDefaults() *CreateMigration`

NewCreateMigrationWithDefaults instantiates a new CreateMigration object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetExecutionOption

`func (o *CreateMigration) GetExecutionOption() string`

GetExecutionOption returns the ExecutionOption field if non-nil, zero value otherwise.

### GetExecutionOptionOk

`func (o *CreateMigration) GetExecutionOptionOk() (*string, bool)`

GetExecutionOptionOk returns a tuple with the ExecutionOption field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetExecutionOption

`func (o *CreateMigration) SetExecutionOption(v string)`

SetExecutionOption sets ExecutionOption field to given value.

### HasExecutionOption

`func (o *CreateMigration) HasExecutionOption() bool`

HasExecutionOption returns a boolean if a field has been set.

### GetAction

`func (o *CreateMigration) GetAction() string`

GetAction returns the Action field if non-nil, zero value otherwise.

### GetActionOk

`func (o *CreateMigration) GetActionOk() (*string, bool)`

GetActionOk returns a tuple with the Action field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetAction

`func (o *CreateMigration) SetAction(v string)`

SetAction sets Action field to given value.


### GetCreateStorageGroupMigrationParam

`func (o *CreateMigration) GetCreateStorageGroupMigrationParam() CreateStorageGroupMigration`

GetCreateStorageGroupMigrationParam returns the CreateStorageGroupMigrationParam field if non-nil, zero value otherwise.

### GetCreateStorageGroupMigrationParamOk

`func (o *CreateMigration) GetCreateStorageGroupMigrationParamOk() (*CreateStorageGroupMigration, bool)`

GetCreateStorageGroupMigrationParamOk returns a tuple with the CreateStorageGroupMigrationParam field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetCreateStorageGroupMigrationParam

`func (o *CreateMigration) SetCreateStorageGroupMigrationParam(v CreateStorageGroupMigration)`

SetCreateStorageGroupMigrationParam sets CreateStorageGroupMigrationParam field to given value.

### HasCreateStorageGroupMigrationParam

`func (o *CreateMigration) HasCreateStorageGroupMigrationParam() bool`

HasCreateStorageGroupMigrationParam returns a boolean if a field has been set.

### GetCreateSanMigrationParam

`func (o *CreateMigration) GetCreateSanMigrationParam() CreateSANMigration`

GetCreateSanMigrationParam returns the CreateSanMigrationParam field if non-nil, zero value otherwise.

### GetCreateSanMigrationParamOk

`func (o *CreateMigration) GetCreateSanMigrationParamOk() (*CreateSANMigration, bool)`

GetCreateSanMigrationParamOk returns a tuple with the CreateSanMigrationParam field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetCreateSanMigrationParam

`func (o *CreateMigration) SetCreateSanMigrationParam(v CreateSANMigration)`

SetCreateSanMigrationParam sets CreateSanMigrationParam field to given value.

### HasCreateSanMigrationParam

`func (o *CreateMigration) HasCreateSanMigrationParam() bool`

HasCreateSanMigrationParam returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


