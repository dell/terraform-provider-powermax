# FileInterfaceCreateArguments

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Role** | Pointer to **string** |                          Production network interfaces are used for all file protocols and services of NAS server. Backup network interfaces are used only for NDMP/NFS backup.                         System network interfaces are reserved for system traffic such as for NAS server migration, they can&#39;t be used for the production traffic.                         - 0 - Production                         - 1 - Backup                         - 2 - System                        Enumeration values: * **Production** * **Backup** * **System**  | [optional] [default to "Production"]
**NasServer** | **string** |  Unique identifier of the nas server  | 
**IpAddress** | **string** |  Ip address of the file interface  | 
**Gateway** | Pointer to **string** |  Gateway of the subnet  | [optional] 
**IsDisabled** | Pointer to **bool** |  Indicates whether the network interface is disabled.  | [optional] 
**VlanId** | Pointer to **int32** |  Indicates the VLAN this File Interface part of.  | [optional] 
**NetworkDevices** | Pointer to [**[]NetworkDeviceArguments**](NetworkDeviceArguments.md) | network_devices | [optional] 

## Methods

### NewFileInterfaceCreateArguments

`func NewFileInterfaceCreateArguments(nasServer string, ipAddress string, ) *FileInterfaceCreateArguments`

NewFileInterfaceCreateArguments instantiates a new FileInterfaceCreateArguments object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewFileInterfaceCreateArgumentsWithDefaults

`func NewFileInterfaceCreateArgumentsWithDefaults() *FileInterfaceCreateArguments`

NewFileInterfaceCreateArgumentsWithDefaults instantiates a new FileInterfaceCreateArguments object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetRole

`func (o *FileInterfaceCreateArguments) GetRole() string`

GetRole returns the Role field if non-nil, zero value otherwise.

### GetRoleOk

`func (o *FileInterfaceCreateArguments) GetRoleOk() (*string, bool)`

GetRoleOk returns a tuple with the Role field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetRole

`func (o *FileInterfaceCreateArguments) SetRole(v string)`

SetRole sets Role field to given value.

### HasRole

`func (o *FileInterfaceCreateArguments) HasRole() bool`

HasRole returns a boolean if a field has been set.

### GetNasServer

`func (o *FileInterfaceCreateArguments) GetNasServer() string`

GetNasServer returns the NasServer field if non-nil, zero value otherwise.

### GetNasServerOk

`func (o *FileInterfaceCreateArguments) GetNasServerOk() (*string, bool)`

GetNasServerOk returns a tuple with the NasServer field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetNasServer

`func (o *FileInterfaceCreateArguments) SetNasServer(v string)`

SetNasServer sets NasServer field to given value.


### GetIpAddress

`func (o *FileInterfaceCreateArguments) GetIpAddress() string`

GetIpAddress returns the IpAddress field if non-nil, zero value otherwise.

### GetIpAddressOk

`func (o *FileInterfaceCreateArguments) GetIpAddressOk() (*string, bool)`

GetIpAddressOk returns a tuple with the IpAddress field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetIpAddress

`func (o *FileInterfaceCreateArguments) SetIpAddress(v string)`

SetIpAddress sets IpAddress field to given value.


### GetGateway

`func (o *FileInterfaceCreateArguments) GetGateway() string`

GetGateway returns the Gateway field if non-nil, zero value otherwise.

### GetGatewayOk

`func (o *FileInterfaceCreateArguments) GetGatewayOk() (*string, bool)`

GetGatewayOk returns a tuple with the Gateway field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetGateway

`func (o *FileInterfaceCreateArguments) SetGateway(v string)`

SetGateway sets Gateway field to given value.

### HasGateway

`func (o *FileInterfaceCreateArguments) HasGateway() bool`

HasGateway returns a boolean if a field has been set.

### GetIsDisabled

`func (o *FileInterfaceCreateArguments) GetIsDisabled() bool`

GetIsDisabled returns the IsDisabled field if non-nil, zero value otherwise.

### GetIsDisabledOk

`func (o *FileInterfaceCreateArguments) GetIsDisabledOk() (*bool, bool)`

GetIsDisabledOk returns a tuple with the IsDisabled field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetIsDisabled

`func (o *FileInterfaceCreateArguments) SetIsDisabled(v bool)`

SetIsDisabled sets IsDisabled field to given value.

### HasIsDisabled

`func (o *FileInterfaceCreateArguments) HasIsDisabled() bool`

HasIsDisabled returns a boolean if a field has been set.

### GetVlanId

`func (o *FileInterfaceCreateArguments) GetVlanId() int32`

GetVlanId returns the VlanId field if non-nil, zero value otherwise.

### GetVlanIdOk

`func (o *FileInterfaceCreateArguments) GetVlanIdOk() (*int32, bool)`

GetVlanIdOk returns a tuple with the VlanId field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetVlanId

`func (o *FileInterfaceCreateArguments) SetVlanId(v int32)`

SetVlanId sets VlanId field to given value.

### HasVlanId

`func (o *FileInterfaceCreateArguments) HasVlanId() bool`

HasVlanId returns a boolean if a field has been set.

### GetNetworkDevices

`func (o *FileInterfaceCreateArguments) GetNetworkDevices() []NetworkDeviceArguments`

GetNetworkDevices returns the NetworkDevices field if non-nil, zero value otherwise.

### GetNetworkDevicesOk

`func (o *FileInterfaceCreateArguments) GetNetworkDevicesOk() (*[]NetworkDeviceArguments, bool)`

GetNetworkDevicesOk returns a tuple with the NetworkDevices field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetNetworkDevices

`func (o *FileInterfaceCreateArguments) SetNetworkDevices(v []NetworkDeviceArguments)`

SetNetworkDevices sets NetworkDevices field to given value.

### HasNetworkDevices

`func (o *FileInterfaceCreateArguments) HasNetworkDevices() bool`

HasNetworkDevices returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


