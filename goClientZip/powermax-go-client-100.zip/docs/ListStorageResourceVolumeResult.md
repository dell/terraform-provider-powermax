# ListStorageResourceVolumeResult

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**VolumeId** | Pointer to **[]string** | List of Volume IDs | [optional] 

## Methods

### NewListStorageResourceVolumeResult

`func NewListStorageResourceVolumeResult() *ListStorageResourceVolumeResult`

NewListStorageResourceVolumeResult instantiates a new ListStorageResourceVolumeResult object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewListStorageResourceVolumeResultWithDefaults

`func NewListStorageResourceVolumeResultWithDefaults() *ListStorageResourceVolumeResult`

NewListStorageResourceVolumeResultWithDefaults instantiates a new ListStorageResourceVolumeResult object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetVolumeId

`func (o *ListStorageResourceVolumeResult) GetVolumeId() []string`

GetVolumeId returns the VolumeId field if non-nil, zero value otherwise.

### GetVolumeIdOk

`func (o *ListStorageResourceVolumeResult) GetVolumeIdOk() (*[]string, bool)`

GetVolumeIdOk returns a tuple with the VolumeId field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetVolumeId

`func (o *ListStorageResourceVolumeResult) SetVolumeId(v []string)`

SetVolumeId sets VolumeId field to given value.

### HasVolumeId

`func (o *ListStorageResourceVolumeResult) HasVolumeId() bool`

HasVolumeId returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


