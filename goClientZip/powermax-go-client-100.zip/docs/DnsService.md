# DnsService

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Id** | Pointer to **string** |                          Unique Identifier of DNS Service                      | [optional] 
**NasServer** | Pointer to **string** |                          Id of associated Nas Server instance that uses this DNS object. Only one DNS object per Nas Server is supported.                      | [optional] 
**Domain** | Pointer to **string** |                          Mandatory name of the DNS domain, where Nas Server does host names lookup when FQDN is not specified in the request.                      | [optional] 
**Addresses** | Pointer to **[]string** |                          The list of DNS server IP addresses.                      | [optional] 
**Transport** | Pointer to **string** |                          Transport used when connecting to the DNS Server                         - 0 - UDP &#x3D;&gt; DNS uses the UDP protocol (default)                         - 1 - TCP &#x3D;&gt; DNS uses the TCP protocol                        Enumeration values: * **UDP** * **TCP**  | [optional] 
**Health** | Pointer to [**Health**](Health.md) |  | [optional] 
**Override** | Pointer to **bool** |                          In the context of a replication, tell if the addresses list has been overridden when this object is in destination mode                      | [optional] 

## Methods

### NewDnsService

`func NewDnsService() *DnsService`

NewDnsService instantiates a new DnsService object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewDnsServiceWithDefaults

`func NewDnsServiceWithDefaults() *DnsService`

NewDnsServiceWithDefaults instantiates a new DnsService object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetId

`func (o *DnsService) GetId() string`

GetId returns the Id field if non-nil, zero value otherwise.

### GetIdOk

`func (o *DnsService) GetIdOk() (*string, bool)`

GetIdOk returns a tuple with the Id field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetId

`func (o *DnsService) SetId(v string)`

SetId sets Id field to given value.

### HasId

`func (o *DnsService) HasId() bool`

HasId returns a boolean if a field has been set.

### GetNasServer

`func (o *DnsService) GetNasServer() string`

GetNasServer returns the NasServer field if non-nil, zero value otherwise.

### GetNasServerOk

`func (o *DnsService) GetNasServerOk() (*string, bool)`

GetNasServerOk returns a tuple with the NasServer field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetNasServer

`func (o *DnsService) SetNasServer(v string)`

SetNasServer sets NasServer field to given value.

### HasNasServer

`func (o *DnsService) HasNasServer() bool`

HasNasServer returns a boolean if a field has been set.

### GetDomain

`func (o *DnsService) GetDomain() string`

GetDomain returns the Domain field if non-nil, zero value otherwise.

### GetDomainOk

`func (o *DnsService) GetDomainOk() (*string, bool)`

GetDomainOk returns a tuple with the Domain field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetDomain

`func (o *DnsService) SetDomain(v string)`

SetDomain sets Domain field to given value.

### HasDomain

`func (o *DnsService) HasDomain() bool`

HasDomain returns a boolean if a field has been set.

### GetAddresses

`func (o *DnsService) GetAddresses() []string`

GetAddresses returns the Addresses field if non-nil, zero value otherwise.

### GetAddressesOk

`func (o *DnsService) GetAddressesOk() (*[]string, bool)`

GetAddressesOk returns a tuple with the Addresses field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetAddresses

`func (o *DnsService) SetAddresses(v []string)`

SetAddresses sets Addresses field to given value.

### HasAddresses

`func (o *DnsService) HasAddresses() bool`

HasAddresses returns a boolean if a field has been set.

### GetTransport

`func (o *DnsService) GetTransport() string`

GetTransport returns the Transport field if non-nil, zero value otherwise.

### GetTransportOk

`func (o *DnsService) GetTransportOk() (*string, bool)`

GetTransportOk returns a tuple with the Transport field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetTransport

`func (o *DnsService) SetTransport(v string)`

SetTransport sets Transport field to given value.

### HasTransport

`func (o *DnsService) HasTransport() bool`

HasTransport returns a boolean if a field has been set.

### GetHealth

`func (o *DnsService) GetHealth() Health`

GetHealth returns the Health field if non-nil, zero value otherwise.

### GetHealthOk

`func (o *DnsService) GetHealthOk() (*Health, bool)`

GetHealthOk returns a tuple with the Health field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetHealth

`func (o *DnsService) SetHealth(v Health)`

SetHealth sets Health field to given value.

### HasHealth

`func (o *DnsService) HasHealth() bool`

HasHealth returns a boolean if a field has been set.

### GetOverride

`func (o *DnsService) GetOverride() bool`

GetOverride returns the Override field if non-nil, zero value otherwise.

### GetOverrideOk

`func (o *DnsService) GetOverrideOk() (*bool, bool)`

GetOverrideOk returns a tuple with the Override field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetOverride

`func (o *DnsService) SetOverride(v bool)`

SetOverride sets Override field to given value.

### HasOverride

`func (o *DnsService) HasOverride() bool`

HasOverride returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


