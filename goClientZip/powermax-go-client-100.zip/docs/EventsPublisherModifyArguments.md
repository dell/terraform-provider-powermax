# EventsPublisherModifyArguments

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Enabled** | Pointer to **bool** |  enable the event publisher default: false | [optional] 
**Username** | Pointer to **string** |                          Name of a Windows user allowing Events Publishing to connect to CEPA servers. To ensure that a secure connection (via Microsoft RPC protocol) is used disable HTTP by setting httpPort to 0                      | [optional] 
**Password** | Pointer to **string** | password | [optional] 
**Heartbeat** | Pointer to **int32** |  Time interval to scan each CEPA server (in seconds) for online/offline status  | [optional] 
**Timeout** | Pointer to **int32** |                          Timeout in milliseconds while attempting to send event to a CEPA server to determine that is offline                      | [optional] 
**HttpPort** | Pointer to **int32** |                          TCP port number used but the service to connect to the CEPA server(s) with HTTP. Default port number is 12228.                         Set this httpPort value to 0 to disable HTTP.                         When enabled, connection via HTTP is attempted first.                         If HTTP connection is disabled, or the connection fails, then connection through MSRPC is attempted if all CEPP server(s) are defined by FQDN.                         The SMB account of the NAS server in the AD Domain is used to make the connection via MSRPC. Note that HTTP connections should only be used on secure networks, as it is neither SSL nor authenticated.                      | [optional] 
**DenyAccessWhenAllServersOffline** | Pointer to **bool** |                          Behaviour when the File Event Service server did not answer. Values are:                         false - indicates that nothing changes with I/O in case of File Event Service server is offline.                         true - indicates that all I/O is denied in case of File Event Service server is offline.                      | [optional] 
**PostEventPolicy** | Pointer to **int32** |                          Post-event notification policies for the Event Service. Values are:                         - 0: Ignore - Continue and tolerate lost events.                         - 1: Accumulate - Continue and use a persistence file as a circular event buffer for lost events.                         - 2: Guarantee - Continue and use a persistence file as a circular event buffer for lost events until the buffer is filled and then deny access to files systems where Events Publishing is Enabled.                         - 3: Deny - Deny access to files systems where Events Publishing is enabled.                      | [optional] 

## Methods

### NewEventsPublisherModifyArguments

`func NewEventsPublisherModifyArguments() *EventsPublisherModifyArguments`

NewEventsPublisherModifyArguments instantiates a new EventsPublisherModifyArguments object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewEventsPublisherModifyArgumentsWithDefaults

`func NewEventsPublisherModifyArgumentsWithDefaults() *EventsPublisherModifyArguments`

NewEventsPublisherModifyArgumentsWithDefaults instantiates a new EventsPublisherModifyArguments object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetEnabled

`func (o *EventsPublisherModifyArguments) GetEnabled() bool`

GetEnabled returns the Enabled field if non-nil, zero value otherwise.

### GetEnabledOk

`func (o *EventsPublisherModifyArguments) GetEnabledOk() (*bool, bool)`

GetEnabledOk returns a tuple with the Enabled field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetEnabled

`func (o *EventsPublisherModifyArguments) SetEnabled(v bool)`

SetEnabled sets Enabled field to given value.

### HasEnabled

`func (o *EventsPublisherModifyArguments) HasEnabled() bool`

HasEnabled returns a boolean if a field has been set.

### GetUsername

`func (o *EventsPublisherModifyArguments) GetUsername() string`

GetUsername returns the Username field if non-nil, zero value otherwise.

### GetUsernameOk

`func (o *EventsPublisherModifyArguments) GetUsernameOk() (*string, bool)`

GetUsernameOk returns a tuple with the Username field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetUsername

`func (o *EventsPublisherModifyArguments) SetUsername(v string)`

SetUsername sets Username field to given value.

### HasUsername

`func (o *EventsPublisherModifyArguments) HasUsername() bool`

HasUsername returns a boolean if a field has been set.

### GetPassword

`func (o *EventsPublisherModifyArguments) GetPassword() string`

GetPassword returns the Password field if non-nil, zero value otherwise.

### GetPasswordOk

`func (o *EventsPublisherModifyArguments) GetPasswordOk() (*string, bool)`

GetPasswordOk returns a tuple with the Password field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetPassword

`func (o *EventsPublisherModifyArguments) SetPassword(v string)`

SetPassword sets Password field to given value.

### HasPassword

`func (o *EventsPublisherModifyArguments) HasPassword() bool`

HasPassword returns a boolean if a field has been set.

### GetHeartbeat

`func (o *EventsPublisherModifyArguments) GetHeartbeat() int32`

GetHeartbeat returns the Heartbeat field if non-nil, zero value otherwise.

### GetHeartbeatOk

`func (o *EventsPublisherModifyArguments) GetHeartbeatOk() (*int32, bool)`

GetHeartbeatOk returns a tuple with the Heartbeat field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetHeartbeat

`func (o *EventsPublisherModifyArguments) SetHeartbeat(v int32)`

SetHeartbeat sets Heartbeat field to given value.

### HasHeartbeat

`func (o *EventsPublisherModifyArguments) HasHeartbeat() bool`

HasHeartbeat returns a boolean if a field has been set.

### GetTimeout

`func (o *EventsPublisherModifyArguments) GetTimeout() int32`

GetTimeout returns the Timeout field if non-nil, zero value otherwise.

### GetTimeoutOk

`func (o *EventsPublisherModifyArguments) GetTimeoutOk() (*int32, bool)`

GetTimeoutOk returns a tuple with the Timeout field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetTimeout

`func (o *EventsPublisherModifyArguments) SetTimeout(v int32)`

SetTimeout sets Timeout field to given value.

### HasTimeout

`func (o *EventsPublisherModifyArguments) HasTimeout() bool`

HasTimeout returns a boolean if a field has been set.

### GetHttpPort

`func (o *EventsPublisherModifyArguments) GetHttpPort() int32`

GetHttpPort returns the HttpPort field if non-nil, zero value otherwise.

### GetHttpPortOk

`func (o *EventsPublisherModifyArguments) GetHttpPortOk() (*int32, bool)`

GetHttpPortOk returns a tuple with the HttpPort field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetHttpPort

`func (o *EventsPublisherModifyArguments) SetHttpPort(v int32)`

SetHttpPort sets HttpPort field to given value.

### HasHttpPort

`func (o *EventsPublisherModifyArguments) HasHttpPort() bool`

HasHttpPort returns a boolean if a field has been set.

### GetDenyAccessWhenAllServersOffline

`func (o *EventsPublisherModifyArguments) GetDenyAccessWhenAllServersOffline() bool`

GetDenyAccessWhenAllServersOffline returns the DenyAccessWhenAllServersOffline field if non-nil, zero value otherwise.

### GetDenyAccessWhenAllServersOfflineOk

`func (o *EventsPublisherModifyArguments) GetDenyAccessWhenAllServersOfflineOk() (*bool, bool)`

GetDenyAccessWhenAllServersOfflineOk returns a tuple with the DenyAccessWhenAllServersOffline field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetDenyAccessWhenAllServersOffline

`func (o *EventsPublisherModifyArguments) SetDenyAccessWhenAllServersOffline(v bool)`

SetDenyAccessWhenAllServersOffline sets DenyAccessWhenAllServersOffline field to given value.

### HasDenyAccessWhenAllServersOffline

`func (o *EventsPublisherModifyArguments) HasDenyAccessWhenAllServersOffline() bool`

HasDenyAccessWhenAllServersOffline returns a boolean if a field has been set.

### GetPostEventPolicy

`func (o *EventsPublisherModifyArguments) GetPostEventPolicy() int32`

GetPostEventPolicy returns the PostEventPolicy field if non-nil, zero value otherwise.

### GetPostEventPolicyOk

`func (o *EventsPublisherModifyArguments) GetPostEventPolicyOk() (*int32, bool)`

GetPostEventPolicyOk returns a tuple with the PostEventPolicy field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetPostEventPolicy

`func (o *EventsPublisherModifyArguments) SetPostEventPolicy(v int32)`

SetPostEventPolicy sets PostEventPolicy field to given value.

### HasPostEventPolicy

`func (o *EventsPublisherModifyArguments) HasPostEventPolicy() bool`

HasPostEventPolicy returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


