# AddVolumeParam

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**VolumeAttributes** | [**[]VolumeAttribute**](VolumeAttribute.md) | The size of each volume to be added to the storage group. | 
**CreateNewVolumes** | Pointer to **bool** | Overrides default volume selection by requesting new volumes instead of best                                 effort. | [optional] 
**Emulation** | Pointer to **string** | The emulation of the volumes to be added to the Storage Group.                                 If an Emulation is defined, it must adhere to the following rules:                                 Specified Storage group is an empty Standalone: any valid Emulation type can be                                 specified, FBA by default                                 Specified Storage group is a Standalone that contains volumes : emulation must                                 match the                                 current volume emulations                                 Specified Storage group is an empty Child, with no other children or all other                                 children                                 are empty: any valid Emulation type can be specified, FBA by default                                 Specified Storage group is an empty Child and at least one other child contains                                 volumes:                                 emulation must match the current volume emulations                                 Specified Storage group is a Child that contains volumes : emulation must match                                 the                                 emulation of all other   Enumeration values: * **FBA** * **CELERRA_FBA** * **CKD-3390** * **CKD-3380** * **FILE_FBA** * **AS/400_D910_099**  | [optional] 
**EnableMobilityId** | Pointer to **bool** | Enable Mobility ID on volumes being added to the Storage Group | [optional] [default to false]
**VolumeIdentifier** | Pointer to [**VolumeIdentifier**](VolumeIdentifier.md) |  | [optional] 
**RemoteSymmSGInfoParam** | Pointer to [**RemoteSymmSGInfoParam**](RemoteSymmSGInfoParam.md) |  | [optional] 

## Methods

### NewAddVolumeParam

`func NewAddVolumeParam(volumeAttributes []VolumeAttribute, ) *AddVolumeParam`

NewAddVolumeParam instantiates a new AddVolumeParam object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewAddVolumeParamWithDefaults

`func NewAddVolumeParamWithDefaults() *AddVolumeParam`

NewAddVolumeParamWithDefaults instantiates a new AddVolumeParam object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetVolumeAttributes

`func (o *AddVolumeParam) GetVolumeAttributes() []VolumeAttribute`

GetVolumeAttributes returns the VolumeAttributes field if non-nil, zero value otherwise.

### GetVolumeAttributesOk

`func (o *AddVolumeParam) GetVolumeAttributesOk() (*[]VolumeAttribute, bool)`

GetVolumeAttributesOk returns a tuple with the VolumeAttributes field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetVolumeAttributes

`func (o *AddVolumeParam) SetVolumeAttributes(v []VolumeAttribute)`

SetVolumeAttributes sets VolumeAttributes field to given value.


### GetCreateNewVolumes

`func (o *AddVolumeParam) GetCreateNewVolumes() bool`

GetCreateNewVolumes returns the CreateNewVolumes field if non-nil, zero value otherwise.

### GetCreateNewVolumesOk

`func (o *AddVolumeParam) GetCreateNewVolumesOk() (*bool, bool)`

GetCreateNewVolumesOk returns a tuple with the CreateNewVolumes field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetCreateNewVolumes

`func (o *AddVolumeParam) SetCreateNewVolumes(v bool)`

SetCreateNewVolumes sets CreateNewVolumes field to given value.

### HasCreateNewVolumes

`func (o *AddVolumeParam) HasCreateNewVolumes() bool`

HasCreateNewVolumes returns a boolean if a field has been set.

### GetEmulation

`func (o *AddVolumeParam) GetEmulation() string`

GetEmulation returns the Emulation field if non-nil, zero value otherwise.

### GetEmulationOk

`func (o *AddVolumeParam) GetEmulationOk() (*string, bool)`

GetEmulationOk returns a tuple with the Emulation field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetEmulation

`func (o *AddVolumeParam) SetEmulation(v string)`

SetEmulation sets Emulation field to given value.

### HasEmulation

`func (o *AddVolumeParam) HasEmulation() bool`

HasEmulation returns a boolean if a field has been set.

### GetEnableMobilityId

`func (o *AddVolumeParam) GetEnableMobilityId() bool`

GetEnableMobilityId returns the EnableMobilityId field if non-nil, zero value otherwise.

### GetEnableMobilityIdOk

`func (o *AddVolumeParam) GetEnableMobilityIdOk() (*bool, bool)`

GetEnableMobilityIdOk returns a tuple with the EnableMobilityId field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetEnableMobilityId

`func (o *AddVolumeParam) SetEnableMobilityId(v bool)`

SetEnableMobilityId sets EnableMobilityId field to given value.

### HasEnableMobilityId

`func (o *AddVolumeParam) HasEnableMobilityId() bool`

HasEnableMobilityId returns a boolean if a field has been set.

### GetVolumeIdentifier

`func (o *AddVolumeParam) GetVolumeIdentifier() VolumeIdentifier`

GetVolumeIdentifier returns the VolumeIdentifier field if non-nil, zero value otherwise.

### GetVolumeIdentifierOk

`func (o *AddVolumeParam) GetVolumeIdentifierOk() (*VolumeIdentifier, bool)`

GetVolumeIdentifierOk returns a tuple with the VolumeIdentifier field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetVolumeIdentifier

`func (o *AddVolumeParam) SetVolumeIdentifier(v VolumeIdentifier)`

SetVolumeIdentifier sets VolumeIdentifier field to given value.

### HasVolumeIdentifier

`func (o *AddVolumeParam) HasVolumeIdentifier() bool`

HasVolumeIdentifier returns a boolean if a field has been set.

### GetRemoteSymmSGInfoParam

`func (o *AddVolumeParam) GetRemoteSymmSGInfoParam() RemoteSymmSGInfoParam`

GetRemoteSymmSGInfoParam returns the RemoteSymmSGInfoParam field if non-nil, zero value otherwise.

### GetRemoteSymmSGInfoParamOk

`func (o *AddVolumeParam) GetRemoteSymmSGInfoParamOk() (*RemoteSymmSGInfoParam, bool)`

GetRemoteSymmSGInfoParamOk returns a tuple with the RemoteSymmSGInfoParam field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetRemoteSymmSGInfoParam

`func (o *AddVolumeParam) SetRemoteSymmSGInfoParam(v RemoteSymmSGInfoParam)`

SetRemoteSymmSGInfoParam sets RemoteSymmSGInfoParam field to given value.

### HasRemoteSymmSGInfoParam

`func (o *AddVolumeParam) HasRemoteSymmSGInfoParam() bool`

HasRemoteSymmSGInfoParam returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


