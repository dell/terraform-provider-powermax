# CategoryKpisDaysToFullParamType

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**SymmetrixId** | **string** | &lt;p&gt;The Symmetrix array ID&lt;/p&gt; | 
**Category** | **string** | &lt;p&gt;SPA Category(Array, SRP or ThinPool).&lt;/p&gt;   Enumeration values: * **Array** * **SRP** * **ThinPool**  | 

## Methods

### NewCategoryKpisDaysToFullParamType

`func NewCategoryKpisDaysToFullParamType(symmetrixId string, category string, ) *CategoryKpisDaysToFullParamType`

NewCategoryKpisDaysToFullParamType instantiates a new CategoryKpisDaysToFullParamType object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewCategoryKpisDaysToFullParamTypeWithDefaults

`func NewCategoryKpisDaysToFullParamTypeWithDefaults() *CategoryKpisDaysToFullParamType`

NewCategoryKpisDaysToFullParamTypeWithDefaults instantiates a new CategoryKpisDaysToFullParamType object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetSymmetrixId

`func (o *CategoryKpisDaysToFullParamType) GetSymmetrixId() string`

GetSymmetrixId returns the SymmetrixId field if non-nil, zero value otherwise.

### GetSymmetrixIdOk

`func (o *CategoryKpisDaysToFullParamType) GetSymmetrixIdOk() (*string, bool)`

GetSymmetrixIdOk returns a tuple with the SymmetrixId field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetSymmetrixId

`func (o *CategoryKpisDaysToFullParamType) SetSymmetrixId(v string)`

SetSymmetrixId sets SymmetrixId field to given value.


### GetCategory

`func (o *CategoryKpisDaysToFullParamType) GetCategory() string`

GetCategory returns the Category field if non-nil, zero value otherwise.

### GetCategoryOk

`func (o *CategoryKpisDaysToFullParamType) GetCategoryOk() (*string, bool)`

GetCategoryOk returns a tuple with the Category field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetCategory

`func (o *CategoryKpisDaysToFullParamType) SetCategory(v string)`

SetCategory sets Category field to given value.



[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


