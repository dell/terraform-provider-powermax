# EnvironSet

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Enabled** | **bool** | Environ Set enabled status | 
**Override** | **bool** | Environ Set overridden status | 

## Methods

### NewEnvironSet

`func NewEnvironSet(enabled bool, override bool, ) *EnvironSet`

NewEnvironSet instantiates a new EnvironSet object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewEnvironSetWithDefaults

`func NewEnvironSetWithDefaults() *EnvironSet`

NewEnvironSetWithDefaults instantiates a new EnvironSet object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetEnabled

`func (o *EnvironSet) GetEnabled() bool`

GetEnabled returns the Enabled field if non-nil, zero value otherwise.

### GetEnabledOk

`func (o *EnvironSet) GetEnabledOk() (*bool, bool)`

GetEnabledOk returns a tuple with the Enabled field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetEnabled

`func (o *EnvironSet) SetEnabled(v bool)`

SetEnabled sets Enabled field to given value.


### GetOverride

`func (o *EnvironSet) GetOverride() bool`

GetOverride returns the Override field if non-nil, zero value otherwise.

### GetOverrideOk

`func (o *EnvironSet) GetOverrideOk() (*bool, bool)`

GetOverrideOk returns a tuple with the Override field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetOverride

`func (o *EnvironSet) SetOverride(v bool)`

SetOverride sets Override field to given value.



[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


