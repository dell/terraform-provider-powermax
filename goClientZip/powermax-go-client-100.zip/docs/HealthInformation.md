# HealthInformation

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**HealthScoreMetric** | Pointer to [**[]HealthScoreMetric**](HealthScoreMetric.md) | Health information for a Symmetrix | [optional] 
**NumFailedDisks** | **int32** | num_failed_disks | 
**HealthCheck** | Pointer to **[]string** | health_check | [optional] 

## Methods

### NewHealthInformation

`func NewHealthInformation(numFailedDisks int32, ) *HealthInformation`

NewHealthInformation instantiates a new HealthInformation object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewHealthInformationWithDefaults

`func NewHealthInformationWithDefaults() *HealthInformation`

NewHealthInformationWithDefaults instantiates a new HealthInformation object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetHealthScoreMetric

`func (o *HealthInformation) GetHealthScoreMetric() []HealthScoreMetric`

GetHealthScoreMetric returns the HealthScoreMetric field if non-nil, zero value otherwise.

### GetHealthScoreMetricOk

`func (o *HealthInformation) GetHealthScoreMetricOk() (*[]HealthScoreMetric, bool)`

GetHealthScoreMetricOk returns a tuple with the HealthScoreMetric field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetHealthScoreMetric

`func (o *HealthInformation) SetHealthScoreMetric(v []HealthScoreMetric)`

SetHealthScoreMetric sets HealthScoreMetric field to given value.

### HasHealthScoreMetric

`func (o *HealthInformation) HasHealthScoreMetric() bool`

HasHealthScoreMetric returns a boolean if a field has been set.

### GetNumFailedDisks

`func (o *HealthInformation) GetNumFailedDisks() int32`

GetNumFailedDisks returns the NumFailedDisks field if non-nil, zero value otherwise.

### GetNumFailedDisksOk

`func (o *HealthInformation) GetNumFailedDisksOk() (*int32, bool)`

GetNumFailedDisksOk returns a tuple with the NumFailedDisks field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetNumFailedDisks

`func (o *HealthInformation) SetNumFailedDisks(v int32)`

SetNumFailedDisks sets NumFailedDisks field to given value.


### GetHealthCheck

`func (o *HealthInformation) GetHealthCheck() []string`

GetHealthCheck returns the HealthCheck field if non-nil, zero value otherwise.

### GetHealthCheckOk

`func (o *HealthInformation) GetHealthCheckOk() (*[]string, bool)`

GetHealthCheckOk returns a tuple with the HealthCheck field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetHealthCheck

`func (o *HealthInformation) SetHealthCheck(v []string)`

SetHealthCheck sets HealthCheck field to given value.

### HasHealthCheck

`func (o *HealthInformation) HasHealthCheck() bool`

HasHealthCheck returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


