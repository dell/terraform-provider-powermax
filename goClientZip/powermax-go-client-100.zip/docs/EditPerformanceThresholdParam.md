# EditPerformanceThresholdParam

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Metric** | **string** | &lt;p&gt;SPA Metric Name.&lt;/p&gt; | 
**FirstThreshold** | **int32** | &lt;p&gt;First Threshold must be less than second threshold.&lt;/p&gt; | 
**SecondThreshold** | **int32** | &lt;p&gt;Second Threshold must be greater than 1st threshold.&lt;/p&gt; | 
**Alert** | **bool** | &lt;p&gt;Alert On/Off. True to enable , False to disable.&lt;/p&gt; | 
**FirstThresholdOccurrrences** | **int32** | &lt;p&gt;Error occurrences . Number between 1 and 999 and less than samples.&lt;/p&gt; | 
**FirstThresholdSamples** | **int32** | &lt;p&gt;Error Samples.  Number between 1 and 999  and greater than occurrences.&lt;/p&gt; | 
**FirstThresholdSeverity** | Pointer to **string** | &lt;p&gt;Error Severity . Must be one of the following values.&lt;/p&gt;                                         &lt;p&gt;&lt;/p&gt;                                         &lt;p&gt;INFORMATION&lt;/p&gt;                                         &lt;p&gt;WARNING&lt;/p&gt;                                 &lt;p&gt;CRITICAL&lt;/p&gt;   Enumeration values: * **INFORMATION** * **WARNING** * **CRITICAL**  | [optional] 
**SecondThresholdOccurrrences** | Pointer to **int32** | &lt;p&gt;Warning occurrences. Number between 1 and 999 and less than samples.&lt;/p&gt; | [optional] 
**SecondThresholdSamples** | Pointer to **int32** | &lt;p&gt;Warning Samples. Number between 1 and 999 and greater than occurrences.&lt;/p&gt; | [optional] 
**SecondThresholdSeverity** | Pointer to **string** | &lt;p&gt;Warning Severity.  Must be one of the following values.&lt;/p&gt;                                         &lt;p&gt;&lt;/p&gt;                                         &lt;p&gt;INFORMATION&lt;/p&gt;                                         &lt;p&gt;WARNING&lt;/p&gt;                                 &lt;p&gt;CRITICAL&lt;/p&gt;   Enumeration values: * **INFORMATION** * **WARNING** * **CRITICAL**  | [optional] 

## Methods

### NewEditPerformanceThresholdParam

`func NewEditPerformanceThresholdParam(metric string, firstThreshold int32, secondThreshold int32, alert bool, firstThresholdOccurrrences int32, firstThresholdSamples int32, ) *EditPerformanceThresholdParam`

NewEditPerformanceThresholdParam instantiates a new EditPerformanceThresholdParam object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewEditPerformanceThresholdParamWithDefaults

`func NewEditPerformanceThresholdParamWithDefaults() *EditPerformanceThresholdParam`

NewEditPerformanceThresholdParamWithDefaults instantiates a new EditPerformanceThresholdParam object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetMetric

`func (o *EditPerformanceThresholdParam) GetMetric() string`

GetMetric returns the Metric field if non-nil, zero value otherwise.

### GetMetricOk

`func (o *EditPerformanceThresholdParam) GetMetricOk() (*string, bool)`

GetMetricOk returns a tuple with the Metric field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetMetric

`func (o *EditPerformanceThresholdParam) SetMetric(v string)`

SetMetric sets Metric field to given value.


### GetFirstThreshold

`func (o *EditPerformanceThresholdParam) GetFirstThreshold() int32`

GetFirstThreshold returns the FirstThreshold field if non-nil, zero value otherwise.

### GetFirstThresholdOk

`func (o *EditPerformanceThresholdParam) GetFirstThresholdOk() (*int32, bool)`

GetFirstThresholdOk returns a tuple with the FirstThreshold field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetFirstThreshold

`func (o *EditPerformanceThresholdParam) SetFirstThreshold(v int32)`

SetFirstThreshold sets FirstThreshold field to given value.


### GetSecondThreshold

`func (o *EditPerformanceThresholdParam) GetSecondThreshold() int32`

GetSecondThreshold returns the SecondThreshold field if non-nil, zero value otherwise.

### GetSecondThresholdOk

`func (o *EditPerformanceThresholdParam) GetSecondThresholdOk() (*int32, bool)`

GetSecondThresholdOk returns a tuple with the SecondThreshold field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetSecondThreshold

`func (o *EditPerformanceThresholdParam) SetSecondThreshold(v int32)`

SetSecondThreshold sets SecondThreshold field to given value.


### GetAlert

`func (o *EditPerformanceThresholdParam) GetAlert() bool`

GetAlert returns the Alert field if non-nil, zero value otherwise.

### GetAlertOk

`func (o *EditPerformanceThresholdParam) GetAlertOk() (*bool, bool)`

GetAlertOk returns a tuple with the Alert field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetAlert

`func (o *EditPerformanceThresholdParam) SetAlert(v bool)`

SetAlert sets Alert field to given value.


### GetFirstThresholdOccurrrences

`func (o *EditPerformanceThresholdParam) GetFirstThresholdOccurrrences() int32`

GetFirstThresholdOccurrrences returns the FirstThresholdOccurrrences field if non-nil, zero value otherwise.

### GetFirstThresholdOccurrrencesOk

`func (o *EditPerformanceThresholdParam) GetFirstThresholdOccurrrencesOk() (*int32, bool)`

GetFirstThresholdOccurrrencesOk returns a tuple with the FirstThresholdOccurrrences field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetFirstThresholdOccurrrences

`func (o *EditPerformanceThresholdParam) SetFirstThresholdOccurrrences(v int32)`

SetFirstThresholdOccurrrences sets FirstThresholdOccurrrences field to given value.


### GetFirstThresholdSamples

`func (o *EditPerformanceThresholdParam) GetFirstThresholdSamples() int32`

GetFirstThresholdSamples returns the FirstThresholdSamples field if non-nil, zero value otherwise.

### GetFirstThresholdSamplesOk

`func (o *EditPerformanceThresholdParam) GetFirstThresholdSamplesOk() (*int32, bool)`

GetFirstThresholdSamplesOk returns a tuple with the FirstThresholdSamples field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetFirstThresholdSamples

`func (o *EditPerformanceThresholdParam) SetFirstThresholdSamples(v int32)`

SetFirstThresholdSamples sets FirstThresholdSamples field to given value.


### GetFirstThresholdSeverity

`func (o *EditPerformanceThresholdParam) GetFirstThresholdSeverity() string`

GetFirstThresholdSeverity returns the FirstThresholdSeverity field if non-nil, zero value otherwise.

### GetFirstThresholdSeverityOk

`func (o *EditPerformanceThresholdParam) GetFirstThresholdSeverityOk() (*string, bool)`

GetFirstThresholdSeverityOk returns a tuple with the FirstThresholdSeverity field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetFirstThresholdSeverity

`func (o *EditPerformanceThresholdParam) SetFirstThresholdSeverity(v string)`

SetFirstThresholdSeverity sets FirstThresholdSeverity field to given value.

### HasFirstThresholdSeverity

`func (o *EditPerformanceThresholdParam) HasFirstThresholdSeverity() bool`

HasFirstThresholdSeverity returns a boolean if a field has been set.

### GetSecondThresholdOccurrrences

`func (o *EditPerformanceThresholdParam) GetSecondThresholdOccurrrences() int32`

GetSecondThresholdOccurrrences returns the SecondThresholdOccurrrences field if non-nil, zero value otherwise.

### GetSecondThresholdOccurrrencesOk

`func (o *EditPerformanceThresholdParam) GetSecondThresholdOccurrrencesOk() (*int32, bool)`

GetSecondThresholdOccurrrencesOk returns a tuple with the SecondThresholdOccurrrences field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetSecondThresholdOccurrrences

`func (o *EditPerformanceThresholdParam) SetSecondThresholdOccurrrences(v int32)`

SetSecondThresholdOccurrrences sets SecondThresholdOccurrrences field to given value.

### HasSecondThresholdOccurrrences

`func (o *EditPerformanceThresholdParam) HasSecondThresholdOccurrrences() bool`

HasSecondThresholdOccurrrences returns a boolean if a field has been set.

### GetSecondThresholdSamples

`func (o *EditPerformanceThresholdParam) GetSecondThresholdSamples() int32`

GetSecondThresholdSamples returns the SecondThresholdSamples field if non-nil, zero value otherwise.

### GetSecondThresholdSamplesOk

`func (o *EditPerformanceThresholdParam) GetSecondThresholdSamplesOk() (*int32, bool)`

GetSecondThresholdSamplesOk returns a tuple with the SecondThresholdSamples field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetSecondThresholdSamples

`func (o *EditPerformanceThresholdParam) SetSecondThresholdSamples(v int32)`

SetSecondThresholdSamples sets SecondThresholdSamples field to given value.

### HasSecondThresholdSamples

`func (o *EditPerformanceThresholdParam) HasSecondThresholdSamples() bool`

HasSecondThresholdSamples returns a boolean if a field has been set.

### GetSecondThresholdSeverity

`func (o *EditPerformanceThresholdParam) GetSecondThresholdSeverity() string`

GetSecondThresholdSeverity returns the SecondThresholdSeverity field if non-nil, zero value otherwise.

### GetSecondThresholdSeverityOk

`func (o *EditPerformanceThresholdParam) GetSecondThresholdSeverityOk() (*string, bool)`

GetSecondThresholdSeverityOk returns a tuple with the SecondThresholdSeverity field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetSecondThresholdSeverity

`func (o *EditPerformanceThresholdParam) SetSecondThresholdSeverity(v string)`

SetSecondThresholdSeverity sets SecondThresholdSeverity field to given value.

### HasSecondThresholdSeverity

`func (o *EditPerformanceThresholdParam) HasSecondThresholdSeverity() bool`

HasSecondThresholdSeverity returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


