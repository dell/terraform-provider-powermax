# DiskParam

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**StartDate** | **int64** | Starting date in millisecond. | 
**EndDate** | **int64** | Ending date in millisecond. | 
**SymmetrixId** | **string** | &lt;p&gt;The Symmetrix array ID.&lt;/p&gt; | 
**DiskId** | **string** | diskId | 
**DataFormat** | Pointer to **string** | &lt;p&gt;Data Format (Average or Maximum).&lt;/p&gt;   Enumeration values: * **Average** * **Maximum**  | [optional] 
**Metrics** | **[]string** | metrics   Enumeration values: * **PercentBusy** - The percent of time that the disk is busy serving IOs. * **AvgQueueDepth** - Calculated value: Accumulated queue depth/total SCSI command per sec. * **TotalSCSICommands** - The total number of read commands, write commands, skip mask commands, verify commands, XOR write commands, and XOR write-read commands performed by the Symmetrix disk each second. * **DiskReads** - he number of host reads per second for the disk. * **DiskWrites** - The number of host writes per second for the disk. * **MBReads** - The read throughput (MBs) of the disk per second. * **MBWritten** - The write throughput (MBs) of the disk per second. * **AvgReadSize** - The average number of kilobytes for a single read command. * **AvgWriteSize** - The average number of kilobytes for a single write command. * **ReadResponseTime** - The average time it took the disk to serve one read command. * **WriteResponseTime** - The average time it took the disk to serve one write command. * **Seeks** - The number of times each second that the disk head moved to find data. * **SeekDistance** - The number of hypervolumes that the disk head crossed (during all seeks) each second. * **AvgHypersPerSeek** - The average number of hypervolumes that the disk head crossed during one seek. * **VerifyCommands** - The number of commands that verify the integrity of the data on the disk. * **SkipMaskCommands** - The skip mask support offers an emulation of the ability to efficiently transfer nearly sequential streams of data. It allows a sequential read or write to execute but skip over certain unwanted or unchanged portions of the data stream, thereby transferring only those portions of the sequential stream that have changed and need to be updated. The skip mask mechanism increases throughput by saving bandwidth; both the bandwidth of processing multiple commands and the bandwidth of transferring unnecessary data. * **XORWriteCommands** - The number of exclusive OR (XOR) write commands performed each second by the disk. XOR commands are used to establish parity protection in RAID-S and RAID 5 configurations. * **XORReadCommands** - The number of exclusive OR (XOR) read commands performed each second by the disk. XOR commands are used to establish parity protection in RAID-S and RAID 5 configurations. * **AvgResponseTime** - The average response time for the reads and writes. * **MBs** - The size of the IO from the host to the disk per second. * **IOs** - The number of host read and write requests for the disk. * **TotalCapacity** - The total capacity of the disk (GBs). * **UsedCapacity** - The used capacity of the disk (GBs). * **PercentCapacityUsed** - The percent of the disk that is used. * **PercentIdle** - % Idle. * **PercentCapacityFree** - The percent of the disk that is free. * **UnmapCommandCount** - UNMAP command count * **SpareHypersCount** - Spare Hypers Count * **RebuildBlocksRead** - Rebuild Blocks Read * **RebuildBlocksWritten** - Rebuild Blocks Written. * **VAAIUnmapCommandCount** - VAAI (VMwares Storage APIs for Array Integration) UNMAP command count * **AVG_HYPER_PER_SEEK** - The average number of hypervolumes that the disk head crossed during one seek. * **AVG_KB_PER_READ** - The average number of kilobytes for a single read command. * **AVG_KB_PER_WRITE** - The a  verage number of kilobytes for a single write command. * **AVG_QUEUE_DEPTH** - Calculated value: Accumulated queue depth/total SCSI command per sec. * **IO_RATE** - The number of host read and write requests for the disk. * **MB_RATE** - The size of the IO from the host to the disk per second. * **MB_READ_PER_SEC** - The read throughput (MBs) of the disk per second. * **MB_WRITE_PER_SEC** - The write throughput (MBs) of the disk per second. * **PERCENT_DISK_BUSY** - The percent of time that the disk is busy serving IOs. * **PERCENT_DISK_IDLE** - The percent of time the disk is idle. * **PERCENT_FREE_CAPACITY** - The percent of the disk that is free. * **PERCENT_USED_CAPACITY** - The percent of the disk that is used. * **READS** - The number of host reads per second for the disk. * **RESPONSE_TIME** - The average response time for the reads and writes. * **RESPONSE_TIME_READ** - The average time it took the disk to serve one read command. * **RESPONSE_TIME_WRITE** - The average time it took the disk to serve one write command. * **SCSI_COMM** - The total number of read commands, write commands, skip mask commands, verify commands, XOR write commands, and XOR write-read commands performed by the Symmetrix disk each second. * **SEEK_DISTANCE_PER_SEC** - The number of hypervolumes that the disk head crossed (during all seeks) each second. * **SEEKS_PER_SEC** - The number of times each second that the disk head moved to find data. * **SKIP_MASK_COMMAD_PER_SEC** - The skip mask support offers an emulation of the ability to efficiently transfer nearly sequential streams of data. It allows a sequential read or write to execute but skip over certain unwanted or unchanged portions of the data stream, thereby transferring only those portions of the sequential stream that have changed and need to be updated. The skip mask mechanism increases throughput by saving bandwidth; both the bandwidth of processing multiple commands and the bandwidth of transferring unnecessary data. * **TOTAL_DISK_CAPACITY_GB** - The total capacity of the disk (GBs). * **VERIFY_COMMAND_PER_SEC** - The number of commands that verify the integrity of the data on the disk. * **WRITES** - The number of host writes per second for the disk. * **XOR_READ_COMMAND_PER_SEC** - The number of exclusive OR (XOR) read commands performed each second by the disk. XOR commands are used to establish parity protection in RAID-S and RAID 5 configurations. * **XOR_WRITE_COMMAND_PER_SEC** - The number of exclusive OR (XOR) write commands performed each second by the disk. XOR commands are used to establish parity protection in RAID-S and RAID 5 configurations. * **USED_DISK_CAPACITY_GB** - The used capacity of the disk (GBs).  | 

## Methods

### NewDiskParam

`func NewDiskParam(startDate int64, endDate int64, symmetrixId string, diskId string, metrics []string, ) *DiskParam`

NewDiskParam instantiates a new DiskParam object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewDiskParamWithDefaults

`func NewDiskParamWithDefaults() *DiskParam`

NewDiskParamWithDefaults instantiates a new DiskParam object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetStartDate

`func (o *DiskParam) GetStartDate() int64`

GetStartDate returns the StartDate field if non-nil, zero value otherwise.

### GetStartDateOk

`func (o *DiskParam) GetStartDateOk() (*int64, bool)`

GetStartDateOk returns a tuple with the StartDate field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetStartDate

`func (o *DiskParam) SetStartDate(v int64)`

SetStartDate sets StartDate field to given value.


### GetEndDate

`func (o *DiskParam) GetEndDate() int64`

GetEndDate returns the EndDate field if non-nil, zero value otherwise.

### GetEndDateOk

`func (o *DiskParam) GetEndDateOk() (*int64, bool)`

GetEndDateOk returns a tuple with the EndDate field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetEndDate

`func (o *DiskParam) SetEndDate(v int64)`

SetEndDate sets EndDate field to given value.


### GetSymmetrixId

`func (o *DiskParam) GetSymmetrixId() string`

GetSymmetrixId returns the SymmetrixId field if non-nil, zero value otherwise.

### GetSymmetrixIdOk

`func (o *DiskParam) GetSymmetrixIdOk() (*string, bool)`

GetSymmetrixIdOk returns a tuple with the SymmetrixId field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetSymmetrixId

`func (o *DiskParam) SetSymmetrixId(v string)`

SetSymmetrixId sets SymmetrixId field to given value.


### GetDiskId

`func (o *DiskParam) GetDiskId() string`

GetDiskId returns the DiskId field if non-nil, zero value otherwise.

### GetDiskIdOk

`func (o *DiskParam) GetDiskIdOk() (*string, bool)`

GetDiskIdOk returns a tuple with the DiskId field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetDiskId

`func (o *DiskParam) SetDiskId(v string)`

SetDiskId sets DiskId field to given value.


### GetDataFormat

`func (o *DiskParam) GetDataFormat() string`

GetDataFormat returns the DataFormat field if non-nil, zero value otherwise.

### GetDataFormatOk

`func (o *DiskParam) GetDataFormatOk() (*string, bool)`

GetDataFormatOk returns a tuple with the DataFormat field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetDataFormat

`func (o *DiskParam) SetDataFormat(v string)`

SetDataFormat sets DataFormat field to given value.

### HasDataFormat

`func (o *DiskParam) HasDataFormat() bool`

HasDataFormat returns a boolean if a field has been set.

### GetMetrics

`func (o *DiskParam) GetMetrics() []string`

GetMetrics returns the Metrics field if non-nil, zero value otherwise.

### GetMetricsOk

`func (o *DiskParam) GetMetricsOk() (*[]string, bool)`

GetMetricsOk returns a tuple with the Metrics field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetMetrics

`func (o *DiskParam) SetMetrics(v []string)`

SetMetrics sets Metrics field to given value.



[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


