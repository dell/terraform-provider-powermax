# Metrics200ResponseEntityTag

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Value** | Pointer to **string** |  | [optional] 
**Weak** | Pointer to **bool** |  | [optional] 

## Methods

### NewMetrics200ResponseEntityTag

`func NewMetrics200ResponseEntityTag() *Metrics200ResponseEntityTag`

NewMetrics200ResponseEntityTag instantiates a new Metrics200ResponseEntityTag object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewMetrics200ResponseEntityTagWithDefaults

`func NewMetrics200ResponseEntityTagWithDefaults() *Metrics200ResponseEntityTag`

NewMetrics200ResponseEntityTagWithDefaults instantiates a new Metrics200ResponseEntityTag object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetValue

`func (o *Metrics200ResponseEntityTag) GetValue() string`

GetValue returns the Value field if non-nil, zero value otherwise.

### GetValueOk

`func (o *Metrics200ResponseEntityTag) GetValueOk() (*string, bool)`

GetValueOk returns a tuple with the Value field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetValue

`func (o *Metrics200ResponseEntityTag) SetValue(v string)`

SetValue sets Value field to given value.

### HasValue

`func (o *Metrics200ResponseEntityTag) HasValue() bool`

HasValue returns a boolean if a field has been set.

### GetWeak

`func (o *Metrics200ResponseEntityTag) GetWeak() bool`

GetWeak returns the Weak field if non-nil, zero value otherwise.

### GetWeakOk

`func (o *Metrics200ResponseEntityTag) GetWeakOk() (*bool, bool)`

GetWeakOk returns a tuple with the Weak field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetWeak

`func (o *Metrics200ResponseEntityTag) SetWeak(v bool)`

SetWeak sets Weak field to given value.

### HasWeak

`func (o *Metrics200ResponseEntityTag) HasWeak() bool`

HasWeak returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


