# DpNetworkModifyArguments

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ClusterIpAddress** | Pointer to **string** |                          IP address for the cluster on the network interface.                      | [optional] 
**PrefixLength** | Pointer to **int32** |                          IP address prefix length for the interface.                      | [optional] 
**Gateway** | Pointer to **string** |                          IPv4 or IPv6 gateway address for the network interface.                      | [optional] 
**VlanId** | Pointer to **int32** |  Indicates the VLAN this File Interface part of.  | [optional] 
**NodeAddresses** | Pointer to **[]string** |                          The list of addresses for the nodes, starting with node 1.                      | [optional] 
**Name** | Pointer to **string** |                          User friendly name of the data protection network; cluster unique                      | [optional] 
**NetworkDevices** | Pointer to [**[]NetworkDeviceArguments**](NetworkDeviceArguments.md) |                          Modify network devices list                      | [optional] 

## Methods

### NewDpNetworkModifyArguments

`func NewDpNetworkModifyArguments() *DpNetworkModifyArguments`

NewDpNetworkModifyArguments instantiates a new DpNetworkModifyArguments object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewDpNetworkModifyArgumentsWithDefaults

`func NewDpNetworkModifyArgumentsWithDefaults() *DpNetworkModifyArguments`

NewDpNetworkModifyArgumentsWithDefaults instantiates a new DpNetworkModifyArguments object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetClusterIpAddress

`func (o *DpNetworkModifyArguments) GetClusterIpAddress() string`

GetClusterIpAddress returns the ClusterIpAddress field if non-nil, zero value otherwise.

### GetClusterIpAddressOk

`func (o *DpNetworkModifyArguments) GetClusterIpAddressOk() (*string, bool)`

GetClusterIpAddressOk returns a tuple with the ClusterIpAddress field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetClusterIpAddress

`func (o *DpNetworkModifyArguments) SetClusterIpAddress(v string)`

SetClusterIpAddress sets ClusterIpAddress field to given value.

### HasClusterIpAddress

`func (o *DpNetworkModifyArguments) HasClusterIpAddress() bool`

HasClusterIpAddress returns a boolean if a field has been set.

### GetPrefixLength

`func (o *DpNetworkModifyArguments) GetPrefixLength() int32`

GetPrefixLength returns the PrefixLength field if non-nil, zero value otherwise.

### GetPrefixLengthOk

`func (o *DpNetworkModifyArguments) GetPrefixLengthOk() (*int32, bool)`

GetPrefixLengthOk returns a tuple with the PrefixLength field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetPrefixLength

`func (o *DpNetworkModifyArguments) SetPrefixLength(v int32)`

SetPrefixLength sets PrefixLength field to given value.

### HasPrefixLength

`func (o *DpNetworkModifyArguments) HasPrefixLength() bool`

HasPrefixLength returns a boolean if a field has been set.

### GetGateway

`func (o *DpNetworkModifyArguments) GetGateway() string`

GetGateway returns the Gateway field if non-nil, zero value otherwise.

### GetGatewayOk

`func (o *DpNetworkModifyArguments) GetGatewayOk() (*string, bool)`

GetGatewayOk returns a tuple with the Gateway field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetGateway

`func (o *DpNetworkModifyArguments) SetGateway(v string)`

SetGateway sets Gateway field to given value.

### HasGateway

`func (o *DpNetworkModifyArguments) HasGateway() bool`

HasGateway returns a boolean if a field has been set.

### GetVlanId

`func (o *DpNetworkModifyArguments) GetVlanId() int32`

GetVlanId returns the VlanId field if non-nil, zero value otherwise.

### GetVlanIdOk

`func (o *DpNetworkModifyArguments) GetVlanIdOk() (*int32, bool)`

GetVlanIdOk returns a tuple with the VlanId field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetVlanId

`func (o *DpNetworkModifyArguments) SetVlanId(v int32)`

SetVlanId sets VlanId field to given value.

### HasVlanId

`func (o *DpNetworkModifyArguments) HasVlanId() bool`

HasVlanId returns a boolean if a field has been set.

### GetNodeAddresses

`func (o *DpNetworkModifyArguments) GetNodeAddresses() []string`

GetNodeAddresses returns the NodeAddresses field if non-nil, zero value otherwise.

### GetNodeAddressesOk

`func (o *DpNetworkModifyArguments) GetNodeAddressesOk() (*[]string, bool)`

GetNodeAddressesOk returns a tuple with the NodeAddresses field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetNodeAddresses

`func (o *DpNetworkModifyArguments) SetNodeAddresses(v []string)`

SetNodeAddresses sets NodeAddresses field to given value.

### HasNodeAddresses

`func (o *DpNetworkModifyArguments) HasNodeAddresses() bool`

HasNodeAddresses returns a boolean if a field has been set.

### GetName

`func (o *DpNetworkModifyArguments) GetName() string`

GetName returns the Name field if non-nil, zero value otherwise.

### GetNameOk

`func (o *DpNetworkModifyArguments) GetNameOk() (*string, bool)`

GetNameOk returns a tuple with the Name field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetName

`func (o *DpNetworkModifyArguments) SetName(v string)`

SetName sets Name field to given value.

### HasName

`func (o *DpNetworkModifyArguments) HasName() bool`

HasName returns a boolean if a field has been set.

### GetNetworkDevices

`func (o *DpNetworkModifyArguments) GetNetworkDevices() []NetworkDeviceArguments`

GetNetworkDevices returns the NetworkDevices field if non-nil, zero value otherwise.

### GetNetworkDevicesOk

`func (o *DpNetworkModifyArguments) GetNetworkDevicesOk() (*[]NetworkDeviceArguments, bool)`

GetNetworkDevicesOk returns a tuple with the NetworkDevices field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetNetworkDevices

`func (o *DpNetworkModifyArguments) SetNetworkDevices(v []NetworkDeviceArguments)`

SetNetworkDevices sets NetworkDevices field to given value.

### HasNetworkDevices

`func (o *DpNetworkModifyArguments) HasNetworkDevices() bool`

HasNetworkDevices returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


