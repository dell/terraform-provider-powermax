# MigrationCreate

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ExecutionOption** | Pointer to **string** |  | [optional] [default to "SYNCHRONOUS"]
**OtherArrayId** | **string** | The System ID for the target of the migration | 
**SrpId** | Pointer to **string** | The name of the migration session target System SRP. | [optional] 
**PortGroupId** | Pointer to **string** | The name of the migration session target System port group. | [optional] 
**NoCompression** | Pointer to **bool** | Create the target Storage Group without compression. Only supported when the target System and SRP support compression. | [optional] 
**PreCopy** | Pointer to **bool** | Create the migration using the precopy option. Only supported when both the source and target System support create with precopy. | [optional] 
**Offline** | Pointer to **bool** | Userd to create a minimally disruptive migration | [optional] 
**MoveIdentity** | Pointer to **bool** | The same device identities as used to access the devices on the source System will be used by the target System devices. | [optional] 
**Validate** | Pointer to **bool** | Just run the validation to see if the Migration can be created. Don&#39;t actually run the create itself. | [optional] 

## Methods

### NewMigrationCreate

`func NewMigrationCreate(otherArrayId string, ) *MigrationCreate`

NewMigrationCreate instantiates a new MigrationCreate object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewMigrationCreateWithDefaults

`func NewMigrationCreateWithDefaults() *MigrationCreate`

NewMigrationCreateWithDefaults instantiates a new MigrationCreate object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetExecutionOption

`func (o *MigrationCreate) GetExecutionOption() string`

GetExecutionOption returns the ExecutionOption field if non-nil, zero value otherwise.

### GetExecutionOptionOk

`func (o *MigrationCreate) GetExecutionOptionOk() (*string, bool)`

GetExecutionOptionOk returns a tuple with the ExecutionOption field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetExecutionOption

`func (o *MigrationCreate) SetExecutionOption(v string)`

SetExecutionOption sets ExecutionOption field to given value.

### HasExecutionOption

`func (o *MigrationCreate) HasExecutionOption() bool`

HasExecutionOption returns a boolean if a field has been set.

### GetOtherArrayId

`func (o *MigrationCreate) GetOtherArrayId() string`

GetOtherArrayId returns the OtherArrayId field if non-nil, zero value otherwise.

### GetOtherArrayIdOk

`func (o *MigrationCreate) GetOtherArrayIdOk() (*string, bool)`

GetOtherArrayIdOk returns a tuple with the OtherArrayId field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetOtherArrayId

`func (o *MigrationCreate) SetOtherArrayId(v string)`

SetOtherArrayId sets OtherArrayId field to given value.


### GetSrpId

`func (o *MigrationCreate) GetSrpId() string`

GetSrpId returns the SrpId field if non-nil, zero value otherwise.

### GetSrpIdOk

`func (o *MigrationCreate) GetSrpIdOk() (*string, bool)`

GetSrpIdOk returns a tuple with the SrpId field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetSrpId

`func (o *MigrationCreate) SetSrpId(v string)`

SetSrpId sets SrpId field to given value.

### HasSrpId

`func (o *MigrationCreate) HasSrpId() bool`

HasSrpId returns a boolean if a field has been set.

### GetPortGroupId

`func (o *MigrationCreate) GetPortGroupId() string`

GetPortGroupId returns the PortGroupId field if non-nil, zero value otherwise.

### GetPortGroupIdOk

`func (o *MigrationCreate) GetPortGroupIdOk() (*string, bool)`

GetPortGroupIdOk returns a tuple with the PortGroupId field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetPortGroupId

`func (o *MigrationCreate) SetPortGroupId(v string)`

SetPortGroupId sets PortGroupId field to given value.

### HasPortGroupId

`func (o *MigrationCreate) HasPortGroupId() bool`

HasPortGroupId returns a boolean if a field has been set.

### GetNoCompression

`func (o *MigrationCreate) GetNoCompression() bool`

GetNoCompression returns the NoCompression field if non-nil, zero value otherwise.

### GetNoCompressionOk

`func (o *MigrationCreate) GetNoCompressionOk() (*bool, bool)`

GetNoCompressionOk returns a tuple with the NoCompression field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetNoCompression

`func (o *MigrationCreate) SetNoCompression(v bool)`

SetNoCompression sets NoCompression field to given value.

### HasNoCompression

`func (o *MigrationCreate) HasNoCompression() bool`

HasNoCompression returns a boolean if a field has been set.

### GetPreCopy

`func (o *MigrationCreate) GetPreCopy() bool`

GetPreCopy returns the PreCopy field if non-nil, zero value otherwise.

### GetPreCopyOk

`func (o *MigrationCreate) GetPreCopyOk() (*bool, bool)`

GetPreCopyOk returns a tuple with the PreCopy field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetPreCopy

`func (o *MigrationCreate) SetPreCopy(v bool)`

SetPreCopy sets PreCopy field to given value.

### HasPreCopy

`func (o *MigrationCreate) HasPreCopy() bool`

HasPreCopy returns a boolean if a field has been set.

### GetOffline

`func (o *MigrationCreate) GetOffline() bool`

GetOffline returns the Offline field if non-nil, zero value otherwise.

### GetOfflineOk

`func (o *MigrationCreate) GetOfflineOk() (*bool, bool)`

GetOfflineOk returns a tuple with the Offline field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetOffline

`func (o *MigrationCreate) SetOffline(v bool)`

SetOffline sets Offline field to given value.

### HasOffline

`func (o *MigrationCreate) HasOffline() bool`

HasOffline returns a boolean if a field has been set.

### GetMoveIdentity

`func (o *MigrationCreate) GetMoveIdentity() bool`

GetMoveIdentity returns the MoveIdentity field if non-nil, zero value otherwise.

### GetMoveIdentityOk

`func (o *MigrationCreate) GetMoveIdentityOk() (*bool, bool)`

GetMoveIdentityOk returns a tuple with the MoveIdentity field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetMoveIdentity

`func (o *MigrationCreate) SetMoveIdentity(v bool)`

SetMoveIdentity sets MoveIdentity field to given value.

### HasMoveIdentity

`func (o *MigrationCreate) HasMoveIdentity() bool`

HasMoveIdentity returns a boolean if a field has been set.

### GetValidate

`func (o *MigrationCreate) GetValidate() bool`

GetValidate returns the Validate field if non-nil, zero value otherwise.

### GetValidateOk

`func (o *MigrationCreate) GetValidateOk() (*bool, bool)`

GetValidateOk returns a tuple with the Validate field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetValidate

`func (o *MigrationCreate) SetValidate(v bool)`

SetValidate sets Validate field to given value.

### HasValidate

`func (o *MigrationCreate) HasValidate() bool`

HasValidate returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


