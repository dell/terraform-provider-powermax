# ComplianceErrorMessage

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Time** | **string** | The time of the error message | 
**ErrorMessage** | **string** | The compliance error message | 

## Methods

### NewComplianceErrorMessage

`func NewComplianceErrorMessage(time string, errorMessage string, ) *ComplianceErrorMessage`

NewComplianceErrorMessage instantiates a new ComplianceErrorMessage object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewComplianceErrorMessageWithDefaults

`func NewComplianceErrorMessageWithDefaults() *ComplianceErrorMessage`

NewComplianceErrorMessageWithDefaults instantiates a new ComplianceErrorMessage object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetTime

`func (o *ComplianceErrorMessage) GetTime() string`

GetTime returns the Time field if non-nil, zero value otherwise.

### GetTimeOk

`func (o *ComplianceErrorMessage) GetTimeOk() (*string, bool)`

GetTimeOk returns a tuple with the Time field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetTime

`func (o *ComplianceErrorMessage) SetTime(v string)`

SetTime sets Time field to given value.


### GetErrorMessage

`func (o *ComplianceErrorMessage) GetErrorMessage() string`

GetErrorMessage returns the ErrorMessage field if non-nil, zero value otherwise.

### GetErrorMessageOk

`func (o *ComplianceErrorMessage) GetErrorMessageOk() (*string, bool)`

GetErrorMessageOk returns a tuple with the ErrorMessage field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetErrorMessage

`func (o *ComplianceErrorMessage) SetErrorMessage(v string)`

SetErrorMessage sets ErrorMessage field to given value.



[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


