# AutoPortGroupParam

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ExecutionOption** | Pointer to **string** |  | [optional] [default to "SYNCHRONOUS"]
**PortGroupId** | Pointer to **string** | Port group name. If not specified, it will be generated from storage group name. | [optional] 
**NumOfPorts** | Pointer to **int32** | Number of ports for new port group. Used for new port groups only. | [optional] 
**PortGroupPolicy** | Pointer to **string** | Create new or use existing port group.   Enumeration values: * **CreateNewPortGroup** -                          Create new port group for request. (Automatic port selection is only available                         for Fibre (SCSI FC). If host initiators are detected to be iSCSI or NVME TCP, ports                         will not be selected. A CreatePortGroupParam will be generated with a portGroupId,                         but an empty symmetrixPortKey list. The symmetrixPortKey list will need to be manually                         populated before attempting to create the masking view.)                      * **UseExistingPortGroup** - Select from existing port groups.  | [optional] [default to "\"CreateNewPortGroup\""]
**PortSelectionPolicy** | Pointer to **string** | Select ports or port group based on utilization only or consider existing zoning as well.   Enumeration values: * **UtilizationBased** - Select least utilized ports or port group. * **ZoningBased** - Select least utilized ports or port group that has existing zoning in place for specified host initiators.  | [optional] [default to "\"UtilizationBased\""]

## Methods

### NewAutoPortGroupParam

`func NewAutoPortGroupParam() *AutoPortGroupParam`

NewAutoPortGroupParam instantiates a new AutoPortGroupParam object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewAutoPortGroupParamWithDefaults

`func NewAutoPortGroupParamWithDefaults() *AutoPortGroupParam`

NewAutoPortGroupParamWithDefaults instantiates a new AutoPortGroupParam object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetExecutionOption

`func (o *AutoPortGroupParam) GetExecutionOption() string`

GetExecutionOption returns the ExecutionOption field if non-nil, zero value otherwise.

### GetExecutionOptionOk

`func (o *AutoPortGroupParam) GetExecutionOptionOk() (*string, bool)`

GetExecutionOptionOk returns a tuple with the ExecutionOption field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetExecutionOption

`func (o *AutoPortGroupParam) SetExecutionOption(v string)`

SetExecutionOption sets ExecutionOption field to given value.

### HasExecutionOption

`func (o *AutoPortGroupParam) HasExecutionOption() bool`

HasExecutionOption returns a boolean if a field has been set.

### GetPortGroupId

`func (o *AutoPortGroupParam) GetPortGroupId() string`

GetPortGroupId returns the PortGroupId field if non-nil, zero value otherwise.

### GetPortGroupIdOk

`func (o *AutoPortGroupParam) GetPortGroupIdOk() (*string, bool)`

GetPortGroupIdOk returns a tuple with the PortGroupId field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetPortGroupId

`func (o *AutoPortGroupParam) SetPortGroupId(v string)`

SetPortGroupId sets PortGroupId field to given value.

### HasPortGroupId

`func (o *AutoPortGroupParam) HasPortGroupId() bool`

HasPortGroupId returns a boolean if a field has been set.

### GetNumOfPorts

`func (o *AutoPortGroupParam) GetNumOfPorts() int32`

GetNumOfPorts returns the NumOfPorts field if non-nil, zero value otherwise.

### GetNumOfPortsOk

`func (o *AutoPortGroupParam) GetNumOfPortsOk() (*int32, bool)`

GetNumOfPortsOk returns a tuple with the NumOfPorts field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetNumOfPorts

`func (o *AutoPortGroupParam) SetNumOfPorts(v int32)`

SetNumOfPorts sets NumOfPorts field to given value.

### HasNumOfPorts

`func (o *AutoPortGroupParam) HasNumOfPorts() bool`

HasNumOfPorts returns a boolean if a field has been set.

### GetPortGroupPolicy

`func (o *AutoPortGroupParam) GetPortGroupPolicy() string`

GetPortGroupPolicy returns the PortGroupPolicy field if non-nil, zero value otherwise.

### GetPortGroupPolicyOk

`func (o *AutoPortGroupParam) GetPortGroupPolicyOk() (*string, bool)`

GetPortGroupPolicyOk returns a tuple with the PortGroupPolicy field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetPortGroupPolicy

`func (o *AutoPortGroupParam) SetPortGroupPolicy(v string)`

SetPortGroupPolicy sets PortGroupPolicy field to given value.

### HasPortGroupPolicy

`func (o *AutoPortGroupParam) HasPortGroupPolicy() bool`

HasPortGroupPolicy returns a boolean if a field has been set.

### GetPortSelectionPolicy

`func (o *AutoPortGroupParam) GetPortSelectionPolicy() string`

GetPortSelectionPolicy returns the PortSelectionPolicy field if non-nil, zero value otherwise.

### GetPortSelectionPolicyOk

`func (o *AutoPortGroupParam) GetPortSelectionPolicyOk() (*string, bool)`

GetPortSelectionPolicyOk returns a tuple with the PortSelectionPolicy field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetPortSelectionPolicy

`func (o *AutoPortGroupParam) SetPortSelectionPolicy(v string)`

SetPortSelectionPolicy sets PortSelectionPolicy field to given value.

### HasPortSelectionPolicy

`func (o *AutoPortGroupParam) HasPortSelectionPolicy() bool`

HasPortSelectionPolicy returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


