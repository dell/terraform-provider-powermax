# CloudiqDetails

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**UnisphereRegistered** | **bool** | unisphere_registered | 
**SendDataToCloudiq** | **bool** | send_data_to_cloudiq | 
**CloudiqSymConnectionList** | Pointer to [**CloudiqSymConnectionList**](CloudiqSymConnectionList.md) |  | [optional] 

## Methods

### NewCloudiqDetails

`func NewCloudiqDetails(unisphereRegistered bool, sendDataToCloudiq bool, ) *CloudiqDetails`

NewCloudiqDetails instantiates a new CloudiqDetails object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewCloudiqDetailsWithDefaults

`func NewCloudiqDetailsWithDefaults() *CloudiqDetails`

NewCloudiqDetailsWithDefaults instantiates a new CloudiqDetails object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetUnisphereRegistered

`func (o *CloudiqDetails) GetUnisphereRegistered() bool`

GetUnisphereRegistered returns the UnisphereRegistered field if non-nil, zero value otherwise.

### GetUnisphereRegisteredOk

`func (o *CloudiqDetails) GetUnisphereRegisteredOk() (*bool, bool)`

GetUnisphereRegisteredOk returns a tuple with the UnisphereRegistered field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetUnisphereRegistered

`func (o *CloudiqDetails) SetUnisphereRegistered(v bool)`

SetUnisphereRegistered sets UnisphereRegistered field to given value.


### GetSendDataToCloudiq

`func (o *CloudiqDetails) GetSendDataToCloudiq() bool`

GetSendDataToCloudiq returns the SendDataToCloudiq field if non-nil, zero value otherwise.

### GetSendDataToCloudiqOk

`func (o *CloudiqDetails) GetSendDataToCloudiqOk() (*bool, bool)`

GetSendDataToCloudiqOk returns a tuple with the SendDataToCloudiq field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetSendDataToCloudiq

`func (o *CloudiqDetails) SetSendDataToCloudiq(v bool)`

SetSendDataToCloudiq sets SendDataToCloudiq field to given value.


### GetCloudiqSymConnectionList

`func (o *CloudiqDetails) GetCloudiqSymConnectionList() CloudiqSymConnectionList`

GetCloudiqSymConnectionList returns the CloudiqSymConnectionList field if non-nil, zero value otherwise.

### GetCloudiqSymConnectionListOk

`func (o *CloudiqDetails) GetCloudiqSymConnectionListOk() (*CloudiqSymConnectionList, bool)`

GetCloudiqSymConnectionListOk returns a tuple with the CloudiqSymConnectionList field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetCloudiqSymConnectionList

`func (o *CloudiqDetails) SetCloudiqSymConnectionList(v CloudiqSymConnectionList)`

SetCloudiqSymConnectionList sets CloudiqSymConnectionList field to given value.

### HasCloudiqSymConnectionList

`func (o *CloudiqDetails) HasCloudiqSymConnectionList() bool`

HasCloudiqSymConnectionList returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


