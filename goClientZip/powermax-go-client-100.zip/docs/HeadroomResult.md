# HeadroomResult

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**GbHeadroom** | Pointer to [**[]GbHeadroom**](GbHeadroom.md) | gbHeadroom | [optional] 
**IopsHeadroom** | Pointer to **float64** | Headroom in IOPS for the System. This headroom is available only for all flash systems. | [optional] 

## Methods

### NewHeadroomResult

`func NewHeadroomResult() *HeadroomResult`

NewHeadroomResult instantiates a new HeadroomResult object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewHeadroomResultWithDefaults

`func NewHeadroomResultWithDefaults() *HeadroomResult`

NewHeadroomResultWithDefaults instantiates a new HeadroomResult object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetGbHeadroom

`func (o *HeadroomResult) GetGbHeadroom() []GbHeadroom`

GetGbHeadroom returns the GbHeadroom field if non-nil, zero value otherwise.

### GetGbHeadroomOk

`func (o *HeadroomResult) GetGbHeadroomOk() (*[]GbHeadroom, bool)`

GetGbHeadroomOk returns a tuple with the GbHeadroom field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetGbHeadroom

`func (o *HeadroomResult) SetGbHeadroom(v []GbHeadroom)`

SetGbHeadroom sets GbHeadroom field to given value.

### HasGbHeadroom

`func (o *HeadroomResult) HasGbHeadroom() bool`

HasGbHeadroom returns a boolean if a field has been set.

### GetIopsHeadroom

`func (o *HeadroomResult) GetIopsHeadroom() float64`

GetIopsHeadroom returns the IopsHeadroom field if non-nil, zero value otherwise.

### GetIopsHeadroomOk

`func (o *HeadroomResult) GetIopsHeadroomOk() (*float64, bool)`

GetIopsHeadroomOk returns a tuple with the IopsHeadroom field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetIopsHeadroom

`func (o *HeadroomResult) SetIopsHeadroom(v float64)`

SetIopsHeadroom sets IopsHeadroom field to given value.

### HasIopsHeadroom

`func (o *HeadroomResult) HasIopsHeadroom() bool`

HasIopsHeadroom returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


