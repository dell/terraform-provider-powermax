# DhsmServerCreateArguments

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**NasServer** | **string** |                          Identifier of the parent NAS server.                      | 
**Username** | **string** |                          User name for authentication to the DHSM server.                      | 
**Password** | **string** |                          The password for authentication to the DHSM server. See &#39;username&#39;.                      | 

## Methods

### NewDhsmServerCreateArguments

`func NewDhsmServerCreateArguments(nasServer string, username string, password string, ) *DhsmServerCreateArguments`

NewDhsmServerCreateArguments instantiates a new DhsmServerCreateArguments object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewDhsmServerCreateArgumentsWithDefaults

`func NewDhsmServerCreateArgumentsWithDefaults() *DhsmServerCreateArguments`

NewDhsmServerCreateArgumentsWithDefaults instantiates a new DhsmServerCreateArguments object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetNasServer

`func (o *DhsmServerCreateArguments) GetNasServer() string`

GetNasServer returns the NasServer field if non-nil, zero value otherwise.

### GetNasServerOk

`func (o *DhsmServerCreateArguments) GetNasServerOk() (*string, bool)`

GetNasServerOk returns a tuple with the NasServer field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetNasServer

`func (o *DhsmServerCreateArguments) SetNasServer(v string)`

SetNasServer sets NasServer field to given value.


### GetUsername

`func (o *DhsmServerCreateArguments) GetUsername() string`

GetUsername returns the Username field if non-nil, zero value otherwise.

### GetUsernameOk

`func (o *DhsmServerCreateArguments) GetUsernameOk() (*string, bool)`

GetUsernameOk returns a tuple with the Username field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetUsername

`func (o *DhsmServerCreateArguments) SetUsername(v string)`

SetUsername sets Username field to given value.


### GetPassword

`func (o *DhsmServerCreateArguments) GetPassword() string`

GetPassword returns the Password field if non-nil, zero value otherwise.

### GetPasswordOk

`func (o *DhsmServerCreateArguments) GetPasswordOk() (*string, bool)`

GetPasswordOk returns a tuple with the Password field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetPassword

`func (o *DhsmServerCreateArguments) SetPassword(v string)`

SetPassword sets Password field to given value.



[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


