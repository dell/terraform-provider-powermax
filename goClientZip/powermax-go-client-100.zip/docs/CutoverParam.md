# CutoverParam

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Force** | Pointer to **bool** | The force option for the action | [optional] 
**Symforce** | Pointer to **bool** | The symforce option for the action | [optional] 

## Methods

### NewCutoverParam

`func NewCutoverParam() *CutoverParam`

NewCutoverParam instantiates a new CutoverParam object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewCutoverParamWithDefaults

`func NewCutoverParamWithDefaults() *CutoverParam`

NewCutoverParamWithDefaults instantiates a new CutoverParam object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetForce

`func (o *CutoverParam) GetForce() bool`

GetForce returns the Force field if non-nil, zero value otherwise.

### GetForceOk

`func (o *CutoverParam) GetForceOk() (*bool, bool)`

GetForceOk returns a tuple with the Force field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetForce

`func (o *CutoverParam) SetForce(v bool)`

SetForce sets Force field to given value.

### HasForce

`func (o *CutoverParam) HasForce() bool`

HasForce returns a boolean if a field has been set.

### GetSymforce

`func (o *CutoverParam) GetSymforce() bool`

GetSymforce returns the Symforce field if non-nil, zero value otherwise.

### GetSymforceOk

`func (o *CutoverParam) GetSymforceOk() (*bool, bool)`

GetSymforceOk returns a tuple with the Symforce field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetSymforce

`func (o *CutoverParam) SetSymforce(v bool)`

SetSymforce sets Symforce field to given value.

### HasSymforce

`func (o *CutoverParam) HasSymforce() bool`

HasSymforce returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


