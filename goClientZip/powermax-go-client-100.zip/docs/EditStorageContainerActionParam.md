# EditStorageContainerActionParam

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**RemoveStorageResourceParam** | Pointer to [**RemoveStorageResourceParam**](RemoveStorageResourceParam.md) |  | [optional] 
**AddNewStorageResourceParam** | Pointer to [**AddNewStorageResourceParam**](AddNewStorageResourceParam.md) |  | [optional] 
**EditStorageContainerAttributesParam** | Pointer to [**EditStorageContainerAttributesParam**](EditStorageContainerAttributesParam.md) |  | [optional] 

## Methods

### NewEditStorageContainerActionParam

`func NewEditStorageContainerActionParam() *EditStorageContainerActionParam`

NewEditStorageContainerActionParam instantiates a new EditStorageContainerActionParam object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewEditStorageContainerActionParamWithDefaults

`func NewEditStorageContainerActionParamWithDefaults() *EditStorageContainerActionParam`

NewEditStorageContainerActionParamWithDefaults instantiates a new EditStorageContainerActionParam object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetRemoveStorageResourceParam

`func (o *EditStorageContainerActionParam) GetRemoveStorageResourceParam() RemoveStorageResourceParam`

GetRemoveStorageResourceParam returns the RemoveStorageResourceParam field if non-nil, zero value otherwise.

### GetRemoveStorageResourceParamOk

`func (o *EditStorageContainerActionParam) GetRemoveStorageResourceParamOk() (*RemoveStorageResourceParam, bool)`

GetRemoveStorageResourceParamOk returns a tuple with the RemoveStorageResourceParam field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetRemoveStorageResourceParam

`func (o *EditStorageContainerActionParam) SetRemoveStorageResourceParam(v RemoveStorageResourceParam)`

SetRemoveStorageResourceParam sets RemoveStorageResourceParam field to given value.

### HasRemoveStorageResourceParam

`func (o *EditStorageContainerActionParam) HasRemoveStorageResourceParam() bool`

HasRemoveStorageResourceParam returns a boolean if a field has been set.

### GetAddNewStorageResourceParam

`func (o *EditStorageContainerActionParam) GetAddNewStorageResourceParam() AddNewStorageResourceParam`

GetAddNewStorageResourceParam returns the AddNewStorageResourceParam field if non-nil, zero value otherwise.

### GetAddNewStorageResourceParamOk

`func (o *EditStorageContainerActionParam) GetAddNewStorageResourceParamOk() (*AddNewStorageResourceParam, bool)`

GetAddNewStorageResourceParamOk returns a tuple with the AddNewStorageResourceParam field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetAddNewStorageResourceParam

`func (o *EditStorageContainerActionParam) SetAddNewStorageResourceParam(v AddNewStorageResourceParam)`

SetAddNewStorageResourceParam sets AddNewStorageResourceParam field to given value.

### HasAddNewStorageResourceParam

`func (o *EditStorageContainerActionParam) HasAddNewStorageResourceParam() bool`

HasAddNewStorageResourceParam returns a boolean if a field has been set.

### GetEditStorageContainerAttributesParam

`func (o *EditStorageContainerActionParam) GetEditStorageContainerAttributesParam() EditStorageContainerAttributesParam`

GetEditStorageContainerAttributesParam returns the EditStorageContainerAttributesParam field if non-nil, zero value otherwise.

### GetEditStorageContainerAttributesParamOk

`func (o *EditStorageContainerActionParam) GetEditStorageContainerAttributesParamOk() (*EditStorageContainerAttributesParam, bool)`

GetEditStorageContainerAttributesParamOk returns a tuple with the EditStorageContainerAttributesParam field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetEditStorageContainerAttributesParam

`func (o *EditStorageContainerActionParam) SetEditStorageContainerAttributesParam(v EditStorageContainerAttributesParam)`

SetEditStorageContainerAttributesParam sets EditStorageContainerAttributesParam field to given value.

### HasEditStorageContainerAttributesParam

`func (o *EditStorageContainerActionParam) HasEditStorageContainerAttributesParam() bool`

HasEditStorageContainerAttributesParam returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


