# CloudProvider

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**CloudProviderId** | **string** | The name of the Cloud Provider | 
**Uuid** | Pointer to **string** | The UUID Cloud Provider | [optional] 
**State** | Pointer to **string** | The current state of the Cloud Provider | [optional] 
**Type** | Pointer to **string** | The Cloud Provider Type [AZURE,ECS etc.. ] | [optional] 
**UsedCapacityGb** | Pointer to **float64** | The Total Cloud Provider Used Capacity in GB | [optional] 
**NumOfCloudPolicies** | Pointer to **int32** | The Total Number of Cloud Policies associated with the Cloud Provider | [optional] 
**NumOfCloudSnapshots** | Pointer to **int32** | The Total Number of Cloud Snapshots associated with the Cloud Provider | [optional] 
**NumOfCloudStorageGroups** | Pointer to **int32** | The total number of Cloud Storage Groups associated with the Cloud Provider | [optional] 
**CloudProviderConnectionDetails** | [**CloudProviderConnectionDetails**](CloudProviderConnectionDetails.md) |  | 

## Methods

### NewCloudProvider

`func NewCloudProvider(cloudProviderId string, cloudProviderConnectionDetails CloudProviderConnectionDetails, ) *CloudProvider`

NewCloudProvider instantiates a new CloudProvider object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewCloudProviderWithDefaults

`func NewCloudProviderWithDefaults() *CloudProvider`

NewCloudProviderWithDefaults instantiates a new CloudProvider object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetCloudProviderId

`func (o *CloudProvider) GetCloudProviderId() string`

GetCloudProviderId returns the CloudProviderId field if non-nil, zero value otherwise.

### GetCloudProviderIdOk

`func (o *CloudProvider) GetCloudProviderIdOk() (*string, bool)`

GetCloudProviderIdOk returns a tuple with the CloudProviderId field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetCloudProviderId

`func (o *CloudProvider) SetCloudProviderId(v string)`

SetCloudProviderId sets CloudProviderId field to given value.


### GetUuid

`func (o *CloudProvider) GetUuid() string`

GetUuid returns the Uuid field if non-nil, zero value otherwise.

### GetUuidOk

`func (o *CloudProvider) GetUuidOk() (*string, bool)`

GetUuidOk returns a tuple with the Uuid field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetUuid

`func (o *CloudProvider) SetUuid(v string)`

SetUuid sets Uuid field to given value.

### HasUuid

`func (o *CloudProvider) HasUuid() bool`

HasUuid returns a boolean if a field has been set.

### GetState

`func (o *CloudProvider) GetState() string`

GetState returns the State field if non-nil, zero value otherwise.

### GetStateOk

`func (o *CloudProvider) GetStateOk() (*string, bool)`

GetStateOk returns a tuple with the State field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetState

`func (o *CloudProvider) SetState(v string)`

SetState sets State field to given value.

### HasState

`func (o *CloudProvider) HasState() bool`

HasState returns a boolean if a field has been set.

### GetType

`func (o *CloudProvider) GetType() string`

GetType returns the Type field if non-nil, zero value otherwise.

### GetTypeOk

`func (o *CloudProvider) GetTypeOk() (*string, bool)`

GetTypeOk returns a tuple with the Type field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetType

`func (o *CloudProvider) SetType(v string)`

SetType sets Type field to given value.

### HasType

`func (o *CloudProvider) HasType() bool`

HasType returns a boolean if a field has been set.

### GetUsedCapacityGb

`func (o *CloudProvider) GetUsedCapacityGb() float64`

GetUsedCapacityGb returns the UsedCapacityGb field if non-nil, zero value otherwise.

### GetUsedCapacityGbOk

`func (o *CloudProvider) GetUsedCapacityGbOk() (*float64, bool)`

GetUsedCapacityGbOk returns a tuple with the UsedCapacityGb field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetUsedCapacityGb

`func (o *CloudProvider) SetUsedCapacityGb(v float64)`

SetUsedCapacityGb sets UsedCapacityGb field to given value.

### HasUsedCapacityGb

`func (o *CloudProvider) HasUsedCapacityGb() bool`

HasUsedCapacityGb returns a boolean if a field has been set.

### GetNumOfCloudPolicies

`func (o *CloudProvider) GetNumOfCloudPolicies() int32`

GetNumOfCloudPolicies returns the NumOfCloudPolicies field if non-nil, zero value otherwise.

### GetNumOfCloudPoliciesOk

`func (o *CloudProvider) GetNumOfCloudPoliciesOk() (*int32, bool)`

GetNumOfCloudPoliciesOk returns a tuple with the NumOfCloudPolicies field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetNumOfCloudPolicies

`func (o *CloudProvider) SetNumOfCloudPolicies(v int32)`

SetNumOfCloudPolicies sets NumOfCloudPolicies field to given value.

### HasNumOfCloudPolicies

`func (o *CloudProvider) HasNumOfCloudPolicies() bool`

HasNumOfCloudPolicies returns a boolean if a field has been set.

### GetNumOfCloudSnapshots

`func (o *CloudProvider) GetNumOfCloudSnapshots() int32`

GetNumOfCloudSnapshots returns the NumOfCloudSnapshots field if non-nil, zero value otherwise.

### GetNumOfCloudSnapshotsOk

`func (o *CloudProvider) GetNumOfCloudSnapshotsOk() (*int32, bool)`

GetNumOfCloudSnapshotsOk returns a tuple with the NumOfCloudSnapshots field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetNumOfCloudSnapshots

`func (o *CloudProvider) SetNumOfCloudSnapshots(v int32)`

SetNumOfCloudSnapshots sets NumOfCloudSnapshots field to given value.

### HasNumOfCloudSnapshots

`func (o *CloudProvider) HasNumOfCloudSnapshots() bool`

HasNumOfCloudSnapshots returns a boolean if a field has been set.

### GetNumOfCloudStorageGroups

`func (o *CloudProvider) GetNumOfCloudStorageGroups() int32`

GetNumOfCloudStorageGroups returns the NumOfCloudStorageGroups field if non-nil, zero value otherwise.

### GetNumOfCloudStorageGroupsOk

`func (o *CloudProvider) GetNumOfCloudStorageGroupsOk() (*int32, bool)`

GetNumOfCloudStorageGroupsOk returns a tuple with the NumOfCloudStorageGroups field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetNumOfCloudStorageGroups

`func (o *CloudProvider) SetNumOfCloudStorageGroups(v int32)`

SetNumOfCloudStorageGroups sets NumOfCloudStorageGroups field to given value.

### HasNumOfCloudStorageGroups

`func (o *CloudProvider) HasNumOfCloudStorageGroups() bool`

HasNumOfCloudStorageGroups returns a boolean if a field has been set.

### GetCloudProviderConnectionDetails

`func (o *CloudProvider) GetCloudProviderConnectionDetails() CloudProviderConnectionDetails`

GetCloudProviderConnectionDetails returns the CloudProviderConnectionDetails field if non-nil, zero value otherwise.

### GetCloudProviderConnectionDetailsOk

`func (o *CloudProvider) GetCloudProviderConnectionDetailsOk() (*CloudProviderConnectionDetails, bool)`

GetCloudProviderConnectionDetailsOk returns a tuple with the CloudProviderConnectionDetails field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetCloudProviderConnectionDetails

`func (o *CloudProvider) SetCloudProviderConnectionDetails(v CloudProviderConnectionDetails)`

SetCloudProviderConnectionDetails sets CloudProviderConnectionDetails field to given value.



[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


