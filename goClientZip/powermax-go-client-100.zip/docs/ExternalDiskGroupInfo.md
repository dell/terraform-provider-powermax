# ExternalDiskGroupInfo

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**FirstAvailableDate** | Pointer to **int64** |  | [optional] 
**LastAvailableDate** | Pointer to **int64** |  | [optional] 
**DiskGroupId** | **string** | diskGroupId | 

## Methods

### NewExternalDiskGroupInfo

`func NewExternalDiskGroupInfo(diskGroupId string, ) *ExternalDiskGroupInfo`

NewExternalDiskGroupInfo instantiates a new ExternalDiskGroupInfo object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewExternalDiskGroupInfoWithDefaults

`func NewExternalDiskGroupInfoWithDefaults() *ExternalDiskGroupInfo`

NewExternalDiskGroupInfoWithDefaults instantiates a new ExternalDiskGroupInfo object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetFirstAvailableDate

`func (o *ExternalDiskGroupInfo) GetFirstAvailableDate() int64`

GetFirstAvailableDate returns the FirstAvailableDate field if non-nil, zero value otherwise.

### GetFirstAvailableDateOk

`func (o *ExternalDiskGroupInfo) GetFirstAvailableDateOk() (*int64, bool)`

GetFirstAvailableDateOk returns a tuple with the FirstAvailableDate field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetFirstAvailableDate

`func (o *ExternalDiskGroupInfo) SetFirstAvailableDate(v int64)`

SetFirstAvailableDate sets FirstAvailableDate field to given value.

### HasFirstAvailableDate

`func (o *ExternalDiskGroupInfo) HasFirstAvailableDate() bool`

HasFirstAvailableDate returns a boolean if a field has been set.

### GetLastAvailableDate

`func (o *ExternalDiskGroupInfo) GetLastAvailableDate() int64`

GetLastAvailableDate returns the LastAvailableDate field if non-nil, zero value otherwise.

### GetLastAvailableDateOk

`func (o *ExternalDiskGroupInfo) GetLastAvailableDateOk() (*int64, bool)`

GetLastAvailableDateOk returns a tuple with the LastAvailableDate field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetLastAvailableDate

`func (o *ExternalDiskGroupInfo) SetLastAvailableDate(v int64)`

SetLastAvailableDate sets LastAvailableDate field to given value.

### HasLastAvailableDate

`func (o *ExternalDiskGroupInfo) HasLastAvailableDate() bool`

HasLastAvailableDate returns a boolean if a field has been set.

### GetDiskGroupId

`func (o *ExternalDiskGroupInfo) GetDiskGroupId() string`

GetDiskGroupId returns the DiskGroupId field if non-nil, zero value otherwise.

### GetDiskGroupIdOk

`func (o *ExternalDiskGroupInfo) GetDiskGroupIdOk() (*string, bool)`

GetDiskGroupIdOk returns a tuple with the DiskGroupId field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetDiskGroupId

`func (o *ExternalDiskGroupInfo) SetDiskGroupId(v string)`

SetDiskGroupId sets DiskGroupId field to given value.



[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


