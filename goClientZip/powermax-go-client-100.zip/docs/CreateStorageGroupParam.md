# CreateStorageGroupParam

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ExecutionOption** | Pointer to **string** |  | [optional] [default to "SYNCHRONOUS"]
**StorageGroupId** | **string** | The Name of the new Storage Group. | 
**SnapshotPolicies** | Pointer to **[]string** | snapshot_policies | [optional] 
**SrpId** | Pointer to **string** | The SRP to be associated with the Storage Group.                                 An existing SRP or &#39;none&#39; must be specified | [optional] 
**SloBasedStorageGroupParam** | Pointer to [**[]SloBasedStorageGroupParam**](SloBasedStorageGroupParam.md) | sloBasedStorageGroupParam | [optional] 
**Emulation** | Pointer to **string** | The emulation to be associated with the Storage Group.   Enumeration values: * **FBA** * **CELERRA_FBA** * **CKD-3390** * **CKD-3380** * **FILE_FBA** * **AS/400_D910_099**  | [optional] [default to "FBA"]

## Methods

### NewCreateStorageGroupParam

`func NewCreateStorageGroupParam(storageGroupId string, ) *CreateStorageGroupParam`

NewCreateStorageGroupParam instantiates a new CreateStorageGroupParam object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewCreateStorageGroupParamWithDefaults

`func NewCreateStorageGroupParamWithDefaults() *CreateStorageGroupParam`

NewCreateStorageGroupParamWithDefaults instantiates a new CreateStorageGroupParam object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetExecutionOption

`func (o *CreateStorageGroupParam) GetExecutionOption() string`

GetExecutionOption returns the ExecutionOption field if non-nil, zero value otherwise.

### GetExecutionOptionOk

`func (o *CreateStorageGroupParam) GetExecutionOptionOk() (*string, bool)`

GetExecutionOptionOk returns a tuple with the ExecutionOption field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetExecutionOption

`func (o *CreateStorageGroupParam) SetExecutionOption(v string)`

SetExecutionOption sets ExecutionOption field to given value.

### HasExecutionOption

`func (o *CreateStorageGroupParam) HasExecutionOption() bool`

HasExecutionOption returns a boolean if a field has been set.

### GetStorageGroupId

`func (o *CreateStorageGroupParam) GetStorageGroupId() string`

GetStorageGroupId returns the StorageGroupId field if non-nil, zero value otherwise.

### GetStorageGroupIdOk

`func (o *CreateStorageGroupParam) GetStorageGroupIdOk() (*string, bool)`

GetStorageGroupIdOk returns a tuple with the StorageGroupId field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetStorageGroupId

`func (o *CreateStorageGroupParam) SetStorageGroupId(v string)`

SetStorageGroupId sets StorageGroupId field to given value.


### GetSnapshotPolicies

`func (o *CreateStorageGroupParam) GetSnapshotPolicies() []string`

GetSnapshotPolicies returns the SnapshotPolicies field if non-nil, zero value otherwise.

### GetSnapshotPoliciesOk

`func (o *CreateStorageGroupParam) GetSnapshotPoliciesOk() (*[]string, bool)`

GetSnapshotPoliciesOk returns a tuple with the SnapshotPolicies field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetSnapshotPolicies

`func (o *CreateStorageGroupParam) SetSnapshotPolicies(v []string)`

SetSnapshotPolicies sets SnapshotPolicies field to given value.

### HasSnapshotPolicies

`func (o *CreateStorageGroupParam) HasSnapshotPolicies() bool`

HasSnapshotPolicies returns a boolean if a field has been set.

### GetSrpId

`func (o *CreateStorageGroupParam) GetSrpId() string`

GetSrpId returns the SrpId field if non-nil, zero value otherwise.

### GetSrpIdOk

`func (o *CreateStorageGroupParam) GetSrpIdOk() (*string, bool)`

GetSrpIdOk returns a tuple with the SrpId field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetSrpId

`func (o *CreateStorageGroupParam) SetSrpId(v string)`

SetSrpId sets SrpId field to given value.

### HasSrpId

`func (o *CreateStorageGroupParam) HasSrpId() bool`

HasSrpId returns a boolean if a field has been set.

### GetSloBasedStorageGroupParam

`func (o *CreateStorageGroupParam) GetSloBasedStorageGroupParam() []SloBasedStorageGroupParam`

GetSloBasedStorageGroupParam returns the SloBasedStorageGroupParam field if non-nil, zero value otherwise.

### GetSloBasedStorageGroupParamOk

`func (o *CreateStorageGroupParam) GetSloBasedStorageGroupParamOk() (*[]SloBasedStorageGroupParam, bool)`

GetSloBasedStorageGroupParamOk returns a tuple with the SloBasedStorageGroupParam field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetSloBasedStorageGroupParam

`func (o *CreateStorageGroupParam) SetSloBasedStorageGroupParam(v []SloBasedStorageGroupParam)`

SetSloBasedStorageGroupParam sets SloBasedStorageGroupParam field to given value.

### HasSloBasedStorageGroupParam

`func (o *CreateStorageGroupParam) HasSloBasedStorageGroupParam() bool`

HasSloBasedStorageGroupParam returns a boolean if a field has been set.

### GetEmulation

`func (o *CreateStorageGroupParam) GetEmulation() string`

GetEmulation returns the Emulation field if non-nil, zero value otherwise.

### GetEmulationOk

`func (o *CreateStorageGroupParam) GetEmulationOk() (*string, bool)`

GetEmulationOk returns a tuple with the Emulation field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetEmulation

`func (o *CreateStorageGroupParam) SetEmulation(v string)`

SetEmulation sets Emulation field to given value.

### HasEmulation

`func (o *CreateStorageGroupParam) HasEmulation() bool`

HasEmulation returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


