# MigrationInitiatorGroup

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Name** | Pointer to **string** | The name of the Masking View | [optional] 
**Invalid** | Pointer to **bool** | Flag to indicate if the entity is invalid | [optional] 
**ChildInvalid** | Pointer to **bool** | Flag to indicate if a child entity is valid | [optional] 
**Missing** | Pointer to **bool** | Flag to indicate if the entity is missing | [optional] 
**Initiator** | Pointer to [**[]MigrationInitiator**](MigrationInitiator.md) | Collection of Port Groups that are part of the Masking View | [optional] 

## Methods

### NewMigrationInitiatorGroup

`func NewMigrationInitiatorGroup() *MigrationInitiatorGroup`

NewMigrationInitiatorGroup instantiates a new MigrationInitiatorGroup object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewMigrationInitiatorGroupWithDefaults

`func NewMigrationInitiatorGroupWithDefaults() *MigrationInitiatorGroup`

NewMigrationInitiatorGroupWithDefaults instantiates a new MigrationInitiatorGroup object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetName

`func (o *MigrationInitiatorGroup) GetName() string`

GetName returns the Name field if non-nil, zero value otherwise.

### GetNameOk

`func (o *MigrationInitiatorGroup) GetNameOk() (*string, bool)`

GetNameOk returns a tuple with the Name field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetName

`func (o *MigrationInitiatorGroup) SetName(v string)`

SetName sets Name field to given value.

### HasName

`func (o *MigrationInitiatorGroup) HasName() bool`

HasName returns a boolean if a field has been set.

### GetInvalid

`func (o *MigrationInitiatorGroup) GetInvalid() bool`

GetInvalid returns the Invalid field if non-nil, zero value otherwise.

### GetInvalidOk

`func (o *MigrationInitiatorGroup) GetInvalidOk() (*bool, bool)`

GetInvalidOk returns a tuple with the Invalid field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetInvalid

`func (o *MigrationInitiatorGroup) SetInvalid(v bool)`

SetInvalid sets Invalid field to given value.

### HasInvalid

`func (o *MigrationInitiatorGroup) HasInvalid() bool`

HasInvalid returns a boolean if a field has been set.

### GetChildInvalid

`func (o *MigrationInitiatorGroup) GetChildInvalid() bool`

GetChildInvalid returns the ChildInvalid field if non-nil, zero value otherwise.

### GetChildInvalidOk

`func (o *MigrationInitiatorGroup) GetChildInvalidOk() (*bool, bool)`

GetChildInvalidOk returns a tuple with the ChildInvalid field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetChildInvalid

`func (o *MigrationInitiatorGroup) SetChildInvalid(v bool)`

SetChildInvalid sets ChildInvalid field to given value.

### HasChildInvalid

`func (o *MigrationInitiatorGroup) HasChildInvalid() bool`

HasChildInvalid returns a boolean if a field has been set.

### GetMissing

`func (o *MigrationInitiatorGroup) GetMissing() bool`

GetMissing returns the Missing field if non-nil, zero value otherwise.

### GetMissingOk

`func (o *MigrationInitiatorGroup) GetMissingOk() (*bool, bool)`

GetMissingOk returns a tuple with the Missing field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetMissing

`func (o *MigrationInitiatorGroup) SetMissing(v bool)`

SetMissing sets Missing field to given value.

### HasMissing

`func (o *MigrationInitiatorGroup) HasMissing() bool`

HasMissing returns a boolean if a field has been set.

### GetInitiator

`func (o *MigrationInitiatorGroup) GetInitiator() []MigrationInitiator`

GetInitiator returns the Initiator field if non-nil, zero value otherwise.

### GetInitiatorOk

`func (o *MigrationInitiatorGroup) GetInitiatorOk() (*[]MigrationInitiator, bool)`

GetInitiatorOk returns a tuple with the Initiator field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetInitiator

`func (o *MigrationInitiatorGroup) SetInitiator(v []MigrationInitiator)`

SetInitiator sets Initiator field to given value.

### HasInitiator

`func (o *MigrationInitiatorGroup) HasInitiator() bool`

HasInitiator returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


