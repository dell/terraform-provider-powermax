# ExpandVolumesParam

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**SpecificVolumeParam** | Pointer to [**[]SpecificVolumeParam**](SpecificVolumeParam.md) | specificVolumeParam | [optional] 
**AllVolumeParam** | Pointer to [**AllVolumeParam**](AllVolumeParam.md) |  | [optional] 

## Methods

### NewExpandVolumesParam

`func NewExpandVolumesParam() *ExpandVolumesParam`

NewExpandVolumesParam instantiates a new ExpandVolumesParam object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewExpandVolumesParamWithDefaults

`func NewExpandVolumesParamWithDefaults() *ExpandVolumesParam`

NewExpandVolumesParamWithDefaults instantiates a new ExpandVolumesParam object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetSpecificVolumeParam

`func (o *ExpandVolumesParam) GetSpecificVolumeParam() []SpecificVolumeParam`

GetSpecificVolumeParam returns the SpecificVolumeParam field if non-nil, zero value otherwise.

### GetSpecificVolumeParamOk

`func (o *ExpandVolumesParam) GetSpecificVolumeParamOk() (*[]SpecificVolumeParam, bool)`

GetSpecificVolumeParamOk returns a tuple with the SpecificVolumeParam field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetSpecificVolumeParam

`func (o *ExpandVolumesParam) SetSpecificVolumeParam(v []SpecificVolumeParam)`

SetSpecificVolumeParam sets SpecificVolumeParam field to given value.

### HasSpecificVolumeParam

`func (o *ExpandVolumesParam) HasSpecificVolumeParam() bool`

HasSpecificVolumeParam returns a boolean if a field has been set.

### GetAllVolumeParam

`func (o *ExpandVolumesParam) GetAllVolumeParam() AllVolumeParam`

GetAllVolumeParam returns the AllVolumeParam field if non-nil, zero value otherwise.

### GetAllVolumeParamOk

`func (o *ExpandVolumesParam) GetAllVolumeParamOk() (*AllVolumeParam, bool)`

GetAllVolumeParamOk returns a tuple with the AllVolumeParam field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetAllVolumeParam

`func (o *ExpandVolumesParam) SetAllVolumeParam(v AllVolumeParam)`

SetAllVolumeParam sets AllVolumeParam field to given value.

### HasAllVolumeParam

`func (o *ExpandVolumesParam) HasAllVolumeParam() bool`

HasAllVolumeParam returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


