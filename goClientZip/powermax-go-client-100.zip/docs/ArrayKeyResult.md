# ArrayKeyResult

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ArrayInfo** | Pointer to [**[]ArrayInfo**](ArrayInfo.md) | arrayInfo | [optional] 

## Methods

### NewArrayKeyResult

`func NewArrayKeyResult() *ArrayKeyResult`

NewArrayKeyResult instantiates a new ArrayKeyResult object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewArrayKeyResultWithDefaults

`func NewArrayKeyResultWithDefaults() *ArrayKeyResult`

NewArrayKeyResultWithDefaults instantiates a new ArrayKeyResult object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetArrayInfo

`func (o *ArrayKeyResult) GetArrayInfo() []ArrayInfo`

GetArrayInfo returns the ArrayInfo field if non-nil, zero value otherwise.

### GetArrayInfoOk

`func (o *ArrayKeyResult) GetArrayInfoOk() (*[]ArrayInfo, bool)`

GetArrayInfoOk returns a tuple with the ArrayInfo field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetArrayInfo

`func (o *ArrayKeyResult) SetArrayInfo(v []ArrayInfo)`

SetArrayInfo sets ArrayInfo field to given value.

### HasArrayInfo

`func (o *ArrayKeyResult) HasArrayInfo() bool`

HasArrayInfo returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


