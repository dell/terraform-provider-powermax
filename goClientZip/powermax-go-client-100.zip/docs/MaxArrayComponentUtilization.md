# MaxArrayComponentUtilization

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Componenttype** | **string** | Component type associated with maximum component utilization. | 
**Componentid** | **string** | Component ID associated with maximum component utilization. | 
**Utilization** | **float64** | Normalized (to component&#39;s best practice limit) component utilization value for a given 4 hour time bucket. | 
**Timestamp** | **int64** | Most recent processed SPA timestamp in a particular 4 hour time window. | 
**Bucketid** | **int32** | A bucket is a four hour time window. A week has 42 buckets (0-indexed). Bucket 0 is Sunday 12am-4am, 1 is Sunday 4am-8am, etc. | 
**ReasonsForExclusion** | Pointer to **[]string** | Data exclusion setting(s) that are causing this data to be ignored by WLP.   Enumeration values: * **StorageGroupOneTime** - Data has been excluded due to a one-time exclusion at the storage group level. * **StorageGroupRecurring** - Data has been excluded due to a recurring exclusion at the storage group level. * **SystemOneTime** - Data has been excluded due to a one-time exclusion at the system level. * **SystemRecurring** - Data has been excluded due to a recurring exclusion at the system level.  | [optional] 

## Methods

### NewMaxArrayComponentUtilization

`func NewMaxArrayComponentUtilization(componenttype string, componentid string, utilization float64, timestamp int64, bucketid int32, ) *MaxArrayComponentUtilization`

NewMaxArrayComponentUtilization instantiates a new MaxArrayComponentUtilization object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewMaxArrayComponentUtilizationWithDefaults

`func NewMaxArrayComponentUtilizationWithDefaults() *MaxArrayComponentUtilization`

NewMaxArrayComponentUtilizationWithDefaults instantiates a new MaxArrayComponentUtilization object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetComponenttype

`func (o *MaxArrayComponentUtilization) GetComponenttype() string`

GetComponenttype returns the Componenttype field if non-nil, zero value otherwise.

### GetComponenttypeOk

`func (o *MaxArrayComponentUtilization) GetComponenttypeOk() (*string, bool)`

GetComponenttypeOk returns a tuple with the Componenttype field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetComponenttype

`func (o *MaxArrayComponentUtilization) SetComponenttype(v string)`

SetComponenttype sets Componenttype field to given value.


### GetComponentid

`func (o *MaxArrayComponentUtilization) GetComponentid() string`

GetComponentid returns the Componentid field if non-nil, zero value otherwise.

### GetComponentidOk

`func (o *MaxArrayComponentUtilization) GetComponentidOk() (*string, bool)`

GetComponentidOk returns a tuple with the Componentid field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetComponentid

`func (o *MaxArrayComponentUtilization) SetComponentid(v string)`

SetComponentid sets Componentid field to given value.


### GetUtilization

`func (o *MaxArrayComponentUtilization) GetUtilization() float64`

GetUtilization returns the Utilization field if non-nil, zero value otherwise.

### GetUtilizationOk

`func (o *MaxArrayComponentUtilization) GetUtilizationOk() (*float64, bool)`

GetUtilizationOk returns a tuple with the Utilization field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetUtilization

`func (o *MaxArrayComponentUtilization) SetUtilization(v float64)`

SetUtilization sets Utilization field to given value.


### GetTimestamp

`func (o *MaxArrayComponentUtilization) GetTimestamp() int64`

GetTimestamp returns the Timestamp field if non-nil, zero value otherwise.

### GetTimestampOk

`func (o *MaxArrayComponentUtilization) GetTimestampOk() (*int64, bool)`

GetTimestampOk returns a tuple with the Timestamp field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetTimestamp

`func (o *MaxArrayComponentUtilization) SetTimestamp(v int64)`

SetTimestamp sets Timestamp field to given value.


### GetBucketid

`func (o *MaxArrayComponentUtilization) GetBucketid() int32`

GetBucketid returns the Bucketid field if non-nil, zero value otherwise.

### GetBucketidOk

`func (o *MaxArrayComponentUtilization) GetBucketidOk() (*int32, bool)`

GetBucketidOk returns a tuple with the Bucketid field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetBucketid

`func (o *MaxArrayComponentUtilization) SetBucketid(v int32)`

SetBucketid sets Bucketid field to given value.


### GetReasonsForExclusion

`func (o *MaxArrayComponentUtilization) GetReasonsForExclusion() []string`

GetReasonsForExclusion returns the ReasonsForExclusion field if non-nil, zero value otherwise.

### GetReasonsForExclusionOk

`func (o *MaxArrayComponentUtilization) GetReasonsForExclusionOk() (*[]string, bool)`

GetReasonsForExclusionOk returns a tuple with the ReasonsForExclusion field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetReasonsForExclusion

`func (o *MaxArrayComponentUtilization) SetReasonsForExclusion(v []string)`

SetReasonsForExclusion sets ReasonsForExclusion field to given value.

### HasReasonsForExclusion

`func (o *MaxArrayComponentUtilization) HasReasonsForExclusion() bool`

HasReasonsForExclusion returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


