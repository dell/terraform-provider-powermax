# ComplianceDetails

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ComplianceEvent** | Pointer to [**[]ComplianceEvent**](ComplianceEvent.md) | complianceEvent | [optional] 

## Methods

### NewComplianceDetails

`func NewComplianceDetails() *ComplianceDetails`

NewComplianceDetails instantiates a new ComplianceDetails object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewComplianceDetailsWithDefaults

`func NewComplianceDetailsWithDefaults() *ComplianceDetails`

NewComplianceDetailsWithDefaults instantiates a new ComplianceDetails object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetComplianceEvent

`func (o *ComplianceDetails) GetComplianceEvent() []ComplianceEvent`

GetComplianceEvent returns the ComplianceEvent field if non-nil, zero value otherwise.

### GetComplianceEventOk

`func (o *ComplianceDetails) GetComplianceEventOk() (*[]ComplianceEvent, bool)`

GetComplianceEventOk returns a tuple with the ComplianceEvent field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetComplianceEvent

`func (o *ComplianceDetails) SetComplianceEvent(v []ComplianceEvent)`

SetComplianceEvent sets ComplianceEvent field to given value.

### HasComplianceEvent

`func (o *ComplianceDetails) HasComplianceEvent() bool`

HasComplianceEvent returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


