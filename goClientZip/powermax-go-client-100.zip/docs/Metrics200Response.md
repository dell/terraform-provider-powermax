# Metrics200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Length** | Pointer to **int32** |  | [optional] 
**Location** | Pointer to **string** |  | [optional] 
**Language** | Pointer to [**Metrics200ResponseLanguage**](Metrics200ResponseLanguage.md) |  | [optional] 
**LastModified** | Pointer to **time.Time** |  | [optional] 
**Date** | Pointer to **time.Time** |  | [optional] 
**Headers** | Pointer to [**Metrics200ResponseHeaders**](Metrics200ResponseHeaders.md) |  | [optional] 
**Status** | Pointer to **int32** |  | [optional] 
**Metadata** | Pointer to [**Metrics200ResponseHeaders**](Metrics200ResponseHeaders.md) |  | [optional] 
**Entity** | Pointer to **map[string]interface{}** |  | [optional] 
**Cookies** | Pointer to [**map[string]Metrics200ResponseCookiesValue**](Metrics200ResponseCookiesValue.md) |  | [optional] 
**Links** | Pointer to [**[]Metrics200ResponseLinksInner**](Metrics200ResponseLinksInner.md) |  | [optional] 
**StatusInfo** | Pointer to [**Metrics200ResponseStatusInfo**](Metrics200ResponseStatusInfo.md) |  | [optional] 
**EntityTag** | Pointer to [**Metrics200ResponseEntityTag**](Metrics200ResponseEntityTag.md) |  | [optional] 
**StringHeaders** | Pointer to [**Metrics200ResponseStringHeaders**](Metrics200ResponseStringHeaders.md) |  | [optional] 
**AllowedMethods** | Pointer to **[]string** |  | [optional] 
**MediaType** | Pointer to [**Metrics200ResponseMediaType**](Metrics200ResponseMediaType.md) |  | [optional] 

## Methods

### NewMetrics200Response

`func NewMetrics200Response() *Metrics200Response`

NewMetrics200Response instantiates a new Metrics200Response object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewMetrics200ResponseWithDefaults

`func NewMetrics200ResponseWithDefaults() *Metrics200Response`

NewMetrics200ResponseWithDefaults instantiates a new Metrics200Response object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetLength

`func (o *Metrics200Response) GetLength() int32`

GetLength returns the Length field if non-nil, zero value otherwise.

### GetLengthOk

`func (o *Metrics200Response) GetLengthOk() (*int32, bool)`

GetLengthOk returns a tuple with the Length field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetLength

`func (o *Metrics200Response) SetLength(v int32)`

SetLength sets Length field to given value.

### HasLength

`func (o *Metrics200Response) HasLength() bool`

HasLength returns a boolean if a field has been set.

### GetLocation

`func (o *Metrics200Response) GetLocation() string`

GetLocation returns the Location field if non-nil, zero value otherwise.

### GetLocationOk

`func (o *Metrics200Response) GetLocationOk() (*string, bool)`

GetLocationOk returns a tuple with the Location field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetLocation

`func (o *Metrics200Response) SetLocation(v string)`

SetLocation sets Location field to given value.

### HasLocation

`func (o *Metrics200Response) HasLocation() bool`

HasLocation returns a boolean if a field has been set.

### GetLanguage

`func (o *Metrics200Response) GetLanguage() Metrics200ResponseLanguage`

GetLanguage returns the Language field if non-nil, zero value otherwise.

### GetLanguageOk

`func (o *Metrics200Response) GetLanguageOk() (*Metrics200ResponseLanguage, bool)`

GetLanguageOk returns a tuple with the Language field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetLanguage

`func (o *Metrics200Response) SetLanguage(v Metrics200ResponseLanguage)`

SetLanguage sets Language field to given value.

### HasLanguage

`func (o *Metrics200Response) HasLanguage() bool`

HasLanguage returns a boolean if a field has been set.

### GetLastModified

`func (o *Metrics200Response) GetLastModified() time.Time`

GetLastModified returns the LastModified field if non-nil, zero value otherwise.

### GetLastModifiedOk

`func (o *Metrics200Response) GetLastModifiedOk() (*time.Time, bool)`

GetLastModifiedOk returns a tuple with the LastModified field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetLastModified

`func (o *Metrics200Response) SetLastModified(v time.Time)`

SetLastModified sets LastModified field to given value.

### HasLastModified

`func (o *Metrics200Response) HasLastModified() bool`

HasLastModified returns a boolean if a field has been set.

### GetDate

`func (o *Metrics200Response) GetDate() time.Time`

GetDate returns the Date field if non-nil, zero value otherwise.

### GetDateOk

`func (o *Metrics200Response) GetDateOk() (*time.Time, bool)`

GetDateOk returns a tuple with the Date field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetDate

`func (o *Metrics200Response) SetDate(v time.Time)`

SetDate sets Date field to given value.

### HasDate

`func (o *Metrics200Response) HasDate() bool`

HasDate returns a boolean if a field has been set.

### GetHeaders

`func (o *Metrics200Response) GetHeaders() Metrics200ResponseHeaders`

GetHeaders returns the Headers field if non-nil, zero value otherwise.

### GetHeadersOk

`func (o *Metrics200Response) GetHeadersOk() (*Metrics200ResponseHeaders, bool)`

GetHeadersOk returns a tuple with the Headers field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetHeaders

`func (o *Metrics200Response) SetHeaders(v Metrics200ResponseHeaders)`

SetHeaders sets Headers field to given value.

### HasHeaders

`func (o *Metrics200Response) HasHeaders() bool`

HasHeaders returns a boolean if a field has been set.

### GetStatus

`func (o *Metrics200Response) GetStatus() int32`

GetStatus returns the Status field if non-nil, zero value otherwise.

### GetStatusOk

`func (o *Metrics200Response) GetStatusOk() (*int32, bool)`

GetStatusOk returns a tuple with the Status field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetStatus

`func (o *Metrics200Response) SetStatus(v int32)`

SetStatus sets Status field to given value.

### HasStatus

`func (o *Metrics200Response) HasStatus() bool`

HasStatus returns a boolean if a field has been set.

### GetMetadata

`func (o *Metrics200Response) GetMetadata() Metrics200ResponseHeaders`

GetMetadata returns the Metadata field if non-nil, zero value otherwise.

### GetMetadataOk

`func (o *Metrics200Response) GetMetadataOk() (*Metrics200ResponseHeaders, bool)`

GetMetadataOk returns a tuple with the Metadata field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetMetadata

`func (o *Metrics200Response) SetMetadata(v Metrics200ResponseHeaders)`

SetMetadata sets Metadata field to given value.

### HasMetadata

`func (o *Metrics200Response) HasMetadata() bool`

HasMetadata returns a boolean if a field has been set.

### GetEntity

`func (o *Metrics200Response) GetEntity() map[string]interface{}`

GetEntity returns the Entity field if non-nil, zero value otherwise.

### GetEntityOk

`func (o *Metrics200Response) GetEntityOk() (*map[string]interface{}, bool)`

GetEntityOk returns a tuple with the Entity field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetEntity

`func (o *Metrics200Response) SetEntity(v map[string]interface{})`

SetEntity sets Entity field to given value.

### HasEntity

`func (o *Metrics200Response) HasEntity() bool`

HasEntity returns a boolean if a field has been set.

### GetCookies

`func (o *Metrics200Response) GetCookies() map[string]Metrics200ResponseCookiesValue`

GetCookies returns the Cookies field if non-nil, zero value otherwise.

### GetCookiesOk

`func (o *Metrics200Response) GetCookiesOk() (*map[string]Metrics200ResponseCookiesValue, bool)`

GetCookiesOk returns a tuple with the Cookies field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetCookies

`func (o *Metrics200Response) SetCookies(v map[string]Metrics200ResponseCookiesValue)`

SetCookies sets Cookies field to given value.

### HasCookies

`func (o *Metrics200Response) HasCookies() bool`

HasCookies returns a boolean if a field has been set.

### GetLinks

`func (o *Metrics200Response) GetLinks() []Metrics200ResponseLinksInner`

GetLinks returns the Links field if non-nil, zero value otherwise.

### GetLinksOk

`func (o *Metrics200Response) GetLinksOk() (*[]Metrics200ResponseLinksInner, bool)`

GetLinksOk returns a tuple with the Links field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetLinks

`func (o *Metrics200Response) SetLinks(v []Metrics200ResponseLinksInner)`

SetLinks sets Links field to given value.

### HasLinks

`func (o *Metrics200Response) HasLinks() bool`

HasLinks returns a boolean if a field has been set.

### GetStatusInfo

`func (o *Metrics200Response) GetStatusInfo() Metrics200ResponseStatusInfo`

GetStatusInfo returns the StatusInfo field if non-nil, zero value otherwise.

### GetStatusInfoOk

`func (o *Metrics200Response) GetStatusInfoOk() (*Metrics200ResponseStatusInfo, bool)`

GetStatusInfoOk returns a tuple with the StatusInfo field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetStatusInfo

`func (o *Metrics200Response) SetStatusInfo(v Metrics200ResponseStatusInfo)`

SetStatusInfo sets StatusInfo field to given value.

### HasStatusInfo

`func (o *Metrics200Response) HasStatusInfo() bool`

HasStatusInfo returns a boolean if a field has been set.

### GetEntityTag

`func (o *Metrics200Response) GetEntityTag() Metrics200ResponseEntityTag`

GetEntityTag returns the EntityTag field if non-nil, zero value otherwise.

### GetEntityTagOk

`func (o *Metrics200Response) GetEntityTagOk() (*Metrics200ResponseEntityTag, bool)`

GetEntityTagOk returns a tuple with the EntityTag field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetEntityTag

`func (o *Metrics200Response) SetEntityTag(v Metrics200ResponseEntityTag)`

SetEntityTag sets EntityTag field to given value.

### HasEntityTag

`func (o *Metrics200Response) HasEntityTag() bool`

HasEntityTag returns a boolean if a field has been set.

### GetStringHeaders

`func (o *Metrics200Response) GetStringHeaders() Metrics200ResponseStringHeaders`

GetStringHeaders returns the StringHeaders field if non-nil, zero value otherwise.

### GetStringHeadersOk

`func (o *Metrics200Response) GetStringHeadersOk() (*Metrics200ResponseStringHeaders, bool)`

GetStringHeadersOk returns a tuple with the StringHeaders field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetStringHeaders

`func (o *Metrics200Response) SetStringHeaders(v Metrics200ResponseStringHeaders)`

SetStringHeaders sets StringHeaders field to given value.

### HasStringHeaders

`func (o *Metrics200Response) HasStringHeaders() bool`

HasStringHeaders returns a boolean if a field has been set.

### GetAllowedMethods

`func (o *Metrics200Response) GetAllowedMethods() []string`

GetAllowedMethods returns the AllowedMethods field if non-nil, zero value otherwise.

### GetAllowedMethodsOk

`func (o *Metrics200Response) GetAllowedMethodsOk() (*[]string, bool)`

GetAllowedMethodsOk returns a tuple with the AllowedMethods field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetAllowedMethods

`func (o *Metrics200Response) SetAllowedMethods(v []string)`

SetAllowedMethods sets AllowedMethods field to given value.

### HasAllowedMethods

`func (o *Metrics200Response) HasAllowedMethods() bool`

HasAllowedMethods returns a boolean if a field has been set.

### GetMediaType

`func (o *Metrics200Response) GetMediaType() Metrics200ResponseMediaType`

GetMediaType returns the MediaType field if non-nil, zero value otherwise.

### GetMediaTypeOk

`func (o *Metrics200Response) GetMediaTypeOk() (*Metrics200ResponseMediaType, bool)`

GetMediaTypeOk returns a tuple with the MediaType field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetMediaType

`func (o *Metrics200Response) SetMediaType(v Metrics200ResponseMediaType)`

SetMediaType sets MediaType field to given value.

### HasMediaType

`func (o *Metrics200Response) HasMediaType() bool`

HasMediaType returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


