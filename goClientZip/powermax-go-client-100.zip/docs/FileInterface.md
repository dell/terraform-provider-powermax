# FileInterface

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Id** | Pointer to **string** |  Unique identifier of File interface | [optional] 
**NasServer** | Pointer to **string** |  Unique identifier of the nas server  | [optional] 
**NetDevice** | Pointer to **string** |  Physical name of the network interface | [optional] 
**MacAddress** | Pointer to **string** |  MacAdderss of the interafce  | [optional] 
**IpAddress** | Pointer to **string** |  Ip Address configured for interface  | [optional] 
**Netmask** | Pointer to **string** |  Network Mask of the subnet | [optional] 
**V6PrefixLength** | Pointer to **int32** |  Ipv6 prefix length | [optional] 
**Gateway** | Pointer to **string** |  Gateway of the subnet  | [optional] 
**VlanId** | Pointer to **int32** |  Vlan of the file Interface  | [optional] 
**Name** | Pointer to **string** |  Name of the file interface  | [optional] 
**Role** | Pointer to **string** |                          Production network interfaces are used for all file protocols and services of NAS server. Backup network interfaces are used only for NDMP/NFS backup.                         System network interfaces are reserved for system traffic such as for NAS server migration, they can&#39;t be used for the production traffic.                         - Production                         - Backup                         - System                        Enumeration values: * **Production** * **Backup** * **System**  | [optional] 
**IsDisabled** | Pointer to **bool** |  Indicates whether the network interface is disabled.  | [optional] 
**Health** | Pointer to [**Health**](Health.md) |  | [optional] 
**Override** | Pointer to **bool** |                          In the context of a replication, tell if the interface properties                         and related routes objects have been overridden when the NAS server                         is in destination mode.                      | [optional] 

## Methods

### NewFileInterface

`func NewFileInterface() *FileInterface`

NewFileInterface instantiates a new FileInterface object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewFileInterfaceWithDefaults

`func NewFileInterfaceWithDefaults() *FileInterface`

NewFileInterfaceWithDefaults instantiates a new FileInterface object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetId

`func (o *FileInterface) GetId() string`

GetId returns the Id field if non-nil, zero value otherwise.

### GetIdOk

`func (o *FileInterface) GetIdOk() (*string, bool)`

GetIdOk returns a tuple with the Id field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetId

`func (o *FileInterface) SetId(v string)`

SetId sets Id field to given value.

### HasId

`func (o *FileInterface) HasId() bool`

HasId returns a boolean if a field has been set.

### GetNasServer

`func (o *FileInterface) GetNasServer() string`

GetNasServer returns the NasServer field if non-nil, zero value otherwise.

### GetNasServerOk

`func (o *FileInterface) GetNasServerOk() (*string, bool)`

GetNasServerOk returns a tuple with the NasServer field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetNasServer

`func (o *FileInterface) SetNasServer(v string)`

SetNasServer sets NasServer field to given value.

### HasNasServer

`func (o *FileInterface) HasNasServer() bool`

HasNasServer returns a boolean if a field has been set.

### GetNetDevice

`func (o *FileInterface) GetNetDevice() string`

GetNetDevice returns the NetDevice field if non-nil, zero value otherwise.

### GetNetDeviceOk

`func (o *FileInterface) GetNetDeviceOk() (*string, bool)`

GetNetDeviceOk returns a tuple with the NetDevice field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetNetDevice

`func (o *FileInterface) SetNetDevice(v string)`

SetNetDevice sets NetDevice field to given value.

### HasNetDevice

`func (o *FileInterface) HasNetDevice() bool`

HasNetDevice returns a boolean if a field has been set.

### GetMacAddress

`func (o *FileInterface) GetMacAddress() string`

GetMacAddress returns the MacAddress field if non-nil, zero value otherwise.

### GetMacAddressOk

`func (o *FileInterface) GetMacAddressOk() (*string, bool)`

GetMacAddressOk returns a tuple with the MacAddress field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetMacAddress

`func (o *FileInterface) SetMacAddress(v string)`

SetMacAddress sets MacAddress field to given value.

### HasMacAddress

`func (o *FileInterface) HasMacAddress() bool`

HasMacAddress returns a boolean if a field has been set.

### GetIpAddress

`func (o *FileInterface) GetIpAddress() string`

GetIpAddress returns the IpAddress field if non-nil, zero value otherwise.

### GetIpAddressOk

`func (o *FileInterface) GetIpAddressOk() (*string, bool)`

GetIpAddressOk returns a tuple with the IpAddress field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetIpAddress

`func (o *FileInterface) SetIpAddress(v string)`

SetIpAddress sets IpAddress field to given value.

### HasIpAddress

`func (o *FileInterface) HasIpAddress() bool`

HasIpAddress returns a boolean if a field has been set.

### GetNetmask

`func (o *FileInterface) GetNetmask() string`

GetNetmask returns the Netmask field if non-nil, zero value otherwise.

### GetNetmaskOk

`func (o *FileInterface) GetNetmaskOk() (*string, bool)`

GetNetmaskOk returns a tuple with the Netmask field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetNetmask

`func (o *FileInterface) SetNetmask(v string)`

SetNetmask sets Netmask field to given value.

### HasNetmask

`func (o *FileInterface) HasNetmask() bool`

HasNetmask returns a boolean if a field has been set.

### GetV6PrefixLength

`func (o *FileInterface) GetV6PrefixLength() int32`

GetV6PrefixLength returns the V6PrefixLength field if non-nil, zero value otherwise.

### GetV6PrefixLengthOk

`func (o *FileInterface) GetV6PrefixLengthOk() (*int32, bool)`

GetV6PrefixLengthOk returns a tuple with the V6PrefixLength field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetV6PrefixLength

`func (o *FileInterface) SetV6PrefixLength(v int32)`

SetV6PrefixLength sets V6PrefixLength field to given value.

### HasV6PrefixLength

`func (o *FileInterface) HasV6PrefixLength() bool`

HasV6PrefixLength returns a boolean if a field has been set.

### GetGateway

`func (o *FileInterface) GetGateway() string`

GetGateway returns the Gateway field if non-nil, zero value otherwise.

### GetGatewayOk

`func (o *FileInterface) GetGatewayOk() (*string, bool)`

GetGatewayOk returns a tuple with the Gateway field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetGateway

`func (o *FileInterface) SetGateway(v string)`

SetGateway sets Gateway field to given value.

### HasGateway

`func (o *FileInterface) HasGateway() bool`

HasGateway returns a boolean if a field has been set.

### GetVlanId

`func (o *FileInterface) GetVlanId() int32`

GetVlanId returns the VlanId field if non-nil, zero value otherwise.

### GetVlanIdOk

`func (o *FileInterface) GetVlanIdOk() (*int32, bool)`

GetVlanIdOk returns a tuple with the VlanId field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetVlanId

`func (o *FileInterface) SetVlanId(v int32)`

SetVlanId sets VlanId field to given value.

### HasVlanId

`func (o *FileInterface) HasVlanId() bool`

HasVlanId returns a boolean if a field has been set.

### GetName

`func (o *FileInterface) GetName() string`

GetName returns the Name field if non-nil, zero value otherwise.

### GetNameOk

`func (o *FileInterface) GetNameOk() (*string, bool)`

GetNameOk returns a tuple with the Name field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetName

`func (o *FileInterface) SetName(v string)`

SetName sets Name field to given value.

### HasName

`func (o *FileInterface) HasName() bool`

HasName returns a boolean if a field has been set.

### GetRole

`func (o *FileInterface) GetRole() string`

GetRole returns the Role field if non-nil, zero value otherwise.

### GetRoleOk

`func (o *FileInterface) GetRoleOk() (*string, bool)`

GetRoleOk returns a tuple with the Role field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetRole

`func (o *FileInterface) SetRole(v string)`

SetRole sets Role field to given value.

### HasRole

`func (o *FileInterface) HasRole() bool`

HasRole returns a boolean if a field has been set.

### GetIsDisabled

`func (o *FileInterface) GetIsDisabled() bool`

GetIsDisabled returns the IsDisabled field if non-nil, zero value otherwise.

### GetIsDisabledOk

`func (o *FileInterface) GetIsDisabledOk() (*bool, bool)`

GetIsDisabledOk returns a tuple with the IsDisabled field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetIsDisabled

`func (o *FileInterface) SetIsDisabled(v bool)`

SetIsDisabled sets IsDisabled field to given value.

### HasIsDisabled

`func (o *FileInterface) HasIsDisabled() bool`

HasIsDisabled returns a boolean if a field has been set.

### GetHealth

`func (o *FileInterface) GetHealth() Health`

GetHealth returns the Health field if non-nil, zero value otherwise.

### GetHealthOk

`func (o *FileInterface) GetHealthOk() (*Health, bool)`

GetHealthOk returns a tuple with the Health field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetHealth

`func (o *FileInterface) SetHealth(v Health)`

SetHealth sets Health field to given value.

### HasHealth

`func (o *FileInterface) HasHealth() bool`

HasHealth returns a boolean if a field has been set.

### GetOverride

`func (o *FileInterface) GetOverride() bool`

GetOverride returns the Override field if non-nil, zero value otherwise.

### GetOverrideOk

`func (o *FileInterface) GetOverrideOk() (*bool, bool)`

GetOverrideOk returns a tuple with the Override field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetOverride

`func (o *FileInterface) SetOverride(v bool)`

SetOverride sets Override field to given value.

### HasOverride

`func (o *FileInterface) HasOverride() bool`

HasOverride returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


