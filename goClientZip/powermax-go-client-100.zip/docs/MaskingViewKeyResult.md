# MaskingViewKeyResult

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**MaskingViewInfo** | Pointer to [**[]MaskingViewInfo**](MaskingViewInfo.md) | maskingViewInfo | [optional] 

## Methods

### NewMaskingViewKeyResult

`func NewMaskingViewKeyResult() *MaskingViewKeyResult`

NewMaskingViewKeyResult instantiates a new MaskingViewKeyResult object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewMaskingViewKeyResultWithDefaults

`func NewMaskingViewKeyResultWithDefaults() *MaskingViewKeyResult`

NewMaskingViewKeyResultWithDefaults instantiates a new MaskingViewKeyResult object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetMaskingViewInfo

`func (o *MaskingViewKeyResult) GetMaskingViewInfo() []MaskingViewInfo`

GetMaskingViewInfo returns the MaskingViewInfo field if non-nil, zero value otherwise.

### GetMaskingViewInfoOk

`func (o *MaskingViewKeyResult) GetMaskingViewInfoOk() (*[]MaskingViewInfo, bool)`

GetMaskingViewInfoOk returns a tuple with the MaskingViewInfo field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetMaskingViewInfo

`func (o *MaskingViewKeyResult) SetMaskingViewInfo(v []MaskingViewInfo)`

SetMaskingViewInfo sets MaskingViewInfo field to given value.

### HasMaskingViewInfo

`func (o *MaskingViewKeyResult) HasMaskingViewInfo() bool`

HasMaskingViewInfo returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


