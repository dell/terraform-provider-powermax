# ExternalDirectorParam

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**StartDate** | **int64** | Starting date in millisecond. | 
**EndDate** | **int64** | Ending date in millisecond. | 
**SymmetrixId** | **string** | &lt;p&gt;The Symmetrix array ID.&lt;/p&gt; | 
**DirectorId** | **string** | &lt;p&gt;Director ID.&lt;/p&gt; | 
**DataFormat** | Pointer to **string** | &lt;p&gt;Data Format (Average or Maximum).&lt;/p&gt;   Enumeration values: * **Average** * **Maximum**  | [optional] 
**Metrics** | **[]string** | metrics   Enumeration values: * **PercentBusy** - The percent of time that a director is busy. * **IOs** - An IO command to the disk. * **Reqs** - Reqs/sec * **ReadReqs** - A data transfer of a read between the director and the cache. * **WriteReqs** - A data transfer of a write between the cache and the director. * **SyscallCount** - The total number of calls seen by this director. * **AvgTimePerSyscall** - The average time spent processing all system calls. * **SyscallRemoteDirCount** - The number of calls sent from the local director to another director in the same system. * **Syscall_RDF_DirCount** - The number of calls sent using RDF to a remote system. * **PrefetchedTracks** - The number of tracks pre-fetched from disk to cache upon detection of a sequential read stream. * **MBRead** - The reads per second in MBs. * **MBWritten** - The writes per second in MBs. * **MBs** - The total IO (reads and writes) per second in MBs. * **CompressedReadReqs** - The number of compressed read requests per second. * **CompressedWriteReqs** - The number of compressed write requests per second. * **CompressedReadMBs** - The size of compressed read MBs per second. * **CompressedWriteMBs** - The size of compressed write MBs per second. * **CompressedReqs** - The total number of compressed requests (read and write) per second. * **CompressedMBs** - The total size of compressed MBs (read and write) per second. * **PercentBusyLogicalCore_0** - The total percent of time that core 0 is busy serving IOs. * **PercentBusyLogicalCore_1** - The total percent of time that core 1 is busy serving IOs. * **PercentNonIOBusyLogicalCore_0** - The total percent of time that core 0 is busy serving non-IO tasks. * **PercentNonIOBusyLogicalCore_1** - he total percent of time that core 1 is busy serving non-IO tasks. * **PercentNonIOBusy** - The total percent of time that the DA is busy serving non-IO tasks. * **PercentReadReqs** - The percent of read requests out of the total requests. * **PercentWriteReqs** - The percent of write requests out of the total requests. * **CloneCopyRead** - Clone Copy Read * **CloneCopyWrite** - Clone Copy Write * **OptimizedWrite** - Optimized Write * **PHCORebuildCopy** - PHCO Rebuild Copy * **PHCORebuildRead** - PHCO Rebuild Read * **SyscallTimePerSec** - Syscall Time * **AVR_TIME_PER_SYSCALL** - The average time spent processing all system calls. * **CLONE_COPY_READ** - These metrics are for internal Symmetrix operations. * **CLONE_COPY_WRITE** - These metrics are for internal Symmetrix operations. * **COPY_ON_FIRST_ACCESS** - These metrics are for internal Symmetrix operations. * **IO_RATE** - An IO command to the disk. * **MB_RATE** - The total IO (reads and writes) per second in MBs. * **MB_READ_PER_SEC** - The reads per second in MBs. * **MB_WRITE_PER_SEC** - The writes per second in MBs. * **OPTIMIZED_WRITE** - These metrics are for internal Symmetrix operations. * **PERCENT_BUSY** - The percent of time that a director is busy. * **PERCENT_IDLE** - The percent of time that a director is idle. * **PERCENT_READ** - The percent of read requests out of the total requests. * **PERCENT_WRITE** - The percent of write requests out of the total requests. * **PHCO_REBUILD_COPY** - These metrics are for internal Symmetrix operations. * **PHCO_REBUILD_READ** - These metrics are for internal Symmetrix operations. * **PORT_0_AVG_REQ_SIZE_KB** - The average IO request moving through port 0 per second. * **PORT_0_IO_PER_SEC** - The number of IOs moving through port 0 per second. * **PORT_0_MB_PER_SEC** - The total MBs moving through port 0 per second. * **PORT_0_SPEED_GBITS_PER_SEC** - The number of gigabits moving through port 0 per second. * **PORT_0_UTILIZATION** - The utilization of port 0. * **PORT_1_AVG_REQ_SIZE_KB** - The average IO request  moving through port 1 per second. * **PORT_1_IO_PER_SEC** - The number of IOs moving through port 1 per second. * **PORT_1_MB_PER_SEC** - The total MBs moving through port 1 per second. * **PORT_1_SPEED_GBITS_PER_SEC** - The number of gigabits moving through port 1 per second. * **PORT_1_UTILIZATION** - The utilization of port 1. * **PREFETCHED_TRACK_PER_SEC** - The number of tracks pre-fetched from disk to cache upon detection of a sequential read stream. * **READS** - A data transfer of a read between the director and the cache. * **WRITES** - A data transfer of a write between the cache and the director. * **REQUEST_PER_SEC** - A data transfer between the director and the cache. An IO may require multiple requests depending on IO size, alignment or both. For writes the request counter increments at the time that the write pending flag is removed from the cache slot. In the event that multiple DAs are involved in the IO operation (such as RAID-1), the request count may not reconcile with the IO count and IO size. * **SYSCALL_COUNT_PER_SEC** - The total number of calls seen by this director. * **SYSCALL_RDF_DIR_COUNT_PER_SEC** - The number of calls sent using RDF to a remote system. * **SYSCALL_REMOTE_DIR_COUNT_PER_SEC** - The number of calls sent from the local director to another director in the same system. * **VLUN_MIG_WRITE** - These metrics are for internal Symmetrix operations. * **VLUN_MIG_READ** - These metrics are for internal Symmetrix operations. * **COMP_READS** - The number of compressed read requests per second. * **COMP_WRITES** - The number of compressed write requests per second. * **COMP_MB_READ_PER_SEC** - The size of compressed read MBs per second. * **COMP_MB_WRITE_PER_SEC** - The size of compressed write MBs per second. * **COMP_REQUESTS** - The total number of compressed requests (read and write) per second. * **COMP_MB_RATE** - The total size of compressed MBs (read and write) per second. * **PERCENT_COMP_READS** - The percent of all compressed requests that were read requests. * **PERCENT_COMP_WRITES** - The percent of all compressed requests that were write requests. * **PERCENT_COMP_REQUESTS** - The total percent of all read and write requests. * **PERCENT_COMP_MB_READ** - The percent of all compressed MBs that were read MBs. * **PERCENT_COMP_MB_WRITTEN** - The percent of all compressed MBs that were write MBs. * **PERCENT_COMP_MB** - The total percent of all compressed read and write MBs. * **PERCENT_BUSY_CORE_0** - The total percent of time that core 0 is busy serving IOs. * **PERCENT_BUSY_CORE_1** - The total percent of time that core 1 is busy serving IOs. * **PERCENT_IDLE_CORE_0** - The total percent of time that core 0 is idle. * **PERCENT_IDLE_CORE_1** - The total percent of time that core 1 is idle. * **PORT_0_READ_PER_SEC** - The count of the reads passed through port 0 per second. * **PORT_1_READ_PER_SEC** - The count of the reads passed through port 1 per second. * **PORT_0_WRITE_PER_SEC** - The count of the writes passed through port 0 per second. * **PORT_1_WRITE_PER_SEC** - The count of the writes passed through port 1 per second. * **PORT_0_MBYTES_READ_PER_SEC** - The number of MBs per second on port 0 that were reads. * **PORT_1_MBYTES_READ_PER_SEC** - The number of MBs per second on port 1 that were reads. * **PORT_0_MBYTES_WRITTEN_PER_SEC** - The number of MBs per second on port 0 that were writes. * **PORT_1_MBYTES_WRITTEN_PER_SEC** - The number of MBs per second on port 1 that were writes. * **PERCENT_NON_IO_BUSY_CORE_0** - The total percent of time that core 0 is busy serving non-IO tasks. * **PERCENT_NON_IO_BUSY_CORE_1** - The total percent of time that core 1 is busy serving non-IO tasks. * **PERCENT_NON_IO_BUSY** - The total percent of time that the DA is busy serving non-IO tasks.  | 

## Methods

### NewExternalDirectorParam

`func NewExternalDirectorParam(startDate int64, endDate int64, symmetrixId string, directorId string, metrics []string, ) *ExternalDirectorParam`

NewExternalDirectorParam instantiates a new ExternalDirectorParam object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewExternalDirectorParamWithDefaults

`func NewExternalDirectorParamWithDefaults() *ExternalDirectorParam`

NewExternalDirectorParamWithDefaults instantiates a new ExternalDirectorParam object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetStartDate

`func (o *ExternalDirectorParam) GetStartDate() int64`

GetStartDate returns the StartDate field if non-nil, zero value otherwise.

### GetStartDateOk

`func (o *ExternalDirectorParam) GetStartDateOk() (*int64, bool)`

GetStartDateOk returns a tuple with the StartDate field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetStartDate

`func (o *ExternalDirectorParam) SetStartDate(v int64)`

SetStartDate sets StartDate field to given value.


### GetEndDate

`func (o *ExternalDirectorParam) GetEndDate() int64`

GetEndDate returns the EndDate field if non-nil, zero value otherwise.

### GetEndDateOk

`func (o *ExternalDirectorParam) GetEndDateOk() (*int64, bool)`

GetEndDateOk returns a tuple with the EndDate field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetEndDate

`func (o *ExternalDirectorParam) SetEndDate(v int64)`

SetEndDate sets EndDate field to given value.


### GetSymmetrixId

`func (o *ExternalDirectorParam) GetSymmetrixId() string`

GetSymmetrixId returns the SymmetrixId field if non-nil, zero value otherwise.

### GetSymmetrixIdOk

`func (o *ExternalDirectorParam) GetSymmetrixIdOk() (*string, bool)`

GetSymmetrixIdOk returns a tuple with the SymmetrixId field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetSymmetrixId

`func (o *ExternalDirectorParam) SetSymmetrixId(v string)`

SetSymmetrixId sets SymmetrixId field to given value.


### GetDirectorId

`func (o *ExternalDirectorParam) GetDirectorId() string`

GetDirectorId returns the DirectorId field if non-nil, zero value otherwise.

### GetDirectorIdOk

`func (o *ExternalDirectorParam) GetDirectorIdOk() (*string, bool)`

GetDirectorIdOk returns a tuple with the DirectorId field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetDirectorId

`func (o *ExternalDirectorParam) SetDirectorId(v string)`

SetDirectorId sets DirectorId field to given value.


### GetDataFormat

`func (o *ExternalDirectorParam) GetDataFormat() string`

GetDataFormat returns the DataFormat field if non-nil, zero value otherwise.

### GetDataFormatOk

`func (o *ExternalDirectorParam) GetDataFormatOk() (*string, bool)`

GetDataFormatOk returns a tuple with the DataFormat field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetDataFormat

`func (o *ExternalDirectorParam) SetDataFormat(v string)`

SetDataFormat sets DataFormat field to given value.

### HasDataFormat

`func (o *ExternalDirectorParam) HasDataFormat() bool`

HasDataFormat returns a boolean if a field has been set.

### GetMetrics

`func (o *ExternalDirectorParam) GetMetrics() []string`

GetMetrics returns the Metrics field if non-nil, zero value otherwise.

### GetMetricsOk

`func (o *ExternalDirectorParam) GetMetricsOk() (*[]string, bool)`

GetMetricsOk returns a tuple with the Metrics field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetMetrics

`func (o *ExternalDirectorParam) SetMetrics(v []string)`

SetMetrics sets Metrics field to given value.



[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


