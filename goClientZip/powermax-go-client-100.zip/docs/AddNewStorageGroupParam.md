# AddNewStorageGroupParam

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**SrpId** | Pointer to **string** | The SRP to be associated with the New Child Storage Group.                                     The Current or 1st Child Storage Group SRP is used if no SRP is defined | [optional] 
**SloBasedStorageGroupParam** | Pointer to [**[]SloBasedStorageGroupParam**](SloBasedStorageGroupParam.md) | sloBasedStorageGroupParam | [optional] 
**Emulation** | Pointer to **string** | The emulation of the volumes to be added to the New Storage Group(s).                                 If an Emulation is defined, it must adhere to the following rules:                                 Specified Storage group is an empty Standalone: any valid Emulation type can be                                 specified, FBA by default                                 Specified Storage group is a Standalone that contains volumes: emulation must                                 match the                                 current volume emulations                                 Specified Storage group is a Parent, and all current children are empty: any                                 valid                                 Emulation type can be specified, FBA by default                                 Specified Storage group is a Parent and at least one other child contains                                 volumes:                                 emulation must match the current volume emulations   Enumeration values: * **FBA** * **CELERRA_FBA** * **CKD-3390** * **CKD-3380** * **FILE_FBA** * **AS/400_D910_099**  | [optional] [default to "FBA"]
**EnableComplianceAlerts** | Pointer to **bool** | Optional setting to enable Compliance Alerts on the Storage Group(s) being added                                 that have the following characteristics:                                 Parent Storage Group is in a masking view                                 Service level other than Optimized and None,                                 Contains non Gatekeepers volumes. | [optional] [default to false]

## Methods

### NewAddNewStorageGroupParam

`func NewAddNewStorageGroupParam() *AddNewStorageGroupParam`

NewAddNewStorageGroupParam instantiates a new AddNewStorageGroupParam object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewAddNewStorageGroupParamWithDefaults

`func NewAddNewStorageGroupParamWithDefaults() *AddNewStorageGroupParam`

NewAddNewStorageGroupParamWithDefaults instantiates a new AddNewStorageGroupParam object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetSrpId

`func (o *AddNewStorageGroupParam) GetSrpId() string`

GetSrpId returns the SrpId field if non-nil, zero value otherwise.

### GetSrpIdOk

`func (o *AddNewStorageGroupParam) GetSrpIdOk() (*string, bool)`

GetSrpIdOk returns a tuple with the SrpId field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetSrpId

`func (o *AddNewStorageGroupParam) SetSrpId(v string)`

SetSrpId sets SrpId field to given value.

### HasSrpId

`func (o *AddNewStorageGroupParam) HasSrpId() bool`

HasSrpId returns a boolean if a field has been set.

### GetSloBasedStorageGroupParam

`func (o *AddNewStorageGroupParam) GetSloBasedStorageGroupParam() []SloBasedStorageGroupParam`

GetSloBasedStorageGroupParam returns the SloBasedStorageGroupParam field if non-nil, zero value otherwise.

### GetSloBasedStorageGroupParamOk

`func (o *AddNewStorageGroupParam) GetSloBasedStorageGroupParamOk() (*[]SloBasedStorageGroupParam, bool)`

GetSloBasedStorageGroupParamOk returns a tuple with the SloBasedStorageGroupParam field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetSloBasedStorageGroupParam

`func (o *AddNewStorageGroupParam) SetSloBasedStorageGroupParam(v []SloBasedStorageGroupParam)`

SetSloBasedStorageGroupParam sets SloBasedStorageGroupParam field to given value.

### HasSloBasedStorageGroupParam

`func (o *AddNewStorageGroupParam) HasSloBasedStorageGroupParam() bool`

HasSloBasedStorageGroupParam returns a boolean if a field has been set.

### GetEmulation

`func (o *AddNewStorageGroupParam) GetEmulation() string`

GetEmulation returns the Emulation field if non-nil, zero value otherwise.

### GetEmulationOk

`func (o *AddNewStorageGroupParam) GetEmulationOk() (*string, bool)`

GetEmulationOk returns a tuple with the Emulation field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetEmulation

`func (o *AddNewStorageGroupParam) SetEmulation(v string)`

SetEmulation sets Emulation field to given value.

### HasEmulation

`func (o *AddNewStorageGroupParam) HasEmulation() bool`

HasEmulation returns a boolean if a field has been set.

### GetEnableComplianceAlerts

`func (o *AddNewStorageGroupParam) GetEnableComplianceAlerts() bool`

GetEnableComplianceAlerts returns the EnableComplianceAlerts field if non-nil, zero value otherwise.

### GetEnableComplianceAlertsOk

`func (o *AddNewStorageGroupParam) GetEnableComplianceAlertsOk() (*bool, bool)`

GetEnableComplianceAlertsOk returns a tuple with the EnableComplianceAlerts field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetEnableComplianceAlerts

`func (o *AddNewStorageGroupParam) SetEnableComplianceAlerts(v bool)`

SetEnableComplianceAlerts sets EnableComplianceAlerts field to given value.

### HasEnableComplianceAlerts

`func (o *AddNewStorageGroupParam) HasEnableComplianceAlerts() bool`

HasEnableComplianceAlerts returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


