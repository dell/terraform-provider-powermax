# EndpointKeyResult

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**EndpointInfo** | Pointer to [**[]EndpointInfo**](EndpointInfo.md) | endpointInfo | [optional] 

## Methods

### NewEndpointKeyResult

`func NewEndpointKeyResult() *EndpointKeyResult`

NewEndpointKeyResult instantiates a new EndpointKeyResult object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewEndpointKeyResultWithDefaults

`func NewEndpointKeyResultWithDefaults() *EndpointKeyResult`

NewEndpointKeyResultWithDefaults instantiates a new EndpointKeyResult object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetEndpointInfo

`func (o *EndpointKeyResult) GetEndpointInfo() []EndpointInfo`

GetEndpointInfo returns the EndpointInfo field if non-nil, zero value otherwise.

### GetEndpointInfoOk

`func (o *EndpointKeyResult) GetEndpointInfoOk() (*[]EndpointInfo, bool)`

GetEndpointInfoOk returns a tuple with the EndpointInfo field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetEndpointInfo

`func (o *EndpointKeyResult) SetEndpointInfo(v []EndpointInfo)`

SetEndpointInfo sets EndpointInfo field to given value.

### HasEndpointInfo

`func (o *EndpointKeyResult) HasEndpointInfo() bool`

HasEndpointInfo returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


