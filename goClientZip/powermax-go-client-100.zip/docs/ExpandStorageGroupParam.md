# ExpandStorageGroupParam

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**AddExistingStorageGroupParam** | Pointer to [**AddExistingStorageGroupParam**](AddExistingStorageGroupParam.md) |  | [optional] 
**AddNewStorageGroupParam** | Pointer to [**AddNewStorageGroupParam**](AddNewStorageGroupParam.md) |  | [optional] 
**ExpandVolumesParam** | Pointer to [**ExpandVolumesParam**](ExpandVolumesParam.md) |  | [optional] 
**AddSpecificVolumeParam** | Pointer to [**AddSpecificVolumeParam**](AddSpecificVolumeParam.md) |  | [optional] 
**AddVolumeParam** | Pointer to [**AddVolumeParam**](AddVolumeParam.md) |  | [optional] 

## Methods

### NewExpandStorageGroupParam

`func NewExpandStorageGroupParam() *ExpandStorageGroupParam`

NewExpandStorageGroupParam instantiates a new ExpandStorageGroupParam object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewExpandStorageGroupParamWithDefaults

`func NewExpandStorageGroupParamWithDefaults() *ExpandStorageGroupParam`

NewExpandStorageGroupParamWithDefaults instantiates a new ExpandStorageGroupParam object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetAddExistingStorageGroupParam

`func (o *ExpandStorageGroupParam) GetAddExistingStorageGroupParam() AddExistingStorageGroupParam`

GetAddExistingStorageGroupParam returns the AddExistingStorageGroupParam field if non-nil, zero value otherwise.

### GetAddExistingStorageGroupParamOk

`func (o *ExpandStorageGroupParam) GetAddExistingStorageGroupParamOk() (*AddExistingStorageGroupParam, bool)`

GetAddExistingStorageGroupParamOk returns a tuple with the AddExistingStorageGroupParam field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetAddExistingStorageGroupParam

`func (o *ExpandStorageGroupParam) SetAddExistingStorageGroupParam(v AddExistingStorageGroupParam)`

SetAddExistingStorageGroupParam sets AddExistingStorageGroupParam field to given value.

### HasAddExistingStorageGroupParam

`func (o *ExpandStorageGroupParam) HasAddExistingStorageGroupParam() bool`

HasAddExistingStorageGroupParam returns a boolean if a field has been set.

### GetAddNewStorageGroupParam

`func (o *ExpandStorageGroupParam) GetAddNewStorageGroupParam() AddNewStorageGroupParam`

GetAddNewStorageGroupParam returns the AddNewStorageGroupParam field if non-nil, zero value otherwise.

### GetAddNewStorageGroupParamOk

`func (o *ExpandStorageGroupParam) GetAddNewStorageGroupParamOk() (*AddNewStorageGroupParam, bool)`

GetAddNewStorageGroupParamOk returns a tuple with the AddNewStorageGroupParam field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetAddNewStorageGroupParam

`func (o *ExpandStorageGroupParam) SetAddNewStorageGroupParam(v AddNewStorageGroupParam)`

SetAddNewStorageGroupParam sets AddNewStorageGroupParam field to given value.

### HasAddNewStorageGroupParam

`func (o *ExpandStorageGroupParam) HasAddNewStorageGroupParam() bool`

HasAddNewStorageGroupParam returns a boolean if a field has been set.

### GetExpandVolumesParam

`func (o *ExpandStorageGroupParam) GetExpandVolumesParam() ExpandVolumesParam`

GetExpandVolumesParam returns the ExpandVolumesParam field if non-nil, zero value otherwise.

### GetExpandVolumesParamOk

`func (o *ExpandStorageGroupParam) GetExpandVolumesParamOk() (*ExpandVolumesParam, bool)`

GetExpandVolumesParamOk returns a tuple with the ExpandVolumesParam field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetExpandVolumesParam

`func (o *ExpandStorageGroupParam) SetExpandVolumesParam(v ExpandVolumesParam)`

SetExpandVolumesParam sets ExpandVolumesParam field to given value.

### HasExpandVolumesParam

`func (o *ExpandStorageGroupParam) HasExpandVolumesParam() bool`

HasExpandVolumesParam returns a boolean if a field has been set.

### GetAddSpecificVolumeParam

`func (o *ExpandStorageGroupParam) GetAddSpecificVolumeParam() AddSpecificVolumeParam`

GetAddSpecificVolumeParam returns the AddSpecificVolumeParam field if non-nil, zero value otherwise.

### GetAddSpecificVolumeParamOk

`func (o *ExpandStorageGroupParam) GetAddSpecificVolumeParamOk() (*AddSpecificVolumeParam, bool)`

GetAddSpecificVolumeParamOk returns a tuple with the AddSpecificVolumeParam field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetAddSpecificVolumeParam

`func (o *ExpandStorageGroupParam) SetAddSpecificVolumeParam(v AddSpecificVolumeParam)`

SetAddSpecificVolumeParam sets AddSpecificVolumeParam field to given value.

### HasAddSpecificVolumeParam

`func (o *ExpandStorageGroupParam) HasAddSpecificVolumeParam() bool`

HasAddSpecificVolumeParam returns a boolean if a field has been set.

### GetAddVolumeParam

`func (o *ExpandStorageGroupParam) GetAddVolumeParam() AddVolumeParam`

GetAddVolumeParam returns the AddVolumeParam field if non-nil, zero value otherwise.

### GetAddVolumeParamOk

`func (o *ExpandStorageGroupParam) GetAddVolumeParamOk() (*AddVolumeParam, bool)`

GetAddVolumeParamOk returns a tuple with the AddVolumeParam field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetAddVolumeParam

`func (o *ExpandStorageGroupParam) SetAddVolumeParam(v AddVolumeParam)`

SetAddVolumeParam sets AddVolumeParam field to given value.

### HasAddVolumeParam

`func (o *ExpandStorageGroupParam) HasAddVolumeParam() bool`

HasAddVolumeParam returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


