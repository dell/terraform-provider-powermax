# HostOrHostGroupSelection

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**AutoHostGroupParam** | Pointer to [**AutoHostGroupParam**](AutoHostGroupParam.md) |  | [optional] 
**CreateHostGroupParam** | Pointer to [**CreateHostGroupParam**](CreateHostGroupParam.md) |  | [optional] 
**UseExistingHostGroupParam** | Pointer to [**UseExistingHostGroupParam**](UseExistingHostGroupParam.md) |  | [optional] 
**CreateHostParam** | Pointer to [**CreateHostParam**](CreateHostParam.md) |  | [optional] 
**UseExistingHostParam** | Pointer to [**UseExistingHostParam**](UseExistingHostParam.md) |  | [optional] 

## Methods

### NewHostOrHostGroupSelection

`func NewHostOrHostGroupSelection() *HostOrHostGroupSelection`

NewHostOrHostGroupSelection instantiates a new HostOrHostGroupSelection object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewHostOrHostGroupSelectionWithDefaults

`func NewHostOrHostGroupSelectionWithDefaults() *HostOrHostGroupSelection`

NewHostOrHostGroupSelectionWithDefaults instantiates a new HostOrHostGroupSelection object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetAutoHostGroupParam

`func (o *HostOrHostGroupSelection) GetAutoHostGroupParam() AutoHostGroupParam`

GetAutoHostGroupParam returns the AutoHostGroupParam field if non-nil, zero value otherwise.

### GetAutoHostGroupParamOk

`func (o *HostOrHostGroupSelection) GetAutoHostGroupParamOk() (*AutoHostGroupParam, bool)`

GetAutoHostGroupParamOk returns a tuple with the AutoHostGroupParam field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetAutoHostGroupParam

`func (o *HostOrHostGroupSelection) SetAutoHostGroupParam(v AutoHostGroupParam)`

SetAutoHostGroupParam sets AutoHostGroupParam field to given value.

### HasAutoHostGroupParam

`func (o *HostOrHostGroupSelection) HasAutoHostGroupParam() bool`

HasAutoHostGroupParam returns a boolean if a field has been set.

### GetCreateHostGroupParam

`func (o *HostOrHostGroupSelection) GetCreateHostGroupParam() CreateHostGroupParam`

GetCreateHostGroupParam returns the CreateHostGroupParam field if non-nil, zero value otherwise.

### GetCreateHostGroupParamOk

`func (o *HostOrHostGroupSelection) GetCreateHostGroupParamOk() (*CreateHostGroupParam, bool)`

GetCreateHostGroupParamOk returns a tuple with the CreateHostGroupParam field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetCreateHostGroupParam

`func (o *HostOrHostGroupSelection) SetCreateHostGroupParam(v CreateHostGroupParam)`

SetCreateHostGroupParam sets CreateHostGroupParam field to given value.

### HasCreateHostGroupParam

`func (o *HostOrHostGroupSelection) HasCreateHostGroupParam() bool`

HasCreateHostGroupParam returns a boolean if a field has been set.

### GetUseExistingHostGroupParam

`func (o *HostOrHostGroupSelection) GetUseExistingHostGroupParam() UseExistingHostGroupParam`

GetUseExistingHostGroupParam returns the UseExistingHostGroupParam field if non-nil, zero value otherwise.

### GetUseExistingHostGroupParamOk

`func (o *HostOrHostGroupSelection) GetUseExistingHostGroupParamOk() (*UseExistingHostGroupParam, bool)`

GetUseExistingHostGroupParamOk returns a tuple with the UseExistingHostGroupParam field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetUseExistingHostGroupParam

`func (o *HostOrHostGroupSelection) SetUseExistingHostGroupParam(v UseExistingHostGroupParam)`

SetUseExistingHostGroupParam sets UseExistingHostGroupParam field to given value.

### HasUseExistingHostGroupParam

`func (o *HostOrHostGroupSelection) HasUseExistingHostGroupParam() bool`

HasUseExistingHostGroupParam returns a boolean if a field has been set.

### GetCreateHostParam

`func (o *HostOrHostGroupSelection) GetCreateHostParam() CreateHostParam`

GetCreateHostParam returns the CreateHostParam field if non-nil, zero value otherwise.

### GetCreateHostParamOk

`func (o *HostOrHostGroupSelection) GetCreateHostParamOk() (*CreateHostParam, bool)`

GetCreateHostParamOk returns a tuple with the CreateHostParam field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetCreateHostParam

`func (o *HostOrHostGroupSelection) SetCreateHostParam(v CreateHostParam)`

SetCreateHostParam sets CreateHostParam field to given value.

### HasCreateHostParam

`func (o *HostOrHostGroupSelection) HasCreateHostParam() bool`

HasCreateHostParam returns a boolean if a field has been set.

### GetUseExistingHostParam

`func (o *HostOrHostGroupSelection) GetUseExistingHostParam() UseExistingHostParam`

GetUseExistingHostParam returns the UseExistingHostParam field if non-nil, zero value otherwise.

### GetUseExistingHostParamOk

`func (o *HostOrHostGroupSelection) GetUseExistingHostParamOk() (*UseExistingHostParam, bool)`

GetUseExistingHostParamOk returns a tuple with the UseExistingHostParam field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetUseExistingHostParam

`func (o *HostOrHostGroupSelection) SetUseExistingHostParam(v UseExistingHostParam)`

SetUseExistingHostParam sets UseExistingHostParam field to given value.

### HasUseExistingHostParam

`func (o *HostOrHostGroupSelection) HasUseExistingHostParam() bool`

HasUseExistingHostParam returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


