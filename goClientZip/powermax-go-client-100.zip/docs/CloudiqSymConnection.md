# CloudiqSymConnection

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**SymId** | **string** | sym_id | 
**DataCollectionEnabled** | **bool** | data_collection_enabled | 

## Methods

### NewCloudiqSymConnection

`func NewCloudiqSymConnection(symId string, dataCollectionEnabled bool, ) *CloudiqSymConnection`

NewCloudiqSymConnection instantiates a new CloudiqSymConnection object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewCloudiqSymConnectionWithDefaults

`func NewCloudiqSymConnectionWithDefaults() *CloudiqSymConnection`

NewCloudiqSymConnectionWithDefaults instantiates a new CloudiqSymConnection object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetSymId

`func (o *CloudiqSymConnection) GetSymId() string`

GetSymId returns the SymId field if non-nil, zero value otherwise.

### GetSymIdOk

`func (o *CloudiqSymConnection) GetSymIdOk() (*string, bool)`

GetSymIdOk returns a tuple with the SymId field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetSymId

`func (o *CloudiqSymConnection) SetSymId(v string)`

SetSymId sets SymId field to given value.


### GetDataCollectionEnabled

`func (o *CloudiqSymConnection) GetDataCollectionEnabled() bool`

GetDataCollectionEnabled returns the DataCollectionEnabled field if non-nil, zero value otherwise.

### GetDataCollectionEnabledOk

`func (o *CloudiqSymConnection) GetDataCollectionEnabledOk() (*bool, bool)`

GetDataCollectionEnabledOk returns a tuple with the DataCollectionEnabled field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetDataCollectionEnabled

`func (o *CloudiqSymConnection) SetDataCollectionEnabled(v bool)`

SetDataCollectionEnabled sets DataCollectionEnabled field to given value.



[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


