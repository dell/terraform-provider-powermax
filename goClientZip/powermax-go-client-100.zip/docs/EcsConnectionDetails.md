# EcsConnectionDetails

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Key** | Pointer to **string** | The Cloud Provider Key | [optional] 
**Secret** | Pointer to **string** | The Cloud Provider Secret | [optional] 
**Node** | Pointer to **string** | The Cloud Provider Node | [optional] 
**Secure** | Pointer to **bool** | Is The Cloud Provider Secure, HTTPS &#x3D; true | [optional] 
**Port** | Pointer to **int32** | The Cloud Provider Port | [optional] 
**Bucket** | Pointer to **string** | The Cloud Provider Bucket id | [optional] 

## Methods

### NewEcsConnectionDetails

`func NewEcsConnectionDetails() *EcsConnectionDetails`

NewEcsConnectionDetails instantiates a new EcsConnectionDetails object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewEcsConnectionDetailsWithDefaults

`func NewEcsConnectionDetailsWithDefaults() *EcsConnectionDetails`

NewEcsConnectionDetailsWithDefaults instantiates a new EcsConnectionDetails object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetKey

`func (o *EcsConnectionDetails) GetKey() string`

GetKey returns the Key field if non-nil, zero value otherwise.

### GetKeyOk

`func (o *EcsConnectionDetails) GetKeyOk() (*string, bool)`

GetKeyOk returns a tuple with the Key field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetKey

`func (o *EcsConnectionDetails) SetKey(v string)`

SetKey sets Key field to given value.

### HasKey

`func (o *EcsConnectionDetails) HasKey() bool`

HasKey returns a boolean if a field has been set.

### GetSecret

`func (o *EcsConnectionDetails) GetSecret() string`

GetSecret returns the Secret field if non-nil, zero value otherwise.

### GetSecretOk

`func (o *EcsConnectionDetails) GetSecretOk() (*string, bool)`

GetSecretOk returns a tuple with the Secret field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetSecret

`func (o *EcsConnectionDetails) SetSecret(v string)`

SetSecret sets Secret field to given value.

### HasSecret

`func (o *EcsConnectionDetails) HasSecret() bool`

HasSecret returns a boolean if a field has been set.

### GetNode

`func (o *EcsConnectionDetails) GetNode() string`

GetNode returns the Node field if non-nil, zero value otherwise.

### GetNodeOk

`func (o *EcsConnectionDetails) GetNodeOk() (*string, bool)`

GetNodeOk returns a tuple with the Node field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetNode

`func (o *EcsConnectionDetails) SetNode(v string)`

SetNode sets Node field to given value.

### HasNode

`func (o *EcsConnectionDetails) HasNode() bool`

HasNode returns a boolean if a field has been set.

### GetSecure

`func (o *EcsConnectionDetails) GetSecure() bool`

GetSecure returns the Secure field if non-nil, zero value otherwise.

### GetSecureOk

`func (o *EcsConnectionDetails) GetSecureOk() (*bool, bool)`

GetSecureOk returns a tuple with the Secure field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetSecure

`func (o *EcsConnectionDetails) SetSecure(v bool)`

SetSecure sets Secure field to given value.

### HasSecure

`func (o *EcsConnectionDetails) HasSecure() bool`

HasSecure returns a boolean if a field has been set.

### GetPort

`func (o *EcsConnectionDetails) GetPort() int32`

GetPort returns the Port field if non-nil, zero value otherwise.

### GetPortOk

`func (o *EcsConnectionDetails) GetPortOk() (*int32, bool)`

GetPortOk returns a tuple with the Port field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetPort

`func (o *EcsConnectionDetails) SetPort(v int32)`

SetPort sets Port field to given value.

### HasPort

`func (o *EcsConnectionDetails) HasPort() bool`

HasPort returns a boolean if a field has been set.

### GetBucket

`func (o *EcsConnectionDetails) GetBucket() string`

GetBucket returns the Bucket field if non-nil, zero value otherwise.

### GetBucketOk

`func (o *EcsConnectionDetails) GetBucketOk() (*string, bool)`

GetBucketOk returns a tuple with the Bucket field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetBucket

`func (o *EcsConnectionDetails) SetBucket(v string)`

SetBucket sets Bucket field to given value.

### HasBucket

`func (o *EcsConnectionDetails) HasBucket() bool`

HasBucket returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


