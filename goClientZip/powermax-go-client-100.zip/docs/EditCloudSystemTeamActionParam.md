# EditCloudSystemTeamActionParam

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**EditTeamSettings** | Pointer to [**EditTeamSettingsParam**](EditTeamSettingsParam.md) |  | [optional] 

## Methods

### NewEditCloudSystemTeamActionParam

`func NewEditCloudSystemTeamActionParam() *EditCloudSystemTeamActionParam`

NewEditCloudSystemTeamActionParam instantiates a new EditCloudSystemTeamActionParam object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewEditCloudSystemTeamActionParamWithDefaults

`func NewEditCloudSystemTeamActionParamWithDefaults() *EditCloudSystemTeamActionParam`

NewEditCloudSystemTeamActionParamWithDefaults instantiates a new EditCloudSystemTeamActionParam object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetEditTeamSettings

`func (o *EditCloudSystemTeamActionParam) GetEditTeamSettings() EditTeamSettingsParam`

GetEditTeamSettings returns the EditTeamSettings field if non-nil, zero value otherwise.

### GetEditTeamSettingsOk

`func (o *EditCloudSystemTeamActionParam) GetEditTeamSettingsOk() (*EditTeamSettingsParam, bool)`

GetEditTeamSettingsOk returns a tuple with the EditTeamSettings field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetEditTeamSettings

`func (o *EditCloudSystemTeamActionParam) SetEditTeamSettings(v EditTeamSettingsParam)`

SetEditTeamSettings sets EditTeamSettings field to given value.

### HasEditTeamSettings

`func (o *EditCloudSystemTeamActionParam) HasEditTeamSettings() bool`

HasEditTeamSettings returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


