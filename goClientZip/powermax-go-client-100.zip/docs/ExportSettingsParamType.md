# ExportSettingsParamType

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**SourceArray** | Pointer to **string** | &lt;p&gt;Identifier for a storage array from which the settings are to be exported.&lt;/p&gt; | [optional] 
**FilePassword** | **string** | &lt;p&gt;Password securing the exported zip file.&lt;/p&gt; | 
**ExcludeUnisphereSettingOptions** | Pointer to **[]string** | &lt;p&gt;Setting names falling into application wide settings category that are to be excluded from the export. Use                                 \&quot;all\&quot; for all the settings in the category. &lt;/p&gt;   Enumeration values: * **all** - All settings in the category * **alert_notification_settings** - Excludes alert notification settings - mail server configuration, email recipients, snmp target list * **performance_preference_settings** - Excludes performance preference settings from the export - custom performance preference settings * **performance_user_templates** - Excludes performance user runbooks from the export - user defined performance runbooks * **performance_metric_settings** - Excludes performance metrics from the export - custom KPI enablement  | [optional] 
**ExcludeSystemSettingOptions** | Pointer to **[]string** | &lt;p&gt;Setting names falling into storage array settings category that are to be excluded from the export. Use \&quot;all\&quot;                                 for all the settings in the category. &lt;/p&gt;   Enumeration values: * **all** - All settings in the category * **alert_policy_settings** - Excludes alert policy settings from the export - alert policy enablement and notification type settings * **system_threshold_settings** - Excludes system threshold and alerts settings from the export - alert level thresholds and notification type settings * **performance_threshold_settings** - Excludes performance threshold and alerts settings from the export - performance level thresholds and notification type settings * **alert_level_notification_settings** - Excludes alert level notification settings from the export - severity levels of the alerts for which the notifications are being sent  | [optional] 

## Methods

### NewExportSettingsParamType

`func NewExportSettingsParamType(filePassword string, ) *ExportSettingsParamType`

NewExportSettingsParamType instantiates a new ExportSettingsParamType object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewExportSettingsParamTypeWithDefaults

`func NewExportSettingsParamTypeWithDefaults() *ExportSettingsParamType`

NewExportSettingsParamTypeWithDefaults instantiates a new ExportSettingsParamType object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetSourceArray

`func (o *ExportSettingsParamType) GetSourceArray() string`

GetSourceArray returns the SourceArray field if non-nil, zero value otherwise.

### GetSourceArrayOk

`func (o *ExportSettingsParamType) GetSourceArrayOk() (*string, bool)`

GetSourceArrayOk returns a tuple with the SourceArray field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetSourceArray

`func (o *ExportSettingsParamType) SetSourceArray(v string)`

SetSourceArray sets SourceArray field to given value.

### HasSourceArray

`func (o *ExportSettingsParamType) HasSourceArray() bool`

HasSourceArray returns a boolean if a field has been set.

### GetFilePassword

`func (o *ExportSettingsParamType) GetFilePassword() string`

GetFilePassword returns the FilePassword field if non-nil, zero value otherwise.

### GetFilePasswordOk

`func (o *ExportSettingsParamType) GetFilePasswordOk() (*string, bool)`

GetFilePasswordOk returns a tuple with the FilePassword field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetFilePassword

`func (o *ExportSettingsParamType) SetFilePassword(v string)`

SetFilePassword sets FilePassword field to given value.


### GetExcludeUnisphereSettingOptions

`func (o *ExportSettingsParamType) GetExcludeUnisphereSettingOptions() []string`

GetExcludeUnisphereSettingOptions returns the ExcludeUnisphereSettingOptions field if non-nil, zero value otherwise.

### GetExcludeUnisphereSettingOptionsOk

`func (o *ExportSettingsParamType) GetExcludeUnisphereSettingOptionsOk() (*[]string, bool)`

GetExcludeUnisphereSettingOptionsOk returns a tuple with the ExcludeUnisphereSettingOptions field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetExcludeUnisphereSettingOptions

`func (o *ExportSettingsParamType) SetExcludeUnisphereSettingOptions(v []string)`

SetExcludeUnisphereSettingOptions sets ExcludeUnisphereSettingOptions field to given value.

### HasExcludeUnisphereSettingOptions

`func (o *ExportSettingsParamType) HasExcludeUnisphereSettingOptions() bool`

HasExcludeUnisphereSettingOptions returns a boolean if a field has been set.

### GetExcludeSystemSettingOptions

`func (o *ExportSettingsParamType) GetExcludeSystemSettingOptions() []string`

GetExcludeSystemSettingOptions returns the ExcludeSystemSettingOptions field if non-nil, zero value otherwise.

### GetExcludeSystemSettingOptionsOk

`func (o *ExportSettingsParamType) GetExcludeSystemSettingOptionsOk() (*[]string, bool)`

GetExcludeSystemSettingOptionsOk returns a tuple with the ExcludeSystemSettingOptions field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetExcludeSystemSettingOptions

`func (o *ExportSettingsParamType) SetExcludeSystemSettingOptions(v []string)`

SetExcludeSystemSettingOptions sets ExcludeSystemSettingOptions field to given value.

### HasExcludeSystemSettingOptions

`func (o *ExportSettingsParamType) HasExcludeSystemSettingOptions() bool`

HasExcludeSystemSettingOptions returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


