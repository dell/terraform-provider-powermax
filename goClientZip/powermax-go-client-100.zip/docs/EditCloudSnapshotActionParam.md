# EditCloudSnapshotActionParam

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Action** | **string** | The action to be performed.   Enumeration values: * **pause** - Pauses the archiving process of the cloud snapshot in the following state only                         [\&quot;Archiving\&quot;] * **resume** - Resumes the archiving process of the cloud snapshot in the following state only                         [\&quot;Paused\&quot;] * **cancel** - Cancels the archiving process of the cloud snapshot in the following states only                         [\&quot;Queued\&quot;, \&quot;Archiving\&quot;] * **recover** - Create a local copy of the cloud snapshot in the following states only [\&quot;Archived\&quot;] * **alter** - Alter the expiration date of a cloud snapshot in the following states only [\&quot;Archived\&quot;]  | 
**Pause** | Pointer to **map[string]interface{}** | Pauses the archiving process of the cloud snapshot in the following state only                 [\&quot;Archiving\&quot;] | [optional] 
**Resume** | Pointer to **map[string]interface{}** | Resumes the archiving process of the cloud snapshot in the following state only                 [\&quot;Paused\&quot;] | [optional] 
**Cancel** | Pointer to **map[string]interface{}** | Cancels the archiving process of the cloud snapshot in the following states only                 [\&quot;Queued\&quot;, \&quot;Archiving\&quot;] | [optional] 
**Recover** | Pointer to [**RecoverCloudSnapshotParam**](RecoverCloudSnapshotParam.md) |  | [optional] 

## Methods

### NewEditCloudSnapshotActionParam

`func NewEditCloudSnapshotActionParam(action string, ) *EditCloudSnapshotActionParam`

NewEditCloudSnapshotActionParam instantiates a new EditCloudSnapshotActionParam object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewEditCloudSnapshotActionParamWithDefaults

`func NewEditCloudSnapshotActionParamWithDefaults() *EditCloudSnapshotActionParam`

NewEditCloudSnapshotActionParamWithDefaults instantiates a new EditCloudSnapshotActionParam object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetAction

`func (o *EditCloudSnapshotActionParam) GetAction() string`

GetAction returns the Action field if non-nil, zero value otherwise.

### GetActionOk

`func (o *EditCloudSnapshotActionParam) GetActionOk() (*string, bool)`

GetActionOk returns a tuple with the Action field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetAction

`func (o *EditCloudSnapshotActionParam) SetAction(v string)`

SetAction sets Action field to given value.


### GetPause

`func (o *EditCloudSnapshotActionParam) GetPause() map[string]interface{}`

GetPause returns the Pause field if non-nil, zero value otherwise.

### GetPauseOk

`func (o *EditCloudSnapshotActionParam) GetPauseOk() (*map[string]interface{}, bool)`

GetPauseOk returns a tuple with the Pause field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetPause

`func (o *EditCloudSnapshotActionParam) SetPause(v map[string]interface{})`

SetPause sets Pause field to given value.

### HasPause

`func (o *EditCloudSnapshotActionParam) HasPause() bool`

HasPause returns a boolean if a field has been set.

### GetResume

`func (o *EditCloudSnapshotActionParam) GetResume() map[string]interface{}`

GetResume returns the Resume field if non-nil, zero value otherwise.

### GetResumeOk

`func (o *EditCloudSnapshotActionParam) GetResumeOk() (*map[string]interface{}, bool)`

GetResumeOk returns a tuple with the Resume field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetResume

`func (o *EditCloudSnapshotActionParam) SetResume(v map[string]interface{})`

SetResume sets Resume field to given value.

### HasResume

`func (o *EditCloudSnapshotActionParam) HasResume() bool`

HasResume returns a boolean if a field has been set.

### GetCancel

`func (o *EditCloudSnapshotActionParam) GetCancel() map[string]interface{}`

GetCancel returns the Cancel field if non-nil, zero value otherwise.

### GetCancelOk

`func (o *EditCloudSnapshotActionParam) GetCancelOk() (*map[string]interface{}, bool)`

GetCancelOk returns a tuple with the Cancel field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetCancel

`func (o *EditCloudSnapshotActionParam) SetCancel(v map[string]interface{})`

SetCancel sets Cancel field to given value.

### HasCancel

`func (o *EditCloudSnapshotActionParam) HasCancel() bool`

HasCancel returns a boolean if a field has been set.

### GetRecover

`func (o *EditCloudSnapshotActionParam) GetRecover() RecoverCloudSnapshotParam`

GetRecover returns the Recover field if non-nil, zero value otherwise.

### GetRecoverOk

`func (o *EditCloudSnapshotActionParam) GetRecoverOk() (*RecoverCloudSnapshotParam, bool)`

GetRecoverOk returns a tuple with the Recover field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetRecover

`func (o *EditCloudSnapshotActionParam) SetRecover(v RecoverCloudSnapshotParam)`

SetRecover sets Recover field to given value.

### HasRecover

`func (o *EditCloudSnapshotActionParam) HasRecover() bool`

HasRecover returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


