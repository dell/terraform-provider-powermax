# EditRMTEntryParamType

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ExecutionOption** | Pointer to **string** |  | [optional] [default to "SYNCHRONOUS"]
**RmtTargetList** | [**[]RmtTargetInfoType**](RmtTargetInfoType.md) | rmt_target_list | 

## Methods

### NewEditRMTEntryParamType

`func NewEditRMTEntryParamType(rmtTargetList []RmtTargetInfoType, ) *EditRMTEntryParamType`

NewEditRMTEntryParamType instantiates a new EditRMTEntryParamType object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewEditRMTEntryParamTypeWithDefaults

`func NewEditRMTEntryParamTypeWithDefaults() *EditRMTEntryParamType`

NewEditRMTEntryParamTypeWithDefaults instantiates a new EditRMTEntryParamType object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetExecutionOption

`func (o *EditRMTEntryParamType) GetExecutionOption() string`

GetExecutionOption returns the ExecutionOption field if non-nil, zero value otherwise.

### GetExecutionOptionOk

`func (o *EditRMTEntryParamType) GetExecutionOptionOk() (*string, bool)`

GetExecutionOptionOk returns a tuple with the ExecutionOption field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetExecutionOption

`func (o *EditRMTEntryParamType) SetExecutionOption(v string)`

SetExecutionOption sets ExecutionOption field to given value.

### HasExecutionOption

`func (o *EditRMTEntryParamType) HasExecutionOption() bool`

HasExecutionOption returns a boolean if a field has been set.

### GetRmtTargetList

`func (o *EditRMTEntryParamType) GetRmtTargetList() []RmtTargetInfoType`

GetRmtTargetList returns the RmtTargetList field if non-nil, zero value otherwise.

### GetRmtTargetListOk

`func (o *EditRMTEntryParamType) GetRmtTargetListOk() (*[]RmtTargetInfoType, bool)`

GetRmtTargetListOk returns a tuple with the RmtTargetList field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetRmtTargetList

`func (o *EditRMTEntryParamType) SetRmtTargetList(v []RmtTargetInfoType)`

SetRmtTargetList sets RmtTargetList field to given value.



[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


