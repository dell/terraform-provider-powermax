# LocalUsersSetPasswordParam

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**CurrentPassword** | **string** | The current password of the local user | 
**NewPassword** | **string** | The new password of the local user | 

## Methods

### NewLocalUsersSetPasswordParam

`func NewLocalUsersSetPasswordParam(currentPassword string, newPassword string, ) *LocalUsersSetPasswordParam`

NewLocalUsersSetPasswordParam instantiates a new LocalUsersSetPasswordParam object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewLocalUsersSetPasswordParamWithDefaults

`func NewLocalUsersSetPasswordParamWithDefaults() *LocalUsersSetPasswordParam`

NewLocalUsersSetPasswordParamWithDefaults instantiates a new LocalUsersSetPasswordParam object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetCurrentPassword

`func (o *LocalUsersSetPasswordParam) GetCurrentPassword() string`

GetCurrentPassword returns the CurrentPassword field if non-nil, zero value otherwise.

### GetCurrentPasswordOk

`func (o *LocalUsersSetPasswordParam) GetCurrentPasswordOk() (*string, bool)`

GetCurrentPasswordOk returns a tuple with the CurrentPassword field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetCurrentPassword

`func (o *LocalUsersSetPasswordParam) SetCurrentPassword(v string)`

SetCurrentPassword sets CurrentPassword field to given value.


### GetNewPassword

`func (o *LocalUsersSetPasswordParam) GetNewPassword() string`

GetNewPassword returns the NewPassword field if non-nil, zero value otherwise.

### GetNewPasswordOk

`func (o *LocalUsersSetPasswordParam) GetNewPasswordOk() (*string, bool)`

GetNewPasswordOk returns a tuple with the NewPassword field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetNewPassword

`func (o *LocalUsersSetPasswordParam) SetNewPassword(v string)`

SetNewPassword sets NewPassword field to given value.



[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


