# BePortInfo

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**FirstAvailableDate** | Pointer to **int64** |  | [optional] 
**LastAvailableDate** | Pointer to **int64** |  | [optional] 
**PortId** | **string** | portId | 

## Methods

### NewBePortInfo

`func NewBePortInfo(portId string, ) *BePortInfo`

NewBePortInfo instantiates a new BePortInfo object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewBePortInfoWithDefaults

`func NewBePortInfoWithDefaults() *BePortInfo`

NewBePortInfoWithDefaults instantiates a new BePortInfo object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetFirstAvailableDate

`func (o *BePortInfo) GetFirstAvailableDate() int64`

GetFirstAvailableDate returns the FirstAvailableDate field if non-nil, zero value otherwise.

### GetFirstAvailableDateOk

`func (o *BePortInfo) GetFirstAvailableDateOk() (*int64, bool)`

GetFirstAvailableDateOk returns a tuple with the FirstAvailableDate field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetFirstAvailableDate

`func (o *BePortInfo) SetFirstAvailableDate(v int64)`

SetFirstAvailableDate sets FirstAvailableDate field to given value.

### HasFirstAvailableDate

`func (o *BePortInfo) HasFirstAvailableDate() bool`

HasFirstAvailableDate returns a boolean if a field has been set.

### GetLastAvailableDate

`func (o *BePortInfo) GetLastAvailableDate() int64`

GetLastAvailableDate returns the LastAvailableDate field if non-nil, zero value otherwise.

### GetLastAvailableDateOk

`func (o *BePortInfo) GetLastAvailableDateOk() (*int64, bool)`

GetLastAvailableDateOk returns a tuple with the LastAvailableDate field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetLastAvailableDate

`func (o *BePortInfo) SetLastAvailableDate(v int64)`

SetLastAvailableDate sets LastAvailableDate field to given value.

### HasLastAvailableDate

`func (o *BePortInfo) HasLastAvailableDate() bool`

HasLastAvailableDate returns a boolean if a field has been set.

### GetPortId

`func (o *BePortInfo) GetPortId() string`

GetPortId returns the PortId field if non-nil, zero value otherwise.

### GetPortIdOk

`func (o *BePortInfo) GetPortIdOk() (*string, bool)`

GetPortIdOk returns a tuple with the PortId field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetPortId

`func (o *BePortInfo) SetPortId(v string)`

SetPortId sets PortId field to given value.



[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


