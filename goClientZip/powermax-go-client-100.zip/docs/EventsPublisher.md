# EventsPublisher

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Id** | Pointer to **string** |  Unique identifier of the Event publisher  | [optional] 
**NasServer** | Pointer to **string** |  Unique identifier of the NasServer  | [optional] 
**Enabled** | Pointer to **bool** |  enable the event publisher default: false | [optional] 
**Heartbeat** | Pointer to **int32** |  Time interval to scan each CEPA server (in seconds) for online/offline status  | [optional] 
**Timeout** | Pointer to **int32** |                          Timeout in milliseconds while attempting to send event to a CEPA server to determine that is offline                      | [optional] 
**PostEventPolicy** | Pointer to **int32** |                          Post-event notification policies for the Event Service. Values are:                         - 0: Ignore - Continue and tolerate lost events.                         - 1: Accumulate - Continue and use a persistence file as a circular event buffer for lost events.                         - 2: Guarantee - Continue and use a persistence file as a circular event buffer for lost events until the buffer is filled and then deny access to files systems where Events Publishing is Enabled.                         - 3: Deny - Deny access to files systems where Events Publishing is enabled.                      | [optional] 
**DenyAccessWhenAllServersOffline** | Pointer to **bool** |                          Behaviour when the File Event Service server did not answer. Values are:                         false - indicates that nothing changes with I/O in case of File Event Service server is offline.                         true - indicates that all I/O is denied in case of File Event Service server is offline.                      | [optional] 
**Username** | Pointer to **string** |                          Name of a Windows user allowing Events Publishing to connect to CEPA servers. To ensure that a secure connection (via Microsoft RPC protocol) is used disable HTTP by setting httpPort to 0                      | [optional] 
**HttpPort** | Pointer to **int32** |                          TCP port number used but the service to connect to the CEPA server(s) with HTTP. Default port number is 12228.                         Set this httpPort value to 0 to disable HTTP.                         When enabled, connection via HTTP is attempted first.                         If HTTP connection is disabled, or the connection fails, then connection through MSRPC is attempted if all CEPP server(s) are defined by FQDN.                         The SMB account of the NAS server in the AD Domain is used to make the connection via MSRPC. Note that HTTP connections should only be used on secure networks, as it is neither SSL nor authenticated.                      | [optional] 
**Health** | Pointer to [**Health**](Health.md) |  | [optional] 

## Methods

### NewEventsPublisher

`func NewEventsPublisher() *EventsPublisher`

NewEventsPublisher instantiates a new EventsPublisher object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewEventsPublisherWithDefaults

`func NewEventsPublisherWithDefaults() *EventsPublisher`

NewEventsPublisherWithDefaults instantiates a new EventsPublisher object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetId

`func (o *EventsPublisher) GetId() string`

GetId returns the Id field if non-nil, zero value otherwise.

### GetIdOk

`func (o *EventsPublisher) GetIdOk() (*string, bool)`

GetIdOk returns a tuple with the Id field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetId

`func (o *EventsPublisher) SetId(v string)`

SetId sets Id field to given value.

### HasId

`func (o *EventsPublisher) HasId() bool`

HasId returns a boolean if a field has been set.

### GetNasServer

`func (o *EventsPublisher) GetNasServer() string`

GetNasServer returns the NasServer field if non-nil, zero value otherwise.

### GetNasServerOk

`func (o *EventsPublisher) GetNasServerOk() (*string, bool)`

GetNasServerOk returns a tuple with the NasServer field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetNasServer

`func (o *EventsPublisher) SetNasServer(v string)`

SetNasServer sets NasServer field to given value.

### HasNasServer

`func (o *EventsPublisher) HasNasServer() bool`

HasNasServer returns a boolean if a field has been set.

### GetEnabled

`func (o *EventsPublisher) GetEnabled() bool`

GetEnabled returns the Enabled field if non-nil, zero value otherwise.

### GetEnabledOk

`func (o *EventsPublisher) GetEnabledOk() (*bool, bool)`

GetEnabledOk returns a tuple with the Enabled field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetEnabled

`func (o *EventsPublisher) SetEnabled(v bool)`

SetEnabled sets Enabled field to given value.

### HasEnabled

`func (o *EventsPublisher) HasEnabled() bool`

HasEnabled returns a boolean if a field has been set.

### GetHeartbeat

`func (o *EventsPublisher) GetHeartbeat() int32`

GetHeartbeat returns the Heartbeat field if non-nil, zero value otherwise.

### GetHeartbeatOk

`func (o *EventsPublisher) GetHeartbeatOk() (*int32, bool)`

GetHeartbeatOk returns a tuple with the Heartbeat field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetHeartbeat

`func (o *EventsPublisher) SetHeartbeat(v int32)`

SetHeartbeat sets Heartbeat field to given value.

### HasHeartbeat

`func (o *EventsPublisher) HasHeartbeat() bool`

HasHeartbeat returns a boolean if a field has been set.

### GetTimeout

`func (o *EventsPublisher) GetTimeout() int32`

GetTimeout returns the Timeout field if non-nil, zero value otherwise.

### GetTimeoutOk

`func (o *EventsPublisher) GetTimeoutOk() (*int32, bool)`

GetTimeoutOk returns a tuple with the Timeout field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetTimeout

`func (o *EventsPublisher) SetTimeout(v int32)`

SetTimeout sets Timeout field to given value.

### HasTimeout

`func (o *EventsPublisher) HasTimeout() bool`

HasTimeout returns a boolean if a field has been set.

### GetPostEventPolicy

`func (o *EventsPublisher) GetPostEventPolicy() int32`

GetPostEventPolicy returns the PostEventPolicy field if non-nil, zero value otherwise.

### GetPostEventPolicyOk

`func (o *EventsPublisher) GetPostEventPolicyOk() (*int32, bool)`

GetPostEventPolicyOk returns a tuple with the PostEventPolicy field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetPostEventPolicy

`func (o *EventsPublisher) SetPostEventPolicy(v int32)`

SetPostEventPolicy sets PostEventPolicy field to given value.

### HasPostEventPolicy

`func (o *EventsPublisher) HasPostEventPolicy() bool`

HasPostEventPolicy returns a boolean if a field has been set.

### GetDenyAccessWhenAllServersOffline

`func (o *EventsPublisher) GetDenyAccessWhenAllServersOffline() bool`

GetDenyAccessWhenAllServersOffline returns the DenyAccessWhenAllServersOffline field if non-nil, zero value otherwise.

### GetDenyAccessWhenAllServersOfflineOk

`func (o *EventsPublisher) GetDenyAccessWhenAllServersOfflineOk() (*bool, bool)`

GetDenyAccessWhenAllServersOfflineOk returns a tuple with the DenyAccessWhenAllServersOffline field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetDenyAccessWhenAllServersOffline

`func (o *EventsPublisher) SetDenyAccessWhenAllServersOffline(v bool)`

SetDenyAccessWhenAllServersOffline sets DenyAccessWhenAllServersOffline field to given value.

### HasDenyAccessWhenAllServersOffline

`func (o *EventsPublisher) HasDenyAccessWhenAllServersOffline() bool`

HasDenyAccessWhenAllServersOffline returns a boolean if a field has been set.

### GetUsername

`func (o *EventsPublisher) GetUsername() string`

GetUsername returns the Username field if non-nil, zero value otherwise.

### GetUsernameOk

`func (o *EventsPublisher) GetUsernameOk() (*string, bool)`

GetUsernameOk returns a tuple with the Username field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetUsername

`func (o *EventsPublisher) SetUsername(v string)`

SetUsername sets Username field to given value.

### HasUsername

`func (o *EventsPublisher) HasUsername() bool`

HasUsername returns a boolean if a field has been set.

### GetHttpPort

`func (o *EventsPublisher) GetHttpPort() int32`

GetHttpPort returns the HttpPort field if non-nil, zero value otherwise.

### GetHttpPortOk

`func (o *EventsPublisher) GetHttpPortOk() (*int32, bool)`

GetHttpPortOk returns a tuple with the HttpPort field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetHttpPort

`func (o *EventsPublisher) SetHttpPort(v int32)`

SetHttpPort sets HttpPort field to given value.

### HasHttpPort

`func (o *EventsPublisher) HasHttpPort() bool`

HasHttpPort returns a boolean if a field has been set.

### GetHealth

`func (o *EventsPublisher) GetHealth() Health`

GetHealth returns the Health field if non-nil, zero value otherwise.

### GetHealthOk

`func (o *EventsPublisher) GetHealthOk() (*Health, bool)`

GetHealthOk returns a tuple with the Health field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetHealth

`func (o *EventsPublisher) SetHealth(v Health)`

SetHealth sets Health field to given value.

### HasHealth

`func (o *EventsPublisher) HasHealth() bool`

HasHealth returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


