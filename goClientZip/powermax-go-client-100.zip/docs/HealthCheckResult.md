# HealthCheckResult

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**TestResult** | Pointer to [**[]HealthCheckResultItem**](HealthCheckResultItem.md) | testResult | [optional] 
**ExecutionStatus** | Pointer to **string** | execution_status | [optional] 
**SymmetrixId** | Pointer to **string** | symmetrixId | [optional] 
**Description** | Pointer to **string** | description | [optional] 
**Date** | Pointer to **int64** | date | [optional] 

## Methods

### NewHealthCheckResult

`func NewHealthCheckResult() *HealthCheckResult`

NewHealthCheckResult instantiates a new HealthCheckResult object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewHealthCheckResultWithDefaults

`func NewHealthCheckResultWithDefaults() *HealthCheckResult`

NewHealthCheckResultWithDefaults instantiates a new HealthCheckResult object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetTestResult

`func (o *HealthCheckResult) GetTestResult() []HealthCheckResultItem`

GetTestResult returns the TestResult field if non-nil, zero value otherwise.

### GetTestResultOk

`func (o *HealthCheckResult) GetTestResultOk() (*[]HealthCheckResultItem, bool)`

GetTestResultOk returns a tuple with the TestResult field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetTestResult

`func (o *HealthCheckResult) SetTestResult(v []HealthCheckResultItem)`

SetTestResult sets TestResult field to given value.

### HasTestResult

`func (o *HealthCheckResult) HasTestResult() bool`

HasTestResult returns a boolean if a field has been set.

### GetExecutionStatus

`func (o *HealthCheckResult) GetExecutionStatus() string`

GetExecutionStatus returns the ExecutionStatus field if non-nil, zero value otherwise.

### GetExecutionStatusOk

`func (o *HealthCheckResult) GetExecutionStatusOk() (*string, bool)`

GetExecutionStatusOk returns a tuple with the ExecutionStatus field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetExecutionStatus

`func (o *HealthCheckResult) SetExecutionStatus(v string)`

SetExecutionStatus sets ExecutionStatus field to given value.

### HasExecutionStatus

`func (o *HealthCheckResult) HasExecutionStatus() bool`

HasExecutionStatus returns a boolean if a field has been set.

### GetSymmetrixId

`func (o *HealthCheckResult) GetSymmetrixId() string`

GetSymmetrixId returns the SymmetrixId field if non-nil, zero value otherwise.

### GetSymmetrixIdOk

`func (o *HealthCheckResult) GetSymmetrixIdOk() (*string, bool)`

GetSymmetrixIdOk returns a tuple with the SymmetrixId field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetSymmetrixId

`func (o *HealthCheckResult) SetSymmetrixId(v string)`

SetSymmetrixId sets SymmetrixId field to given value.

### HasSymmetrixId

`func (o *HealthCheckResult) HasSymmetrixId() bool`

HasSymmetrixId returns a boolean if a field has been set.

### GetDescription

`func (o *HealthCheckResult) GetDescription() string`

GetDescription returns the Description field if non-nil, zero value otherwise.

### GetDescriptionOk

`func (o *HealthCheckResult) GetDescriptionOk() (*string, bool)`

GetDescriptionOk returns a tuple with the Description field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetDescription

`func (o *HealthCheckResult) SetDescription(v string)`

SetDescription sets Description field to given value.

### HasDescription

`func (o *HealthCheckResult) HasDescription() bool`

HasDescription returns a boolean if a field has been set.

### GetDate

`func (o *HealthCheckResult) GetDate() int64`

GetDate returns the Date field if non-nil, zero value otherwise.

### GetDateOk

`func (o *HealthCheckResult) GetDateOk() (*int64, bool)`

GetDateOk returns a tuple with the Date field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetDate

`func (o *HealthCheckResult) SetDate(v int64)`

SetDate sets Date field to given value.

### HasDate

`func (o *HealthCheckResult) HasDate() bool`

HasDate returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


