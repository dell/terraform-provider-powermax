# DiskKeyResult

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**DiskInfo** | Pointer to [**[]DiskInfo**](DiskInfo.md) | diskInfo | [optional] 

## Methods

### NewDiskKeyResult

`func NewDiskKeyResult() *DiskKeyResult`

NewDiskKeyResult instantiates a new DiskKeyResult object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewDiskKeyResultWithDefaults

`func NewDiskKeyResultWithDefaults() *DiskKeyResult`

NewDiskKeyResultWithDefaults instantiates a new DiskKeyResult object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetDiskInfo

`func (o *DiskKeyResult) GetDiskInfo() []DiskInfo`

GetDiskInfo returns the DiskInfo field if non-nil, zero value otherwise.

### GetDiskInfoOk

`func (o *DiskKeyResult) GetDiskInfoOk() (*[]DiskInfo, bool)`

GetDiskInfoOk returns a tuple with the DiskInfo field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetDiskInfo

`func (o *DiskKeyResult) SetDiskInfo(v []DiskInfo)`

SetDiskInfo sets DiskInfo field to given value.

### HasDiskInfo

`func (o *DiskKeyResult) HasDiskInfo() bool`

HasDiskInfo returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


