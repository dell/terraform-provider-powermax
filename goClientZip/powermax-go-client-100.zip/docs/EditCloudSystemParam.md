# EditCloudSystemParam

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ExecutionOption** | Pointer to **string** |  | [optional] [default to "SYNCHRONOUS"]
**Action** | **string** | The action to be performed.   Enumeration values: * **resolve** - Resolves any issues with the Cloud System where possible * **rerun_setup** - Re-runs the setup procedure to establish communication with the Cloud System,                         Note: Cloud System must be in an un-enrolled state before running this command.  | 

## Methods

### NewEditCloudSystemParam

`func NewEditCloudSystemParam(action string, ) *EditCloudSystemParam`

NewEditCloudSystemParam instantiates a new EditCloudSystemParam object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewEditCloudSystemParamWithDefaults

`func NewEditCloudSystemParamWithDefaults() *EditCloudSystemParam`

NewEditCloudSystemParamWithDefaults instantiates a new EditCloudSystemParam object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetExecutionOption

`func (o *EditCloudSystemParam) GetExecutionOption() string`

GetExecutionOption returns the ExecutionOption field if non-nil, zero value otherwise.

### GetExecutionOptionOk

`func (o *EditCloudSystemParam) GetExecutionOptionOk() (*string, bool)`

GetExecutionOptionOk returns a tuple with the ExecutionOption field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetExecutionOption

`func (o *EditCloudSystemParam) SetExecutionOption(v string)`

SetExecutionOption sets ExecutionOption field to given value.

### HasExecutionOption

`func (o *EditCloudSystemParam) HasExecutionOption() bool`

HasExecutionOption returns a boolean if a field has been set.

### GetAction

`func (o *EditCloudSystemParam) GetAction() string`

GetAction returns the Action field if non-nil, zero value otherwise.

### GetActionOk

`func (o *EditCloudSystemParam) GetActionOk() (*string, bool)`

GetActionOk returns a tuple with the Action field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetAction

`func (o *EditCloudSystemParam) SetAction(v string)`

SetAction sets Action field to given value.



[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


