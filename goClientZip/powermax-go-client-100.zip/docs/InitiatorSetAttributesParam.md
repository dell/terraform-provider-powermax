# InitiatorSetAttributesParam

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**FcidValue** | **string** | The new FCID value. | 

## Methods

### NewInitiatorSetAttributesParam

`func NewInitiatorSetAttributesParam(fcidValue string, ) *InitiatorSetAttributesParam`

NewInitiatorSetAttributesParam instantiates a new InitiatorSetAttributesParam object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewInitiatorSetAttributesParamWithDefaults

`func NewInitiatorSetAttributesParamWithDefaults() *InitiatorSetAttributesParam`

NewInitiatorSetAttributesParamWithDefaults instantiates a new InitiatorSetAttributesParam object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetFcidValue

`func (o *InitiatorSetAttributesParam) GetFcidValue() string`

GetFcidValue returns the FcidValue field if non-nil, zero value otherwise.

### GetFcidValueOk

`func (o *InitiatorSetAttributesParam) GetFcidValueOk() (*string, bool)`

GetFcidValueOk returns a tuple with the FcidValue field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetFcidValue

`func (o *InitiatorSetAttributesParam) SetFcidValue(v string)`

SetFcidValue sets FcidValue field to given value.



[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


