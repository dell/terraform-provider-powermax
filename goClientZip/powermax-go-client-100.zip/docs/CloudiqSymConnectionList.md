# CloudiqSymConnectionList

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**CloudiqSymConnection** | [**[]CloudiqSymConnection**](CloudiqSymConnection.md) | cloudiq_sym_connection | 

## Methods

### NewCloudiqSymConnectionList

`func NewCloudiqSymConnectionList(cloudiqSymConnection []CloudiqSymConnection, ) *CloudiqSymConnectionList`

NewCloudiqSymConnectionList instantiates a new CloudiqSymConnectionList object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewCloudiqSymConnectionListWithDefaults

`func NewCloudiqSymConnectionListWithDefaults() *CloudiqSymConnectionList`

NewCloudiqSymConnectionListWithDefaults instantiates a new CloudiqSymConnectionList object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetCloudiqSymConnection

`func (o *CloudiqSymConnectionList) GetCloudiqSymConnection() []CloudiqSymConnection`

GetCloudiqSymConnection returns the CloudiqSymConnection field if non-nil, zero value otherwise.

### GetCloudiqSymConnectionOk

`func (o *CloudiqSymConnectionList) GetCloudiqSymConnectionOk() (*[]CloudiqSymConnection, bool)`

GetCloudiqSymConnectionOk returns a tuple with the CloudiqSymConnection field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetCloudiqSymConnection

`func (o *CloudiqSymConnectionList) SetCloudiqSymConnection(v []CloudiqSymConnection)`

SetCloudiqSymConnection sets CloudiqSymConnection field to given value.



[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


