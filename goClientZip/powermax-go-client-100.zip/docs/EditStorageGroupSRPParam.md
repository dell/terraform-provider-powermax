# EditStorageGroupSRPParam

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**SrpId** | **string** | The New SRP Name | 

## Methods

### NewEditStorageGroupSRPParam

`func NewEditStorageGroupSRPParam(srpId string, ) *EditStorageGroupSRPParam`

NewEditStorageGroupSRPParam instantiates a new EditStorageGroupSRPParam object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewEditStorageGroupSRPParamWithDefaults

`func NewEditStorageGroupSRPParamWithDefaults() *EditStorageGroupSRPParam`

NewEditStorageGroupSRPParamWithDefaults instantiates a new EditStorageGroupSRPParam object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetSrpId

`func (o *EditStorageGroupSRPParam) GetSrpId() string`

GetSrpId returns the SrpId field if non-nil, zero value otherwise.

### GetSrpIdOk

`func (o *EditStorageGroupSRPParam) GetSrpIdOk() (*string, bool)`

GetSrpIdOk returns a tuple with the SrpId field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetSrpId

`func (o *EditStorageGroupSRPParam) SetSrpId(v string)`

SetSrpId sets SrpId field to given value.



[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


