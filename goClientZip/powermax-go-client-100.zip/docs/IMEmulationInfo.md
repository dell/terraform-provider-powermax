# IMEmulationInfo

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**FirstAvailableDate** | Pointer to **int64** |  | [optional] 
**LastAvailableDate** | Pointer to **int64** |  | [optional] 
**ImEmulationId** | **string** | imEmulationId | 

## Methods

### NewIMEmulationInfo

`func NewIMEmulationInfo(imEmulationId string, ) *IMEmulationInfo`

NewIMEmulationInfo instantiates a new IMEmulationInfo object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewIMEmulationInfoWithDefaults

`func NewIMEmulationInfoWithDefaults() *IMEmulationInfo`

NewIMEmulationInfoWithDefaults instantiates a new IMEmulationInfo object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetFirstAvailableDate

`func (o *IMEmulationInfo) GetFirstAvailableDate() int64`

GetFirstAvailableDate returns the FirstAvailableDate field if non-nil, zero value otherwise.

### GetFirstAvailableDateOk

`func (o *IMEmulationInfo) GetFirstAvailableDateOk() (*int64, bool)`

GetFirstAvailableDateOk returns a tuple with the FirstAvailableDate field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetFirstAvailableDate

`func (o *IMEmulationInfo) SetFirstAvailableDate(v int64)`

SetFirstAvailableDate sets FirstAvailableDate field to given value.

### HasFirstAvailableDate

`func (o *IMEmulationInfo) HasFirstAvailableDate() bool`

HasFirstAvailableDate returns a boolean if a field has been set.

### GetLastAvailableDate

`func (o *IMEmulationInfo) GetLastAvailableDate() int64`

GetLastAvailableDate returns the LastAvailableDate field if non-nil, zero value otherwise.

### GetLastAvailableDateOk

`func (o *IMEmulationInfo) GetLastAvailableDateOk() (*int64, bool)`

GetLastAvailableDateOk returns a tuple with the LastAvailableDate field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetLastAvailableDate

`func (o *IMEmulationInfo) SetLastAvailableDate(v int64)`

SetLastAvailableDate sets LastAvailableDate field to given value.

### HasLastAvailableDate

`func (o *IMEmulationInfo) HasLastAvailableDate() bool`

HasLastAvailableDate returns a boolean if a field has been set.

### GetImEmulationId

`func (o *IMEmulationInfo) GetImEmulationId() string`

GetImEmulationId returns the ImEmulationId field if non-nil, zero value otherwise.

### GetImEmulationIdOk

`func (o *IMEmulationInfo) GetImEmulationIdOk() (*string, bool)`

GetImEmulationIdOk returns a tuple with the ImEmulationId field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetImEmulationId

`func (o *IMEmulationInfo) SetImEmulationId(v string)`

SetImEmulationId sets ImEmulationId field to given value.



[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


