# EditVasaProviderParam

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ExecutionOption** | Pointer to **string** |  | [optional] [default to "SYNCHRONOUS"]
**EditVasaProviderActionParam** | [**EditVasaProviderActionParam**](EditVasaProviderActionParam.md) |  | 

## Methods

### NewEditVasaProviderParam

`func NewEditVasaProviderParam(editVasaProviderActionParam EditVasaProviderActionParam, ) *EditVasaProviderParam`

NewEditVasaProviderParam instantiates a new EditVasaProviderParam object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewEditVasaProviderParamWithDefaults

`func NewEditVasaProviderParamWithDefaults() *EditVasaProviderParam`

NewEditVasaProviderParamWithDefaults instantiates a new EditVasaProviderParam object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetExecutionOption

`func (o *EditVasaProviderParam) GetExecutionOption() string`

GetExecutionOption returns the ExecutionOption field if non-nil, zero value otherwise.

### GetExecutionOptionOk

`func (o *EditVasaProviderParam) GetExecutionOptionOk() (*string, bool)`

GetExecutionOptionOk returns a tuple with the ExecutionOption field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetExecutionOption

`func (o *EditVasaProviderParam) SetExecutionOption(v string)`

SetExecutionOption sets ExecutionOption field to given value.

### HasExecutionOption

`func (o *EditVasaProviderParam) HasExecutionOption() bool`

HasExecutionOption returns a boolean if a field has been set.

### GetEditVasaProviderActionParam

`func (o *EditVasaProviderParam) GetEditVasaProviderActionParam() EditVasaProviderActionParam`

GetEditVasaProviderActionParam returns the EditVasaProviderActionParam field if non-nil, zero value otherwise.

### GetEditVasaProviderActionParamOk

`func (o *EditVasaProviderParam) GetEditVasaProviderActionParamOk() (*EditVasaProviderActionParam, bool)`

GetEditVasaProviderActionParamOk returns a tuple with the EditVasaProviderActionParam field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetEditVasaProviderActionParam

`func (o *EditVasaProviderParam) SetEditVasaProviderActionParam(v EditVasaProviderActionParam)`

SetEditVasaProviderActionParam sets EditVasaProviderActionParam field to given value.



[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


