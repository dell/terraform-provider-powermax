# CloudJobInfoList

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**CloudJobInfo** | Pointer to [**[]CloudJobInfo**](CloudJobInfo.md) | The List of Cloud Job Infos | [optional] 

## Methods

### NewCloudJobInfoList

`func NewCloudJobInfoList() *CloudJobInfoList`

NewCloudJobInfoList instantiates a new CloudJobInfoList object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewCloudJobInfoListWithDefaults

`func NewCloudJobInfoListWithDefaults() *CloudJobInfoList`

NewCloudJobInfoListWithDefaults instantiates a new CloudJobInfoList object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetCloudJobInfo

`func (o *CloudJobInfoList) GetCloudJobInfo() []CloudJobInfo`

GetCloudJobInfo returns the CloudJobInfo field if non-nil, zero value otherwise.

### GetCloudJobInfoOk

`func (o *CloudJobInfoList) GetCloudJobInfoOk() (*[]CloudJobInfo, bool)`

GetCloudJobInfoOk returns a tuple with the CloudJobInfo field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetCloudJobInfo

`func (o *CloudJobInfoList) SetCloudJobInfo(v []CloudJobInfo)`

SetCloudJobInfo sets CloudJobInfo field to given value.

### HasCloudJobInfo

`func (o *CloudJobInfoList) HasCloudJobInfo() bool`

HasCloudJobInfo returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


