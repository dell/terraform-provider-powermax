# MetroDrEnvironment

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Name** | **string** | The name of the MetroDR environment. | 
**Valid** | Pointer to **bool** | Indicates that the MetroDR environment is valid | [optional] 
**EnvironmentExempt** | Pointer to **bool** | Indicates that there are exempt devices in the environment | [optional] 
**EnvironmentState** | Pointer to **string** | The state of the environment. | [optional] 
**CapacityGb** | Pointer to **float64** | The capacity, in GB, of the MetroDR environment. | [optional] 
**MetroState** | Pointer to **string** | The state of the Metro session in the environment. | [optional] 
**MetroLinkState** | Pointer to **string** | The state of the metro link in the environment | [optional] 
**MetroExempt** | Pointer to **bool** | Some volumes may be exempt in the Metro session | [optional] 
**MetroServiceState** | Pointer to **string** | The Service State of the Metro leg. | [optional] 
**MetroWitnessState** | Pointer to **string** | The state of the Metro witness. | [optional] 
**MetroPercentComplete** | Pointer to **int32** | The percent copied value | [optional] 
**MetroRemainCapacityToCopyMb** | Pointer to **int64** | The capacity remaining to copy (in MB) | [optional] 
**MetroR1ConnectivityHealth** | Pointer to **string** | The Connectivity Health for the Metro R1 System | [optional] 
**MetroR1ArrayHealth** | Pointer to **string** | The System Health for the Metro R1 System | [optional] 
**MetroR2ConnectivityHealth** | Pointer to **string** | The Connectivity Health for the Metro R2 System | [optional] 
**MetroR2ArrayHealth** | Pointer to **string** | The System Health for the Metro R2 System | [optional] 
**DrState** | Pointer to **string** | The State of the DR Session in the environment. | [optional] 
**DrLinkState** | Pointer to **string** | The state of the DR link in the environment | [optional] 
**DrExempt** | Pointer to **bool** | Some devices may be exempt in the DR session | [optional] 
**DrServiceState** | Pointer to **string** | The Service State of the DR leg. | [optional] 
**DrRdfMode** | Pointer to **string** | Indicates the mode for the DR session | [optional] 
**DrPercentComplete** | Pointer to **int32** | The percent copied value | [optional] 
**DrRemainCapacityToCopyMb** | Pointer to **int64** | The capacity remaining to copy (in MB) | [optional] 
**Configuration** | Pointer to [**MetroDrEnvironmentConfig**](MetroDrEnvironmentConfig.md) |  | [optional] 

## Methods

### NewMetroDrEnvironment

`func NewMetroDrEnvironment(name string, ) *MetroDrEnvironment`

NewMetroDrEnvironment instantiates a new MetroDrEnvironment object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewMetroDrEnvironmentWithDefaults

`func NewMetroDrEnvironmentWithDefaults() *MetroDrEnvironment`

NewMetroDrEnvironmentWithDefaults instantiates a new MetroDrEnvironment object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetName

`func (o *MetroDrEnvironment) GetName() string`

GetName returns the Name field if non-nil, zero value otherwise.

### GetNameOk

`func (o *MetroDrEnvironment) GetNameOk() (*string, bool)`

GetNameOk returns a tuple with the Name field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetName

`func (o *MetroDrEnvironment) SetName(v string)`

SetName sets Name field to given value.


### GetValid

`func (o *MetroDrEnvironment) GetValid() bool`

GetValid returns the Valid field if non-nil, zero value otherwise.

### GetValidOk

`func (o *MetroDrEnvironment) GetValidOk() (*bool, bool)`

GetValidOk returns a tuple with the Valid field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetValid

`func (o *MetroDrEnvironment) SetValid(v bool)`

SetValid sets Valid field to given value.

### HasValid

`func (o *MetroDrEnvironment) HasValid() bool`

HasValid returns a boolean if a field has been set.

### GetEnvironmentExempt

`func (o *MetroDrEnvironment) GetEnvironmentExempt() bool`

GetEnvironmentExempt returns the EnvironmentExempt field if non-nil, zero value otherwise.

### GetEnvironmentExemptOk

`func (o *MetroDrEnvironment) GetEnvironmentExemptOk() (*bool, bool)`

GetEnvironmentExemptOk returns a tuple with the EnvironmentExempt field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetEnvironmentExempt

`func (o *MetroDrEnvironment) SetEnvironmentExempt(v bool)`

SetEnvironmentExempt sets EnvironmentExempt field to given value.

### HasEnvironmentExempt

`func (o *MetroDrEnvironment) HasEnvironmentExempt() bool`

HasEnvironmentExempt returns a boolean if a field has been set.

### GetEnvironmentState

`func (o *MetroDrEnvironment) GetEnvironmentState() string`

GetEnvironmentState returns the EnvironmentState field if non-nil, zero value otherwise.

### GetEnvironmentStateOk

`func (o *MetroDrEnvironment) GetEnvironmentStateOk() (*string, bool)`

GetEnvironmentStateOk returns a tuple with the EnvironmentState field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetEnvironmentState

`func (o *MetroDrEnvironment) SetEnvironmentState(v string)`

SetEnvironmentState sets EnvironmentState field to given value.

### HasEnvironmentState

`func (o *MetroDrEnvironment) HasEnvironmentState() bool`

HasEnvironmentState returns a boolean if a field has been set.

### GetCapacityGb

`func (o *MetroDrEnvironment) GetCapacityGb() float64`

GetCapacityGb returns the CapacityGb field if non-nil, zero value otherwise.

### GetCapacityGbOk

`func (o *MetroDrEnvironment) GetCapacityGbOk() (*float64, bool)`

GetCapacityGbOk returns a tuple with the CapacityGb field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetCapacityGb

`func (o *MetroDrEnvironment) SetCapacityGb(v float64)`

SetCapacityGb sets CapacityGb field to given value.

### HasCapacityGb

`func (o *MetroDrEnvironment) HasCapacityGb() bool`

HasCapacityGb returns a boolean if a field has been set.

### GetMetroState

`func (o *MetroDrEnvironment) GetMetroState() string`

GetMetroState returns the MetroState field if non-nil, zero value otherwise.

### GetMetroStateOk

`func (o *MetroDrEnvironment) GetMetroStateOk() (*string, bool)`

GetMetroStateOk returns a tuple with the MetroState field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetMetroState

`func (o *MetroDrEnvironment) SetMetroState(v string)`

SetMetroState sets MetroState field to given value.

### HasMetroState

`func (o *MetroDrEnvironment) HasMetroState() bool`

HasMetroState returns a boolean if a field has been set.

### GetMetroLinkState

`func (o *MetroDrEnvironment) GetMetroLinkState() string`

GetMetroLinkState returns the MetroLinkState field if non-nil, zero value otherwise.

### GetMetroLinkStateOk

`func (o *MetroDrEnvironment) GetMetroLinkStateOk() (*string, bool)`

GetMetroLinkStateOk returns a tuple with the MetroLinkState field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetMetroLinkState

`func (o *MetroDrEnvironment) SetMetroLinkState(v string)`

SetMetroLinkState sets MetroLinkState field to given value.

### HasMetroLinkState

`func (o *MetroDrEnvironment) HasMetroLinkState() bool`

HasMetroLinkState returns a boolean if a field has been set.

### GetMetroExempt

`func (o *MetroDrEnvironment) GetMetroExempt() bool`

GetMetroExempt returns the MetroExempt field if non-nil, zero value otherwise.

### GetMetroExemptOk

`func (o *MetroDrEnvironment) GetMetroExemptOk() (*bool, bool)`

GetMetroExemptOk returns a tuple with the MetroExempt field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetMetroExempt

`func (o *MetroDrEnvironment) SetMetroExempt(v bool)`

SetMetroExempt sets MetroExempt field to given value.

### HasMetroExempt

`func (o *MetroDrEnvironment) HasMetroExempt() bool`

HasMetroExempt returns a boolean if a field has been set.

### GetMetroServiceState

`func (o *MetroDrEnvironment) GetMetroServiceState() string`

GetMetroServiceState returns the MetroServiceState field if non-nil, zero value otherwise.

### GetMetroServiceStateOk

`func (o *MetroDrEnvironment) GetMetroServiceStateOk() (*string, bool)`

GetMetroServiceStateOk returns a tuple with the MetroServiceState field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetMetroServiceState

`func (o *MetroDrEnvironment) SetMetroServiceState(v string)`

SetMetroServiceState sets MetroServiceState field to given value.

### HasMetroServiceState

`func (o *MetroDrEnvironment) HasMetroServiceState() bool`

HasMetroServiceState returns a boolean if a field has been set.

### GetMetroWitnessState

`func (o *MetroDrEnvironment) GetMetroWitnessState() string`

GetMetroWitnessState returns the MetroWitnessState field if non-nil, zero value otherwise.

### GetMetroWitnessStateOk

`func (o *MetroDrEnvironment) GetMetroWitnessStateOk() (*string, bool)`

GetMetroWitnessStateOk returns a tuple with the MetroWitnessState field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetMetroWitnessState

`func (o *MetroDrEnvironment) SetMetroWitnessState(v string)`

SetMetroWitnessState sets MetroWitnessState field to given value.

### HasMetroWitnessState

`func (o *MetroDrEnvironment) HasMetroWitnessState() bool`

HasMetroWitnessState returns a boolean if a field has been set.

### GetMetroPercentComplete

`func (o *MetroDrEnvironment) GetMetroPercentComplete() int32`

GetMetroPercentComplete returns the MetroPercentComplete field if non-nil, zero value otherwise.

### GetMetroPercentCompleteOk

`func (o *MetroDrEnvironment) GetMetroPercentCompleteOk() (*int32, bool)`

GetMetroPercentCompleteOk returns a tuple with the MetroPercentComplete field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetMetroPercentComplete

`func (o *MetroDrEnvironment) SetMetroPercentComplete(v int32)`

SetMetroPercentComplete sets MetroPercentComplete field to given value.

### HasMetroPercentComplete

`func (o *MetroDrEnvironment) HasMetroPercentComplete() bool`

HasMetroPercentComplete returns a boolean if a field has been set.

### GetMetroRemainCapacityToCopyMb

`func (o *MetroDrEnvironment) GetMetroRemainCapacityToCopyMb() int64`

GetMetroRemainCapacityToCopyMb returns the MetroRemainCapacityToCopyMb field if non-nil, zero value otherwise.

### GetMetroRemainCapacityToCopyMbOk

`func (o *MetroDrEnvironment) GetMetroRemainCapacityToCopyMbOk() (*int64, bool)`

GetMetroRemainCapacityToCopyMbOk returns a tuple with the MetroRemainCapacityToCopyMb field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetMetroRemainCapacityToCopyMb

`func (o *MetroDrEnvironment) SetMetroRemainCapacityToCopyMb(v int64)`

SetMetroRemainCapacityToCopyMb sets MetroRemainCapacityToCopyMb field to given value.

### HasMetroRemainCapacityToCopyMb

`func (o *MetroDrEnvironment) HasMetroRemainCapacityToCopyMb() bool`

HasMetroRemainCapacityToCopyMb returns a boolean if a field has been set.

### GetMetroR1ConnectivityHealth

`func (o *MetroDrEnvironment) GetMetroR1ConnectivityHealth() string`

GetMetroR1ConnectivityHealth returns the MetroR1ConnectivityHealth field if non-nil, zero value otherwise.

### GetMetroR1ConnectivityHealthOk

`func (o *MetroDrEnvironment) GetMetroR1ConnectivityHealthOk() (*string, bool)`

GetMetroR1ConnectivityHealthOk returns a tuple with the MetroR1ConnectivityHealth field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetMetroR1ConnectivityHealth

`func (o *MetroDrEnvironment) SetMetroR1ConnectivityHealth(v string)`

SetMetroR1ConnectivityHealth sets MetroR1ConnectivityHealth field to given value.

### HasMetroR1ConnectivityHealth

`func (o *MetroDrEnvironment) HasMetroR1ConnectivityHealth() bool`

HasMetroR1ConnectivityHealth returns a boolean if a field has been set.

### GetMetroR1ArrayHealth

`func (o *MetroDrEnvironment) GetMetroR1ArrayHealth() string`

GetMetroR1ArrayHealth returns the MetroR1ArrayHealth field if non-nil, zero value otherwise.

### GetMetroR1ArrayHealthOk

`func (o *MetroDrEnvironment) GetMetroR1ArrayHealthOk() (*string, bool)`

GetMetroR1ArrayHealthOk returns a tuple with the MetroR1ArrayHealth field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetMetroR1ArrayHealth

`func (o *MetroDrEnvironment) SetMetroR1ArrayHealth(v string)`

SetMetroR1ArrayHealth sets MetroR1ArrayHealth field to given value.

### HasMetroR1ArrayHealth

`func (o *MetroDrEnvironment) HasMetroR1ArrayHealth() bool`

HasMetroR1ArrayHealth returns a boolean if a field has been set.

### GetMetroR2ConnectivityHealth

`func (o *MetroDrEnvironment) GetMetroR2ConnectivityHealth() string`

GetMetroR2ConnectivityHealth returns the MetroR2ConnectivityHealth field if non-nil, zero value otherwise.

### GetMetroR2ConnectivityHealthOk

`func (o *MetroDrEnvironment) GetMetroR2ConnectivityHealthOk() (*string, bool)`

GetMetroR2ConnectivityHealthOk returns a tuple with the MetroR2ConnectivityHealth field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetMetroR2ConnectivityHealth

`func (o *MetroDrEnvironment) SetMetroR2ConnectivityHealth(v string)`

SetMetroR2ConnectivityHealth sets MetroR2ConnectivityHealth field to given value.

### HasMetroR2ConnectivityHealth

`func (o *MetroDrEnvironment) HasMetroR2ConnectivityHealth() bool`

HasMetroR2ConnectivityHealth returns a boolean if a field has been set.

### GetMetroR2ArrayHealth

`func (o *MetroDrEnvironment) GetMetroR2ArrayHealth() string`

GetMetroR2ArrayHealth returns the MetroR2ArrayHealth field if non-nil, zero value otherwise.

### GetMetroR2ArrayHealthOk

`func (o *MetroDrEnvironment) GetMetroR2ArrayHealthOk() (*string, bool)`

GetMetroR2ArrayHealthOk returns a tuple with the MetroR2ArrayHealth field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetMetroR2ArrayHealth

`func (o *MetroDrEnvironment) SetMetroR2ArrayHealth(v string)`

SetMetroR2ArrayHealth sets MetroR2ArrayHealth field to given value.

### HasMetroR2ArrayHealth

`func (o *MetroDrEnvironment) HasMetroR2ArrayHealth() bool`

HasMetroR2ArrayHealth returns a boolean if a field has been set.

### GetDrState

`func (o *MetroDrEnvironment) GetDrState() string`

GetDrState returns the DrState field if non-nil, zero value otherwise.

### GetDrStateOk

`func (o *MetroDrEnvironment) GetDrStateOk() (*string, bool)`

GetDrStateOk returns a tuple with the DrState field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetDrState

`func (o *MetroDrEnvironment) SetDrState(v string)`

SetDrState sets DrState field to given value.

### HasDrState

`func (o *MetroDrEnvironment) HasDrState() bool`

HasDrState returns a boolean if a field has been set.

### GetDrLinkState

`func (o *MetroDrEnvironment) GetDrLinkState() string`

GetDrLinkState returns the DrLinkState field if non-nil, zero value otherwise.

### GetDrLinkStateOk

`func (o *MetroDrEnvironment) GetDrLinkStateOk() (*string, bool)`

GetDrLinkStateOk returns a tuple with the DrLinkState field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetDrLinkState

`func (o *MetroDrEnvironment) SetDrLinkState(v string)`

SetDrLinkState sets DrLinkState field to given value.

### HasDrLinkState

`func (o *MetroDrEnvironment) HasDrLinkState() bool`

HasDrLinkState returns a boolean if a field has been set.

### GetDrExempt

`func (o *MetroDrEnvironment) GetDrExempt() bool`

GetDrExempt returns the DrExempt field if non-nil, zero value otherwise.

### GetDrExemptOk

`func (o *MetroDrEnvironment) GetDrExemptOk() (*bool, bool)`

GetDrExemptOk returns a tuple with the DrExempt field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetDrExempt

`func (o *MetroDrEnvironment) SetDrExempt(v bool)`

SetDrExempt sets DrExempt field to given value.

### HasDrExempt

`func (o *MetroDrEnvironment) HasDrExempt() bool`

HasDrExempt returns a boolean if a field has been set.

### GetDrServiceState

`func (o *MetroDrEnvironment) GetDrServiceState() string`

GetDrServiceState returns the DrServiceState field if non-nil, zero value otherwise.

### GetDrServiceStateOk

`func (o *MetroDrEnvironment) GetDrServiceStateOk() (*string, bool)`

GetDrServiceStateOk returns a tuple with the DrServiceState field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetDrServiceState

`func (o *MetroDrEnvironment) SetDrServiceState(v string)`

SetDrServiceState sets DrServiceState field to given value.

### HasDrServiceState

`func (o *MetroDrEnvironment) HasDrServiceState() bool`

HasDrServiceState returns a boolean if a field has been set.

### GetDrRdfMode

`func (o *MetroDrEnvironment) GetDrRdfMode() string`

GetDrRdfMode returns the DrRdfMode field if non-nil, zero value otherwise.

### GetDrRdfModeOk

`func (o *MetroDrEnvironment) GetDrRdfModeOk() (*string, bool)`

GetDrRdfModeOk returns a tuple with the DrRdfMode field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetDrRdfMode

`func (o *MetroDrEnvironment) SetDrRdfMode(v string)`

SetDrRdfMode sets DrRdfMode field to given value.

### HasDrRdfMode

`func (o *MetroDrEnvironment) HasDrRdfMode() bool`

HasDrRdfMode returns a boolean if a field has been set.

### GetDrPercentComplete

`func (o *MetroDrEnvironment) GetDrPercentComplete() int32`

GetDrPercentComplete returns the DrPercentComplete field if non-nil, zero value otherwise.

### GetDrPercentCompleteOk

`func (o *MetroDrEnvironment) GetDrPercentCompleteOk() (*int32, bool)`

GetDrPercentCompleteOk returns a tuple with the DrPercentComplete field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetDrPercentComplete

`func (o *MetroDrEnvironment) SetDrPercentComplete(v int32)`

SetDrPercentComplete sets DrPercentComplete field to given value.

### HasDrPercentComplete

`func (o *MetroDrEnvironment) HasDrPercentComplete() bool`

HasDrPercentComplete returns a boolean if a field has been set.

### GetDrRemainCapacityToCopyMb

`func (o *MetroDrEnvironment) GetDrRemainCapacityToCopyMb() int64`

GetDrRemainCapacityToCopyMb returns the DrRemainCapacityToCopyMb field if non-nil, zero value otherwise.

### GetDrRemainCapacityToCopyMbOk

`func (o *MetroDrEnvironment) GetDrRemainCapacityToCopyMbOk() (*int64, bool)`

GetDrRemainCapacityToCopyMbOk returns a tuple with the DrRemainCapacityToCopyMb field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetDrRemainCapacityToCopyMb

`func (o *MetroDrEnvironment) SetDrRemainCapacityToCopyMb(v int64)`

SetDrRemainCapacityToCopyMb sets DrRemainCapacityToCopyMb field to given value.

### HasDrRemainCapacityToCopyMb

`func (o *MetroDrEnvironment) HasDrRemainCapacityToCopyMb() bool`

HasDrRemainCapacityToCopyMb returns a boolean if a field has been set.

### GetConfiguration

`func (o *MetroDrEnvironment) GetConfiguration() MetroDrEnvironmentConfig`

GetConfiguration returns the Configuration field if non-nil, zero value otherwise.

### GetConfigurationOk

`func (o *MetroDrEnvironment) GetConfigurationOk() (*MetroDrEnvironmentConfig, bool)`

GetConfigurationOk returns a tuple with the Configuration field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetConfiguration

`func (o *MetroDrEnvironment) SetConfiguration(v MetroDrEnvironmentConfig)`

SetConfiguration sets Configuration field to given value.

### HasConfiguration

`func (o *MetroDrEnvironment) HasConfiguration() bool`

HasConfiguration returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


