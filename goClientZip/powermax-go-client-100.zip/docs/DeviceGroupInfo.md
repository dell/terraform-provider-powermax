# DeviceGroupInfo

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**FirstAvailableDate** | Pointer to **int64** |  | [optional] 
**LastAvailableDate** | Pointer to **int64** |  | [optional] 
**DeviceGroupId** | **string** | deviceGroupId | 

## Methods

### NewDeviceGroupInfo

`func NewDeviceGroupInfo(deviceGroupId string, ) *DeviceGroupInfo`

NewDeviceGroupInfo instantiates a new DeviceGroupInfo object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewDeviceGroupInfoWithDefaults

`func NewDeviceGroupInfoWithDefaults() *DeviceGroupInfo`

NewDeviceGroupInfoWithDefaults instantiates a new DeviceGroupInfo object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetFirstAvailableDate

`func (o *DeviceGroupInfo) GetFirstAvailableDate() int64`

GetFirstAvailableDate returns the FirstAvailableDate field if non-nil, zero value otherwise.

### GetFirstAvailableDateOk

`func (o *DeviceGroupInfo) GetFirstAvailableDateOk() (*int64, bool)`

GetFirstAvailableDateOk returns a tuple with the FirstAvailableDate field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetFirstAvailableDate

`func (o *DeviceGroupInfo) SetFirstAvailableDate(v int64)`

SetFirstAvailableDate sets FirstAvailableDate field to given value.

### HasFirstAvailableDate

`func (o *DeviceGroupInfo) HasFirstAvailableDate() bool`

HasFirstAvailableDate returns a boolean if a field has been set.

### GetLastAvailableDate

`func (o *DeviceGroupInfo) GetLastAvailableDate() int64`

GetLastAvailableDate returns the LastAvailableDate field if non-nil, zero value otherwise.

### GetLastAvailableDateOk

`func (o *DeviceGroupInfo) GetLastAvailableDateOk() (*int64, bool)`

GetLastAvailableDateOk returns a tuple with the LastAvailableDate field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetLastAvailableDate

`func (o *DeviceGroupInfo) SetLastAvailableDate(v int64)`

SetLastAvailableDate sets LastAvailableDate field to given value.

### HasLastAvailableDate

`func (o *DeviceGroupInfo) HasLastAvailableDate() bool`

HasLastAvailableDate returns a boolean if a field has been set.

### GetDeviceGroupId

`func (o *DeviceGroupInfo) GetDeviceGroupId() string`

GetDeviceGroupId returns the DeviceGroupId field if non-nil, zero value otherwise.

### GetDeviceGroupIdOk

`func (o *DeviceGroupInfo) GetDeviceGroupIdOk() (*string, bool)`

GetDeviceGroupIdOk returns a tuple with the DeviceGroupId field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetDeviceGroupId

`func (o *DeviceGroupInfo) SetDeviceGroupId(v string)`

SetDeviceGroupId sets DeviceGroupId field to given value.



[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


