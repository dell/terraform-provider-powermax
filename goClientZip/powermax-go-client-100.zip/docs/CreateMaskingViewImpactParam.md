# CreateMaskingViewImpactParam

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**MaskingViewId** | Pointer to **string** | Masking view name. If not specified, it will be generated from storage group name. | [optional] 
**AutoPortGroupParam** | [**AutoPortGroupParam**](AutoPortGroupParam.md) |  | 
**AutoHostGroupParam** | [**AutoHostGroupParam**](AutoHostGroupParam.md) |  | 
**CreateStorageGroupParam** | [**CreateStorageGroupParam**](CreateStorageGroupParam.md) |  | 
**EnableComplianceAlerts** | Pointer to **bool** |                                  Optional setting to enable Compliance Alerts on the Storage Group(s) in the                                 masking view that have the following characteristics:                                 Non Parent Storage Group,                                 Service level other than Optimized and None,                                 Contains non Gatekeepers volumes.                              | [optional] [default to false]

## Methods

### NewCreateMaskingViewImpactParam

`func NewCreateMaskingViewImpactParam(autoPortGroupParam AutoPortGroupParam, autoHostGroupParam AutoHostGroupParam, createStorageGroupParam CreateStorageGroupParam, ) *CreateMaskingViewImpactParam`

NewCreateMaskingViewImpactParam instantiates a new CreateMaskingViewImpactParam object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewCreateMaskingViewImpactParamWithDefaults

`func NewCreateMaskingViewImpactParamWithDefaults() *CreateMaskingViewImpactParam`

NewCreateMaskingViewImpactParamWithDefaults instantiates a new CreateMaskingViewImpactParam object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetMaskingViewId

`func (o *CreateMaskingViewImpactParam) GetMaskingViewId() string`

GetMaskingViewId returns the MaskingViewId field if non-nil, zero value otherwise.

### GetMaskingViewIdOk

`func (o *CreateMaskingViewImpactParam) GetMaskingViewIdOk() (*string, bool)`

GetMaskingViewIdOk returns a tuple with the MaskingViewId field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetMaskingViewId

`func (o *CreateMaskingViewImpactParam) SetMaskingViewId(v string)`

SetMaskingViewId sets MaskingViewId field to given value.

### HasMaskingViewId

`func (o *CreateMaskingViewImpactParam) HasMaskingViewId() bool`

HasMaskingViewId returns a boolean if a field has been set.

### GetAutoPortGroupParam

`func (o *CreateMaskingViewImpactParam) GetAutoPortGroupParam() AutoPortGroupParam`

GetAutoPortGroupParam returns the AutoPortGroupParam field if non-nil, zero value otherwise.

### GetAutoPortGroupParamOk

`func (o *CreateMaskingViewImpactParam) GetAutoPortGroupParamOk() (*AutoPortGroupParam, bool)`

GetAutoPortGroupParamOk returns a tuple with the AutoPortGroupParam field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetAutoPortGroupParam

`func (o *CreateMaskingViewImpactParam) SetAutoPortGroupParam(v AutoPortGroupParam)`

SetAutoPortGroupParam sets AutoPortGroupParam field to given value.


### GetAutoHostGroupParam

`func (o *CreateMaskingViewImpactParam) GetAutoHostGroupParam() AutoHostGroupParam`

GetAutoHostGroupParam returns the AutoHostGroupParam field if non-nil, zero value otherwise.

### GetAutoHostGroupParamOk

`func (o *CreateMaskingViewImpactParam) GetAutoHostGroupParamOk() (*AutoHostGroupParam, bool)`

GetAutoHostGroupParamOk returns a tuple with the AutoHostGroupParam field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetAutoHostGroupParam

`func (o *CreateMaskingViewImpactParam) SetAutoHostGroupParam(v AutoHostGroupParam)`

SetAutoHostGroupParam sets AutoHostGroupParam field to given value.


### GetCreateStorageGroupParam

`func (o *CreateMaskingViewImpactParam) GetCreateStorageGroupParam() CreateStorageGroupParam`

GetCreateStorageGroupParam returns the CreateStorageGroupParam field if non-nil, zero value otherwise.

### GetCreateStorageGroupParamOk

`func (o *CreateMaskingViewImpactParam) GetCreateStorageGroupParamOk() (*CreateStorageGroupParam, bool)`

GetCreateStorageGroupParamOk returns a tuple with the CreateStorageGroupParam field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetCreateStorageGroupParam

`func (o *CreateMaskingViewImpactParam) SetCreateStorageGroupParam(v CreateStorageGroupParam)`

SetCreateStorageGroupParam sets CreateStorageGroupParam field to given value.


### GetEnableComplianceAlerts

`func (o *CreateMaskingViewImpactParam) GetEnableComplianceAlerts() bool`

GetEnableComplianceAlerts returns the EnableComplianceAlerts field if non-nil, zero value otherwise.

### GetEnableComplianceAlertsOk

`func (o *CreateMaskingViewImpactParam) GetEnableComplianceAlertsOk() (*bool, bool)`

GetEnableComplianceAlertsOk returns a tuple with the EnableComplianceAlerts field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetEnableComplianceAlerts

`func (o *CreateMaskingViewImpactParam) SetEnableComplianceAlerts(v bool)`

SetEnableComplianceAlerts sets EnableComplianceAlerts field to given value.

### HasEnableComplianceAlerts

`func (o *CreateMaskingViewImpactParam) HasEnableComplianceAlerts() bool`

HasEnableComplianceAlerts returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


