# InitiatorKeyResult

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**InitiatorInfo** | Pointer to [**[]InitiatorInfo**](InitiatorInfo.md) | initiatorInfo | [optional] 

## Methods

### NewInitiatorKeyResult

`func NewInitiatorKeyResult() *InitiatorKeyResult`

NewInitiatorKeyResult instantiates a new InitiatorKeyResult object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewInitiatorKeyResultWithDefaults

`func NewInitiatorKeyResultWithDefaults() *InitiatorKeyResult`

NewInitiatorKeyResultWithDefaults instantiates a new InitiatorKeyResult object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetInitiatorInfo

`func (o *InitiatorKeyResult) GetInitiatorInfo() []InitiatorInfo`

GetInitiatorInfo returns the InitiatorInfo field if non-nil, zero value otherwise.

### GetInitiatorInfoOk

`func (o *InitiatorKeyResult) GetInitiatorInfoOk() (*[]InitiatorInfo, bool)`

GetInitiatorInfoOk returns a tuple with the InitiatorInfo field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetInitiatorInfo

`func (o *InitiatorKeyResult) SetInitiatorInfo(v []InitiatorInfo)`

SetInitiatorInfo sets InitiatorInfo field to given value.

### HasInitiatorInfo

`func (o *InitiatorKeyResult) HasInitiatorInfo() bool`

HasInitiatorInfo returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


