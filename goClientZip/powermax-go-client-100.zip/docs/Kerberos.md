# Kerberos

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Id** | Pointer to **string** |                          Unique identifier of the Kerberos instance.                      | [optional] 
**NasServer** | Pointer to **string** |                          Id of associated Nas Server instance that uses this Kerberos object. Only one Kerberos object per Nas Server is supported.                      | [optional] 
**Realm** | Pointer to **string** |                          Realm name of the Kerberos Service                      | [optional] 
**KdcNames** | Pointer to **[]string** |                          Fully Qualified domain names of the Kerberos Key Distribution Center (KDC) servers.                      | [optional] 
**PortNumber** | Pointer to **int32** |                          KDC servers TCP port. Default: 88.                      | [optional] 
**Health** | Pointer to [**Health**](Health.md) |  | [optional] 

## Methods

### NewKerberos

`func NewKerberos() *Kerberos`

NewKerberos instantiates a new Kerberos object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewKerberosWithDefaults

`func NewKerberosWithDefaults() *Kerberos`

NewKerberosWithDefaults instantiates a new Kerberos object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetId

`func (o *Kerberos) GetId() string`

GetId returns the Id field if non-nil, zero value otherwise.

### GetIdOk

`func (o *Kerberos) GetIdOk() (*string, bool)`

GetIdOk returns a tuple with the Id field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetId

`func (o *Kerberos) SetId(v string)`

SetId sets Id field to given value.

### HasId

`func (o *Kerberos) HasId() bool`

HasId returns a boolean if a field has been set.

### GetNasServer

`func (o *Kerberos) GetNasServer() string`

GetNasServer returns the NasServer field if non-nil, zero value otherwise.

### GetNasServerOk

`func (o *Kerberos) GetNasServerOk() (*string, bool)`

GetNasServerOk returns a tuple with the NasServer field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetNasServer

`func (o *Kerberos) SetNasServer(v string)`

SetNasServer sets NasServer field to given value.

### HasNasServer

`func (o *Kerberos) HasNasServer() bool`

HasNasServer returns a boolean if a field has been set.

### GetRealm

`func (o *Kerberos) GetRealm() string`

GetRealm returns the Realm field if non-nil, zero value otherwise.

### GetRealmOk

`func (o *Kerberos) GetRealmOk() (*string, bool)`

GetRealmOk returns a tuple with the Realm field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetRealm

`func (o *Kerberos) SetRealm(v string)`

SetRealm sets Realm field to given value.

### HasRealm

`func (o *Kerberos) HasRealm() bool`

HasRealm returns a boolean if a field has been set.

### GetKdcNames

`func (o *Kerberos) GetKdcNames() []string`

GetKdcNames returns the KdcNames field if non-nil, zero value otherwise.

### GetKdcNamesOk

`func (o *Kerberos) GetKdcNamesOk() (*[]string, bool)`

GetKdcNamesOk returns a tuple with the KdcNames field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetKdcNames

`func (o *Kerberos) SetKdcNames(v []string)`

SetKdcNames sets KdcNames field to given value.

### HasKdcNames

`func (o *Kerberos) HasKdcNames() bool`

HasKdcNames returns a boolean if a field has been set.

### GetPortNumber

`func (o *Kerberos) GetPortNumber() int32`

GetPortNumber returns the PortNumber field if non-nil, zero value otherwise.

### GetPortNumberOk

`func (o *Kerberos) GetPortNumberOk() (*int32, bool)`

GetPortNumberOk returns a tuple with the PortNumber field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetPortNumber

`func (o *Kerberos) SetPortNumber(v int32)`

SetPortNumber sets PortNumber field to given value.

### HasPortNumber

`func (o *Kerberos) HasPortNumber() bool`

HasPortNumber returns a boolean if a field has been set.

### GetHealth

`func (o *Kerberos) GetHealth() Health`

GetHealth returns the Health field if non-nil, zero value otherwise.

### GetHealthOk

`func (o *Kerberos) GetHealthOk() (*Health, bool)`

GetHealthOk returns a tuple with the Health field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetHealth

`func (o *Kerberos) SetHealth(v Health)`

SetHealth sets Health field to given value.

### HasHealth

`func (o *Kerberos) HasHealth() bool`

HasHealth returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


