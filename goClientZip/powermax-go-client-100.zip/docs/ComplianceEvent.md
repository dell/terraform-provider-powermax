# ComplianceEvent

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**StartTime** | **int64** | Start timestamp for the compliance event. | 
**EndTime** | **int64** | End timestamp for the compliance event. | 
**EventDescription** | Pointer to [**[]EventDescription**](EventDescription.md) | eventDescription | [optional] 

## Methods

### NewComplianceEvent

`func NewComplianceEvent(startTime int64, endTime int64, ) *ComplianceEvent`

NewComplianceEvent instantiates a new ComplianceEvent object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewComplianceEventWithDefaults

`func NewComplianceEventWithDefaults() *ComplianceEvent`

NewComplianceEventWithDefaults instantiates a new ComplianceEvent object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetStartTime

`func (o *ComplianceEvent) GetStartTime() int64`

GetStartTime returns the StartTime field if non-nil, zero value otherwise.

### GetStartTimeOk

`func (o *ComplianceEvent) GetStartTimeOk() (*int64, bool)`

GetStartTimeOk returns a tuple with the StartTime field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetStartTime

`func (o *ComplianceEvent) SetStartTime(v int64)`

SetStartTime sets StartTime field to given value.


### GetEndTime

`func (o *ComplianceEvent) GetEndTime() int64`

GetEndTime returns the EndTime field if non-nil, zero value otherwise.

### GetEndTimeOk

`func (o *ComplianceEvent) GetEndTimeOk() (*int64, bool)`

GetEndTimeOk returns a tuple with the EndTime field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetEndTime

`func (o *ComplianceEvent) SetEndTime(v int64)`

SetEndTime sets EndTime field to given value.


### GetEventDescription

`func (o *ComplianceEvent) GetEventDescription() []EventDescription`

GetEventDescription returns the EventDescription field if non-nil, zero value otherwise.

### GetEventDescriptionOk

`func (o *ComplianceEvent) GetEventDescriptionOk() (*[]EventDescription, bool)`

GetEventDescriptionOk returns a tuple with the EventDescription field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetEventDescription

`func (o *ComplianceEvent) SetEventDescription(v []EventDescription)`

SetEventDescription sets EventDescription field to given value.

### HasEventDescription

`func (o *ComplianceEvent) HasEventDescription() bool`

HasEventDescription returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


