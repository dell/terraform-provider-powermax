# KerberosIdentifier

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Id** | Pointer to **string** |                          Object Id of the service                      | [optional] 
**Realm** | Pointer to **string** | realm | [optional] 

## Methods

### NewKerberosIdentifier

`func NewKerberosIdentifier() *KerberosIdentifier`

NewKerberosIdentifier instantiates a new KerberosIdentifier object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewKerberosIdentifierWithDefaults

`func NewKerberosIdentifierWithDefaults() *KerberosIdentifier`

NewKerberosIdentifierWithDefaults instantiates a new KerberosIdentifier object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetId

`func (o *KerberosIdentifier) GetId() string`

GetId returns the Id field if non-nil, zero value otherwise.

### GetIdOk

`func (o *KerberosIdentifier) GetIdOk() (*string, bool)`

GetIdOk returns a tuple with the Id field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetId

`func (o *KerberosIdentifier) SetId(v string)`

SetId sets Id field to given value.

### HasId

`func (o *KerberosIdentifier) HasId() bool`

HasId returns a boolean if a field has been set.

### GetRealm

`func (o *KerberosIdentifier) GetRealm() string`

GetRealm returns the Realm field if non-nil, zero value otherwise.

### GetRealmOk

`func (o *KerberosIdentifier) GetRealmOk() (*string, bool)`

GetRealmOk returns a tuple with the Realm field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetRealm

`func (o *KerberosIdentifier) SetRealm(v string)`

SetRealm sets Realm field to given value.

### HasRealm

`func (o *KerberosIdentifier) HasRealm() bool`

HasRealm returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


