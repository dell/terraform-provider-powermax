# Export

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Id** | Pointer to **string** |                          Unique identifier of the export instance.                      | [optional] 
**Type** | Pointer to **string** |                          NFS Share type.                         - 1 : **Nfs_Share** &#x3D;&gt; The NFS export is created on a filesystem.                         - 2 : **Vmware_Nfs** &#x3D;&gt; The NFS export is created on a VMware datastore.                         - 3 : **Nfs_Snapshot** &#x3D;&gt; The NFS export is created on a snapshot.                        Enumeration values: * **Nfs_Export** * **Nfs_VMWare** * **Nfs_Snapshot**  | [optional] 
**Filesystem** | Pointer to **string** |                          *(Applies to NFS exports that are not on snapshots)* Parent file system associated with the NFS expot, as defined by the filesystem resource type.                      | [optional] 
**Snap** | Pointer to **string** |                          *(Applies to NFS exports on snapshots)* Parent file system snapshot associated with the NFS export, as defined by the snap resource type.                      | [optional] 
**NasServer** | Pointer to **string** |                          Id of associated Nas Server instance that uses this export object.                      | [optional] 
**Name** | Pointer to **string** |                          NFS export name. May be a directory path, but leading slash must be omitted. Export name is reported as a directory path to behave as a symbolic link to the exported directory path.                      | [optional] 
**Path** | Pointer to **string** |                           Local path to a location within the file system.                         With NFS, each export must have a unique local path. The path is specified relative to the root of the file system (top-most directory).                         Before you can create additional exports within an NFS exported folder, you must create directories within it from a Linux/Unix host that is connected to the file system. After a directory has been created from a mounted host in the readWriteRootHosts list, you can create a corresponding export and set access permissions accordingly.                       | [optional] 
**Description** | Pointer to **string** |                          User defined NFS export description.                      | [optional] 
**DefaultAccess** | Pointer to **string** |                          Default access level for all hosts that can access the export.                         - 0 : **NoAccess** &#x3D;&gt; Deny access to the export for the hosts.                         - 1 : **ReadOnly** &#x3D;&gt; Allow read only access to the export for the hosts.                         - 2 : **ReadWrite** &#x3D;&gt; Allow read write access to the export for the hosts.                         - 3 : **Root** &#x3D;&gt; Allow read write access to the export for the hosts. Allow access to the share for root user.                         - 4 : **RoRoot** &#x3D;&gt; Allow read only root access to the export for the hosts.                        Enumeration values: * **NoAccess** * **ReadOnly** * **ReadWrite** * **Root** * **RoRoot**  | [optional] 
**MinSecurity** | Pointer to **string** |                          NFS minimum enforced security type for users accessing an NFS export.                         - 0 : **Sys** &#x3D;&gt; Allow user to authenticate with any NFS security types: UNIX, Kerberos, Kerberos with integrity and Kerberos with encryption. *sys/krb5/krb5i/krb5p*                         - 1 : **Kerberos** &#x3D;&gt; Allow only Kerberos security for user authentication. *krb5/krb5i/krb5p*                         - 2 : **KerberosWithIntegrity** &#x3D;&gt; Allow only Kerberos with integrity and Kerberos with encryption security for user authentication. *krb5i/krb5p*                         - 3 : **KerberosWithEncryption** &#x3D;&gt; Allow only Kerberos with encryption security for user authentication. *krb5p*                        Enumeration values: * **Sys** * **Kerberos** * **KerberosWithIntegrity** * **KerberosWithEncryption**  | [optional] 
**NfsOwnerUsername** | Pointer to **string** |                          (*Applies to NFS exports of VMware NFS storage resources*) Default owner of the NFS export associated with the datastore. Required if secure NFS is enabled. For NFSv3 or NFSv4 without Kerberos, the default owner is root.                      | [optional] 
**NoAccessHosts** | Pointer to **[]string** |                          Hosts with **no** access to the NFS export or its snapshots. This list is useful when \&quot;defaultAccess\&quot; is not \&quot;NoAccess\&quot;.                      | [optional] 
**ReadOnlyHosts** | Pointer to **[]string** |                          Hosts with **read-only** access to the NFS export and its snapshots.                      | [optional] 
**ReadOnlyRootHosts** | Pointer to **[]string** |                          Hosts with **read-only** *and* **ready-only for root user** access * to the NFS export and its snapshots.                      | [optional] 
**ReadWriteHosts** | Pointer to **[]string** |                          Hosts with **read and write** access to the NFS export and its snapshots.                      | [optional] 
**ReadWriteRootHosts** | Pointer to **[]string** |                          Hosts with **read and write** *and* **read and write for root user** access to the NFS export and its snapshots.                      | [optional] 
**AnonymousUid** | Pointer to **int32** |                          Specifies the user ID of the anonymous account.                      | [optional] 
**AnonymousGid** | Pointer to **int32** |                          Specifies the group ID of the anonymous account.                      | [optional] 
**NoSuid** | Pointer to **bool** |                          if set, do not allow access to set SUID. Otherwise, allow access.                      | [optional] 
**Health** | Pointer to [**Health**](Health.md) |  | [optional] 

## Methods

### NewExport

`func NewExport() *Export`

NewExport instantiates a new Export object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewExportWithDefaults

`func NewExportWithDefaults() *Export`

NewExportWithDefaults instantiates a new Export object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetId

`func (o *Export) GetId() string`

GetId returns the Id field if non-nil, zero value otherwise.

### GetIdOk

`func (o *Export) GetIdOk() (*string, bool)`

GetIdOk returns a tuple with the Id field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetId

`func (o *Export) SetId(v string)`

SetId sets Id field to given value.

### HasId

`func (o *Export) HasId() bool`

HasId returns a boolean if a field has been set.

### GetType

`func (o *Export) GetType() string`

GetType returns the Type field if non-nil, zero value otherwise.

### GetTypeOk

`func (o *Export) GetTypeOk() (*string, bool)`

GetTypeOk returns a tuple with the Type field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetType

`func (o *Export) SetType(v string)`

SetType sets Type field to given value.

### HasType

`func (o *Export) HasType() bool`

HasType returns a boolean if a field has been set.

### GetFilesystem

`func (o *Export) GetFilesystem() string`

GetFilesystem returns the Filesystem field if non-nil, zero value otherwise.

### GetFilesystemOk

`func (o *Export) GetFilesystemOk() (*string, bool)`

GetFilesystemOk returns a tuple with the Filesystem field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetFilesystem

`func (o *Export) SetFilesystem(v string)`

SetFilesystem sets Filesystem field to given value.

### HasFilesystem

`func (o *Export) HasFilesystem() bool`

HasFilesystem returns a boolean if a field has been set.

### GetSnap

`func (o *Export) GetSnap() string`

GetSnap returns the Snap field if non-nil, zero value otherwise.

### GetSnapOk

`func (o *Export) GetSnapOk() (*string, bool)`

GetSnapOk returns a tuple with the Snap field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetSnap

`func (o *Export) SetSnap(v string)`

SetSnap sets Snap field to given value.

### HasSnap

`func (o *Export) HasSnap() bool`

HasSnap returns a boolean if a field has been set.

### GetNasServer

`func (o *Export) GetNasServer() string`

GetNasServer returns the NasServer field if non-nil, zero value otherwise.

### GetNasServerOk

`func (o *Export) GetNasServerOk() (*string, bool)`

GetNasServerOk returns a tuple with the NasServer field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetNasServer

`func (o *Export) SetNasServer(v string)`

SetNasServer sets NasServer field to given value.

### HasNasServer

`func (o *Export) HasNasServer() bool`

HasNasServer returns a boolean if a field has been set.

### GetName

`func (o *Export) GetName() string`

GetName returns the Name field if non-nil, zero value otherwise.

### GetNameOk

`func (o *Export) GetNameOk() (*string, bool)`

GetNameOk returns a tuple with the Name field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetName

`func (o *Export) SetName(v string)`

SetName sets Name field to given value.

### HasName

`func (o *Export) HasName() bool`

HasName returns a boolean if a field has been set.

### GetPath

`func (o *Export) GetPath() string`

GetPath returns the Path field if non-nil, zero value otherwise.

### GetPathOk

`func (o *Export) GetPathOk() (*string, bool)`

GetPathOk returns a tuple with the Path field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetPath

`func (o *Export) SetPath(v string)`

SetPath sets Path field to given value.

### HasPath

`func (o *Export) HasPath() bool`

HasPath returns a boolean if a field has been set.

### GetDescription

`func (o *Export) GetDescription() string`

GetDescription returns the Description field if non-nil, zero value otherwise.

### GetDescriptionOk

`func (o *Export) GetDescriptionOk() (*string, bool)`

GetDescriptionOk returns a tuple with the Description field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetDescription

`func (o *Export) SetDescription(v string)`

SetDescription sets Description field to given value.

### HasDescription

`func (o *Export) HasDescription() bool`

HasDescription returns a boolean if a field has been set.

### GetDefaultAccess

`func (o *Export) GetDefaultAccess() string`

GetDefaultAccess returns the DefaultAccess field if non-nil, zero value otherwise.

### GetDefaultAccessOk

`func (o *Export) GetDefaultAccessOk() (*string, bool)`

GetDefaultAccessOk returns a tuple with the DefaultAccess field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetDefaultAccess

`func (o *Export) SetDefaultAccess(v string)`

SetDefaultAccess sets DefaultAccess field to given value.

### HasDefaultAccess

`func (o *Export) HasDefaultAccess() bool`

HasDefaultAccess returns a boolean if a field has been set.

### GetMinSecurity

`func (o *Export) GetMinSecurity() string`

GetMinSecurity returns the MinSecurity field if non-nil, zero value otherwise.

### GetMinSecurityOk

`func (o *Export) GetMinSecurityOk() (*string, bool)`

GetMinSecurityOk returns a tuple with the MinSecurity field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetMinSecurity

`func (o *Export) SetMinSecurity(v string)`

SetMinSecurity sets MinSecurity field to given value.

### HasMinSecurity

`func (o *Export) HasMinSecurity() bool`

HasMinSecurity returns a boolean if a field has been set.

### GetNfsOwnerUsername

`func (o *Export) GetNfsOwnerUsername() string`

GetNfsOwnerUsername returns the NfsOwnerUsername field if non-nil, zero value otherwise.

### GetNfsOwnerUsernameOk

`func (o *Export) GetNfsOwnerUsernameOk() (*string, bool)`

GetNfsOwnerUsernameOk returns a tuple with the NfsOwnerUsername field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetNfsOwnerUsername

`func (o *Export) SetNfsOwnerUsername(v string)`

SetNfsOwnerUsername sets NfsOwnerUsername field to given value.

### HasNfsOwnerUsername

`func (o *Export) HasNfsOwnerUsername() bool`

HasNfsOwnerUsername returns a boolean if a field has been set.

### GetNoAccessHosts

`func (o *Export) GetNoAccessHosts() []string`

GetNoAccessHosts returns the NoAccessHosts field if non-nil, zero value otherwise.

### GetNoAccessHostsOk

`func (o *Export) GetNoAccessHostsOk() (*[]string, bool)`

GetNoAccessHostsOk returns a tuple with the NoAccessHosts field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetNoAccessHosts

`func (o *Export) SetNoAccessHosts(v []string)`

SetNoAccessHosts sets NoAccessHosts field to given value.

### HasNoAccessHosts

`func (o *Export) HasNoAccessHosts() bool`

HasNoAccessHosts returns a boolean if a field has been set.

### GetReadOnlyHosts

`func (o *Export) GetReadOnlyHosts() []string`

GetReadOnlyHosts returns the ReadOnlyHosts field if non-nil, zero value otherwise.

### GetReadOnlyHostsOk

`func (o *Export) GetReadOnlyHostsOk() (*[]string, bool)`

GetReadOnlyHostsOk returns a tuple with the ReadOnlyHosts field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetReadOnlyHosts

`func (o *Export) SetReadOnlyHosts(v []string)`

SetReadOnlyHosts sets ReadOnlyHosts field to given value.

### HasReadOnlyHosts

`func (o *Export) HasReadOnlyHosts() bool`

HasReadOnlyHosts returns a boolean if a field has been set.

### GetReadOnlyRootHosts

`func (o *Export) GetReadOnlyRootHosts() []string`

GetReadOnlyRootHosts returns the ReadOnlyRootHosts field if non-nil, zero value otherwise.

### GetReadOnlyRootHostsOk

`func (o *Export) GetReadOnlyRootHostsOk() (*[]string, bool)`

GetReadOnlyRootHostsOk returns a tuple with the ReadOnlyRootHosts field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetReadOnlyRootHosts

`func (o *Export) SetReadOnlyRootHosts(v []string)`

SetReadOnlyRootHosts sets ReadOnlyRootHosts field to given value.

### HasReadOnlyRootHosts

`func (o *Export) HasReadOnlyRootHosts() bool`

HasReadOnlyRootHosts returns a boolean if a field has been set.

### GetReadWriteHosts

`func (o *Export) GetReadWriteHosts() []string`

GetReadWriteHosts returns the ReadWriteHosts field if non-nil, zero value otherwise.

### GetReadWriteHostsOk

`func (o *Export) GetReadWriteHostsOk() (*[]string, bool)`

GetReadWriteHostsOk returns a tuple with the ReadWriteHosts field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetReadWriteHosts

`func (o *Export) SetReadWriteHosts(v []string)`

SetReadWriteHosts sets ReadWriteHosts field to given value.

### HasReadWriteHosts

`func (o *Export) HasReadWriteHosts() bool`

HasReadWriteHosts returns a boolean if a field has been set.

### GetReadWriteRootHosts

`func (o *Export) GetReadWriteRootHosts() []string`

GetReadWriteRootHosts returns the ReadWriteRootHosts field if non-nil, zero value otherwise.

### GetReadWriteRootHostsOk

`func (o *Export) GetReadWriteRootHostsOk() (*[]string, bool)`

GetReadWriteRootHostsOk returns a tuple with the ReadWriteRootHosts field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetReadWriteRootHosts

`func (o *Export) SetReadWriteRootHosts(v []string)`

SetReadWriteRootHosts sets ReadWriteRootHosts field to given value.

### HasReadWriteRootHosts

`func (o *Export) HasReadWriteRootHosts() bool`

HasReadWriteRootHosts returns a boolean if a field has been set.

### GetAnonymousUid

`func (o *Export) GetAnonymousUid() int32`

GetAnonymousUid returns the AnonymousUid field if non-nil, zero value otherwise.

### GetAnonymousUidOk

`func (o *Export) GetAnonymousUidOk() (*int32, bool)`

GetAnonymousUidOk returns a tuple with the AnonymousUid field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetAnonymousUid

`func (o *Export) SetAnonymousUid(v int32)`

SetAnonymousUid sets AnonymousUid field to given value.

### HasAnonymousUid

`func (o *Export) HasAnonymousUid() bool`

HasAnonymousUid returns a boolean if a field has been set.

### GetAnonymousGid

`func (o *Export) GetAnonymousGid() int32`

GetAnonymousGid returns the AnonymousGid field if non-nil, zero value otherwise.

### GetAnonymousGidOk

`func (o *Export) GetAnonymousGidOk() (*int32, bool)`

GetAnonymousGidOk returns a tuple with the AnonymousGid field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetAnonymousGid

`func (o *Export) SetAnonymousGid(v int32)`

SetAnonymousGid sets AnonymousGid field to given value.

### HasAnonymousGid

`func (o *Export) HasAnonymousGid() bool`

HasAnonymousGid returns a boolean if a field has been set.

### GetNoSuid

`func (o *Export) GetNoSuid() bool`

GetNoSuid returns the NoSuid field if non-nil, zero value otherwise.

### GetNoSuidOk

`func (o *Export) GetNoSuidOk() (*bool, bool)`

GetNoSuidOk returns a tuple with the NoSuid field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetNoSuid

`func (o *Export) SetNoSuid(v bool)`

SetNoSuid sets NoSuid field to given value.

### HasNoSuid

`func (o *Export) HasNoSuid() bool`

HasNoSuid returns a boolean if a field has been set.

### GetHealth

`func (o *Export) GetHealth() Health`

GetHealth returns the Health field if non-nil, zero value otherwise.

### GetHealthOk

`func (o *Export) GetHealthOk() (*Health, bool)`

GetHealthOk returns a tuple with the Health field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetHealth

`func (o *Export) SetHealth(v Health)`

SetHealth sets Health field to given value.

### HasHealth

`func (o *Export) HasHealth() bool`

HasHealth returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


