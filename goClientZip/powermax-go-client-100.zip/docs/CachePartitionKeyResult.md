# CachePartitionKeyResult

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**CachePartitionInfo** | Pointer to [**[]CachePartitionInfo**](CachePartitionInfo.md) | cachePartitionInfo | [optional] 

## Methods

### NewCachePartitionKeyResult

`func NewCachePartitionKeyResult() *CachePartitionKeyResult`

NewCachePartitionKeyResult instantiates a new CachePartitionKeyResult object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewCachePartitionKeyResultWithDefaults

`func NewCachePartitionKeyResultWithDefaults() *CachePartitionKeyResult`

NewCachePartitionKeyResultWithDefaults instantiates a new CachePartitionKeyResult object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetCachePartitionInfo

`func (o *CachePartitionKeyResult) GetCachePartitionInfo() []CachePartitionInfo`

GetCachePartitionInfo returns the CachePartitionInfo field if non-nil, zero value otherwise.

### GetCachePartitionInfoOk

`func (o *CachePartitionKeyResult) GetCachePartitionInfoOk() (*[]CachePartitionInfo, bool)`

GetCachePartitionInfoOk returns a tuple with the CachePartitionInfo field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetCachePartitionInfo

`func (o *CachePartitionKeyResult) SetCachePartitionInfo(v []CachePartitionInfo)`

SetCachePartitionInfo sets CachePartitionInfo field to given value.

### HasCachePartitionInfo

`func (o *CachePartitionKeyResult) HasCachePartitionInfo() bool`

HasCachePartitionInfo returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


