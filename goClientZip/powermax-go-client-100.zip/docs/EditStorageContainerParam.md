# EditStorageContainerParam

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ExecutionOption** | Pointer to **string** |  | [optional] [default to "SYNCHRONOUS"]
**EditStorageContainerActionParam** | [**EditStorageContainerActionParam**](EditStorageContainerActionParam.md) |  | 

## Methods

### NewEditStorageContainerParam

`func NewEditStorageContainerParam(editStorageContainerActionParam EditStorageContainerActionParam, ) *EditStorageContainerParam`

NewEditStorageContainerParam instantiates a new EditStorageContainerParam object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewEditStorageContainerParamWithDefaults

`func NewEditStorageContainerParamWithDefaults() *EditStorageContainerParam`

NewEditStorageContainerParamWithDefaults instantiates a new EditStorageContainerParam object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetExecutionOption

`func (o *EditStorageContainerParam) GetExecutionOption() string`

GetExecutionOption returns the ExecutionOption field if non-nil, zero value otherwise.

### GetExecutionOptionOk

`func (o *EditStorageContainerParam) GetExecutionOptionOk() (*string, bool)`

GetExecutionOptionOk returns a tuple with the ExecutionOption field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetExecutionOption

`func (o *EditStorageContainerParam) SetExecutionOption(v string)`

SetExecutionOption sets ExecutionOption field to given value.

### HasExecutionOption

`func (o *EditStorageContainerParam) HasExecutionOption() bool`

HasExecutionOption returns a boolean if a field has been set.

### GetEditStorageContainerActionParam

`func (o *EditStorageContainerParam) GetEditStorageContainerActionParam() EditStorageContainerActionParam`

GetEditStorageContainerActionParam returns the EditStorageContainerActionParam field if non-nil, zero value otherwise.

### GetEditStorageContainerActionParamOk

`func (o *EditStorageContainerParam) GetEditStorageContainerActionParamOk() (*EditStorageContainerActionParam, bool)`

GetEditStorageContainerActionParamOk returns a tuple with the EditStorageContainerActionParam field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetEditStorageContainerActionParam

`func (o *EditStorageContainerParam) SetEditStorageContainerActionParam(v EditStorageContainerActionParam)`

SetEditStorageContainerActionParam sets EditStorageContainerActionParam field to given value.



[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


