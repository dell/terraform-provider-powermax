# ListVasaProviderResult

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**VasaProviders** | Pointer to [**[]VasaProvider**](VasaProvider.md) | List of VASA Providers. | [optional] 

## Methods

### NewListVasaProviderResult

`func NewListVasaProviderResult() *ListVasaProviderResult`

NewListVasaProviderResult instantiates a new ListVasaProviderResult object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewListVasaProviderResultWithDefaults

`func NewListVasaProviderResultWithDefaults() *ListVasaProviderResult`

NewListVasaProviderResultWithDefaults instantiates a new ListVasaProviderResult object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetVasaProviders

`func (o *ListVasaProviderResult) GetVasaProviders() []VasaProvider`

GetVasaProviders returns the VasaProviders field if non-nil, zero value otherwise.

### GetVasaProvidersOk

`func (o *ListVasaProviderResult) GetVasaProvidersOk() (*[]VasaProvider, bool)`

GetVasaProvidersOk returns a tuple with the VasaProviders field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetVasaProviders

`func (o *ListVasaProviderResult) SetVasaProviders(v []VasaProvider)`

SetVasaProviders sets VasaProviders field to given value.

### HasVasaProviders

`func (o *ListVasaProviderResult) HasVasaProviders() bool`

HasVasaProviders returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


