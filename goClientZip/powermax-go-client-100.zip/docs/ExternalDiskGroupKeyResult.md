# ExternalDiskGroupKeyResult

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ExternalDiskGroupInfo** | Pointer to [**[]ExternalDiskGroupInfo**](ExternalDiskGroupInfo.md) | externalDiskGroupInfo | [optional] 

## Methods

### NewExternalDiskGroupKeyResult

`func NewExternalDiskGroupKeyResult() *ExternalDiskGroupKeyResult`

NewExternalDiskGroupKeyResult instantiates a new ExternalDiskGroupKeyResult object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewExternalDiskGroupKeyResultWithDefaults

`func NewExternalDiskGroupKeyResultWithDefaults() *ExternalDiskGroupKeyResult`

NewExternalDiskGroupKeyResultWithDefaults instantiates a new ExternalDiskGroupKeyResult object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetExternalDiskGroupInfo

`func (o *ExternalDiskGroupKeyResult) GetExternalDiskGroupInfo() []ExternalDiskGroupInfo`

GetExternalDiskGroupInfo returns the ExternalDiskGroupInfo field if non-nil, zero value otherwise.

### GetExternalDiskGroupInfoOk

`func (o *ExternalDiskGroupKeyResult) GetExternalDiskGroupInfoOk() (*[]ExternalDiskGroupInfo, bool)`

GetExternalDiskGroupInfoOk returns a tuple with the ExternalDiskGroupInfo field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetExternalDiskGroupInfo

`func (o *ExternalDiskGroupKeyResult) SetExternalDiskGroupInfo(v []ExternalDiskGroupInfo)`

SetExternalDiskGroupInfo sets ExternalDiskGroupInfo field to given value.

### HasExternalDiskGroupInfo

`func (o *ExternalDiskGroupKeyResult) HasExternalDiskGroupInfo() bool`

HasExternalDiskGroupInfo returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


