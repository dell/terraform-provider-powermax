# EditHostActionParam

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ClearHostBWLimitParam** | Pointer to **map[string]interface{}** | Clear Host BW Limit | [optional] 
**SetHostBWLimitParam** | Pointer to [**SetHostBWLimitParam**](SetHostBWLimitParam.md) |  | [optional] 
**SetHostFlagsParam** | Pointer to [**SetHostFlagsParam**](SetHostFlagsParam.md) |  | [optional] 
**RemoveInitiatorParam** | Pointer to [**RemoveInitiatorParam**](RemoveInitiatorParam.md) |  | [optional] 
**AddInitiatorParam** | Pointer to [**AddInitiatorParam**](AddInitiatorParam.md) |  | [optional] 
**RenameHostParam** | Pointer to [**RenameHostParam**](RenameHostParam.md) |  | [optional] 

## Methods

### NewEditHostActionParam

`func NewEditHostActionParam() *EditHostActionParam`

NewEditHostActionParam instantiates a new EditHostActionParam object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewEditHostActionParamWithDefaults

`func NewEditHostActionParamWithDefaults() *EditHostActionParam`

NewEditHostActionParamWithDefaults instantiates a new EditHostActionParam object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetClearHostBWLimitParam

`func (o *EditHostActionParam) GetClearHostBWLimitParam() map[string]interface{}`

GetClearHostBWLimitParam returns the ClearHostBWLimitParam field if non-nil, zero value otherwise.

### GetClearHostBWLimitParamOk

`func (o *EditHostActionParam) GetClearHostBWLimitParamOk() (*map[string]interface{}, bool)`

GetClearHostBWLimitParamOk returns a tuple with the ClearHostBWLimitParam field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetClearHostBWLimitParam

`func (o *EditHostActionParam) SetClearHostBWLimitParam(v map[string]interface{})`

SetClearHostBWLimitParam sets ClearHostBWLimitParam field to given value.

### HasClearHostBWLimitParam

`func (o *EditHostActionParam) HasClearHostBWLimitParam() bool`

HasClearHostBWLimitParam returns a boolean if a field has been set.

### GetSetHostBWLimitParam

`func (o *EditHostActionParam) GetSetHostBWLimitParam() SetHostBWLimitParam`

GetSetHostBWLimitParam returns the SetHostBWLimitParam field if non-nil, zero value otherwise.

### GetSetHostBWLimitParamOk

`func (o *EditHostActionParam) GetSetHostBWLimitParamOk() (*SetHostBWLimitParam, bool)`

GetSetHostBWLimitParamOk returns a tuple with the SetHostBWLimitParam field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetSetHostBWLimitParam

`func (o *EditHostActionParam) SetSetHostBWLimitParam(v SetHostBWLimitParam)`

SetSetHostBWLimitParam sets SetHostBWLimitParam field to given value.

### HasSetHostBWLimitParam

`func (o *EditHostActionParam) HasSetHostBWLimitParam() bool`

HasSetHostBWLimitParam returns a boolean if a field has been set.

### GetSetHostFlagsParam

`func (o *EditHostActionParam) GetSetHostFlagsParam() SetHostFlagsParam`

GetSetHostFlagsParam returns the SetHostFlagsParam field if non-nil, zero value otherwise.

### GetSetHostFlagsParamOk

`func (o *EditHostActionParam) GetSetHostFlagsParamOk() (*SetHostFlagsParam, bool)`

GetSetHostFlagsParamOk returns a tuple with the SetHostFlagsParam field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetSetHostFlagsParam

`func (o *EditHostActionParam) SetSetHostFlagsParam(v SetHostFlagsParam)`

SetSetHostFlagsParam sets SetHostFlagsParam field to given value.

### HasSetHostFlagsParam

`func (o *EditHostActionParam) HasSetHostFlagsParam() bool`

HasSetHostFlagsParam returns a boolean if a field has been set.

### GetRemoveInitiatorParam

`func (o *EditHostActionParam) GetRemoveInitiatorParam() RemoveInitiatorParam`

GetRemoveInitiatorParam returns the RemoveInitiatorParam field if non-nil, zero value otherwise.

### GetRemoveInitiatorParamOk

`func (o *EditHostActionParam) GetRemoveInitiatorParamOk() (*RemoveInitiatorParam, bool)`

GetRemoveInitiatorParamOk returns a tuple with the RemoveInitiatorParam field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetRemoveInitiatorParam

`func (o *EditHostActionParam) SetRemoveInitiatorParam(v RemoveInitiatorParam)`

SetRemoveInitiatorParam sets RemoveInitiatorParam field to given value.

### HasRemoveInitiatorParam

`func (o *EditHostActionParam) HasRemoveInitiatorParam() bool`

HasRemoveInitiatorParam returns a boolean if a field has been set.

### GetAddInitiatorParam

`func (o *EditHostActionParam) GetAddInitiatorParam() AddInitiatorParam`

GetAddInitiatorParam returns the AddInitiatorParam field if non-nil, zero value otherwise.

### GetAddInitiatorParamOk

`func (o *EditHostActionParam) GetAddInitiatorParamOk() (*AddInitiatorParam, bool)`

GetAddInitiatorParamOk returns a tuple with the AddInitiatorParam field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetAddInitiatorParam

`func (o *EditHostActionParam) SetAddInitiatorParam(v AddInitiatorParam)`

SetAddInitiatorParam sets AddInitiatorParam field to given value.

### HasAddInitiatorParam

`func (o *EditHostActionParam) HasAddInitiatorParam() bool`

HasAddInitiatorParam returns a boolean if a field has been set.

### GetRenameHostParam

`func (o *EditHostActionParam) GetRenameHostParam() RenameHostParam`

GetRenameHostParam returns the RenameHostParam field if non-nil, zero value otherwise.

### GetRenameHostParamOk

`func (o *EditHostActionParam) GetRenameHostParamOk() (*RenameHostParam, bool)`

GetRenameHostParamOk returns a tuple with the RenameHostParam field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetRenameHostParam

`func (o *EditHostActionParam) SetRenameHostParam(v RenameHostParam)`

SetRenameHostParam sets RenameHostParam field to given value.

### HasRenameHostParam

`func (o *EditHostActionParam) HasRenameHostParam() bool`

HasRenameHostParam returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


