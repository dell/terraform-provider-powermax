# CreateMaskingViewParam

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ExecutionOption** | Pointer to **string** |  | [optional] [default to "SYNCHRONOUS"]
**MaskingViewId** | **string** | Masking view name | 
**HostOrHostGroupSelection** | Pointer to [**HostOrHostGroupSelection**](HostOrHostGroupSelection.md) |  | [optional] 
**PortGroupSelection** | Pointer to [**PortGroupSelection**](PortGroupSelection.md) |  | [optional] 
**StorageGroupSelection** | Pointer to [**StorageGroupSelection**](StorageGroupSelection.md) |  | [optional] 
**EnableComplianceAlerts** | Pointer to **bool** | Optional setting to enable Compliance Alerts on the Storage Group(s) in the                                 masking view that have the following characteristics:                                 Non Parent Storage Group,                                 Service level other than Optimized and None,                                 Contains non Gatekeepers volumes. | [optional] [default to false]
**PerformanceImpactValidationOption** | Pointer to **string** | performance_Impact_Validation_Option   Enumeration values: * **Preview** -                          Run performance impact tests and return performance impact scores for requested operation.                         Return input object (with generated fields, if applicable) for relevant followup API.                      * **IfRecommended** -                          Run performance impact tests. If no performance capacity threshold is breached, run the                         requested configuration change operation. If a performance capacity threshold is breached,                         Return tested input object (with generated fields, if applicable), performance impact scores                         for requested operation, and relevant warnings/errors.                       | [optional] 

## Methods

### NewCreateMaskingViewParam

`func NewCreateMaskingViewParam(maskingViewId string, ) *CreateMaskingViewParam`

NewCreateMaskingViewParam instantiates a new CreateMaskingViewParam object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewCreateMaskingViewParamWithDefaults

`func NewCreateMaskingViewParamWithDefaults() *CreateMaskingViewParam`

NewCreateMaskingViewParamWithDefaults instantiates a new CreateMaskingViewParam object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetExecutionOption

`func (o *CreateMaskingViewParam) GetExecutionOption() string`

GetExecutionOption returns the ExecutionOption field if non-nil, zero value otherwise.

### GetExecutionOptionOk

`func (o *CreateMaskingViewParam) GetExecutionOptionOk() (*string, bool)`

GetExecutionOptionOk returns a tuple with the ExecutionOption field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetExecutionOption

`func (o *CreateMaskingViewParam) SetExecutionOption(v string)`

SetExecutionOption sets ExecutionOption field to given value.

### HasExecutionOption

`func (o *CreateMaskingViewParam) HasExecutionOption() bool`

HasExecutionOption returns a boolean if a field has been set.

### GetMaskingViewId

`func (o *CreateMaskingViewParam) GetMaskingViewId() string`

GetMaskingViewId returns the MaskingViewId field if non-nil, zero value otherwise.

### GetMaskingViewIdOk

`func (o *CreateMaskingViewParam) GetMaskingViewIdOk() (*string, bool)`

GetMaskingViewIdOk returns a tuple with the MaskingViewId field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetMaskingViewId

`func (o *CreateMaskingViewParam) SetMaskingViewId(v string)`

SetMaskingViewId sets MaskingViewId field to given value.


### GetHostOrHostGroupSelection

`func (o *CreateMaskingViewParam) GetHostOrHostGroupSelection() HostOrHostGroupSelection`

GetHostOrHostGroupSelection returns the HostOrHostGroupSelection field if non-nil, zero value otherwise.

### GetHostOrHostGroupSelectionOk

`func (o *CreateMaskingViewParam) GetHostOrHostGroupSelectionOk() (*HostOrHostGroupSelection, bool)`

GetHostOrHostGroupSelectionOk returns a tuple with the HostOrHostGroupSelection field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetHostOrHostGroupSelection

`func (o *CreateMaskingViewParam) SetHostOrHostGroupSelection(v HostOrHostGroupSelection)`

SetHostOrHostGroupSelection sets HostOrHostGroupSelection field to given value.

### HasHostOrHostGroupSelection

`func (o *CreateMaskingViewParam) HasHostOrHostGroupSelection() bool`

HasHostOrHostGroupSelection returns a boolean if a field has been set.

### GetPortGroupSelection

`func (o *CreateMaskingViewParam) GetPortGroupSelection() PortGroupSelection`

GetPortGroupSelection returns the PortGroupSelection field if non-nil, zero value otherwise.

### GetPortGroupSelectionOk

`func (o *CreateMaskingViewParam) GetPortGroupSelectionOk() (*PortGroupSelection, bool)`

GetPortGroupSelectionOk returns a tuple with the PortGroupSelection field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetPortGroupSelection

`func (o *CreateMaskingViewParam) SetPortGroupSelection(v PortGroupSelection)`

SetPortGroupSelection sets PortGroupSelection field to given value.

### HasPortGroupSelection

`func (o *CreateMaskingViewParam) HasPortGroupSelection() bool`

HasPortGroupSelection returns a boolean if a field has been set.

### GetStorageGroupSelection

`func (o *CreateMaskingViewParam) GetStorageGroupSelection() StorageGroupSelection`

GetStorageGroupSelection returns the StorageGroupSelection field if non-nil, zero value otherwise.

### GetStorageGroupSelectionOk

`func (o *CreateMaskingViewParam) GetStorageGroupSelectionOk() (*StorageGroupSelection, bool)`

GetStorageGroupSelectionOk returns a tuple with the StorageGroupSelection field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetStorageGroupSelection

`func (o *CreateMaskingViewParam) SetStorageGroupSelection(v StorageGroupSelection)`

SetStorageGroupSelection sets StorageGroupSelection field to given value.

### HasStorageGroupSelection

`func (o *CreateMaskingViewParam) HasStorageGroupSelection() bool`

HasStorageGroupSelection returns a boolean if a field has been set.

### GetEnableComplianceAlerts

`func (o *CreateMaskingViewParam) GetEnableComplianceAlerts() bool`

GetEnableComplianceAlerts returns the EnableComplianceAlerts field if non-nil, zero value otherwise.

### GetEnableComplianceAlertsOk

`func (o *CreateMaskingViewParam) GetEnableComplianceAlertsOk() (*bool, bool)`

GetEnableComplianceAlertsOk returns a tuple with the EnableComplianceAlerts field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetEnableComplianceAlerts

`func (o *CreateMaskingViewParam) SetEnableComplianceAlerts(v bool)`

SetEnableComplianceAlerts sets EnableComplianceAlerts field to given value.

### HasEnableComplianceAlerts

`func (o *CreateMaskingViewParam) HasEnableComplianceAlerts() bool`

HasEnableComplianceAlerts returns a boolean if a field has been set.

### GetPerformanceImpactValidationOption

`func (o *CreateMaskingViewParam) GetPerformanceImpactValidationOption() string`

GetPerformanceImpactValidationOption returns the PerformanceImpactValidationOption field if non-nil, zero value otherwise.

### GetPerformanceImpactValidationOptionOk

`func (o *CreateMaskingViewParam) GetPerformanceImpactValidationOptionOk() (*string, bool)`

GetPerformanceImpactValidationOptionOk returns a tuple with the PerformanceImpactValidationOption field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetPerformanceImpactValidationOption

`func (o *CreateMaskingViewParam) SetPerformanceImpactValidationOption(v string)`

SetPerformanceImpactValidationOption sets PerformanceImpactValidationOption field to given value.

### HasPerformanceImpactValidationOption

`func (o *CreateMaskingViewParam) HasPerformanceImpactValidationOption() bool`

HasPerformanceImpactValidationOption returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


