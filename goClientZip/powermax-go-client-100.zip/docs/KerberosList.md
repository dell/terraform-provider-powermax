# KerberosList

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Entries** | Pointer to [**[]KerberosIdentifier**](KerberosIdentifier.md) |                                  List of kerberos objects                              | [optional] 

## Methods

### NewKerberosList

`func NewKerberosList() *KerberosList`

NewKerberosList instantiates a new KerberosList object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewKerberosListWithDefaults

`func NewKerberosListWithDefaults() *KerberosList`

NewKerberosListWithDefaults instantiates a new KerberosList object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetEntries

`func (o *KerberosList) GetEntries() []KerberosIdentifier`

GetEntries returns the Entries field if non-nil, zero value otherwise.

### GetEntriesOk

`func (o *KerberosList) GetEntriesOk() (*[]KerberosIdentifier, bool)`

GetEntriesOk returns a tuple with the Entries field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetEntries

`func (o *KerberosList) SetEntries(v []KerberosIdentifier)`

SetEntries sets Entries field to given value.

### HasEntries

`func (o *KerberosList) HasEntries() bool`

HasEntries returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


