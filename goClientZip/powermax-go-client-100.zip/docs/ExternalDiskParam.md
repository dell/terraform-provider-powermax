# ExternalDiskParam

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**StartDate** | **int64** | &lt;p&gt;Starting date in millisecond.&lt;/p&gt; | 
**EndDate** | **int64** | &lt;p&gt;Ending date in millisecond.&lt;/p&gt; | 
**SymmetrixId** | **string** | &lt;p&gt;The Symmetrix array ID.&lt;/p&gt; | 
**DiskId** | **string** | diskId | 
**DataFormat** | Pointer to **string** | &lt;p&gt;Data Format (Average or Maximum).&lt;/p&gt;   Enumeration values: * **Average** * **Maximum**  | [optional] 
**Metrics** | **[]string** | metrics   Enumeration values: * **DiskReads** - Reads/sec * **DiskWrites** - Writes/sec * **MBReads** - The reads per second in MBs. * **MBWrittens** - The write throughput (MBs) of the disk per second. * **AvgReadSize** - The average number of kilobytes for a single read command. * **AvgWriteSize** - The average number of kilobytes for a single write command. * **ReadResponseTime** - The average time it took the disk to serve one read command. * **WriteResponseTime** - The average time it took the disk to serve one write command. * **ResponseTime** - Calculated value: (Total Read Time/sec + Total Write Time/sec) / (Reads/sec + Writes/sec) * **MBs** - The total IO (reads and writes) per second in MBs. * **IOs** - An IO command to the disk. * **TotalCapacity** - The total capacity of the disk in GBs. * **UsedCapacity** - The used capacity of the disk in GBs. * **PercentCapacityUsed** - The percent of the pools capacity that is used. * **Members** - Members * **AvgQueueDepth** - Avg Queue Depth * **PercentBusy** - The number of backend reads and writes per GB of disk. * **PercentIdle** - % Idle. * **UnmapCommandCount** - UNMAP command count * **VAAIUnmapCommandCount** - VAAI (VMwares Storage APIs for Array Integration) UNMAP command count  | 

## Methods

### NewExternalDiskParam

`func NewExternalDiskParam(startDate int64, endDate int64, symmetrixId string, diskId string, metrics []string, ) *ExternalDiskParam`

NewExternalDiskParam instantiates a new ExternalDiskParam object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewExternalDiskParamWithDefaults

`func NewExternalDiskParamWithDefaults() *ExternalDiskParam`

NewExternalDiskParamWithDefaults instantiates a new ExternalDiskParam object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetStartDate

`func (o *ExternalDiskParam) GetStartDate() int64`

GetStartDate returns the StartDate field if non-nil, zero value otherwise.

### GetStartDateOk

`func (o *ExternalDiskParam) GetStartDateOk() (*int64, bool)`

GetStartDateOk returns a tuple with the StartDate field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetStartDate

`func (o *ExternalDiskParam) SetStartDate(v int64)`

SetStartDate sets StartDate field to given value.


### GetEndDate

`func (o *ExternalDiskParam) GetEndDate() int64`

GetEndDate returns the EndDate field if non-nil, zero value otherwise.

### GetEndDateOk

`func (o *ExternalDiskParam) GetEndDateOk() (*int64, bool)`

GetEndDateOk returns a tuple with the EndDate field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetEndDate

`func (o *ExternalDiskParam) SetEndDate(v int64)`

SetEndDate sets EndDate field to given value.


### GetSymmetrixId

`func (o *ExternalDiskParam) GetSymmetrixId() string`

GetSymmetrixId returns the SymmetrixId field if non-nil, zero value otherwise.

### GetSymmetrixIdOk

`func (o *ExternalDiskParam) GetSymmetrixIdOk() (*string, bool)`

GetSymmetrixIdOk returns a tuple with the SymmetrixId field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetSymmetrixId

`func (o *ExternalDiskParam) SetSymmetrixId(v string)`

SetSymmetrixId sets SymmetrixId field to given value.


### GetDiskId

`func (o *ExternalDiskParam) GetDiskId() string`

GetDiskId returns the DiskId field if non-nil, zero value otherwise.

### GetDiskIdOk

`func (o *ExternalDiskParam) GetDiskIdOk() (*string, bool)`

GetDiskIdOk returns a tuple with the DiskId field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetDiskId

`func (o *ExternalDiskParam) SetDiskId(v string)`

SetDiskId sets DiskId field to given value.


### GetDataFormat

`func (o *ExternalDiskParam) GetDataFormat() string`

GetDataFormat returns the DataFormat field if non-nil, zero value otherwise.

### GetDataFormatOk

`func (o *ExternalDiskParam) GetDataFormatOk() (*string, bool)`

GetDataFormatOk returns a tuple with the DataFormat field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetDataFormat

`func (o *ExternalDiskParam) SetDataFormat(v string)`

SetDataFormat sets DataFormat field to given value.

### HasDataFormat

`func (o *ExternalDiskParam) HasDataFormat() bool`

HasDataFormat returns a boolean if a field has been set.

### GetMetrics

`func (o *ExternalDiskParam) GetMetrics() []string`

GetMetrics returns the Metrics field if non-nil, zero value otherwise.

### GetMetricsOk

`func (o *ExternalDiskParam) GetMetricsOk() (*[]string, bool)`

GetMetricsOk returns a tuple with the Metrics field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetMetrics

`func (o *ExternalDiskParam) SetMetrics(v []string)`

SetMetrics sets Metrics field to given value.



[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


