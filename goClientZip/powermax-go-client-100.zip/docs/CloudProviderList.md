# CloudProviderList

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**CloudProviderId** | Pointer to **[]string** | cloud_provider_id | [optional] 

## Methods

### NewCloudProviderList

`func NewCloudProviderList() *CloudProviderList`

NewCloudProviderList instantiates a new CloudProviderList object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewCloudProviderListWithDefaults

`func NewCloudProviderListWithDefaults() *CloudProviderList`

NewCloudProviderListWithDefaults instantiates a new CloudProviderList object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetCloudProviderId

`func (o *CloudProviderList) GetCloudProviderId() []string`

GetCloudProviderId returns the CloudProviderId field if non-nil, zero value otherwise.

### GetCloudProviderIdOk

`func (o *CloudProviderList) GetCloudProviderIdOk() (*[]string, bool)`

GetCloudProviderIdOk returns a tuple with the CloudProviderId field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetCloudProviderId

`func (o *CloudProviderList) SetCloudProviderId(v []string)`

SetCloudProviderId sets CloudProviderId field to given value.

### HasCloudProviderId

`func (o *CloudProviderList) HasCloudProviderId() bool`

HasCloudProviderId returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


