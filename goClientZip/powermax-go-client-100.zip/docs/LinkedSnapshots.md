# LinkedSnapshots

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Name** | **string** | The storage group name. | 
**SourceVolumeName** | **string** | The source volumes name. | 
**LinkedVolumeName** | **string** | The linked volumes name. | 
**Tracks** | **int64** | Number of tracks. | 
**TrackSize** | **int64** | Size of the tracks. | 
**PercentageCopied** | **int64** | Percentage of tracks copied. | 
**LinkedCreationTimestamp** | **string** | The average timestamp of all linked volumes that are linked. | 
**Defined** | Pointer to **bool** | When the snapshot link has been fully defined. | [optional] 
**BackgroundDefineInProgress** | Pointer to **bool** | When the snapshot link is being defined. | [optional] 

## Methods

### NewLinkedSnapshots

`func NewLinkedSnapshots(name string, sourceVolumeName string, linkedVolumeName string, tracks int64, trackSize int64, percentageCopied int64, linkedCreationTimestamp string, ) *LinkedSnapshots`

NewLinkedSnapshots instantiates a new LinkedSnapshots object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewLinkedSnapshotsWithDefaults

`func NewLinkedSnapshotsWithDefaults() *LinkedSnapshots`

NewLinkedSnapshotsWithDefaults instantiates a new LinkedSnapshots object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetName

`func (o *LinkedSnapshots) GetName() string`

GetName returns the Name field if non-nil, zero value otherwise.

### GetNameOk

`func (o *LinkedSnapshots) GetNameOk() (*string, bool)`

GetNameOk returns a tuple with the Name field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetName

`func (o *LinkedSnapshots) SetName(v string)`

SetName sets Name field to given value.


### GetSourceVolumeName

`func (o *LinkedSnapshots) GetSourceVolumeName() string`

GetSourceVolumeName returns the SourceVolumeName field if non-nil, zero value otherwise.

### GetSourceVolumeNameOk

`func (o *LinkedSnapshots) GetSourceVolumeNameOk() (*string, bool)`

GetSourceVolumeNameOk returns a tuple with the SourceVolumeName field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetSourceVolumeName

`func (o *LinkedSnapshots) SetSourceVolumeName(v string)`

SetSourceVolumeName sets SourceVolumeName field to given value.


### GetLinkedVolumeName

`func (o *LinkedSnapshots) GetLinkedVolumeName() string`

GetLinkedVolumeName returns the LinkedVolumeName field if non-nil, zero value otherwise.

### GetLinkedVolumeNameOk

`func (o *LinkedSnapshots) GetLinkedVolumeNameOk() (*string, bool)`

GetLinkedVolumeNameOk returns a tuple with the LinkedVolumeName field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetLinkedVolumeName

`func (o *LinkedSnapshots) SetLinkedVolumeName(v string)`

SetLinkedVolumeName sets LinkedVolumeName field to given value.


### GetTracks

`func (o *LinkedSnapshots) GetTracks() int64`

GetTracks returns the Tracks field if non-nil, zero value otherwise.

### GetTracksOk

`func (o *LinkedSnapshots) GetTracksOk() (*int64, bool)`

GetTracksOk returns a tuple with the Tracks field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetTracks

`func (o *LinkedSnapshots) SetTracks(v int64)`

SetTracks sets Tracks field to given value.


### GetTrackSize

`func (o *LinkedSnapshots) GetTrackSize() int64`

GetTrackSize returns the TrackSize field if non-nil, zero value otherwise.

### GetTrackSizeOk

`func (o *LinkedSnapshots) GetTrackSizeOk() (*int64, bool)`

GetTrackSizeOk returns a tuple with the TrackSize field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetTrackSize

`func (o *LinkedSnapshots) SetTrackSize(v int64)`

SetTrackSize sets TrackSize field to given value.


### GetPercentageCopied

`func (o *LinkedSnapshots) GetPercentageCopied() int64`

GetPercentageCopied returns the PercentageCopied field if non-nil, zero value otherwise.

### GetPercentageCopiedOk

`func (o *LinkedSnapshots) GetPercentageCopiedOk() (*int64, bool)`

GetPercentageCopiedOk returns a tuple with the PercentageCopied field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetPercentageCopied

`func (o *LinkedSnapshots) SetPercentageCopied(v int64)`

SetPercentageCopied sets PercentageCopied field to given value.


### GetLinkedCreationTimestamp

`func (o *LinkedSnapshots) GetLinkedCreationTimestamp() string`

GetLinkedCreationTimestamp returns the LinkedCreationTimestamp field if non-nil, zero value otherwise.

### GetLinkedCreationTimestampOk

`func (o *LinkedSnapshots) GetLinkedCreationTimestampOk() (*string, bool)`

GetLinkedCreationTimestampOk returns a tuple with the LinkedCreationTimestamp field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetLinkedCreationTimestamp

`func (o *LinkedSnapshots) SetLinkedCreationTimestamp(v string)`

SetLinkedCreationTimestamp sets LinkedCreationTimestamp field to given value.


### GetDefined

`func (o *LinkedSnapshots) GetDefined() bool`

GetDefined returns the Defined field if non-nil, zero value otherwise.

### GetDefinedOk

`func (o *LinkedSnapshots) GetDefinedOk() (*bool, bool)`

GetDefinedOk returns a tuple with the Defined field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetDefined

`func (o *LinkedSnapshots) SetDefined(v bool)`

SetDefined sets Defined field to given value.

### HasDefined

`func (o *LinkedSnapshots) HasDefined() bool`

HasDefined returns a boolean if a field has been set.

### GetBackgroundDefineInProgress

`func (o *LinkedSnapshots) GetBackgroundDefineInProgress() bool`

GetBackgroundDefineInProgress returns the BackgroundDefineInProgress field if non-nil, zero value otherwise.

### GetBackgroundDefineInProgressOk

`func (o *LinkedSnapshots) GetBackgroundDefineInProgressOk() (*bool, bool)`

GetBackgroundDefineInProgressOk returns a tuple with the BackgroundDefineInProgress field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetBackgroundDefineInProgress

`func (o *LinkedSnapshots) SetBackgroundDefineInProgress(v bool)`

SetBackgroundDefineInProgress sets BackgroundDefineInProgress field to given value.

### HasBackgroundDefineInProgress

`func (o *LinkedSnapshots) HasBackgroundDefineInProgress() bool`

HasBackgroundDefineInProgress returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


