# ExternalPortPath

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ExternalPortWwn** | Pointer to **string** | WWN of the external port | [optional] 
**ArrayId** | Pointer to **string** | Serial ID of the external array | [optional] 
**VendorName** | Pointer to **string** | Vendor name of the remote array | [optional] 
**LunCount** | Pointer to **int64** | Number of LUNS mapped to external port | [optional] 
**RemoteDir** | Pointer to **int64** | The external director number | [optional] 
**RemotePort** | Pointer to **int64** | The external port number | [optional] 
**LocalPort** | Pointer to [**SymmetrixPortKey**](SymmetrixPortKey.md) |  | [optional] 
**LocalDirStatus** | Pointer to **string** | The status of the local director doing the scanning | [optional] 
**RdfDirLinkConfig** | Pointer to **string** | The configuration of the SRDF link | [optional] 
**FibreAdapterType** | Pointer to **string** | Configuration of the fibre adapter | [optional] 
**LocalPortStatus** | Pointer to **string** | The status of the local port doing the scanning | [optional] 
**Incomplete** | Pointer to **bool** | Add description text here | [optional] 
**Disconnected** | Pointer to **bool** | Add description text here | [optional] 
**Connected** | Pointer to **bool** | Add description text here | [optional] 
**ConectionInProgress** | Pointer to **bool** | Add description text here | [optional] 
**Hba** | Pointer to **bool** | Is the port a HBA | [optional] 

## Methods

### NewExternalPortPath

`func NewExternalPortPath() *ExternalPortPath`

NewExternalPortPath instantiates a new ExternalPortPath object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewExternalPortPathWithDefaults

`func NewExternalPortPathWithDefaults() *ExternalPortPath`

NewExternalPortPathWithDefaults instantiates a new ExternalPortPath object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetExternalPortWwn

`func (o *ExternalPortPath) GetExternalPortWwn() string`

GetExternalPortWwn returns the ExternalPortWwn field if non-nil, zero value otherwise.

### GetExternalPortWwnOk

`func (o *ExternalPortPath) GetExternalPortWwnOk() (*string, bool)`

GetExternalPortWwnOk returns a tuple with the ExternalPortWwn field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetExternalPortWwn

`func (o *ExternalPortPath) SetExternalPortWwn(v string)`

SetExternalPortWwn sets ExternalPortWwn field to given value.

### HasExternalPortWwn

`func (o *ExternalPortPath) HasExternalPortWwn() bool`

HasExternalPortWwn returns a boolean if a field has been set.

### GetArrayId

`func (o *ExternalPortPath) GetArrayId() string`

GetArrayId returns the ArrayId field if non-nil, zero value otherwise.

### GetArrayIdOk

`func (o *ExternalPortPath) GetArrayIdOk() (*string, bool)`

GetArrayIdOk returns a tuple with the ArrayId field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetArrayId

`func (o *ExternalPortPath) SetArrayId(v string)`

SetArrayId sets ArrayId field to given value.

### HasArrayId

`func (o *ExternalPortPath) HasArrayId() bool`

HasArrayId returns a boolean if a field has been set.

### GetVendorName

`func (o *ExternalPortPath) GetVendorName() string`

GetVendorName returns the VendorName field if non-nil, zero value otherwise.

### GetVendorNameOk

`func (o *ExternalPortPath) GetVendorNameOk() (*string, bool)`

GetVendorNameOk returns a tuple with the VendorName field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetVendorName

`func (o *ExternalPortPath) SetVendorName(v string)`

SetVendorName sets VendorName field to given value.

### HasVendorName

`func (o *ExternalPortPath) HasVendorName() bool`

HasVendorName returns a boolean if a field has been set.

### GetLunCount

`func (o *ExternalPortPath) GetLunCount() int64`

GetLunCount returns the LunCount field if non-nil, zero value otherwise.

### GetLunCountOk

`func (o *ExternalPortPath) GetLunCountOk() (*int64, bool)`

GetLunCountOk returns a tuple with the LunCount field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetLunCount

`func (o *ExternalPortPath) SetLunCount(v int64)`

SetLunCount sets LunCount field to given value.

### HasLunCount

`func (o *ExternalPortPath) HasLunCount() bool`

HasLunCount returns a boolean if a field has been set.

### GetRemoteDir

`func (o *ExternalPortPath) GetRemoteDir() int64`

GetRemoteDir returns the RemoteDir field if non-nil, zero value otherwise.

### GetRemoteDirOk

`func (o *ExternalPortPath) GetRemoteDirOk() (*int64, bool)`

GetRemoteDirOk returns a tuple with the RemoteDir field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetRemoteDir

`func (o *ExternalPortPath) SetRemoteDir(v int64)`

SetRemoteDir sets RemoteDir field to given value.

### HasRemoteDir

`func (o *ExternalPortPath) HasRemoteDir() bool`

HasRemoteDir returns a boolean if a field has been set.

### GetRemotePort

`func (o *ExternalPortPath) GetRemotePort() int64`

GetRemotePort returns the RemotePort field if non-nil, zero value otherwise.

### GetRemotePortOk

`func (o *ExternalPortPath) GetRemotePortOk() (*int64, bool)`

GetRemotePortOk returns a tuple with the RemotePort field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetRemotePort

`func (o *ExternalPortPath) SetRemotePort(v int64)`

SetRemotePort sets RemotePort field to given value.

### HasRemotePort

`func (o *ExternalPortPath) HasRemotePort() bool`

HasRemotePort returns a boolean if a field has been set.

### GetLocalPort

`func (o *ExternalPortPath) GetLocalPort() SymmetrixPortKey`

GetLocalPort returns the LocalPort field if non-nil, zero value otherwise.

### GetLocalPortOk

`func (o *ExternalPortPath) GetLocalPortOk() (*SymmetrixPortKey, bool)`

GetLocalPortOk returns a tuple with the LocalPort field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetLocalPort

`func (o *ExternalPortPath) SetLocalPort(v SymmetrixPortKey)`

SetLocalPort sets LocalPort field to given value.

### HasLocalPort

`func (o *ExternalPortPath) HasLocalPort() bool`

HasLocalPort returns a boolean if a field has been set.

### GetLocalDirStatus

`func (o *ExternalPortPath) GetLocalDirStatus() string`

GetLocalDirStatus returns the LocalDirStatus field if non-nil, zero value otherwise.

### GetLocalDirStatusOk

`func (o *ExternalPortPath) GetLocalDirStatusOk() (*string, bool)`

GetLocalDirStatusOk returns a tuple with the LocalDirStatus field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetLocalDirStatus

`func (o *ExternalPortPath) SetLocalDirStatus(v string)`

SetLocalDirStatus sets LocalDirStatus field to given value.

### HasLocalDirStatus

`func (o *ExternalPortPath) HasLocalDirStatus() bool`

HasLocalDirStatus returns a boolean if a field has been set.

### GetRdfDirLinkConfig

`func (o *ExternalPortPath) GetRdfDirLinkConfig() string`

GetRdfDirLinkConfig returns the RdfDirLinkConfig field if non-nil, zero value otherwise.

### GetRdfDirLinkConfigOk

`func (o *ExternalPortPath) GetRdfDirLinkConfigOk() (*string, bool)`

GetRdfDirLinkConfigOk returns a tuple with the RdfDirLinkConfig field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetRdfDirLinkConfig

`func (o *ExternalPortPath) SetRdfDirLinkConfig(v string)`

SetRdfDirLinkConfig sets RdfDirLinkConfig field to given value.

### HasRdfDirLinkConfig

`func (o *ExternalPortPath) HasRdfDirLinkConfig() bool`

HasRdfDirLinkConfig returns a boolean if a field has been set.

### GetFibreAdapterType

`func (o *ExternalPortPath) GetFibreAdapterType() string`

GetFibreAdapterType returns the FibreAdapterType field if non-nil, zero value otherwise.

### GetFibreAdapterTypeOk

`func (o *ExternalPortPath) GetFibreAdapterTypeOk() (*string, bool)`

GetFibreAdapterTypeOk returns a tuple with the FibreAdapterType field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetFibreAdapterType

`func (o *ExternalPortPath) SetFibreAdapterType(v string)`

SetFibreAdapterType sets FibreAdapterType field to given value.

### HasFibreAdapterType

`func (o *ExternalPortPath) HasFibreAdapterType() bool`

HasFibreAdapterType returns a boolean if a field has been set.

### GetLocalPortStatus

`func (o *ExternalPortPath) GetLocalPortStatus() string`

GetLocalPortStatus returns the LocalPortStatus field if non-nil, zero value otherwise.

### GetLocalPortStatusOk

`func (o *ExternalPortPath) GetLocalPortStatusOk() (*string, bool)`

GetLocalPortStatusOk returns a tuple with the LocalPortStatus field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetLocalPortStatus

`func (o *ExternalPortPath) SetLocalPortStatus(v string)`

SetLocalPortStatus sets LocalPortStatus field to given value.

### HasLocalPortStatus

`func (o *ExternalPortPath) HasLocalPortStatus() bool`

HasLocalPortStatus returns a boolean if a field has been set.

### GetIncomplete

`func (o *ExternalPortPath) GetIncomplete() bool`

GetIncomplete returns the Incomplete field if non-nil, zero value otherwise.

### GetIncompleteOk

`func (o *ExternalPortPath) GetIncompleteOk() (*bool, bool)`

GetIncompleteOk returns a tuple with the Incomplete field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetIncomplete

`func (o *ExternalPortPath) SetIncomplete(v bool)`

SetIncomplete sets Incomplete field to given value.

### HasIncomplete

`func (o *ExternalPortPath) HasIncomplete() bool`

HasIncomplete returns a boolean if a field has been set.

### GetDisconnected

`func (o *ExternalPortPath) GetDisconnected() bool`

GetDisconnected returns the Disconnected field if non-nil, zero value otherwise.

### GetDisconnectedOk

`func (o *ExternalPortPath) GetDisconnectedOk() (*bool, bool)`

GetDisconnectedOk returns a tuple with the Disconnected field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetDisconnected

`func (o *ExternalPortPath) SetDisconnected(v bool)`

SetDisconnected sets Disconnected field to given value.

### HasDisconnected

`func (o *ExternalPortPath) HasDisconnected() bool`

HasDisconnected returns a boolean if a field has been set.

### GetConnected

`func (o *ExternalPortPath) GetConnected() bool`

GetConnected returns the Connected field if non-nil, zero value otherwise.

### GetConnectedOk

`func (o *ExternalPortPath) GetConnectedOk() (*bool, bool)`

GetConnectedOk returns a tuple with the Connected field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetConnected

`func (o *ExternalPortPath) SetConnected(v bool)`

SetConnected sets Connected field to given value.

### HasConnected

`func (o *ExternalPortPath) HasConnected() bool`

HasConnected returns a boolean if a field has been set.

### GetConectionInProgress

`func (o *ExternalPortPath) GetConectionInProgress() bool`

GetConectionInProgress returns the ConectionInProgress field if non-nil, zero value otherwise.

### GetConectionInProgressOk

`func (o *ExternalPortPath) GetConectionInProgressOk() (*bool, bool)`

GetConectionInProgressOk returns a tuple with the ConectionInProgress field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetConectionInProgress

`func (o *ExternalPortPath) SetConectionInProgress(v bool)`

SetConectionInProgress sets ConectionInProgress field to given value.

### HasConectionInProgress

`func (o *ExternalPortPath) HasConectionInProgress() bool`

HasConectionInProgress returns a boolean if a field has been set.

### GetHba

`func (o *ExternalPortPath) GetHba() bool`

GetHba returns the Hba field if non-nil, zero value otherwise.

### GetHbaOk

`func (o *ExternalPortPath) GetHbaOk() (*bool, bool)`

GetHbaOk returns a tuple with the Hba field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetHba

`func (o *ExternalPortPath) SetHba(v bool)`

SetHba sets Hba field to given value.

### HasHba

`func (o *ExternalPortPath) HasHba() bool`

HasHba returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


