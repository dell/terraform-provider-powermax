# DmStorageGroupList

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Name** | Pointer to **[]string** | The Storage Group name for this System | [optional] 
**MigratingName** | Pointer to **[]string** | The migrating or non-migrating Storage Group names for this System | [optional] 

## Methods

### NewDmStorageGroupList

`func NewDmStorageGroupList() *DmStorageGroupList`

NewDmStorageGroupList instantiates a new DmStorageGroupList object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewDmStorageGroupListWithDefaults

`func NewDmStorageGroupListWithDefaults() *DmStorageGroupList`

NewDmStorageGroupListWithDefaults instantiates a new DmStorageGroupList object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetName

`func (o *DmStorageGroupList) GetName() []string`

GetName returns the Name field if non-nil, zero value otherwise.

### GetNameOk

`func (o *DmStorageGroupList) GetNameOk() (*[]string, bool)`

GetNameOk returns a tuple with the Name field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetName

`func (o *DmStorageGroupList) SetName(v []string)`

SetName sets Name field to given value.

### HasName

`func (o *DmStorageGroupList) HasName() bool`

HasName returns a boolean if a field has been set.

### GetMigratingName

`func (o *DmStorageGroupList) GetMigratingName() []string`

GetMigratingName returns the MigratingName field if non-nil, zero value otherwise.

### GetMigratingNameOk

`func (o *DmStorageGroupList) GetMigratingNameOk() (*[]string, bool)`

GetMigratingNameOk returns a tuple with the MigratingName field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetMigratingName

`func (o *DmStorageGroupList) SetMigratingName(v []string)`

SetMigratingName sets MigratingName field to given value.

### HasMigratingName

`func (o *DmStorageGroupList) HasMigratingName() bool`

HasMigratingName returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


