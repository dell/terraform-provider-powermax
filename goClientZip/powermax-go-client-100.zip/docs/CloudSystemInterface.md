# CloudSystemInterface

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**InterfaceId** | **string** | The ID of the Cloud System Route | 
**State** | Pointer to **string** | The IP Address of the NIC Team | [optional] 
**IpAddress** | Pointer to **string** | The IP Address of the NIC Team | [optional] 
**Prefix** | Pointer to **int32** | The Netmask Prefix Number of the NIC Team | [optional] 
**MacAddress** | Pointer to **string** | The MAC address of the interface in the NIC Team | [optional] 
**Mtu** | Pointer to **int32** | The MTU Speed of the interface in the NIC Team | [optional] 
**NumOfRoutes** | Pointer to **int32** | The number of routes associated with the interface in the NIC Team | [optional] 
**Type** | Pointer to **string** | The default interface type in the NIC Team | [optional] 
**IpSource** | Pointer to **string** | The IP Source of the interface in the NIC Team | [optional] 

## Methods

### NewCloudSystemInterface

`func NewCloudSystemInterface(interfaceId string, ) *CloudSystemInterface`

NewCloudSystemInterface instantiates a new CloudSystemInterface object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewCloudSystemInterfaceWithDefaults

`func NewCloudSystemInterfaceWithDefaults() *CloudSystemInterface`

NewCloudSystemInterfaceWithDefaults instantiates a new CloudSystemInterface object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetInterfaceId

`func (o *CloudSystemInterface) GetInterfaceId() string`

GetInterfaceId returns the InterfaceId field if non-nil, zero value otherwise.

### GetInterfaceIdOk

`func (o *CloudSystemInterface) GetInterfaceIdOk() (*string, bool)`

GetInterfaceIdOk returns a tuple with the InterfaceId field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetInterfaceId

`func (o *CloudSystemInterface) SetInterfaceId(v string)`

SetInterfaceId sets InterfaceId field to given value.


### GetState

`func (o *CloudSystemInterface) GetState() string`

GetState returns the State field if non-nil, zero value otherwise.

### GetStateOk

`func (o *CloudSystemInterface) GetStateOk() (*string, bool)`

GetStateOk returns a tuple with the State field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetState

`func (o *CloudSystemInterface) SetState(v string)`

SetState sets State field to given value.

### HasState

`func (o *CloudSystemInterface) HasState() bool`

HasState returns a boolean if a field has been set.

### GetIpAddress

`func (o *CloudSystemInterface) GetIpAddress() string`

GetIpAddress returns the IpAddress field if non-nil, zero value otherwise.

### GetIpAddressOk

`func (o *CloudSystemInterface) GetIpAddressOk() (*string, bool)`

GetIpAddressOk returns a tuple with the IpAddress field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetIpAddress

`func (o *CloudSystemInterface) SetIpAddress(v string)`

SetIpAddress sets IpAddress field to given value.

### HasIpAddress

`func (o *CloudSystemInterface) HasIpAddress() bool`

HasIpAddress returns a boolean if a field has been set.

### GetPrefix

`func (o *CloudSystemInterface) GetPrefix() int32`

GetPrefix returns the Prefix field if non-nil, zero value otherwise.

### GetPrefixOk

`func (o *CloudSystemInterface) GetPrefixOk() (*int32, bool)`

GetPrefixOk returns a tuple with the Prefix field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetPrefix

`func (o *CloudSystemInterface) SetPrefix(v int32)`

SetPrefix sets Prefix field to given value.

### HasPrefix

`func (o *CloudSystemInterface) HasPrefix() bool`

HasPrefix returns a boolean if a field has been set.

### GetMacAddress

`func (o *CloudSystemInterface) GetMacAddress() string`

GetMacAddress returns the MacAddress field if non-nil, zero value otherwise.

### GetMacAddressOk

`func (o *CloudSystemInterface) GetMacAddressOk() (*string, bool)`

GetMacAddressOk returns a tuple with the MacAddress field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetMacAddress

`func (o *CloudSystemInterface) SetMacAddress(v string)`

SetMacAddress sets MacAddress field to given value.

### HasMacAddress

`func (o *CloudSystemInterface) HasMacAddress() bool`

HasMacAddress returns a boolean if a field has been set.

### GetMtu

`func (o *CloudSystemInterface) GetMtu() int32`

GetMtu returns the Mtu field if non-nil, zero value otherwise.

### GetMtuOk

`func (o *CloudSystemInterface) GetMtuOk() (*int32, bool)`

GetMtuOk returns a tuple with the Mtu field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetMtu

`func (o *CloudSystemInterface) SetMtu(v int32)`

SetMtu sets Mtu field to given value.

### HasMtu

`func (o *CloudSystemInterface) HasMtu() bool`

HasMtu returns a boolean if a field has been set.

### GetNumOfRoutes

`func (o *CloudSystemInterface) GetNumOfRoutes() int32`

GetNumOfRoutes returns the NumOfRoutes field if non-nil, zero value otherwise.

### GetNumOfRoutesOk

`func (o *CloudSystemInterface) GetNumOfRoutesOk() (*int32, bool)`

GetNumOfRoutesOk returns a tuple with the NumOfRoutes field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetNumOfRoutes

`func (o *CloudSystemInterface) SetNumOfRoutes(v int32)`

SetNumOfRoutes sets NumOfRoutes field to given value.

### HasNumOfRoutes

`func (o *CloudSystemInterface) HasNumOfRoutes() bool`

HasNumOfRoutes returns a boolean if a field has been set.

### GetType

`func (o *CloudSystemInterface) GetType() string`

GetType returns the Type field if non-nil, zero value otherwise.

### GetTypeOk

`func (o *CloudSystemInterface) GetTypeOk() (*string, bool)`

GetTypeOk returns a tuple with the Type field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetType

`func (o *CloudSystemInterface) SetType(v string)`

SetType sets Type field to given value.

### HasType

`func (o *CloudSystemInterface) HasType() bool`

HasType returns a boolean if a field has been set.

### GetIpSource

`func (o *CloudSystemInterface) GetIpSource() string`

GetIpSource returns the IpSource field if non-nil, zero value otherwise.

### GetIpSourceOk

`func (o *CloudSystemInterface) GetIpSourceOk() (*string, bool)`

GetIpSourceOk returns a tuple with the IpSource field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetIpSource

`func (o *CloudSystemInterface) SetIpSource(v string)`

SetIpSource sets IpSource field to given value.

### HasIpSource

`func (o *CloudSystemInterface) HasIpSource() bool`

HasIpSource returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


