# EditStorageGroupWorkloadParam

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**WorkloadSelection** | **string** | The New Workload Selection | 

## Methods

### NewEditStorageGroupWorkloadParam

`func NewEditStorageGroupWorkloadParam(workloadSelection string, ) *EditStorageGroupWorkloadParam`

NewEditStorageGroupWorkloadParam instantiates a new EditStorageGroupWorkloadParam object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewEditStorageGroupWorkloadParamWithDefaults

`func NewEditStorageGroupWorkloadParamWithDefaults() *EditStorageGroupWorkloadParam`

NewEditStorageGroupWorkloadParamWithDefaults instantiates a new EditStorageGroupWorkloadParam object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetWorkloadSelection

`func (o *EditStorageGroupWorkloadParam) GetWorkloadSelection() string`

GetWorkloadSelection returns the WorkloadSelection field if non-nil, zero value otherwise.

### GetWorkloadSelectionOk

`func (o *EditStorageGroupWorkloadParam) GetWorkloadSelectionOk() (*string, bool)`

GetWorkloadSelectionOk returns a tuple with the WorkloadSelection field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetWorkloadSelection

`func (o *EditStorageGroupWorkloadParam) SetWorkloadSelection(v string)`

SetWorkloadSelection sets WorkloadSelection field to given value.



[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


