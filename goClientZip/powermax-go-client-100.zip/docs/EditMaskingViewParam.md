# EditMaskingViewParam

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ExecutionOption** | Pointer to **string** |  | [optional] [default to "SYNCHRONOUS"]
**EditMaskingViewActionParam** | [**EditMaskingViewActionParam**](EditMaskingViewActionParam.md) |  | 

## Methods

### NewEditMaskingViewParam

`func NewEditMaskingViewParam(editMaskingViewActionParam EditMaskingViewActionParam, ) *EditMaskingViewParam`

NewEditMaskingViewParam instantiates a new EditMaskingViewParam object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewEditMaskingViewParamWithDefaults

`func NewEditMaskingViewParamWithDefaults() *EditMaskingViewParam`

NewEditMaskingViewParamWithDefaults instantiates a new EditMaskingViewParam object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetExecutionOption

`func (o *EditMaskingViewParam) GetExecutionOption() string`

GetExecutionOption returns the ExecutionOption field if non-nil, zero value otherwise.

### GetExecutionOptionOk

`func (o *EditMaskingViewParam) GetExecutionOptionOk() (*string, bool)`

GetExecutionOptionOk returns a tuple with the ExecutionOption field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetExecutionOption

`func (o *EditMaskingViewParam) SetExecutionOption(v string)`

SetExecutionOption sets ExecutionOption field to given value.

### HasExecutionOption

`func (o *EditMaskingViewParam) HasExecutionOption() bool`

HasExecutionOption returns a boolean if a field has been set.

### GetEditMaskingViewActionParam

`func (o *EditMaskingViewParam) GetEditMaskingViewActionParam() EditMaskingViewActionParam`

GetEditMaskingViewActionParam returns the EditMaskingViewActionParam field if non-nil, zero value otherwise.

### GetEditMaskingViewActionParamOk

`func (o *EditMaskingViewParam) GetEditMaskingViewActionParamOk() (*EditMaskingViewActionParam, bool)`

GetEditMaskingViewActionParamOk returns a tuple with the EditMaskingViewActionParam field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetEditMaskingViewActionParam

`func (o *EditMaskingViewParam) SetEditMaskingViewActionParam(v EditMaskingViewActionParam)`

SetEditMaskingViewActionParam sets EditMaskingViewActionParam field to given value.



[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


