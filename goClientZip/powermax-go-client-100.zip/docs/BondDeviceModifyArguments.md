# BondDeviceModifyArguments

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**FdnList** | Pointer to **[]string** |                          Array of two or more FDNs from same subnet.                      | [optional] 

## Methods

### NewBondDeviceModifyArguments

`func NewBondDeviceModifyArguments() *BondDeviceModifyArguments`

NewBondDeviceModifyArguments instantiates a new BondDeviceModifyArguments object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewBondDeviceModifyArgumentsWithDefaults

`func NewBondDeviceModifyArgumentsWithDefaults() *BondDeviceModifyArguments`

NewBondDeviceModifyArgumentsWithDefaults instantiates a new BondDeviceModifyArguments object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetFdnList

`func (o *BondDeviceModifyArguments) GetFdnList() []string`

GetFdnList returns the FdnList field if non-nil, zero value otherwise.

### GetFdnListOk

`func (o *BondDeviceModifyArguments) GetFdnListOk() (*[]string, bool)`

GetFdnListOk returns a tuple with the FdnList field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetFdnList

`func (o *BondDeviceModifyArguments) SetFdnList(v []string)`

SetFdnList sets FdnList field to given value.

### HasFdnList

`func (o *BondDeviceModifyArguments) HasFdnList() bool`

HasFdnList returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


