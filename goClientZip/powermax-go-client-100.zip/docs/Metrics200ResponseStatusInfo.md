# Metrics200ResponseStatusInfo

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Family** | Pointer to **string** |  | [optional] 
**ReasonPhrase** | Pointer to **string** |  | [optional] 
**StatusCode** | Pointer to **int32** |  | [optional] 

## Methods

### NewMetrics200ResponseStatusInfo

`func NewMetrics200ResponseStatusInfo() *Metrics200ResponseStatusInfo`

NewMetrics200ResponseStatusInfo instantiates a new Metrics200ResponseStatusInfo object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewMetrics200ResponseStatusInfoWithDefaults

`func NewMetrics200ResponseStatusInfoWithDefaults() *Metrics200ResponseStatusInfo`

NewMetrics200ResponseStatusInfoWithDefaults instantiates a new Metrics200ResponseStatusInfo object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetFamily

`func (o *Metrics200ResponseStatusInfo) GetFamily() string`

GetFamily returns the Family field if non-nil, zero value otherwise.

### GetFamilyOk

`func (o *Metrics200ResponseStatusInfo) GetFamilyOk() (*string, bool)`

GetFamilyOk returns a tuple with the Family field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetFamily

`func (o *Metrics200ResponseStatusInfo) SetFamily(v string)`

SetFamily sets Family field to given value.

### HasFamily

`func (o *Metrics200ResponseStatusInfo) HasFamily() bool`

HasFamily returns a boolean if a field has been set.

### GetReasonPhrase

`func (o *Metrics200ResponseStatusInfo) GetReasonPhrase() string`

GetReasonPhrase returns the ReasonPhrase field if non-nil, zero value otherwise.

### GetReasonPhraseOk

`func (o *Metrics200ResponseStatusInfo) GetReasonPhraseOk() (*string, bool)`

GetReasonPhraseOk returns a tuple with the ReasonPhrase field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetReasonPhrase

`func (o *Metrics200ResponseStatusInfo) SetReasonPhrase(v string)`

SetReasonPhrase sets ReasonPhrase field to given value.

### HasReasonPhrase

`func (o *Metrics200ResponseStatusInfo) HasReasonPhrase() bool`

HasReasonPhrase returns a boolean if a field has been set.

### GetStatusCode

`func (o *Metrics200ResponseStatusInfo) GetStatusCode() int32`

GetStatusCode returns the StatusCode field if non-nil, zero value otherwise.

### GetStatusCodeOk

`func (o *Metrics200ResponseStatusInfo) GetStatusCodeOk() (*int32, bool)`

GetStatusCodeOk returns a tuple with the StatusCode field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetStatusCode

`func (o *Metrics200ResponseStatusInfo) SetStatusCode(v int32)`

SetStatusCode sets StatusCode field to given value.

### HasStatusCode

`func (o *Metrics200ResponseStatusInfo) HasStatusCode() bool`

HasStatusCode returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


