# CloudStorageGroupInfo

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**StorageGroupUuid** | **string** | The unique identifier of the cloud storage group | 
**StorageGroupId** | Pointer to **string** | The name of the current local storage group based on the UUID of the cloud storage group                                 or                                 The name of the storage group at the time the most recent cloud snapshot was taken | [optional] 
**LastCreationDateTimestamp** | Pointer to **int64** | The timestamp the most recent cloud snapshot was taken | [optional] 

## Methods

### NewCloudStorageGroupInfo

`func NewCloudStorageGroupInfo(storageGroupUuid string, ) *CloudStorageGroupInfo`

NewCloudStorageGroupInfo instantiates a new CloudStorageGroupInfo object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewCloudStorageGroupInfoWithDefaults

`func NewCloudStorageGroupInfoWithDefaults() *CloudStorageGroupInfo`

NewCloudStorageGroupInfoWithDefaults instantiates a new CloudStorageGroupInfo object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetStorageGroupUuid

`func (o *CloudStorageGroupInfo) GetStorageGroupUuid() string`

GetStorageGroupUuid returns the StorageGroupUuid field if non-nil, zero value otherwise.

### GetStorageGroupUuidOk

`func (o *CloudStorageGroupInfo) GetStorageGroupUuidOk() (*string, bool)`

GetStorageGroupUuidOk returns a tuple with the StorageGroupUuid field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetStorageGroupUuid

`func (o *CloudStorageGroupInfo) SetStorageGroupUuid(v string)`

SetStorageGroupUuid sets StorageGroupUuid field to given value.


### GetStorageGroupId

`func (o *CloudStorageGroupInfo) GetStorageGroupId() string`

GetStorageGroupId returns the StorageGroupId field if non-nil, zero value otherwise.

### GetStorageGroupIdOk

`func (o *CloudStorageGroupInfo) GetStorageGroupIdOk() (*string, bool)`

GetStorageGroupIdOk returns a tuple with the StorageGroupId field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetStorageGroupId

`func (o *CloudStorageGroupInfo) SetStorageGroupId(v string)`

SetStorageGroupId sets StorageGroupId field to given value.

### HasStorageGroupId

`func (o *CloudStorageGroupInfo) HasStorageGroupId() bool`

HasStorageGroupId returns a boolean if a field has been set.

### GetLastCreationDateTimestamp

`func (o *CloudStorageGroupInfo) GetLastCreationDateTimestamp() int64`

GetLastCreationDateTimestamp returns the LastCreationDateTimestamp field if non-nil, zero value otherwise.

### GetLastCreationDateTimestampOk

`func (o *CloudStorageGroupInfo) GetLastCreationDateTimestampOk() (*int64, bool)`

GetLastCreationDateTimestampOk returns a tuple with the LastCreationDateTimestamp field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetLastCreationDateTimestamp

`func (o *CloudStorageGroupInfo) SetLastCreationDateTimestamp(v int64)`

SetLastCreationDateTimestamp sets LastCreationDateTimestamp field to given value.

### HasLastCreationDateTimestamp

`func (o *CloudStorageGroupInfo) HasLastCreationDateTimestamp() bool`

HasLastCreationDateTimestamp returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


