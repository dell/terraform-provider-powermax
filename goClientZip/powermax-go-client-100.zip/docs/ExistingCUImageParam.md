# ExistingCUImageParam

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**CuImageSSID** | **string** | The CU image SSID. | 
**StartBaseAddress** | **string** | The starting base address to use for the volume mapping. | 

## Methods

### NewExistingCUImageParam

`func NewExistingCUImageParam(cuImageSSID string, startBaseAddress string, ) *ExistingCUImageParam`

NewExistingCUImageParam instantiates a new ExistingCUImageParam object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewExistingCUImageParamWithDefaults

`func NewExistingCUImageParamWithDefaults() *ExistingCUImageParam`

NewExistingCUImageParamWithDefaults instantiates a new ExistingCUImageParam object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetCuImageSSID

`func (o *ExistingCUImageParam) GetCuImageSSID() string`

GetCuImageSSID returns the CuImageSSID field if non-nil, zero value otherwise.

### GetCuImageSSIDOk

`func (o *ExistingCUImageParam) GetCuImageSSIDOk() (*string, bool)`

GetCuImageSSIDOk returns a tuple with the CuImageSSID field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetCuImageSSID

`func (o *ExistingCUImageParam) SetCuImageSSID(v string)`

SetCuImageSSID sets CuImageSSID field to given value.


### GetStartBaseAddress

`func (o *ExistingCUImageParam) GetStartBaseAddress() string`

GetStartBaseAddress returns the StartBaseAddress field if non-nil, zero value otherwise.

### GetStartBaseAddressOk

`func (o *ExistingCUImageParam) GetStartBaseAddressOk() (*string, bool)`

GetStartBaseAddressOk returns a tuple with the StartBaseAddress field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetStartBaseAddress

`func (o *ExistingCUImageParam) SetStartBaseAddress(v string)`

SetStartBaseAddress sets StartBaseAddress field to given value.



[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


