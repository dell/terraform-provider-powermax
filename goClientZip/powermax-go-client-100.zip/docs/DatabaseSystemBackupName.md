# DatabaseSystemBackupName

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**SystemBackupName** | **string** | system_backup_name | 

## Methods

### NewDatabaseSystemBackupName

`func NewDatabaseSystemBackupName(systemBackupName string, ) *DatabaseSystemBackupName`

NewDatabaseSystemBackupName instantiates a new DatabaseSystemBackupName object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewDatabaseSystemBackupNameWithDefaults

`func NewDatabaseSystemBackupNameWithDefaults() *DatabaseSystemBackupName`

NewDatabaseSystemBackupNameWithDefaults instantiates a new DatabaseSystemBackupName object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetSystemBackupName

`func (o *DatabaseSystemBackupName) GetSystemBackupName() string`

GetSystemBackupName returns the SystemBackupName field if non-nil, zero value otherwise.

### GetSystemBackupNameOk

`func (o *DatabaseSystemBackupName) GetSystemBackupNameOk() (*string, bool)`

GetSystemBackupNameOk returns a tuple with the SystemBackupName field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetSystemBackupName

`func (o *DatabaseSystemBackupName) SetSystemBackupName(v string)`

SetSystemBackupName sets SystemBackupName field to given value.



[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


