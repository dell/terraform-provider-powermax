# LocalSnapshotPolicyDetails

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Secure** | Pointer to **bool** | The snapshot policy will create secure snapshots | [optional] 
**SnapshotCount** | Pointer to **int32** | The number of the snapshots that will be maintained by the snapshot policy | [optional] 

## Methods

### NewLocalSnapshotPolicyDetails

`func NewLocalSnapshotPolicyDetails() *LocalSnapshotPolicyDetails`

NewLocalSnapshotPolicyDetails instantiates a new LocalSnapshotPolicyDetails object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewLocalSnapshotPolicyDetailsWithDefaults

`func NewLocalSnapshotPolicyDetailsWithDefaults() *LocalSnapshotPolicyDetails`

NewLocalSnapshotPolicyDetailsWithDefaults instantiates a new LocalSnapshotPolicyDetails object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetSecure

`func (o *LocalSnapshotPolicyDetails) GetSecure() bool`

GetSecure returns the Secure field if non-nil, zero value otherwise.

### GetSecureOk

`func (o *LocalSnapshotPolicyDetails) GetSecureOk() (*bool, bool)`

GetSecureOk returns a tuple with the Secure field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetSecure

`func (o *LocalSnapshotPolicyDetails) SetSecure(v bool)`

SetSecure sets Secure field to given value.

### HasSecure

`func (o *LocalSnapshotPolicyDetails) HasSecure() bool`

HasSecure returns a boolean if a field has been set.

### GetSnapshotCount

`func (o *LocalSnapshotPolicyDetails) GetSnapshotCount() int32`

GetSnapshotCount returns the SnapshotCount field if non-nil, zero value otherwise.

### GetSnapshotCountOk

`func (o *LocalSnapshotPolicyDetails) GetSnapshotCountOk() (*int32, bool)`

GetSnapshotCountOk returns a tuple with the SnapshotCount field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetSnapshotCount

`func (o *LocalSnapshotPolicyDetails) SetSnapshotCount(v int32)`

SetSnapshotCount sets SnapshotCount field to given value.

### HasSnapshotCount

`func (o *LocalSnapshotPolicyDetails) HasSnapshotCount() bool`

HasSnapshotCount returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


