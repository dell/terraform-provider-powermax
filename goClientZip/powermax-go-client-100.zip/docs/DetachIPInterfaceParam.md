# DetachIPInterfaceParam

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**IpInterfaceParam** | Pointer to [**[]IpInterfaceParam**](IpInterfaceParam.md) | ipInterfaceParam | [optional] 

## Methods

### NewDetachIPInterfaceParam

`func NewDetachIPInterfaceParam() *DetachIPInterfaceParam`

NewDetachIPInterfaceParam instantiates a new DetachIPInterfaceParam object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewDetachIPInterfaceParamWithDefaults

`func NewDetachIPInterfaceParamWithDefaults() *DetachIPInterfaceParam`

NewDetachIPInterfaceParamWithDefaults instantiates a new DetachIPInterfaceParam object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetIpInterfaceParam

`func (o *DetachIPInterfaceParam) GetIpInterfaceParam() []IpInterfaceParam`

GetIpInterfaceParam returns the IpInterfaceParam field if non-nil, zero value otherwise.

### GetIpInterfaceParamOk

`func (o *DetachIPInterfaceParam) GetIpInterfaceParamOk() (*[]IpInterfaceParam, bool)`

GetIpInterfaceParamOk returns a tuple with the IpInterfaceParam field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetIpInterfaceParam

`func (o *DetachIPInterfaceParam) SetIpInterfaceParam(v []IpInterfaceParam)`

SetIpInterfaceParam sets IpInterfaceParam field to given value.

### HasIpInterfaceParam

`func (o *DetachIPInterfaceParam) HasIpInterfaceParam() bool`

HasIpInterfaceParam returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


