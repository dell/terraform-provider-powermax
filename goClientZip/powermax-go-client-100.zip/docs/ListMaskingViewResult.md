# ListMaskingViewResult

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**MaskingViewId** | Pointer to **[]string** | List of masking views | [optional] 

## Methods

### NewListMaskingViewResult

`func NewListMaskingViewResult() *ListMaskingViewResult`

NewListMaskingViewResult instantiates a new ListMaskingViewResult object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewListMaskingViewResultWithDefaults

`func NewListMaskingViewResultWithDefaults() *ListMaskingViewResult`

NewListMaskingViewResultWithDefaults instantiates a new ListMaskingViewResult object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetMaskingViewId

`func (o *ListMaskingViewResult) GetMaskingViewId() []string`

GetMaskingViewId returns the MaskingViewId field if non-nil, zero value otherwise.

### GetMaskingViewIdOk

`func (o *ListMaskingViewResult) GetMaskingViewIdOk() (*[]string, bool)`

GetMaskingViewIdOk returns a tuple with the MaskingViewId field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetMaskingViewId

`func (o *ListMaskingViewResult) SetMaskingViewId(v []string)`

SetMaskingViewId sets MaskingViewId field to given value.

### HasMaskingViewId

`func (o *ListMaskingViewResult) HasMaskingViewId() bool`

HasMaskingViewId returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


