# DsePoolParam

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**StartDate** | **int64** | Starting date in millisecond. | 
**EndDate** | **int64** | Ending date in millisecond. | 
**SymmetrixId** | **string** | &lt;p&gt;The Symmetrix array ID.&lt;/p&gt; | 
**PoolId** | **string** | poolId | 
**DataFormat** | Pointer to **string** | &lt;p&gt;Data Format (Average or Maximum).&lt;/p&gt;   Enumeration values: * **Average** * **Maximum**  | [optional] 
**Metrics** | **[]string** | metrics   Enumeration values: * **BEReqs** - The number of read/write requests each second performed by the disk directors to cache. * **BEReadReqs** - The number of read requests each second performed by the disk directors to cache. * **BEWriteReqs** - The number of write requests each second performed by the disk directors to cache. * **BEMBTransferred** - Calculated value: (MBs read per sec + MBs written per sec) * **BEMBRead** - The number of MBs read by the disk directors from the disk each second. * **BEMBWritten** - The number of MBs written to the disk from the disk director each second. * **BEReadRequestTime** - The average time it takes to make a read request by the disk directors to the cache. * **BEDiskReadResponseTime** - The average time it takes cache to respond to a read request by the disk directors. * **BEReadTaskTime** - The time from the point when the HA puts the read request on the queue and the DA picks it up; this can be considered queue time. * **PercentUsedCapacity** - The percent of the pools total capacity that is used. * **TotalPoolCapacity** - The  total pool capacity in GBs. * **EnabledPoolCapacity** - The enabled pool capacity in GBs. * **UsedPoolCapacity** - The  used pool capacity in GBs. * **AllocatedPoolCapacity** - The allocated pool capacity in GBs. * **ALLOCATED_POOL_CAPACITY_GB** - The allocated pool capacity in GBs. * **AVG_BE_DISK_TIME** - The average time it takes cache to respond to a read request by the disk directors. * **AVG_BE_REQ_TIME** - The average time it takes to make a read request by the disk directors to the cache. * **AVG_BE_TASK_TIME** - The time from the point when the HA puts the read request on the queue and the DA picks it up; this can be considered queue time. * **BE_MB_READ_RATE** - The number of MBs read by the disk directors from the disk each second. * **BE_MB_TRANSFERED_PER_SEC** - Calculated value: (MBs read per sec + MBs written per sec) * **BE_MB_WRITE_RATE** - The number of MBs written to the disk from the disk director each second. * **BE_READS** - The number of read requests each second performed by the disk directors to cache. * **BE_WRITES** - The number of write requests each second performed by the disk directors to cache. * **ENABLED_POOL_CAPACITY_GB** - The enabled pool capacity in GBs. * **PERCENT_USED_CAPACITY** - The percent of the pools total capacity that is used. * **TOTAL_BE_REQ_PER_SEC** - The number of read/write requests each second performed by the disk directors to cache. * **TOTAL_POOL_CAPACITY_GB** - The  total pool capacity in GBs. * **USED_POOL_CAPACITY_GB** - The  used pool capacity in GBs.  | 

## Methods

### NewDsePoolParam

`func NewDsePoolParam(startDate int64, endDate int64, symmetrixId string, poolId string, metrics []string, ) *DsePoolParam`

NewDsePoolParam instantiates a new DsePoolParam object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewDsePoolParamWithDefaults

`func NewDsePoolParamWithDefaults() *DsePoolParam`

NewDsePoolParamWithDefaults instantiates a new DsePoolParam object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetStartDate

`func (o *DsePoolParam) GetStartDate() int64`

GetStartDate returns the StartDate field if non-nil, zero value otherwise.

### GetStartDateOk

`func (o *DsePoolParam) GetStartDateOk() (*int64, bool)`

GetStartDateOk returns a tuple with the StartDate field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetStartDate

`func (o *DsePoolParam) SetStartDate(v int64)`

SetStartDate sets StartDate field to given value.


### GetEndDate

`func (o *DsePoolParam) GetEndDate() int64`

GetEndDate returns the EndDate field if non-nil, zero value otherwise.

### GetEndDateOk

`func (o *DsePoolParam) GetEndDateOk() (*int64, bool)`

GetEndDateOk returns a tuple with the EndDate field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetEndDate

`func (o *DsePoolParam) SetEndDate(v int64)`

SetEndDate sets EndDate field to given value.


### GetSymmetrixId

`func (o *DsePoolParam) GetSymmetrixId() string`

GetSymmetrixId returns the SymmetrixId field if non-nil, zero value otherwise.

### GetSymmetrixIdOk

`func (o *DsePoolParam) GetSymmetrixIdOk() (*string, bool)`

GetSymmetrixIdOk returns a tuple with the SymmetrixId field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetSymmetrixId

`func (o *DsePoolParam) SetSymmetrixId(v string)`

SetSymmetrixId sets SymmetrixId field to given value.


### GetPoolId

`func (o *DsePoolParam) GetPoolId() string`

GetPoolId returns the PoolId field if non-nil, zero value otherwise.

### GetPoolIdOk

`func (o *DsePoolParam) GetPoolIdOk() (*string, bool)`

GetPoolIdOk returns a tuple with the PoolId field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetPoolId

`func (o *DsePoolParam) SetPoolId(v string)`

SetPoolId sets PoolId field to given value.


### GetDataFormat

`func (o *DsePoolParam) GetDataFormat() string`

GetDataFormat returns the DataFormat field if non-nil, zero value otherwise.

### GetDataFormatOk

`func (o *DsePoolParam) GetDataFormatOk() (*string, bool)`

GetDataFormatOk returns a tuple with the DataFormat field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetDataFormat

`func (o *DsePoolParam) SetDataFormat(v string)`

SetDataFormat sets DataFormat field to given value.

### HasDataFormat

`func (o *DsePoolParam) HasDataFormat() bool`

HasDataFormat returns a boolean if a field has been set.

### GetMetrics

`func (o *DsePoolParam) GetMetrics() []string`

GetMetrics returns the Metrics field if non-nil, zero value otherwise.

### GetMetricsOk

`func (o *DsePoolParam) GetMetricsOk() (*[]string, bool)`

GetMetricsOk returns a tuple with the Metrics field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetMetrics

`func (o *DsePoolParam) SetMetrics(v []string)`

SetMetrics sets Metrics field to given value.



[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


