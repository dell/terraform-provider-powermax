# DiskInformation

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**SpindleId** | **string** | spindle_id | 
**Type** | **string** | type | 
**Vendor** | **string** | vendor | 
**Capacity** | **float64** | capacity | 

## Methods

### NewDiskInformation

`func NewDiskInformation(spindleId string, type_ string, vendor string, capacity float64, ) *DiskInformation`

NewDiskInformation instantiates a new DiskInformation object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewDiskInformationWithDefaults

`func NewDiskInformationWithDefaults() *DiskInformation`

NewDiskInformationWithDefaults instantiates a new DiskInformation object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetSpindleId

`func (o *DiskInformation) GetSpindleId() string`

GetSpindleId returns the SpindleId field if non-nil, zero value otherwise.

### GetSpindleIdOk

`func (o *DiskInformation) GetSpindleIdOk() (*string, bool)`

GetSpindleIdOk returns a tuple with the SpindleId field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetSpindleId

`func (o *DiskInformation) SetSpindleId(v string)`

SetSpindleId sets SpindleId field to given value.


### GetType

`func (o *DiskInformation) GetType() string`

GetType returns the Type field if non-nil, zero value otherwise.

### GetTypeOk

`func (o *DiskInformation) GetTypeOk() (*string, bool)`

GetTypeOk returns a tuple with the Type field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetType

`func (o *DiskInformation) SetType(v string)`

SetType sets Type field to given value.


### GetVendor

`func (o *DiskInformation) GetVendor() string`

GetVendor returns the Vendor field if non-nil, zero value otherwise.

### GetVendorOk

`func (o *DiskInformation) GetVendorOk() (*string, bool)`

GetVendorOk returns a tuple with the Vendor field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetVendor

`func (o *DiskInformation) SetVendor(v string)`

SetVendor sets Vendor field to given value.


### GetCapacity

`func (o *DiskInformation) GetCapacity() float64`

GetCapacity returns the Capacity field if non-nil, zero value otherwise.

### GetCapacityOk

`func (o *DiskInformation) GetCapacityOk() (*float64, bool)`

GetCapacityOk returns a tuple with the Capacity field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetCapacity

`func (o *DiskInformation) SetCapacity(v float64)`

SetCapacity sets Capacity field to given value.



[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


