# DataReductionBreakdown

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**EnabledAndReducingTb** | Pointer to **float64** | Amount of data which is both enabled for reduction and is capable of being reduced | [optional] 
**EnabledAndUnreducibleTb** | Pointer to **float64** | Amount of data which is enabled for reduction but is not capable of being reduced | [optional] 
**EnabledAndUnevaluatedTb** | Pointer to **float64** | Amount of data which is enabled for reduction but is currently not evaluated | [optional] 
**DisabledAndUnreducedTb** | Pointer to **float64** | Amount fo data which is not enabled for reduction | [optional] 

## Methods

### NewDataReductionBreakdown

`func NewDataReductionBreakdown() *DataReductionBreakdown`

NewDataReductionBreakdown instantiates a new DataReductionBreakdown object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewDataReductionBreakdownWithDefaults

`func NewDataReductionBreakdownWithDefaults() *DataReductionBreakdown`

NewDataReductionBreakdownWithDefaults instantiates a new DataReductionBreakdown object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetEnabledAndReducingTb

`func (o *DataReductionBreakdown) GetEnabledAndReducingTb() float64`

GetEnabledAndReducingTb returns the EnabledAndReducingTb field if non-nil, zero value otherwise.

### GetEnabledAndReducingTbOk

`func (o *DataReductionBreakdown) GetEnabledAndReducingTbOk() (*float64, bool)`

GetEnabledAndReducingTbOk returns a tuple with the EnabledAndReducingTb field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetEnabledAndReducingTb

`func (o *DataReductionBreakdown) SetEnabledAndReducingTb(v float64)`

SetEnabledAndReducingTb sets EnabledAndReducingTb field to given value.

### HasEnabledAndReducingTb

`func (o *DataReductionBreakdown) HasEnabledAndReducingTb() bool`

HasEnabledAndReducingTb returns a boolean if a field has been set.

### GetEnabledAndUnreducibleTb

`func (o *DataReductionBreakdown) GetEnabledAndUnreducibleTb() float64`

GetEnabledAndUnreducibleTb returns the EnabledAndUnreducibleTb field if non-nil, zero value otherwise.

### GetEnabledAndUnreducibleTbOk

`func (o *DataReductionBreakdown) GetEnabledAndUnreducibleTbOk() (*float64, bool)`

GetEnabledAndUnreducibleTbOk returns a tuple with the EnabledAndUnreducibleTb field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetEnabledAndUnreducibleTb

`func (o *DataReductionBreakdown) SetEnabledAndUnreducibleTb(v float64)`

SetEnabledAndUnreducibleTb sets EnabledAndUnreducibleTb field to given value.

### HasEnabledAndUnreducibleTb

`func (o *DataReductionBreakdown) HasEnabledAndUnreducibleTb() bool`

HasEnabledAndUnreducibleTb returns a boolean if a field has been set.

### GetEnabledAndUnevaluatedTb

`func (o *DataReductionBreakdown) GetEnabledAndUnevaluatedTb() float64`

GetEnabledAndUnevaluatedTb returns the EnabledAndUnevaluatedTb field if non-nil, zero value otherwise.

### GetEnabledAndUnevaluatedTbOk

`func (o *DataReductionBreakdown) GetEnabledAndUnevaluatedTbOk() (*float64, bool)`

GetEnabledAndUnevaluatedTbOk returns a tuple with the EnabledAndUnevaluatedTb field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetEnabledAndUnevaluatedTb

`func (o *DataReductionBreakdown) SetEnabledAndUnevaluatedTb(v float64)`

SetEnabledAndUnevaluatedTb sets EnabledAndUnevaluatedTb field to given value.

### HasEnabledAndUnevaluatedTb

`func (o *DataReductionBreakdown) HasEnabledAndUnevaluatedTb() bool`

HasEnabledAndUnevaluatedTb returns a boolean if a field has been set.

### GetDisabledAndUnreducedTb

`func (o *DataReductionBreakdown) GetDisabledAndUnreducedTb() float64`

GetDisabledAndUnreducedTb returns the DisabledAndUnreducedTb field if non-nil, zero value otherwise.

### GetDisabledAndUnreducedTbOk

`func (o *DataReductionBreakdown) GetDisabledAndUnreducedTbOk() (*float64, bool)`

GetDisabledAndUnreducedTbOk returns a tuple with the DisabledAndUnreducedTb field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetDisabledAndUnreducedTb

`func (o *DataReductionBreakdown) SetDisabledAndUnreducedTb(v float64)`

SetDisabledAndUnreducedTb sets DisabledAndUnreducedTb field to given value.

### HasDisabledAndUnreducedTb

`func (o *DataReductionBreakdown) HasDisabledAndUnreducedTb() bool`

HasDisabledAndUnreducedTb returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


