# DiskTechPoolKeyResult

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**DiskTechPoolInfo** | Pointer to [**[]DiskTechPoolInfo**](DiskTechPoolInfo.md) | diskTechPoolInfo | [optional] 

## Methods

### NewDiskTechPoolKeyResult

`func NewDiskTechPoolKeyResult() *DiskTechPoolKeyResult`

NewDiskTechPoolKeyResult instantiates a new DiskTechPoolKeyResult object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewDiskTechPoolKeyResultWithDefaults

`func NewDiskTechPoolKeyResultWithDefaults() *DiskTechPoolKeyResult`

NewDiskTechPoolKeyResultWithDefaults instantiates a new DiskTechPoolKeyResult object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetDiskTechPoolInfo

`func (o *DiskTechPoolKeyResult) GetDiskTechPoolInfo() []DiskTechPoolInfo`

GetDiskTechPoolInfo returns the DiskTechPoolInfo field if non-nil, zero value otherwise.

### GetDiskTechPoolInfoOk

`func (o *DiskTechPoolKeyResult) GetDiskTechPoolInfoOk() (*[]DiskTechPoolInfo, bool)`

GetDiskTechPoolInfoOk returns a tuple with the DiskTechPoolInfo field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetDiskTechPoolInfo

`func (o *DiskTechPoolKeyResult) SetDiskTechPoolInfo(v []DiskTechPoolInfo)`

SetDiskTechPoolInfo sets DiskTechPoolInfo field to given value.

### HasDiskTechPoolInfo

`func (o *DiskTechPoolKeyResult) HasDiskTechPoolInfo() bool`

HasDiskTechPoolInfo returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


