# EditHostGroupParam

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ExecutionOption** | Pointer to **string** |  | [optional] [default to "SYNCHRONOUS"]
**EditHostGroupActionParam** | [**EditHostGroupActionParam**](EditHostGroupActionParam.md) |  | 

## Methods

### NewEditHostGroupParam

`func NewEditHostGroupParam(editHostGroupActionParam EditHostGroupActionParam, ) *EditHostGroupParam`

NewEditHostGroupParam instantiates a new EditHostGroupParam object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewEditHostGroupParamWithDefaults

`func NewEditHostGroupParamWithDefaults() *EditHostGroupParam`

NewEditHostGroupParamWithDefaults instantiates a new EditHostGroupParam object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetExecutionOption

`func (o *EditHostGroupParam) GetExecutionOption() string`

GetExecutionOption returns the ExecutionOption field if non-nil, zero value otherwise.

### GetExecutionOptionOk

`func (o *EditHostGroupParam) GetExecutionOptionOk() (*string, bool)`

GetExecutionOptionOk returns a tuple with the ExecutionOption field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetExecutionOption

`func (o *EditHostGroupParam) SetExecutionOption(v string)`

SetExecutionOption sets ExecutionOption field to given value.

### HasExecutionOption

`func (o *EditHostGroupParam) HasExecutionOption() bool`

HasExecutionOption returns a boolean if a field has been set.

### GetEditHostGroupActionParam

`func (o *EditHostGroupParam) GetEditHostGroupActionParam() EditHostGroupActionParam`

GetEditHostGroupActionParam returns the EditHostGroupActionParam field if non-nil, zero value otherwise.

### GetEditHostGroupActionParamOk

`func (o *EditHostGroupParam) GetEditHostGroupActionParamOk() (*EditHostGroupActionParam, bool)`

GetEditHostGroupActionParamOk returns a tuple with the EditHostGroupActionParam field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetEditHostGroupActionParam

`func (o *EditHostGroupParam) SetEditHostGroupActionParam(v EditHostGroupActionParam)`

SetEditHostGroupActionParam sets EditHostGroupActionParam field to given value.



[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


