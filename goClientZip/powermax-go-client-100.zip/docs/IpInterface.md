# IpInterface

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**IpInterfaceId** | **string** | ip_interface_id | 
**IpAddress** | Pointer to **string** | ip_address | [optional] 
**DefaultGateway** | Pointer to **string** | default_gateway | [optional] 
**NetworkId** | Pointer to **int64** | network_id | [optional] 
**IpPrefixLength** | Pointer to **int32** | ip_prefix_length | [optional] 
**VlanId** | Pointer to **int64** | vlan_id | [optional] 
**Mtu** | Pointer to **int64** | mtu | [optional] 
**EndpointDirector** | Pointer to **string** | endpoint_director | [optional] 
**EndpointPort** | Pointer to **int32** | endpoint_port | [optional] 
**CdcIpAddress** | Pointer to **string** | cdc_ip_address | [optional] 
**CdcPort** | Pointer to **int32** | cdc_port | [optional] 
**CdcConnectionStatus** | Pointer to **string** | cdc_connection_status | [optional] 
**CdcState** | Pointer to **string** | cdc_state | [optional] 
**MDNSState** | Pointer to **string** | mDNS_state | [optional] 

## Methods

### NewIpInterface

`func NewIpInterface(ipInterfaceId string, ) *IpInterface`

NewIpInterface instantiates a new IpInterface object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewIpInterfaceWithDefaults

`func NewIpInterfaceWithDefaults() *IpInterface`

NewIpInterfaceWithDefaults instantiates a new IpInterface object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetIpInterfaceId

`func (o *IpInterface) GetIpInterfaceId() string`

GetIpInterfaceId returns the IpInterfaceId field if non-nil, zero value otherwise.

### GetIpInterfaceIdOk

`func (o *IpInterface) GetIpInterfaceIdOk() (*string, bool)`

GetIpInterfaceIdOk returns a tuple with the IpInterfaceId field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetIpInterfaceId

`func (o *IpInterface) SetIpInterfaceId(v string)`

SetIpInterfaceId sets IpInterfaceId field to given value.


### GetIpAddress

`func (o *IpInterface) GetIpAddress() string`

GetIpAddress returns the IpAddress field if non-nil, zero value otherwise.

### GetIpAddressOk

`func (o *IpInterface) GetIpAddressOk() (*string, bool)`

GetIpAddressOk returns a tuple with the IpAddress field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetIpAddress

`func (o *IpInterface) SetIpAddress(v string)`

SetIpAddress sets IpAddress field to given value.

### HasIpAddress

`func (o *IpInterface) HasIpAddress() bool`

HasIpAddress returns a boolean if a field has been set.

### GetDefaultGateway

`func (o *IpInterface) GetDefaultGateway() string`

GetDefaultGateway returns the DefaultGateway field if non-nil, zero value otherwise.

### GetDefaultGatewayOk

`func (o *IpInterface) GetDefaultGatewayOk() (*string, bool)`

GetDefaultGatewayOk returns a tuple with the DefaultGateway field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetDefaultGateway

`func (o *IpInterface) SetDefaultGateway(v string)`

SetDefaultGateway sets DefaultGateway field to given value.

### HasDefaultGateway

`func (o *IpInterface) HasDefaultGateway() bool`

HasDefaultGateway returns a boolean if a field has been set.

### GetNetworkId

`func (o *IpInterface) GetNetworkId() int64`

GetNetworkId returns the NetworkId field if non-nil, zero value otherwise.

### GetNetworkIdOk

`func (o *IpInterface) GetNetworkIdOk() (*int64, bool)`

GetNetworkIdOk returns a tuple with the NetworkId field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetNetworkId

`func (o *IpInterface) SetNetworkId(v int64)`

SetNetworkId sets NetworkId field to given value.

### HasNetworkId

`func (o *IpInterface) HasNetworkId() bool`

HasNetworkId returns a boolean if a field has been set.

### GetIpPrefixLength

`func (o *IpInterface) GetIpPrefixLength() int32`

GetIpPrefixLength returns the IpPrefixLength field if non-nil, zero value otherwise.

### GetIpPrefixLengthOk

`func (o *IpInterface) GetIpPrefixLengthOk() (*int32, bool)`

GetIpPrefixLengthOk returns a tuple with the IpPrefixLength field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetIpPrefixLength

`func (o *IpInterface) SetIpPrefixLength(v int32)`

SetIpPrefixLength sets IpPrefixLength field to given value.

### HasIpPrefixLength

`func (o *IpInterface) HasIpPrefixLength() bool`

HasIpPrefixLength returns a boolean if a field has been set.

### GetVlanId

`func (o *IpInterface) GetVlanId() int64`

GetVlanId returns the VlanId field if non-nil, zero value otherwise.

### GetVlanIdOk

`func (o *IpInterface) GetVlanIdOk() (*int64, bool)`

GetVlanIdOk returns a tuple with the VlanId field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetVlanId

`func (o *IpInterface) SetVlanId(v int64)`

SetVlanId sets VlanId field to given value.

### HasVlanId

`func (o *IpInterface) HasVlanId() bool`

HasVlanId returns a boolean if a field has been set.

### GetMtu

`func (o *IpInterface) GetMtu() int64`

GetMtu returns the Mtu field if non-nil, zero value otherwise.

### GetMtuOk

`func (o *IpInterface) GetMtuOk() (*int64, bool)`

GetMtuOk returns a tuple with the Mtu field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetMtu

`func (o *IpInterface) SetMtu(v int64)`

SetMtu sets Mtu field to given value.

### HasMtu

`func (o *IpInterface) HasMtu() bool`

HasMtu returns a boolean if a field has been set.

### GetEndpointDirector

`func (o *IpInterface) GetEndpointDirector() string`

GetEndpointDirector returns the EndpointDirector field if non-nil, zero value otherwise.

### GetEndpointDirectorOk

`func (o *IpInterface) GetEndpointDirectorOk() (*string, bool)`

GetEndpointDirectorOk returns a tuple with the EndpointDirector field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetEndpointDirector

`func (o *IpInterface) SetEndpointDirector(v string)`

SetEndpointDirector sets EndpointDirector field to given value.

### HasEndpointDirector

`func (o *IpInterface) HasEndpointDirector() bool`

HasEndpointDirector returns a boolean if a field has been set.

### GetEndpointPort

`func (o *IpInterface) GetEndpointPort() int32`

GetEndpointPort returns the EndpointPort field if non-nil, zero value otherwise.

### GetEndpointPortOk

`func (o *IpInterface) GetEndpointPortOk() (*int32, bool)`

GetEndpointPortOk returns a tuple with the EndpointPort field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetEndpointPort

`func (o *IpInterface) SetEndpointPort(v int32)`

SetEndpointPort sets EndpointPort field to given value.

### HasEndpointPort

`func (o *IpInterface) HasEndpointPort() bool`

HasEndpointPort returns a boolean if a field has been set.

### GetCdcIpAddress

`func (o *IpInterface) GetCdcIpAddress() string`

GetCdcIpAddress returns the CdcIpAddress field if non-nil, zero value otherwise.

### GetCdcIpAddressOk

`func (o *IpInterface) GetCdcIpAddressOk() (*string, bool)`

GetCdcIpAddressOk returns a tuple with the CdcIpAddress field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetCdcIpAddress

`func (o *IpInterface) SetCdcIpAddress(v string)`

SetCdcIpAddress sets CdcIpAddress field to given value.

### HasCdcIpAddress

`func (o *IpInterface) HasCdcIpAddress() bool`

HasCdcIpAddress returns a boolean if a field has been set.

### GetCdcPort

`func (o *IpInterface) GetCdcPort() int32`

GetCdcPort returns the CdcPort field if non-nil, zero value otherwise.

### GetCdcPortOk

`func (o *IpInterface) GetCdcPortOk() (*int32, bool)`

GetCdcPortOk returns a tuple with the CdcPort field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetCdcPort

`func (o *IpInterface) SetCdcPort(v int32)`

SetCdcPort sets CdcPort field to given value.

### HasCdcPort

`func (o *IpInterface) HasCdcPort() bool`

HasCdcPort returns a boolean if a field has been set.

### GetCdcConnectionStatus

`func (o *IpInterface) GetCdcConnectionStatus() string`

GetCdcConnectionStatus returns the CdcConnectionStatus field if non-nil, zero value otherwise.

### GetCdcConnectionStatusOk

`func (o *IpInterface) GetCdcConnectionStatusOk() (*string, bool)`

GetCdcConnectionStatusOk returns a tuple with the CdcConnectionStatus field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetCdcConnectionStatus

`func (o *IpInterface) SetCdcConnectionStatus(v string)`

SetCdcConnectionStatus sets CdcConnectionStatus field to given value.

### HasCdcConnectionStatus

`func (o *IpInterface) HasCdcConnectionStatus() bool`

HasCdcConnectionStatus returns a boolean if a field has been set.

### GetCdcState

`func (o *IpInterface) GetCdcState() string`

GetCdcState returns the CdcState field if non-nil, zero value otherwise.

### GetCdcStateOk

`func (o *IpInterface) GetCdcStateOk() (*string, bool)`

GetCdcStateOk returns a tuple with the CdcState field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetCdcState

`func (o *IpInterface) SetCdcState(v string)`

SetCdcState sets CdcState field to given value.

### HasCdcState

`func (o *IpInterface) HasCdcState() bool`

HasCdcState returns a boolean if a field has been set.

### GetMDNSState

`func (o *IpInterface) GetMDNSState() string`

GetMDNSState returns the MDNSState field if non-nil, zero value otherwise.

### GetMDNSStateOk

`func (o *IpInterface) GetMDNSStateOk() (*string, bool)`

GetMDNSStateOk returns a tuple with the MDNSState field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetMDNSState

`func (o *IpInterface) SetMDNSState(v string)`

SetMDNSState sets MDNSState field to given value.

### HasMDNSState

`func (o *IpInterface) HasMDNSState() bool`

HasMDNSState returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


