# EditCloudSnapshotParam

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ExecutionOption** | Pointer to **string** |  | [optional] [default to "SYNCHRONOUS"]
**EditCloudSnapshotActionParam** | [**EditCloudSnapshotActionParam**](EditCloudSnapshotActionParam.md) |  | 

## Methods

### NewEditCloudSnapshotParam

`func NewEditCloudSnapshotParam(editCloudSnapshotActionParam EditCloudSnapshotActionParam, ) *EditCloudSnapshotParam`

NewEditCloudSnapshotParam instantiates a new EditCloudSnapshotParam object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewEditCloudSnapshotParamWithDefaults

`func NewEditCloudSnapshotParamWithDefaults() *EditCloudSnapshotParam`

NewEditCloudSnapshotParamWithDefaults instantiates a new EditCloudSnapshotParam object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetExecutionOption

`func (o *EditCloudSnapshotParam) GetExecutionOption() string`

GetExecutionOption returns the ExecutionOption field if non-nil, zero value otherwise.

### GetExecutionOptionOk

`func (o *EditCloudSnapshotParam) GetExecutionOptionOk() (*string, bool)`

GetExecutionOptionOk returns a tuple with the ExecutionOption field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetExecutionOption

`func (o *EditCloudSnapshotParam) SetExecutionOption(v string)`

SetExecutionOption sets ExecutionOption field to given value.

### HasExecutionOption

`func (o *EditCloudSnapshotParam) HasExecutionOption() bool`

HasExecutionOption returns a boolean if a field has been set.

### GetEditCloudSnapshotActionParam

`func (o *EditCloudSnapshotParam) GetEditCloudSnapshotActionParam() EditCloudSnapshotActionParam`

GetEditCloudSnapshotActionParam returns the EditCloudSnapshotActionParam field if non-nil, zero value otherwise.

### GetEditCloudSnapshotActionParamOk

`func (o *EditCloudSnapshotParam) GetEditCloudSnapshotActionParamOk() (*EditCloudSnapshotActionParam, bool)`

GetEditCloudSnapshotActionParamOk returns a tuple with the EditCloudSnapshotActionParam field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetEditCloudSnapshotActionParam

`func (o *EditCloudSnapshotParam) SetEditCloudSnapshotActionParam(v EditCloudSnapshotActionParam)`

SetEditCloudSnapshotActionParam sets EditCloudSnapshotActionParam field to given value.



[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


