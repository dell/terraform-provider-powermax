# MigrationMaskingView

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Name** | Pointer to **string** | The name of the Masking View | [optional] 
**Invalid** | Pointer to **bool** | Flag to indicate if the entity is invalid | [optional] 
**ChildInvalid** | Pointer to **bool** | Flag to indicate if a child entity is valid | [optional] 
**Missing** | Pointer to **bool** | Flag to indicate if the entity is missing | [optional] 
**InitiatorGroup** | Pointer to [**MigrationInitiatorGroup**](MigrationInitiatorGroup.md) |  | [optional] 
**PortGroup** | Pointer to [**MigrationPortGroup**](MigrationPortGroup.md) |  | [optional] 

## Methods

### NewMigrationMaskingView

`func NewMigrationMaskingView() *MigrationMaskingView`

NewMigrationMaskingView instantiates a new MigrationMaskingView object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewMigrationMaskingViewWithDefaults

`func NewMigrationMaskingViewWithDefaults() *MigrationMaskingView`

NewMigrationMaskingViewWithDefaults instantiates a new MigrationMaskingView object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetName

`func (o *MigrationMaskingView) GetName() string`

GetName returns the Name field if non-nil, zero value otherwise.

### GetNameOk

`func (o *MigrationMaskingView) GetNameOk() (*string, bool)`

GetNameOk returns a tuple with the Name field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetName

`func (o *MigrationMaskingView) SetName(v string)`

SetName sets Name field to given value.

### HasName

`func (o *MigrationMaskingView) HasName() bool`

HasName returns a boolean if a field has been set.

### GetInvalid

`func (o *MigrationMaskingView) GetInvalid() bool`

GetInvalid returns the Invalid field if non-nil, zero value otherwise.

### GetInvalidOk

`func (o *MigrationMaskingView) GetInvalidOk() (*bool, bool)`

GetInvalidOk returns a tuple with the Invalid field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetInvalid

`func (o *MigrationMaskingView) SetInvalid(v bool)`

SetInvalid sets Invalid field to given value.

### HasInvalid

`func (o *MigrationMaskingView) HasInvalid() bool`

HasInvalid returns a boolean if a field has been set.

### GetChildInvalid

`func (o *MigrationMaskingView) GetChildInvalid() bool`

GetChildInvalid returns the ChildInvalid field if non-nil, zero value otherwise.

### GetChildInvalidOk

`func (o *MigrationMaskingView) GetChildInvalidOk() (*bool, bool)`

GetChildInvalidOk returns a tuple with the ChildInvalid field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetChildInvalid

`func (o *MigrationMaskingView) SetChildInvalid(v bool)`

SetChildInvalid sets ChildInvalid field to given value.

### HasChildInvalid

`func (o *MigrationMaskingView) HasChildInvalid() bool`

HasChildInvalid returns a boolean if a field has been set.

### GetMissing

`func (o *MigrationMaskingView) GetMissing() bool`

GetMissing returns the Missing field if non-nil, zero value otherwise.

### GetMissingOk

`func (o *MigrationMaskingView) GetMissingOk() (*bool, bool)`

GetMissingOk returns a tuple with the Missing field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetMissing

`func (o *MigrationMaskingView) SetMissing(v bool)`

SetMissing sets Missing field to given value.

### HasMissing

`func (o *MigrationMaskingView) HasMissing() bool`

HasMissing returns a boolean if a field has been set.

### GetInitiatorGroup

`func (o *MigrationMaskingView) GetInitiatorGroup() MigrationInitiatorGroup`

GetInitiatorGroup returns the InitiatorGroup field if non-nil, zero value otherwise.

### GetInitiatorGroupOk

`func (o *MigrationMaskingView) GetInitiatorGroupOk() (*MigrationInitiatorGroup, bool)`

GetInitiatorGroupOk returns a tuple with the InitiatorGroup field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetInitiatorGroup

`func (o *MigrationMaskingView) SetInitiatorGroup(v MigrationInitiatorGroup)`

SetInitiatorGroup sets InitiatorGroup field to given value.

### HasInitiatorGroup

`func (o *MigrationMaskingView) HasInitiatorGroup() bool`

HasInitiatorGroup returns a boolean if a field has been set.

### GetPortGroup

`func (o *MigrationMaskingView) GetPortGroup() MigrationPortGroup`

GetPortGroup returns the PortGroup field if non-nil, zero value otherwise.

### GetPortGroupOk

`func (o *MigrationMaskingView) GetPortGroupOk() (*MigrationPortGroup, bool)`

GetPortGroupOk returns a tuple with the PortGroup field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetPortGroup

`func (o *MigrationMaskingView) SetPortGroup(v MigrationPortGroup)`

SetPortGroup sets PortGroup field to given value.

### HasPortGroup

`func (o *MigrationMaskingView) HasPortGroup() bool`

HasPortGroup returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


