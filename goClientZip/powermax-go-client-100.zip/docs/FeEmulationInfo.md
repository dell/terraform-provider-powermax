# FeEmulationInfo

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**FirstAvailableDate** | Pointer to **int64** |  | [optional] 
**LastAvailableDate** | Pointer to **int64** |  | [optional] 
**FeEmulationId** | **string** | feEmulationId | 

## Methods

### NewFeEmulationInfo

`func NewFeEmulationInfo(feEmulationId string, ) *FeEmulationInfo`

NewFeEmulationInfo instantiates a new FeEmulationInfo object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewFeEmulationInfoWithDefaults

`func NewFeEmulationInfoWithDefaults() *FeEmulationInfo`

NewFeEmulationInfoWithDefaults instantiates a new FeEmulationInfo object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetFirstAvailableDate

`func (o *FeEmulationInfo) GetFirstAvailableDate() int64`

GetFirstAvailableDate returns the FirstAvailableDate field if non-nil, zero value otherwise.

### GetFirstAvailableDateOk

`func (o *FeEmulationInfo) GetFirstAvailableDateOk() (*int64, bool)`

GetFirstAvailableDateOk returns a tuple with the FirstAvailableDate field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetFirstAvailableDate

`func (o *FeEmulationInfo) SetFirstAvailableDate(v int64)`

SetFirstAvailableDate sets FirstAvailableDate field to given value.

### HasFirstAvailableDate

`func (o *FeEmulationInfo) HasFirstAvailableDate() bool`

HasFirstAvailableDate returns a boolean if a field has been set.

### GetLastAvailableDate

`func (o *FeEmulationInfo) GetLastAvailableDate() int64`

GetLastAvailableDate returns the LastAvailableDate field if non-nil, zero value otherwise.

### GetLastAvailableDateOk

`func (o *FeEmulationInfo) GetLastAvailableDateOk() (*int64, bool)`

GetLastAvailableDateOk returns a tuple with the LastAvailableDate field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetLastAvailableDate

`func (o *FeEmulationInfo) SetLastAvailableDate(v int64)`

SetLastAvailableDate sets LastAvailableDate field to given value.

### HasLastAvailableDate

`func (o *FeEmulationInfo) HasLastAvailableDate() bool`

HasLastAvailableDate returns a boolean if a field has been set.

### GetFeEmulationId

`func (o *FeEmulationInfo) GetFeEmulationId() string`

GetFeEmulationId returns the FeEmulationId field if non-nil, zero value otherwise.

### GetFeEmulationIdOk

`func (o *FeEmulationInfo) GetFeEmulationIdOk() (*string, bool)`

GetFeEmulationIdOk returns a tuple with the FeEmulationId field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetFeEmulationId

`func (o *FeEmulationInfo) SetFeEmulationId(v string)`

SetFeEmulationId sets FeEmulationId field to given value.



[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


