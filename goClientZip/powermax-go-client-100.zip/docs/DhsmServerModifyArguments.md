# DhsmServerModifyArguments

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Username** | Pointer to **string** |                          User name for authentication to the DHSM server.                      | [optional] 
**Password** | Pointer to **string** |                          The password for authentication to the DHSM server. See &#39;username&#39;.                      | [optional] 

## Methods

### NewDhsmServerModifyArguments

`func NewDhsmServerModifyArguments() *DhsmServerModifyArguments`

NewDhsmServerModifyArguments instantiates a new DhsmServerModifyArguments object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewDhsmServerModifyArgumentsWithDefaults

`func NewDhsmServerModifyArgumentsWithDefaults() *DhsmServerModifyArguments`

NewDhsmServerModifyArgumentsWithDefaults instantiates a new DhsmServerModifyArguments object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetUsername

`func (o *DhsmServerModifyArguments) GetUsername() string`

GetUsername returns the Username field if non-nil, zero value otherwise.

### GetUsernameOk

`func (o *DhsmServerModifyArguments) GetUsernameOk() (*string, bool)`

GetUsernameOk returns a tuple with the Username field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetUsername

`func (o *DhsmServerModifyArguments) SetUsername(v string)`

SetUsername sets Username field to given value.

### HasUsername

`func (o *DhsmServerModifyArguments) HasUsername() bool`

HasUsername returns a boolean if a field has been set.

### GetPassword

`func (o *DhsmServerModifyArguments) GetPassword() string`

GetPassword returns the Password field if non-nil, zero value otherwise.

### GetPasswordOk

`func (o *DhsmServerModifyArguments) GetPasswordOk() (*string, bool)`

GetPasswordOk returns a tuple with the Password field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetPassword

`func (o *DhsmServerModifyArguments) SetPassword(v string)`

SetPassword sets Password field to given value.

### HasPassword

`func (o *DhsmServerModifyArguments) HasPassword() bool`

HasPassword returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


