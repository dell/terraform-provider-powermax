# FePortKeyResult

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**FePortInfo** | Pointer to [**[]FePortInfo**](FePortInfo.md) | fePortInfo | [optional] 

## Methods

### NewFePortKeyResult

`func NewFePortKeyResult() *FePortKeyResult`

NewFePortKeyResult instantiates a new FePortKeyResult object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewFePortKeyResultWithDefaults

`func NewFePortKeyResultWithDefaults() *FePortKeyResult`

NewFePortKeyResultWithDefaults instantiates a new FePortKeyResult object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetFePortInfo

`func (o *FePortKeyResult) GetFePortInfo() []FePortInfo`

GetFePortInfo returns the FePortInfo field if non-nil, zero value otherwise.

### GetFePortInfoOk

`func (o *FePortKeyResult) GetFePortInfoOk() (*[]FePortInfo, bool)`

GetFePortInfoOk returns a tuple with the FePortInfo field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetFePortInfo

`func (o *FePortKeyResult) SetFePortInfo(v []FePortInfo)`

SetFePortInfo sets FePortInfo field to given value.

### HasFePortInfo

`func (o *FePortKeyResult) HasFePortInfo() bool`

HasFePortInfo returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


