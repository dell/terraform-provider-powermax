# CloudProviderConnectionDetails

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**EcsConnectionDetails** | Pointer to [**EcsConnectionDetails**](EcsConnectionDetails.md) |  | [optional] 
**AzureConnectionDetails** | Pointer to [**AzureConnectionDetails**](AzureConnectionDetails.md) |  | [optional] 
**AmazonConnectionDetails** | Pointer to [**AmazonConnectionDetails**](AmazonConnectionDetails.md) |  | [optional] 

## Methods

### NewCloudProviderConnectionDetails

`func NewCloudProviderConnectionDetails() *CloudProviderConnectionDetails`

NewCloudProviderConnectionDetails instantiates a new CloudProviderConnectionDetails object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewCloudProviderConnectionDetailsWithDefaults

`func NewCloudProviderConnectionDetailsWithDefaults() *CloudProviderConnectionDetails`

NewCloudProviderConnectionDetailsWithDefaults instantiates a new CloudProviderConnectionDetails object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetEcsConnectionDetails

`func (o *CloudProviderConnectionDetails) GetEcsConnectionDetails() EcsConnectionDetails`

GetEcsConnectionDetails returns the EcsConnectionDetails field if non-nil, zero value otherwise.

### GetEcsConnectionDetailsOk

`func (o *CloudProviderConnectionDetails) GetEcsConnectionDetailsOk() (*EcsConnectionDetails, bool)`

GetEcsConnectionDetailsOk returns a tuple with the EcsConnectionDetails field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetEcsConnectionDetails

`func (o *CloudProviderConnectionDetails) SetEcsConnectionDetails(v EcsConnectionDetails)`

SetEcsConnectionDetails sets EcsConnectionDetails field to given value.

### HasEcsConnectionDetails

`func (o *CloudProviderConnectionDetails) HasEcsConnectionDetails() bool`

HasEcsConnectionDetails returns a boolean if a field has been set.

### GetAzureConnectionDetails

`func (o *CloudProviderConnectionDetails) GetAzureConnectionDetails() AzureConnectionDetails`

GetAzureConnectionDetails returns the AzureConnectionDetails field if non-nil, zero value otherwise.

### GetAzureConnectionDetailsOk

`func (o *CloudProviderConnectionDetails) GetAzureConnectionDetailsOk() (*AzureConnectionDetails, bool)`

GetAzureConnectionDetailsOk returns a tuple with the AzureConnectionDetails field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetAzureConnectionDetails

`func (o *CloudProviderConnectionDetails) SetAzureConnectionDetails(v AzureConnectionDetails)`

SetAzureConnectionDetails sets AzureConnectionDetails field to given value.

### HasAzureConnectionDetails

`func (o *CloudProviderConnectionDetails) HasAzureConnectionDetails() bool`

HasAzureConnectionDetails returns a boolean if a field has been set.

### GetAmazonConnectionDetails

`func (o *CloudProviderConnectionDetails) GetAmazonConnectionDetails() AmazonConnectionDetails`

GetAmazonConnectionDetails returns the AmazonConnectionDetails field if non-nil, zero value otherwise.

### GetAmazonConnectionDetailsOk

`func (o *CloudProviderConnectionDetails) GetAmazonConnectionDetailsOk() (*AmazonConnectionDetails, bool)`

GetAmazonConnectionDetailsOk returns a tuple with the AmazonConnectionDetails field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetAmazonConnectionDetails

`func (o *CloudProviderConnectionDetails) SetAmazonConnectionDetails(v AmazonConnectionDetails)`

SetAmazonConnectionDetails sets AmazonConnectionDetails field to given value.

### HasAmazonConnectionDetails

`func (o *CloudProviderConnectionDetails) HasAmazonConnectionDetails() bool`

HasAmazonConnectionDetails returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


