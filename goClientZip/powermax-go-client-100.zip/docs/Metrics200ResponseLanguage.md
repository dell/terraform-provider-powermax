# Metrics200ResponseLanguage

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Language** | Pointer to **string** |  | [optional] 
**Script** | Pointer to **string** |  | [optional] 
**Country** | Pointer to **string** |  | [optional] 
**Variant** | Pointer to **string** |  | [optional] 
**ExtensionKeys** | Pointer to **[]string** |  | [optional] 
**UnicodeLocaleAttributes** | Pointer to **[]string** |  | [optional] 
**UnicodeLocaleKeys** | Pointer to **[]string** |  | [optional] 
**Iso3Language** | Pointer to **string** |  | [optional] 
**Iso3Country** | Pointer to **string** |  | [optional] 
**DisplayLanguage** | Pointer to **string** |  | [optional] 
**DisplayScript** | Pointer to **string** |  | [optional] 
**DisplayCountry** | Pointer to **string** |  | [optional] 
**DisplayVariant** | Pointer to **string** |  | [optional] 
**DisplayName** | Pointer to **string** |  | [optional] 

## Methods

### NewMetrics200ResponseLanguage

`func NewMetrics200ResponseLanguage() *Metrics200ResponseLanguage`

NewMetrics200ResponseLanguage instantiates a new Metrics200ResponseLanguage object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewMetrics200ResponseLanguageWithDefaults

`func NewMetrics200ResponseLanguageWithDefaults() *Metrics200ResponseLanguage`

NewMetrics200ResponseLanguageWithDefaults instantiates a new Metrics200ResponseLanguage object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetLanguage

`func (o *Metrics200ResponseLanguage) GetLanguage() string`

GetLanguage returns the Language field if non-nil, zero value otherwise.

### GetLanguageOk

`func (o *Metrics200ResponseLanguage) GetLanguageOk() (*string, bool)`

GetLanguageOk returns a tuple with the Language field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetLanguage

`func (o *Metrics200ResponseLanguage) SetLanguage(v string)`

SetLanguage sets Language field to given value.

### HasLanguage

`func (o *Metrics200ResponseLanguage) HasLanguage() bool`

HasLanguage returns a boolean if a field has been set.

### GetScript

`func (o *Metrics200ResponseLanguage) GetScript() string`

GetScript returns the Script field if non-nil, zero value otherwise.

### GetScriptOk

`func (o *Metrics200ResponseLanguage) GetScriptOk() (*string, bool)`

GetScriptOk returns a tuple with the Script field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetScript

`func (o *Metrics200ResponseLanguage) SetScript(v string)`

SetScript sets Script field to given value.

### HasScript

`func (o *Metrics200ResponseLanguage) HasScript() bool`

HasScript returns a boolean if a field has been set.

### GetCountry

`func (o *Metrics200ResponseLanguage) GetCountry() string`

GetCountry returns the Country field if non-nil, zero value otherwise.

### GetCountryOk

`func (o *Metrics200ResponseLanguage) GetCountryOk() (*string, bool)`

GetCountryOk returns a tuple with the Country field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetCountry

`func (o *Metrics200ResponseLanguage) SetCountry(v string)`

SetCountry sets Country field to given value.

### HasCountry

`func (o *Metrics200ResponseLanguage) HasCountry() bool`

HasCountry returns a boolean if a field has been set.

### GetVariant

`func (o *Metrics200ResponseLanguage) GetVariant() string`

GetVariant returns the Variant field if non-nil, zero value otherwise.

### GetVariantOk

`func (o *Metrics200ResponseLanguage) GetVariantOk() (*string, bool)`

GetVariantOk returns a tuple with the Variant field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetVariant

`func (o *Metrics200ResponseLanguage) SetVariant(v string)`

SetVariant sets Variant field to given value.

### HasVariant

`func (o *Metrics200ResponseLanguage) HasVariant() bool`

HasVariant returns a boolean if a field has been set.

### GetExtensionKeys

`func (o *Metrics200ResponseLanguage) GetExtensionKeys() []string`

GetExtensionKeys returns the ExtensionKeys field if non-nil, zero value otherwise.

### GetExtensionKeysOk

`func (o *Metrics200ResponseLanguage) GetExtensionKeysOk() (*[]string, bool)`

GetExtensionKeysOk returns a tuple with the ExtensionKeys field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetExtensionKeys

`func (o *Metrics200ResponseLanguage) SetExtensionKeys(v []string)`

SetExtensionKeys sets ExtensionKeys field to given value.

### HasExtensionKeys

`func (o *Metrics200ResponseLanguage) HasExtensionKeys() bool`

HasExtensionKeys returns a boolean if a field has been set.

### GetUnicodeLocaleAttributes

`func (o *Metrics200ResponseLanguage) GetUnicodeLocaleAttributes() []string`

GetUnicodeLocaleAttributes returns the UnicodeLocaleAttributes field if non-nil, zero value otherwise.

### GetUnicodeLocaleAttributesOk

`func (o *Metrics200ResponseLanguage) GetUnicodeLocaleAttributesOk() (*[]string, bool)`

GetUnicodeLocaleAttributesOk returns a tuple with the UnicodeLocaleAttributes field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetUnicodeLocaleAttributes

`func (o *Metrics200ResponseLanguage) SetUnicodeLocaleAttributes(v []string)`

SetUnicodeLocaleAttributes sets UnicodeLocaleAttributes field to given value.

### HasUnicodeLocaleAttributes

`func (o *Metrics200ResponseLanguage) HasUnicodeLocaleAttributes() bool`

HasUnicodeLocaleAttributes returns a boolean if a field has been set.

### GetUnicodeLocaleKeys

`func (o *Metrics200ResponseLanguage) GetUnicodeLocaleKeys() []string`

GetUnicodeLocaleKeys returns the UnicodeLocaleKeys field if non-nil, zero value otherwise.

### GetUnicodeLocaleKeysOk

`func (o *Metrics200ResponseLanguage) GetUnicodeLocaleKeysOk() (*[]string, bool)`

GetUnicodeLocaleKeysOk returns a tuple with the UnicodeLocaleKeys field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetUnicodeLocaleKeys

`func (o *Metrics200ResponseLanguage) SetUnicodeLocaleKeys(v []string)`

SetUnicodeLocaleKeys sets UnicodeLocaleKeys field to given value.

### HasUnicodeLocaleKeys

`func (o *Metrics200ResponseLanguage) HasUnicodeLocaleKeys() bool`

HasUnicodeLocaleKeys returns a boolean if a field has been set.

### GetIso3Language

`func (o *Metrics200ResponseLanguage) GetIso3Language() string`

GetIso3Language returns the Iso3Language field if non-nil, zero value otherwise.

### GetIso3LanguageOk

`func (o *Metrics200ResponseLanguage) GetIso3LanguageOk() (*string, bool)`

GetIso3LanguageOk returns a tuple with the Iso3Language field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetIso3Language

`func (o *Metrics200ResponseLanguage) SetIso3Language(v string)`

SetIso3Language sets Iso3Language field to given value.

### HasIso3Language

`func (o *Metrics200ResponseLanguage) HasIso3Language() bool`

HasIso3Language returns a boolean if a field has been set.

### GetIso3Country

`func (o *Metrics200ResponseLanguage) GetIso3Country() string`

GetIso3Country returns the Iso3Country field if non-nil, zero value otherwise.

### GetIso3CountryOk

`func (o *Metrics200ResponseLanguage) GetIso3CountryOk() (*string, bool)`

GetIso3CountryOk returns a tuple with the Iso3Country field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetIso3Country

`func (o *Metrics200ResponseLanguage) SetIso3Country(v string)`

SetIso3Country sets Iso3Country field to given value.

### HasIso3Country

`func (o *Metrics200ResponseLanguage) HasIso3Country() bool`

HasIso3Country returns a boolean if a field has been set.

### GetDisplayLanguage

`func (o *Metrics200ResponseLanguage) GetDisplayLanguage() string`

GetDisplayLanguage returns the DisplayLanguage field if non-nil, zero value otherwise.

### GetDisplayLanguageOk

`func (o *Metrics200ResponseLanguage) GetDisplayLanguageOk() (*string, bool)`

GetDisplayLanguageOk returns a tuple with the DisplayLanguage field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetDisplayLanguage

`func (o *Metrics200ResponseLanguage) SetDisplayLanguage(v string)`

SetDisplayLanguage sets DisplayLanguage field to given value.

### HasDisplayLanguage

`func (o *Metrics200ResponseLanguage) HasDisplayLanguage() bool`

HasDisplayLanguage returns a boolean if a field has been set.

### GetDisplayScript

`func (o *Metrics200ResponseLanguage) GetDisplayScript() string`

GetDisplayScript returns the DisplayScript field if non-nil, zero value otherwise.

### GetDisplayScriptOk

`func (o *Metrics200ResponseLanguage) GetDisplayScriptOk() (*string, bool)`

GetDisplayScriptOk returns a tuple with the DisplayScript field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetDisplayScript

`func (o *Metrics200ResponseLanguage) SetDisplayScript(v string)`

SetDisplayScript sets DisplayScript field to given value.

### HasDisplayScript

`func (o *Metrics200ResponseLanguage) HasDisplayScript() bool`

HasDisplayScript returns a boolean if a field has been set.

### GetDisplayCountry

`func (o *Metrics200ResponseLanguage) GetDisplayCountry() string`

GetDisplayCountry returns the DisplayCountry field if non-nil, zero value otherwise.

### GetDisplayCountryOk

`func (o *Metrics200ResponseLanguage) GetDisplayCountryOk() (*string, bool)`

GetDisplayCountryOk returns a tuple with the DisplayCountry field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetDisplayCountry

`func (o *Metrics200ResponseLanguage) SetDisplayCountry(v string)`

SetDisplayCountry sets DisplayCountry field to given value.

### HasDisplayCountry

`func (o *Metrics200ResponseLanguage) HasDisplayCountry() bool`

HasDisplayCountry returns a boolean if a field has been set.

### GetDisplayVariant

`func (o *Metrics200ResponseLanguage) GetDisplayVariant() string`

GetDisplayVariant returns the DisplayVariant field if non-nil, zero value otherwise.

### GetDisplayVariantOk

`func (o *Metrics200ResponseLanguage) GetDisplayVariantOk() (*string, bool)`

GetDisplayVariantOk returns a tuple with the DisplayVariant field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetDisplayVariant

`func (o *Metrics200ResponseLanguage) SetDisplayVariant(v string)`

SetDisplayVariant sets DisplayVariant field to given value.

### HasDisplayVariant

`func (o *Metrics200ResponseLanguage) HasDisplayVariant() bool`

HasDisplayVariant returns a boolean if a field has been set.

### GetDisplayName

`func (o *Metrics200ResponseLanguage) GetDisplayName() string`

GetDisplayName returns the DisplayName field if non-nil, zero value otherwise.

### GetDisplayNameOk

`func (o *Metrics200ResponseLanguage) GetDisplayNameOk() (*string, bool)`

GetDisplayNameOk returns a tuple with the DisplayName field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetDisplayName

`func (o *Metrics200ResponseLanguage) SetDisplayName(v string)`

SetDisplayName sets DisplayName field to given value.

### HasDisplayName

`func (o *Metrics200ResponseLanguage) HasDisplayName() bool`

HasDisplayName returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


