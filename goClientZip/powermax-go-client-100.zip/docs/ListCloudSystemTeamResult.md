# ListCloudSystemTeamResult

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**TeamId** | Pointer to **[]string** | team_id | [optional] 

## Methods

### NewListCloudSystemTeamResult

`func NewListCloudSystemTeamResult() *ListCloudSystemTeamResult`

NewListCloudSystemTeamResult instantiates a new ListCloudSystemTeamResult object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewListCloudSystemTeamResultWithDefaults

`func NewListCloudSystemTeamResultWithDefaults() *ListCloudSystemTeamResult`

NewListCloudSystemTeamResultWithDefaults instantiates a new ListCloudSystemTeamResult object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetTeamId

`func (o *ListCloudSystemTeamResult) GetTeamId() []string`

GetTeamId returns the TeamId field if non-nil, zero value otherwise.

### GetTeamIdOk

`func (o *ListCloudSystemTeamResult) GetTeamIdOk() (*[]string, bool)`

GetTeamIdOk returns a tuple with the TeamId field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetTeamId

`func (o *ListCloudSystemTeamResult) SetTeamId(v []string)`

SetTeamId sets TeamId field to given value.

### HasTeamId

`func (o *ListCloudSystemTeamResult) HasTeamId() bool`

HasTeamId returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


