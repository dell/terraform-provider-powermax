# DhsmServer

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Id** | Pointer to **string** |                          Identifier of the DHSM server                      | [optional] 
**NasServer** | Pointer to **string** |                          Identifier of the parent NAS server.                      | [optional] 
**Username** | Pointer to **string** |                          User name for authentication to the DHSM server.                      | [optional] 
**Health** | Pointer to [**Health**](Health.md) |  | [optional] 

## Methods

### NewDhsmServer

`func NewDhsmServer() *DhsmServer`

NewDhsmServer instantiates a new DhsmServer object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewDhsmServerWithDefaults

`func NewDhsmServerWithDefaults() *DhsmServer`

NewDhsmServerWithDefaults instantiates a new DhsmServer object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetId

`func (o *DhsmServer) GetId() string`

GetId returns the Id field if non-nil, zero value otherwise.

### GetIdOk

`func (o *DhsmServer) GetIdOk() (*string, bool)`

GetIdOk returns a tuple with the Id field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetId

`func (o *DhsmServer) SetId(v string)`

SetId sets Id field to given value.

### HasId

`func (o *DhsmServer) HasId() bool`

HasId returns a boolean if a field has been set.

### GetNasServer

`func (o *DhsmServer) GetNasServer() string`

GetNasServer returns the NasServer field if non-nil, zero value otherwise.

### GetNasServerOk

`func (o *DhsmServer) GetNasServerOk() (*string, bool)`

GetNasServerOk returns a tuple with the NasServer field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetNasServer

`func (o *DhsmServer) SetNasServer(v string)`

SetNasServer sets NasServer field to given value.

### HasNasServer

`func (o *DhsmServer) HasNasServer() bool`

HasNasServer returns a boolean if a field has been set.

### GetUsername

`func (o *DhsmServer) GetUsername() string`

GetUsername returns the Username field if non-nil, zero value otherwise.

### GetUsernameOk

`func (o *DhsmServer) GetUsernameOk() (*string, bool)`

GetUsernameOk returns a tuple with the Username field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetUsername

`func (o *DhsmServer) SetUsername(v string)`

SetUsername sets Username field to given value.

### HasUsername

`func (o *DhsmServer) HasUsername() bool`

HasUsername returns a boolean if a field has been set.

### GetHealth

`func (o *DhsmServer) GetHealth() Health`

GetHealth returns the Health field if non-nil, zero value otherwise.

### GetHealthOk

`func (o *DhsmServer) GetHealthOk() (*Health, bool)`

GetHealthOk returns a tuple with the Health field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetHealth

`func (o *DhsmServer) SetHealth(v Health)`

SetHealth sets Health field to given value.

### HasHealth

`func (o *DhsmServer) HasHealth() bool`

HasHealth returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


