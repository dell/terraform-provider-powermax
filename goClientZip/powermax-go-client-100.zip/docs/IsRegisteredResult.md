# IsRegisteredResult

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**IsRegistered** | **bool** | isRegistered | [default to false]

## Methods

### NewIsRegisteredResult

`func NewIsRegisteredResult(isRegistered bool, ) *IsRegisteredResult`

NewIsRegisteredResult instantiates a new IsRegisteredResult object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewIsRegisteredResultWithDefaults

`func NewIsRegisteredResultWithDefaults() *IsRegisteredResult`

NewIsRegisteredResultWithDefaults instantiates a new IsRegisteredResult object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetIsRegistered

`func (o *IsRegisteredResult) GetIsRegistered() bool`

GetIsRegistered returns the IsRegistered field if non-nil, zero value otherwise.

### GetIsRegisteredOk

`func (o *IsRegisteredResult) GetIsRegisteredOk() (*bool, bool)`

GetIsRegisteredOk returns a tuple with the IsRegistered field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetIsRegistered

`func (o *IsRegisteredResult) SetIsRegistered(v bool)`

SetIsRegistered sets IsRegistered field to given value.



[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


