# DgEstablishParam

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Force** | Pointer to **bool** | Attempts to force the operation even though one or more volumes may not be in the normal, expected state(s) for the                                 specified                                 operation. | [optional] 
**SymForce** | Pointer to **bool** | Requests the System force operation be executed when normally it is rejected. Use extreme caution when using                                 this                                 option.                                  CAUTION: Use care when applying symforce, as data could be lost or corrupted. Use of this option is not recommended,                                 except in                                 an emergency.                                  NOTE: To enable symforce, a parameter called SYMAPI_ALLOW_RDF_SYMFORCE in the options file must be set to TRUE and                                 restart the                                 Unisphere server to pick up the change.                                  When used with symforce, a split command executes on an SRDF pair, even when the pair is sync in progress or restore in                                 progress.                                 During the execution of an establish or restore command, -symforce prohibits the verification of valid tracks on the                                 device at                                 the source. | [optional] 
**Star** | Pointer to **bool** | Targets the action at volumes in STAR mode. | [optional] 
**Hop2** | Pointer to **bool** | Targets the SRDF action at the group&#39;s second-hop volumes in a cascaded SRDF relationship. For example, in an RDF1                                 group, the                                 action                                 targets the R21-&gt;R2 pair of the R1-&gt;R21-&gt;R2 relationship. | [optional] 
**Bypass** | Pointer to **bool** | Bypasses any existing System exclusive locks during an SRDF operation.                                 WARNING: Only use this flag if you are certain no other SRDF operation is in progress at the local and/or remote                                 System. | [optional] 
**All** | Pointer to **bool** | Lists all SRDF mirrors of the selected devices. Used with symrdf list.                                 When performing an SRDF control or set operation, it targets the SRDF action at all devices in the device group:                                 Standard SRDF                                 devices                                 and locally-attached BCV SRDF devices.                                 This option is only supported for list and device group operations. | [optional] 
**Bcv** | Pointer to **bool** | Targets the SRDF action at the Device Group&#39;s locally-associated BCV volumes that are configured as SRDF BCV volumes. | [optional] 
**Full** | Pointer to **bool** | Make the action a Full Establish as opposed to an Incremental Establish | [optional] 
**MetroBias** | Pointer to **bool** | When the SRDF Mode is set to Active, this specifies to make the R1 System the Bias | [optional] 

## Methods

### NewDgEstablishParam

`func NewDgEstablishParam() *DgEstablishParam`

NewDgEstablishParam instantiates a new DgEstablishParam object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewDgEstablishParamWithDefaults

`func NewDgEstablishParamWithDefaults() *DgEstablishParam`

NewDgEstablishParamWithDefaults instantiates a new DgEstablishParam object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetForce

`func (o *DgEstablishParam) GetForce() bool`

GetForce returns the Force field if non-nil, zero value otherwise.

### GetForceOk

`func (o *DgEstablishParam) GetForceOk() (*bool, bool)`

GetForceOk returns a tuple with the Force field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetForce

`func (o *DgEstablishParam) SetForce(v bool)`

SetForce sets Force field to given value.

### HasForce

`func (o *DgEstablishParam) HasForce() bool`

HasForce returns a boolean if a field has been set.

### GetSymForce

`func (o *DgEstablishParam) GetSymForce() bool`

GetSymForce returns the SymForce field if non-nil, zero value otherwise.

### GetSymForceOk

`func (o *DgEstablishParam) GetSymForceOk() (*bool, bool)`

GetSymForceOk returns a tuple with the SymForce field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetSymForce

`func (o *DgEstablishParam) SetSymForce(v bool)`

SetSymForce sets SymForce field to given value.

### HasSymForce

`func (o *DgEstablishParam) HasSymForce() bool`

HasSymForce returns a boolean if a field has been set.

### GetStar

`func (o *DgEstablishParam) GetStar() bool`

GetStar returns the Star field if non-nil, zero value otherwise.

### GetStarOk

`func (o *DgEstablishParam) GetStarOk() (*bool, bool)`

GetStarOk returns a tuple with the Star field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetStar

`func (o *DgEstablishParam) SetStar(v bool)`

SetStar sets Star field to given value.

### HasStar

`func (o *DgEstablishParam) HasStar() bool`

HasStar returns a boolean if a field has been set.

### GetHop2

`func (o *DgEstablishParam) GetHop2() bool`

GetHop2 returns the Hop2 field if non-nil, zero value otherwise.

### GetHop2Ok

`func (o *DgEstablishParam) GetHop2Ok() (*bool, bool)`

GetHop2Ok returns a tuple with the Hop2 field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetHop2

`func (o *DgEstablishParam) SetHop2(v bool)`

SetHop2 sets Hop2 field to given value.

### HasHop2

`func (o *DgEstablishParam) HasHop2() bool`

HasHop2 returns a boolean if a field has been set.

### GetBypass

`func (o *DgEstablishParam) GetBypass() bool`

GetBypass returns the Bypass field if non-nil, zero value otherwise.

### GetBypassOk

`func (o *DgEstablishParam) GetBypassOk() (*bool, bool)`

GetBypassOk returns a tuple with the Bypass field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetBypass

`func (o *DgEstablishParam) SetBypass(v bool)`

SetBypass sets Bypass field to given value.

### HasBypass

`func (o *DgEstablishParam) HasBypass() bool`

HasBypass returns a boolean if a field has been set.

### GetAll

`func (o *DgEstablishParam) GetAll() bool`

GetAll returns the All field if non-nil, zero value otherwise.

### GetAllOk

`func (o *DgEstablishParam) GetAllOk() (*bool, bool)`

GetAllOk returns a tuple with the All field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetAll

`func (o *DgEstablishParam) SetAll(v bool)`

SetAll sets All field to given value.

### HasAll

`func (o *DgEstablishParam) HasAll() bool`

HasAll returns a boolean if a field has been set.

### GetBcv

`func (o *DgEstablishParam) GetBcv() bool`

GetBcv returns the Bcv field if non-nil, zero value otherwise.

### GetBcvOk

`func (o *DgEstablishParam) GetBcvOk() (*bool, bool)`

GetBcvOk returns a tuple with the Bcv field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetBcv

`func (o *DgEstablishParam) SetBcv(v bool)`

SetBcv sets Bcv field to given value.

### HasBcv

`func (o *DgEstablishParam) HasBcv() bool`

HasBcv returns a boolean if a field has been set.

### GetFull

`func (o *DgEstablishParam) GetFull() bool`

GetFull returns the Full field if non-nil, zero value otherwise.

### GetFullOk

`func (o *DgEstablishParam) GetFullOk() (*bool, bool)`

GetFullOk returns a tuple with the Full field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetFull

`func (o *DgEstablishParam) SetFull(v bool)`

SetFull sets Full field to given value.

### HasFull

`func (o *DgEstablishParam) HasFull() bool`

HasFull returns a boolean if a field has been set.

### GetMetroBias

`func (o *DgEstablishParam) GetMetroBias() bool`

GetMetroBias returns the MetroBias field if non-nil, zero value otherwise.

### GetMetroBiasOk

`func (o *DgEstablishParam) GetMetroBiasOk() (*bool, bool)`

GetMetroBiasOk returns a tuple with the MetroBias field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetMetroBias

`func (o *DgEstablishParam) SetMetroBias(v bool)`

SetMetroBias sets MetroBias field to given value.

### HasMetroBias

`func (o *DgEstablishParam) HasMetroBias() bool`

HasMetroBias returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


