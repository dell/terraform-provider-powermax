# EditIPInterfaceOptionsParam

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**IpAddress** | Pointer to **string** | ip_address | [optional] 
**NetworkId** | Pointer to **int64** | network_id | [optional] 
**IpPrefixLength** | Pointer to **int32** | ip_prefix_length | [optional] 
**Mtu** | Pointer to **int64** | mtu | [optional] 
**CdcDiscoverType** | Pointer to **string** | cdc_Discover_Type   Enumeration values: * **auto_discover_cdc_ip** * **advertise_ddc_ip** * **auto_discover_disabled** * **manual_cdc_configuration**  | [optional] 
**CdcIpAddress** | Pointer to **string** | cdc_ip_address | [optional] 
**CdcPortNumber** | Pointer to **int32** | cdc_port_number | [optional] 

## Methods

### NewEditIPInterfaceOptionsParam

`func NewEditIPInterfaceOptionsParam() *EditIPInterfaceOptionsParam`

NewEditIPInterfaceOptionsParam instantiates a new EditIPInterfaceOptionsParam object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewEditIPInterfaceOptionsParamWithDefaults

`func NewEditIPInterfaceOptionsParamWithDefaults() *EditIPInterfaceOptionsParam`

NewEditIPInterfaceOptionsParamWithDefaults instantiates a new EditIPInterfaceOptionsParam object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetIpAddress

`func (o *EditIPInterfaceOptionsParam) GetIpAddress() string`

GetIpAddress returns the IpAddress field if non-nil, zero value otherwise.

### GetIpAddressOk

`func (o *EditIPInterfaceOptionsParam) GetIpAddressOk() (*string, bool)`

GetIpAddressOk returns a tuple with the IpAddress field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetIpAddress

`func (o *EditIPInterfaceOptionsParam) SetIpAddress(v string)`

SetIpAddress sets IpAddress field to given value.

### HasIpAddress

`func (o *EditIPInterfaceOptionsParam) HasIpAddress() bool`

HasIpAddress returns a boolean if a field has been set.

### GetNetworkId

`func (o *EditIPInterfaceOptionsParam) GetNetworkId() int64`

GetNetworkId returns the NetworkId field if non-nil, zero value otherwise.

### GetNetworkIdOk

`func (o *EditIPInterfaceOptionsParam) GetNetworkIdOk() (*int64, bool)`

GetNetworkIdOk returns a tuple with the NetworkId field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetNetworkId

`func (o *EditIPInterfaceOptionsParam) SetNetworkId(v int64)`

SetNetworkId sets NetworkId field to given value.

### HasNetworkId

`func (o *EditIPInterfaceOptionsParam) HasNetworkId() bool`

HasNetworkId returns a boolean if a field has been set.

### GetIpPrefixLength

`func (o *EditIPInterfaceOptionsParam) GetIpPrefixLength() int32`

GetIpPrefixLength returns the IpPrefixLength field if non-nil, zero value otherwise.

### GetIpPrefixLengthOk

`func (o *EditIPInterfaceOptionsParam) GetIpPrefixLengthOk() (*int32, bool)`

GetIpPrefixLengthOk returns a tuple with the IpPrefixLength field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetIpPrefixLength

`func (o *EditIPInterfaceOptionsParam) SetIpPrefixLength(v int32)`

SetIpPrefixLength sets IpPrefixLength field to given value.

### HasIpPrefixLength

`func (o *EditIPInterfaceOptionsParam) HasIpPrefixLength() bool`

HasIpPrefixLength returns a boolean if a field has been set.

### GetMtu

`func (o *EditIPInterfaceOptionsParam) GetMtu() int64`

GetMtu returns the Mtu field if non-nil, zero value otherwise.

### GetMtuOk

`func (o *EditIPInterfaceOptionsParam) GetMtuOk() (*int64, bool)`

GetMtuOk returns a tuple with the Mtu field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetMtu

`func (o *EditIPInterfaceOptionsParam) SetMtu(v int64)`

SetMtu sets Mtu field to given value.

### HasMtu

`func (o *EditIPInterfaceOptionsParam) HasMtu() bool`

HasMtu returns a boolean if a field has been set.

### GetCdcDiscoverType

`func (o *EditIPInterfaceOptionsParam) GetCdcDiscoverType() string`

GetCdcDiscoverType returns the CdcDiscoverType field if non-nil, zero value otherwise.

### GetCdcDiscoverTypeOk

`func (o *EditIPInterfaceOptionsParam) GetCdcDiscoverTypeOk() (*string, bool)`

GetCdcDiscoverTypeOk returns a tuple with the CdcDiscoverType field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetCdcDiscoverType

`func (o *EditIPInterfaceOptionsParam) SetCdcDiscoverType(v string)`

SetCdcDiscoverType sets CdcDiscoverType field to given value.

### HasCdcDiscoverType

`func (o *EditIPInterfaceOptionsParam) HasCdcDiscoverType() bool`

HasCdcDiscoverType returns a boolean if a field has been set.

### GetCdcIpAddress

`func (o *EditIPInterfaceOptionsParam) GetCdcIpAddress() string`

GetCdcIpAddress returns the CdcIpAddress field if non-nil, zero value otherwise.

### GetCdcIpAddressOk

`func (o *EditIPInterfaceOptionsParam) GetCdcIpAddressOk() (*string, bool)`

GetCdcIpAddressOk returns a tuple with the CdcIpAddress field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetCdcIpAddress

`func (o *EditIPInterfaceOptionsParam) SetCdcIpAddress(v string)`

SetCdcIpAddress sets CdcIpAddress field to given value.

### HasCdcIpAddress

`func (o *EditIPInterfaceOptionsParam) HasCdcIpAddress() bool`

HasCdcIpAddress returns a boolean if a field has been set.

### GetCdcPortNumber

`func (o *EditIPInterfaceOptionsParam) GetCdcPortNumber() int32`

GetCdcPortNumber returns the CdcPortNumber field if non-nil, zero value otherwise.

### GetCdcPortNumberOk

`func (o *EditIPInterfaceOptionsParam) GetCdcPortNumberOk() (*int32, bool)`

GetCdcPortNumberOk returns a tuple with the CdcPortNumber field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetCdcPortNumber

`func (o *EditIPInterfaceOptionsParam) SetCdcPortNumber(v int32)`

SetCdcPortNumber sets CdcPortNumber field to given value.

### HasCdcPortNumber

`func (o *EditIPInterfaceOptionsParam) HasCdcPortNumber() bool`

HasCdcPortNumber returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


