# LdapList

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Entries** | Pointer to [**[]ServiceListObject**](ServiceListObject.md) |                                  List of ldap service objects                              | [optional] 

## Methods

### NewLdapList

`func NewLdapList() *LdapList`

NewLdapList instantiates a new LdapList object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewLdapListWithDefaults

`func NewLdapListWithDefaults() *LdapList`

NewLdapListWithDefaults instantiates a new LdapList object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetEntries

`func (o *LdapList) GetEntries() []ServiceListObject`

GetEntries returns the Entries field if non-nil, zero value otherwise.

### GetEntriesOk

`func (o *LdapList) GetEntriesOk() (*[]ServiceListObject, bool)`

GetEntriesOk returns a tuple with the Entries field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetEntries

`func (o *LdapList) SetEntries(v []ServiceListObject)`

SetEntries sets Entries field to given value.

### HasEntries

`func (o *LdapList) HasEntries() bool`

HasEntries returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


