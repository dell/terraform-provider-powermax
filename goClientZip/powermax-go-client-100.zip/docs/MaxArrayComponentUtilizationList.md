# MaxArrayComponentUtilizationList

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**MaxArrayComponentUtilization** | [**[]MaxArrayComponentUtilization**](MaxArrayComponentUtilization.md) | maxArrayComponentUtilization | 

## Methods

### NewMaxArrayComponentUtilizationList

`func NewMaxArrayComponentUtilizationList(maxArrayComponentUtilization []MaxArrayComponentUtilization, ) *MaxArrayComponentUtilizationList`

NewMaxArrayComponentUtilizationList instantiates a new MaxArrayComponentUtilizationList object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewMaxArrayComponentUtilizationListWithDefaults

`func NewMaxArrayComponentUtilizationListWithDefaults() *MaxArrayComponentUtilizationList`

NewMaxArrayComponentUtilizationListWithDefaults instantiates a new MaxArrayComponentUtilizationList object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetMaxArrayComponentUtilization

`func (o *MaxArrayComponentUtilizationList) GetMaxArrayComponentUtilization() []MaxArrayComponentUtilization`

GetMaxArrayComponentUtilization returns the MaxArrayComponentUtilization field if non-nil, zero value otherwise.

### GetMaxArrayComponentUtilizationOk

`func (o *MaxArrayComponentUtilizationList) GetMaxArrayComponentUtilizationOk() (*[]MaxArrayComponentUtilization, bool)`

GetMaxArrayComponentUtilizationOk returns a tuple with the MaxArrayComponentUtilization field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetMaxArrayComponentUtilization

`func (o *MaxArrayComponentUtilizationList) SetMaxArrayComponentUtilization(v []MaxArrayComponentUtilization)`

SetMaxArrayComponentUtilization sets MaxArrayComponentUtilization field to given value.



[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


