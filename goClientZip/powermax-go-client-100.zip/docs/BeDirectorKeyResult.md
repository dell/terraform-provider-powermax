# BeDirectorKeyResult

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**BeDirectorInfo** | Pointer to [**[]BeDirectorInfo**](BeDirectorInfo.md) | beDirectorInfo | [optional] 

## Methods

### NewBeDirectorKeyResult

`func NewBeDirectorKeyResult() *BeDirectorKeyResult`

NewBeDirectorKeyResult instantiates a new BeDirectorKeyResult object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewBeDirectorKeyResultWithDefaults

`func NewBeDirectorKeyResultWithDefaults() *BeDirectorKeyResult`

NewBeDirectorKeyResultWithDefaults instantiates a new BeDirectorKeyResult object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetBeDirectorInfo

`func (o *BeDirectorKeyResult) GetBeDirectorInfo() []BeDirectorInfo`

GetBeDirectorInfo returns the BeDirectorInfo field if non-nil, zero value otherwise.

### GetBeDirectorInfoOk

`func (o *BeDirectorKeyResult) GetBeDirectorInfoOk() (*[]BeDirectorInfo, bool)`

GetBeDirectorInfoOk returns a tuple with the BeDirectorInfo field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetBeDirectorInfo

`func (o *BeDirectorKeyResult) SetBeDirectorInfo(v []BeDirectorInfo)`

SetBeDirectorInfo sets BeDirectorInfo field to given value.

### HasBeDirectorInfo

`func (o *BeDirectorKeyResult) HasBeDirectorInfo() bool`

HasBeDirectorInfo returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


