# IMEmulationKeyResult

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ImemulationInfos** | Pointer to [**[]IMEmulationInfo**](IMEmulationInfo.md) |  | [optional] 

## Methods

### NewIMEmulationKeyResult

`func NewIMEmulationKeyResult() *IMEmulationKeyResult`

NewIMEmulationKeyResult instantiates a new IMEmulationKeyResult object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewIMEmulationKeyResultWithDefaults

`func NewIMEmulationKeyResultWithDefaults() *IMEmulationKeyResult`

NewIMEmulationKeyResultWithDefaults instantiates a new IMEmulationKeyResult object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetImemulationInfos

`func (o *IMEmulationKeyResult) GetImemulationInfos() []IMEmulationInfo`

GetImemulationInfos returns the ImemulationInfos field if non-nil, zero value otherwise.

### GetImemulationInfosOk

`func (o *IMEmulationKeyResult) GetImemulationInfosOk() (*[]IMEmulationInfo, bool)`

GetImemulationInfosOk returns a tuple with the ImemulationInfos field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetImemulationInfos

`func (o *IMEmulationKeyResult) SetImemulationInfos(v []IMEmulationInfo)`

SetImemulationInfos sets ImemulationInfos field to given value.

### HasImemulationInfos

`func (o *IMEmulationKeyResult) HasImemulationInfos() bool`

HasImemulationInfos returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


