# CloudSystemDnsServer

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**DnsId** | Pointer to **string** | The IP Address of the Cloud System Dns Server | [optional] 

## Methods

### NewCloudSystemDnsServer

`func NewCloudSystemDnsServer() *CloudSystemDnsServer`

NewCloudSystemDnsServer instantiates a new CloudSystemDnsServer object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewCloudSystemDnsServerWithDefaults

`func NewCloudSystemDnsServerWithDefaults() *CloudSystemDnsServer`

NewCloudSystemDnsServerWithDefaults instantiates a new CloudSystemDnsServer object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetDnsId

`func (o *CloudSystemDnsServer) GetDnsId() string`

GetDnsId returns the DnsId field if non-nil, zero value otherwise.

### GetDnsIdOk

`func (o *CloudSystemDnsServer) GetDnsIdOk() (*string, bool)`

GetDnsIdOk returns a tuple with the DnsId field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetDnsId

`func (o *CloudSystemDnsServer) SetDnsId(v string)`

SetDnsId sets DnsId field to given value.

### HasDnsId

`func (o *CloudSystemDnsServer) HasDnsId() bool`

HasDnsId returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


