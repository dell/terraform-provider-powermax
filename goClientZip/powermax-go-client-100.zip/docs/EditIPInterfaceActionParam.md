# EditIPInterfaceActionParam

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**EditIPInterfaceOptionsParam** | Pointer to [**EditIPInterfaceOptionsParam**](EditIPInterfaceOptionsParam.md) |  | [optional] 

## Methods

### NewEditIPInterfaceActionParam

`func NewEditIPInterfaceActionParam() *EditIPInterfaceActionParam`

NewEditIPInterfaceActionParam instantiates a new EditIPInterfaceActionParam object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewEditIPInterfaceActionParamWithDefaults

`func NewEditIPInterfaceActionParamWithDefaults() *EditIPInterfaceActionParam`

NewEditIPInterfaceActionParamWithDefaults instantiates a new EditIPInterfaceActionParam object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetEditIPInterfaceOptionsParam

`func (o *EditIPInterfaceActionParam) GetEditIPInterfaceOptionsParam() EditIPInterfaceOptionsParam`

GetEditIPInterfaceOptionsParam returns the EditIPInterfaceOptionsParam field if non-nil, zero value otherwise.

### GetEditIPInterfaceOptionsParamOk

`func (o *EditIPInterfaceActionParam) GetEditIPInterfaceOptionsParamOk() (*EditIPInterfaceOptionsParam, bool)`

GetEditIPInterfaceOptionsParamOk returns a tuple with the EditIPInterfaceOptionsParam field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetEditIPInterfaceOptionsParam

`func (o *EditIPInterfaceActionParam) SetEditIPInterfaceOptionsParam(v EditIPInterfaceOptionsParam)`

SetEditIPInterfaceOptionsParam sets EditIPInterfaceOptionsParam field to given value.

### HasEditIPInterfaceOptionsParam

`func (o *EditIPInterfaceActionParam) HasEditIPInterfaceOptionsParam() bool`

HasEditIPInterfaceOptionsParam returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


