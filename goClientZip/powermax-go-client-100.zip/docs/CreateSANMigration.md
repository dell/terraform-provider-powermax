# CreateSANMigration

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Wwn** | **[]string** | The source WWN(s) to be used for the migration session | 
**TargetStorageGroupId** | **string** | The name of the migration session target storage group. | 
**SrpId** | Pointer to **string** | The name of the migration session target System SRP. | [optional] 
**PortGroupSelection** | [**PortGroupSelection**](PortGroupSelection.md) |  | 
**HostOrHostGroupSelection** | [**HostOrHostGroupSelection**](HostOrHostGroupSelection.md) |  | 
**NoCompression** | Pointer to **bool** | Create the target Storage Group without compression. Only supported when the target System and SRP support compression. | [optional] 
**Validate** | Pointer to **bool** | Just run the validation to see if the Migration can be created. Don&#39;t actually run the create itself. | [optional] 

## Methods

### NewCreateSANMigration

`func NewCreateSANMigration(wwn []string, targetStorageGroupId string, portGroupSelection PortGroupSelection, hostOrHostGroupSelection HostOrHostGroupSelection, ) *CreateSANMigration`

NewCreateSANMigration instantiates a new CreateSANMigration object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewCreateSANMigrationWithDefaults

`func NewCreateSANMigrationWithDefaults() *CreateSANMigration`

NewCreateSANMigrationWithDefaults instantiates a new CreateSANMigration object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetWwn

`func (o *CreateSANMigration) GetWwn() []string`

GetWwn returns the Wwn field if non-nil, zero value otherwise.

### GetWwnOk

`func (o *CreateSANMigration) GetWwnOk() (*[]string, bool)`

GetWwnOk returns a tuple with the Wwn field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetWwn

`func (o *CreateSANMigration) SetWwn(v []string)`

SetWwn sets Wwn field to given value.


### GetTargetStorageGroupId

`func (o *CreateSANMigration) GetTargetStorageGroupId() string`

GetTargetStorageGroupId returns the TargetStorageGroupId field if non-nil, zero value otherwise.

### GetTargetStorageGroupIdOk

`func (o *CreateSANMigration) GetTargetStorageGroupIdOk() (*string, bool)`

GetTargetStorageGroupIdOk returns a tuple with the TargetStorageGroupId field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetTargetStorageGroupId

`func (o *CreateSANMigration) SetTargetStorageGroupId(v string)`

SetTargetStorageGroupId sets TargetStorageGroupId field to given value.


### GetSrpId

`func (o *CreateSANMigration) GetSrpId() string`

GetSrpId returns the SrpId field if non-nil, zero value otherwise.

### GetSrpIdOk

`func (o *CreateSANMigration) GetSrpIdOk() (*string, bool)`

GetSrpIdOk returns a tuple with the SrpId field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetSrpId

`func (o *CreateSANMigration) SetSrpId(v string)`

SetSrpId sets SrpId field to given value.

### HasSrpId

`func (o *CreateSANMigration) HasSrpId() bool`

HasSrpId returns a boolean if a field has been set.

### GetPortGroupSelection

`func (o *CreateSANMigration) GetPortGroupSelection() PortGroupSelection`

GetPortGroupSelection returns the PortGroupSelection field if non-nil, zero value otherwise.

### GetPortGroupSelectionOk

`func (o *CreateSANMigration) GetPortGroupSelectionOk() (*PortGroupSelection, bool)`

GetPortGroupSelectionOk returns a tuple with the PortGroupSelection field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetPortGroupSelection

`func (o *CreateSANMigration) SetPortGroupSelection(v PortGroupSelection)`

SetPortGroupSelection sets PortGroupSelection field to given value.


### GetHostOrHostGroupSelection

`func (o *CreateSANMigration) GetHostOrHostGroupSelection() HostOrHostGroupSelection`

GetHostOrHostGroupSelection returns the HostOrHostGroupSelection field if non-nil, zero value otherwise.

### GetHostOrHostGroupSelectionOk

`func (o *CreateSANMigration) GetHostOrHostGroupSelectionOk() (*HostOrHostGroupSelection, bool)`

GetHostOrHostGroupSelectionOk returns a tuple with the HostOrHostGroupSelection field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetHostOrHostGroupSelection

`func (o *CreateSANMigration) SetHostOrHostGroupSelection(v HostOrHostGroupSelection)`

SetHostOrHostGroupSelection sets HostOrHostGroupSelection field to given value.


### GetNoCompression

`func (o *CreateSANMigration) GetNoCompression() bool`

GetNoCompression returns the NoCompression field if non-nil, zero value otherwise.

### GetNoCompressionOk

`func (o *CreateSANMigration) GetNoCompressionOk() (*bool, bool)`

GetNoCompressionOk returns a tuple with the NoCompression field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetNoCompression

`func (o *CreateSANMigration) SetNoCompression(v bool)`

SetNoCompression sets NoCompression field to given value.

### HasNoCompression

`func (o *CreateSANMigration) HasNoCompression() bool`

HasNoCompression returns a boolean if a field has been set.

### GetValidate

`func (o *CreateSANMigration) GetValidate() bool`

GetValidate returns the Validate field if non-nil, zero value otherwise.

### GetValidateOk

`func (o *CreateSANMigration) GetValidateOk() (*bool, bool)`

GetValidateOk returns a tuple with the Validate field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetValidate

`func (o *CreateSANMigration) SetValidate(v bool)`

SetValidate sets Validate field to given value.

### HasValidate

`func (o *CreateSANMigration) HasValidate() bool`

HasValidate returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


