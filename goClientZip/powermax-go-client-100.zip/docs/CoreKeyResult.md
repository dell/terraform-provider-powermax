# CoreKeyResult

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**CoreInfo** | Pointer to [**[]CoreInfo**](CoreInfo.md) | coreInfo | [optional] 

## Methods

### NewCoreKeyResult

`func NewCoreKeyResult() *CoreKeyResult`

NewCoreKeyResult instantiates a new CoreKeyResult object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewCoreKeyResultWithDefaults

`func NewCoreKeyResultWithDefaults() *CoreKeyResult`

NewCoreKeyResultWithDefaults instantiates a new CoreKeyResult object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetCoreInfo

`func (o *CoreKeyResult) GetCoreInfo() []CoreInfo`

GetCoreInfo returns the CoreInfo field if non-nil, zero value otherwise.

### GetCoreInfoOk

`func (o *CoreKeyResult) GetCoreInfoOk() (*[]CoreInfo, bool)`

GetCoreInfoOk returns a tuple with the CoreInfo field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetCoreInfo

`func (o *CoreKeyResult) SetCoreInfo(v []CoreInfo)`

SetCoreInfo sets CoreInfo field to given value.

### HasCoreInfo

`func (o *CoreKeyResult) HasCoreInfo() bool`

HasCoreInfo returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


