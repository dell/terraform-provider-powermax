# ArrayImpact

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**FrontEnd** | Pointer to [**ComponentImpact**](ComponentImpact.md) |  | [optional] 
**BackEnd** | Pointer to [**ComponentImpact**](ComponentImpact.md) |  | [optional] 
**Cache** | Pointer to [**ComponentImpact**](ComponentImpact.md) |  | [optional] 
**Overall** | Pointer to [**ComponentImpact**](ComponentImpact.md) |  | [optional] 

## Methods

### NewArrayImpact

`func NewArrayImpact() *ArrayImpact`

NewArrayImpact instantiates a new ArrayImpact object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewArrayImpactWithDefaults

`func NewArrayImpactWithDefaults() *ArrayImpact`

NewArrayImpactWithDefaults instantiates a new ArrayImpact object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetFrontEnd

`func (o *ArrayImpact) GetFrontEnd() ComponentImpact`

GetFrontEnd returns the FrontEnd field if non-nil, zero value otherwise.

### GetFrontEndOk

`func (o *ArrayImpact) GetFrontEndOk() (*ComponentImpact, bool)`

GetFrontEndOk returns a tuple with the FrontEnd field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetFrontEnd

`func (o *ArrayImpact) SetFrontEnd(v ComponentImpact)`

SetFrontEnd sets FrontEnd field to given value.

### HasFrontEnd

`func (o *ArrayImpact) HasFrontEnd() bool`

HasFrontEnd returns a boolean if a field has been set.

### GetBackEnd

`func (o *ArrayImpact) GetBackEnd() ComponentImpact`

GetBackEnd returns the BackEnd field if non-nil, zero value otherwise.

### GetBackEndOk

`func (o *ArrayImpact) GetBackEndOk() (*ComponentImpact, bool)`

GetBackEndOk returns a tuple with the BackEnd field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetBackEnd

`func (o *ArrayImpact) SetBackEnd(v ComponentImpact)`

SetBackEnd sets BackEnd field to given value.

### HasBackEnd

`func (o *ArrayImpact) HasBackEnd() bool`

HasBackEnd returns a boolean if a field has been set.

### GetCache

`func (o *ArrayImpact) GetCache() ComponentImpact`

GetCache returns the Cache field if non-nil, zero value otherwise.

### GetCacheOk

`func (o *ArrayImpact) GetCacheOk() (*ComponentImpact, bool)`

GetCacheOk returns a tuple with the Cache field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetCache

`func (o *ArrayImpact) SetCache(v ComponentImpact)`

SetCache sets Cache field to given value.

### HasCache

`func (o *ArrayImpact) HasCache() bool`

HasCache returns a boolean if a field has been set.

### GetOverall

`func (o *ArrayImpact) GetOverall() ComponentImpact`

GetOverall returns the Overall field if non-nil, zero value otherwise.

### GetOverallOk

`func (o *ArrayImpact) GetOverallOk() (*ComponentImpact, bool)`

GetOverallOk returns a tuple with the Overall field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetOverall

`func (o *ArrayImpact) SetOverall(v ComponentImpact)`

SetOverall sets Overall field to given value.

### HasOverall

`func (o *ArrayImpact) HasOverall() bool`

HasOverall returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


