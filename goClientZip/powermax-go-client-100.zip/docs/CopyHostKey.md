# CopyHostKey

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**SymmetrixId** | **string** | symmetrix_Id | 
**HostGroupId** | **string** | host_Group_Id | 

## Methods

### NewCopyHostKey

`func NewCopyHostKey(symmetrixId string, hostGroupId string, ) *CopyHostKey`

NewCopyHostKey instantiates a new CopyHostKey object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewCopyHostKeyWithDefaults

`func NewCopyHostKeyWithDefaults() *CopyHostKey`

NewCopyHostKeyWithDefaults instantiates a new CopyHostKey object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetSymmetrixId

`func (o *CopyHostKey) GetSymmetrixId() string`

GetSymmetrixId returns the SymmetrixId field if non-nil, zero value otherwise.

### GetSymmetrixIdOk

`func (o *CopyHostKey) GetSymmetrixIdOk() (*string, bool)`

GetSymmetrixIdOk returns a tuple with the SymmetrixId field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetSymmetrixId

`func (o *CopyHostKey) SetSymmetrixId(v string)`

SetSymmetrixId sets SymmetrixId field to given value.


### GetHostGroupId

`func (o *CopyHostKey) GetHostGroupId() string`

GetHostGroupId returns the HostGroupId field if non-nil, zero value otherwise.

### GetHostGroupIdOk

`func (o *CopyHostKey) GetHostGroupIdOk() (*string, bool)`

GetHostGroupIdOk returns a tuple with the HostGroupId field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetHostGroupId

`func (o *CopyHostKey) SetHostGroupId(v string)`

SetHostGroupId sets HostGroupId field to given value.



[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


