# LdapService

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Id** | Pointer to **string** |                          LDAP Service object identifier.                      | [optional] 
**NasServer** | Pointer to **string** |                          Id of associated Nas Server instance that uses this LDAP object.                         Only one LDAP object per Nas Server is supported.                      | [optional] 
**BaseDn** | Pointer to **string** |                          Base Distinguished Name. This is the root of the LDAP directory tree where the SDNAS server will query information.                         The base DN must be expressed in X.509 format by using the attribute dc&#x3D;. For example, if the fully-qualified domain name is mycompany.com, the base DN is dc&#x3D;mycompany,dc&#x3D;com.                      | [optional] 
**ProfileDn** | Pointer to **string** |                          For an iPlanet LDAP server, specifies the DN of the entry with the configuration profile.                      | [optional] 
**Addresses** | Pointer to **[]string** |                          IP addresses of the LDAP servers.                      | [optional] 
**PortNumber** | Pointer to **int32** |                          The TCP/IP port used by the Nas Server to connect to the LDAP servers.                         Default value for LDAP is 389 and LDAPS is 636.                      | [optional] 
**AuthenticationType** | Pointer to **string** |                          Authentication type for the LDAP server.                         - 0 - Anonymous &#x3D;&gt; Anonymous authentication means no authentication occurs and the Nas Server uses an anonymous login to access the LDAP-based directory server.                         - 1 - Simple &#x3D;&gt; Simple authentication means the Nas Server must provide a bind distinguished name and password to access the LDAP-based directory server.                         - 2 - Kerberos &#x3D;&gt; Kerberos authentication means the Nas Server uses a KDC to confirm the identity when accessing the Active Directory.                        Enumeration values: * **Anonymous** * **Simple** * **Kerberos**  | [optional] 
**Protocol** | Pointer to **string** |                          Indicates whether the LDAP protocol uses SSL for secure network communication. SSL encrypts data over the network and provides message and server authentication.                         - 0 - ldap &#x3D;&gt; LDAP protocol without SSL.                         - 1 - ldaps &#x3D;&gt; (Default) LDAP protocol with SSL. When you enable LDAPS, make sure to specify the appropriate LDAPS port (usually port 636) and to upload an LDAPS trust certificate to the LDAP server.                         - 2 - unknown &#x3D;&gt; Unknown protocol.                        Enumeration values: * **ldap** * **ldaps** * **unknown**  | [optional] 
**VerifyServerCertificate** | Pointer to **bool** |                          Indicates whether Certification Authority certificate is used to verify the LDAP server certificate for secure SSL connections. Values are:                         - {true} - verifies LDAP server&#39;s certificate.                         - {false} - doesn&#39;t verify LDAP server&#39;s certificate.                      | [optional] 
**BindDn** | Pointer to **string** |                          Bind Distinguished Name (DN) to be used when binding.                      | [optional] 
**SmbAccountUsed** | Pointer to **bool** |                          Indicates whether SMB authentication is used to authenticate to the LDAP server. Values are:                         - {true} - Indicates that the SMB settings are used for Kerberos authentication.                         - {false} - Indicates that Kerberos uses its own settings.                      | [optional] 
**Principal** | Pointer to **string** |                          Specifies the principal name for Kerberos authentication.                      | [optional] 
**Realm** | Pointer to **string** |                          Specifies the realm name for Kerberos authentication.                      | [optional] 
**SchemeType** | Pointer to **string** |                          LDAP server scheme type.                         - 0 - unknown &#x3D;&gt; Unknown LDAP scheme.                         - 1 - RFC2307 &#x3D;&gt; OpenLDAP/iPlanet scheme.                         - 2 - Microsoft &#x3D;&gt; Microsoft Identity Management for UNIX (IDMU/SFU) scheme.                        Enumeration values: * **unknown** * **RFC2307** * **Microsoft**  | [optional] 
**Health** | Pointer to [**Health**](Health.md) |  | [optional] 
**Override** | Pointer to **bool** |                          In the context of a replication, tell if the addresses list has been overridden when this object is in destination mode                      | [optional] 

## Methods

### NewLdapService

`func NewLdapService() *LdapService`

NewLdapService instantiates a new LdapService object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewLdapServiceWithDefaults

`func NewLdapServiceWithDefaults() *LdapService`

NewLdapServiceWithDefaults instantiates a new LdapService object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetId

`func (o *LdapService) GetId() string`

GetId returns the Id field if non-nil, zero value otherwise.

### GetIdOk

`func (o *LdapService) GetIdOk() (*string, bool)`

GetIdOk returns a tuple with the Id field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetId

`func (o *LdapService) SetId(v string)`

SetId sets Id field to given value.

### HasId

`func (o *LdapService) HasId() bool`

HasId returns a boolean if a field has been set.

### GetNasServer

`func (o *LdapService) GetNasServer() string`

GetNasServer returns the NasServer field if non-nil, zero value otherwise.

### GetNasServerOk

`func (o *LdapService) GetNasServerOk() (*string, bool)`

GetNasServerOk returns a tuple with the NasServer field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetNasServer

`func (o *LdapService) SetNasServer(v string)`

SetNasServer sets NasServer field to given value.

### HasNasServer

`func (o *LdapService) HasNasServer() bool`

HasNasServer returns a boolean if a field has been set.

### GetBaseDn

`func (o *LdapService) GetBaseDn() string`

GetBaseDn returns the BaseDn field if non-nil, zero value otherwise.

### GetBaseDnOk

`func (o *LdapService) GetBaseDnOk() (*string, bool)`

GetBaseDnOk returns a tuple with the BaseDn field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetBaseDn

`func (o *LdapService) SetBaseDn(v string)`

SetBaseDn sets BaseDn field to given value.

### HasBaseDn

`func (o *LdapService) HasBaseDn() bool`

HasBaseDn returns a boolean if a field has been set.

### GetProfileDn

`func (o *LdapService) GetProfileDn() string`

GetProfileDn returns the ProfileDn field if non-nil, zero value otherwise.

### GetProfileDnOk

`func (o *LdapService) GetProfileDnOk() (*string, bool)`

GetProfileDnOk returns a tuple with the ProfileDn field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetProfileDn

`func (o *LdapService) SetProfileDn(v string)`

SetProfileDn sets ProfileDn field to given value.

### HasProfileDn

`func (o *LdapService) HasProfileDn() bool`

HasProfileDn returns a boolean if a field has been set.

### GetAddresses

`func (o *LdapService) GetAddresses() []string`

GetAddresses returns the Addresses field if non-nil, zero value otherwise.

### GetAddressesOk

`func (o *LdapService) GetAddressesOk() (*[]string, bool)`

GetAddressesOk returns a tuple with the Addresses field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetAddresses

`func (o *LdapService) SetAddresses(v []string)`

SetAddresses sets Addresses field to given value.

### HasAddresses

`func (o *LdapService) HasAddresses() bool`

HasAddresses returns a boolean if a field has been set.

### GetPortNumber

`func (o *LdapService) GetPortNumber() int32`

GetPortNumber returns the PortNumber field if non-nil, zero value otherwise.

### GetPortNumberOk

`func (o *LdapService) GetPortNumberOk() (*int32, bool)`

GetPortNumberOk returns a tuple with the PortNumber field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetPortNumber

`func (o *LdapService) SetPortNumber(v int32)`

SetPortNumber sets PortNumber field to given value.

### HasPortNumber

`func (o *LdapService) HasPortNumber() bool`

HasPortNumber returns a boolean if a field has been set.

### GetAuthenticationType

`func (o *LdapService) GetAuthenticationType() string`

GetAuthenticationType returns the AuthenticationType field if non-nil, zero value otherwise.

### GetAuthenticationTypeOk

`func (o *LdapService) GetAuthenticationTypeOk() (*string, bool)`

GetAuthenticationTypeOk returns a tuple with the AuthenticationType field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetAuthenticationType

`func (o *LdapService) SetAuthenticationType(v string)`

SetAuthenticationType sets AuthenticationType field to given value.

### HasAuthenticationType

`func (o *LdapService) HasAuthenticationType() bool`

HasAuthenticationType returns a boolean if a field has been set.

### GetProtocol

`func (o *LdapService) GetProtocol() string`

GetProtocol returns the Protocol field if non-nil, zero value otherwise.

### GetProtocolOk

`func (o *LdapService) GetProtocolOk() (*string, bool)`

GetProtocolOk returns a tuple with the Protocol field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetProtocol

`func (o *LdapService) SetProtocol(v string)`

SetProtocol sets Protocol field to given value.

### HasProtocol

`func (o *LdapService) HasProtocol() bool`

HasProtocol returns a boolean if a field has been set.

### GetVerifyServerCertificate

`func (o *LdapService) GetVerifyServerCertificate() bool`

GetVerifyServerCertificate returns the VerifyServerCertificate field if non-nil, zero value otherwise.

### GetVerifyServerCertificateOk

`func (o *LdapService) GetVerifyServerCertificateOk() (*bool, bool)`

GetVerifyServerCertificateOk returns a tuple with the VerifyServerCertificate field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetVerifyServerCertificate

`func (o *LdapService) SetVerifyServerCertificate(v bool)`

SetVerifyServerCertificate sets VerifyServerCertificate field to given value.

### HasVerifyServerCertificate

`func (o *LdapService) HasVerifyServerCertificate() bool`

HasVerifyServerCertificate returns a boolean if a field has been set.

### GetBindDn

`func (o *LdapService) GetBindDn() string`

GetBindDn returns the BindDn field if non-nil, zero value otherwise.

### GetBindDnOk

`func (o *LdapService) GetBindDnOk() (*string, bool)`

GetBindDnOk returns a tuple with the BindDn field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetBindDn

`func (o *LdapService) SetBindDn(v string)`

SetBindDn sets BindDn field to given value.

### HasBindDn

`func (o *LdapService) HasBindDn() bool`

HasBindDn returns a boolean if a field has been set.

### GetSmbAccountUsed

`func (o *LdapService) GetSmbAccountUsed() bool`

GetSmbAccountUsed returns the SmbAccountUsed field if non-nil, zero value otherwise.

### GetSmbAccountUsedOk

`func (o *LdapService) GetSmbAccountUsedOk() (*bool, bool)`

GetSmbAccountUsedOk returns a tuple with the SmbAccountUsed field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetSmbAccountUsed

`func (o *LdapService) SetSmbAccountUsed(v bool)`

SetSmbAccountUsed sets SmbAccountUsed field to given value.

### HasSmbAccountUsed

`func (o *LdapService) HasSmbAccountUsed() bool`

HasSmbAccountUsed returns a boolean if a field has been set.

### GetPrincipal

`func (o *LdapService) GetPrincipal() string`

GetPrincipal returns the Principal field if non-nil, zero value otherwise.

### GetPrincipalOk

`func (o *LdapService) GetPrincipalOk() (*string, bool)`

GetPrincipalOk returns a tuple with the Principal field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetPrincipal

`func (o *LdapService) SetPrincipal(v string)`

SetPrincipal sets Principal field to given value.

### HasPrincipal

`func (o *LdapService) HasPrincipal() bool`

HasPrincipal returns a boolean if a field has been set.

### GetRealm

`func (o *LdapService) GetRealm() string`

GetRealm returns the Realm field if non-nil, zero value otherwise.

### GetRealmOk

`func (o *LdapService) GetRealmOk() (*string, bool)`

GetRealmOk returns a tuple with the Realm field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetRealm

`func (o *LdapService) SetRealm(v string)`

SetRealm sets Realm field to given value.

### HasRealm

`func (o *LdapService) HasRealm() bool`

HasRealm returns a boolean if a field has been set.

### GetSchemeType

`func (o *LdapService) GetSchemeType() string`

GetSchemeType returns the SchemeType field if non-nil, zero value otherwise.

### GetSchemeTypeOk

`func (o *LdapService) GetSchemeTypeOk() (*string, bool)`

GetSchemeTypeOk returns a tuple with the SchemeType field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetSchemeType

`func (o *LdapService) SetSchemeType(v string)`

SetSchemeType sets SchemeType field to given value.

### HasSchemeType

`func (o *LdapService) HasSchemeType() bool`

HasSchemeType returns a boolean if a field has been set.

### GetHealth

`func (o *LdapService) GetHealth() Health`

GetHealth returns the Health field if non-nil, zero value otherwise.

### GetHealthOk

`func (o *LdapService) GetHealthOk() (*Health, bool)`

GetHealthOk returns a tuple with the Health field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetHealth

`func (o *LdapService) SetHealth(v Health)`

SetHealth sets Health field to given value.

### HasHealth

`func (o *LdapService) HasHealth() bool`

HasHealth returns a boolean if a field has been set.

### GetOverride

`func (o *LdapService) GetOverride() bool`

GetOverride returns the Override field if non-nil, zero value otherwise.

### GetOverrideOk

`func (o *LdapService) GetOverrideOk() (*bool, bool)`

GetOverrideOk returns a tuple with the Override field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetOverride

`func (o *LdapService) SetOverride(v bool)`

SetOverride sets Override field to given value.

### HasOverride

`func (o *LdapService) HasOverride() bool`

HasOverride returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


