# ImDirectorKeyResult

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ImDirectorInfo** | Pointer to [**[]ImDirectorInfo**](ImDirectorInfo.md) | imDirectorInfo | [optional] 

## Methods

### NewImDirectorKeyResult

`func NewImDirectorKeyResult() *ImDirectorKeyResult`

NewImDirectorKeyResult instantiates a new ImDirectorKeyResult object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewImDirectorKeyResultWithDefaults

`func NewImDirectorKeyResultWithDefaults() *ImDirectorKeyResult`

NewImDirectorKeyResultWithDefaults instantiates a new ImDirectorKeyResult object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetImDirectorInfo

`func (o *ImDirectorKeyResult) GetImDirectorInfo() []ImDirectorInfo`

GetImDirectorInfo returns the ImDirectorInfo field if non-nil, zero value otherwise.

### GetImDirectorInfoOk

`func (o *ImDirectorKeyResult) GetImDirectorInfoOk() (*[]ImDirectorInfo, bool)`

GetImDirectorInfoOk returns a tuple with the ImDirectorInfo field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetImDirectorInfo

`func (o *ImDirectorKeyResult) SetImDirectorInfo(v []ImDirectorInfo)`

SetImDirectorInfo sets ImDirectorInfo field to given value.

### HasImDirectorInfo

`func (o *ImDirectorKeyResult) HasImDirectorInfo() bool`

HasImDirectorInfo returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


