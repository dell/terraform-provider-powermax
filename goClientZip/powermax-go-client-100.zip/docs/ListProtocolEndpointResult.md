# ListProtocolEndpointResult

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ProtocolEndpointId** | Pointer to **[]string** | The Protocol Endpoint ID. | [optional] 

## Methods

### NewListProtocolEndpointResult

`func NewListProtocolEndpointResult() *ListProtocolEndpointResult`

NewListProtocolEndpointResult instantiates a new ListProtocolEndpointResult object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewListProtocolEndpointResultWithDefaults

`func NewListProtocolEndpointResultWithDefaults() *ListProtocolEndpointResult`

NewListProtocolEndpointResultWithDefaults instantiates a new ListProtocolEndpointResult object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetProtocolEndpointId

`func (o *ListProtocolEndpointResult) GetProtocolEndpointId() []string`

GetProtocolEndpointId returns the ProtocolEndpointId field if non-nil, zero value otherwise.

### GetProtocolEndpointIdOk

`func (o *ListProtocolEndpointResult) GetProtocolEndpointIdOk() (*[]string, bool)`

GetProtocolEndpointIdOk returns a tuple with the ProtocolEndpointId field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetProtocolEndpointId

`func (o *ListProtocolEndpointResult) SetProtocolEndpointId(v []string)`

SetProtocolEndpointId sets ProtocolEndpointId field to given value.

### HasProtocolEndpointId

`func (o *ListProtocolEndpointResult) HasProtocolEndpointId() bool`

HasProtocolEndpointId returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


