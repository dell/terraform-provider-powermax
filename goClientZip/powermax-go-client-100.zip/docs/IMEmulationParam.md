# IMEmulationParam

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**StartDate** | **int64** | Starting date in millisecond. | 
**EndDate** | **int64** | Ending date in millisecond. | 
**SymmetrixId** | **string** | &lt;p&gt;The Symmetrix array ID.&lt;/p&gt; | 
**ImEmulationId** | **string** | imEmulationId | 
**DataFormat** | Pointer to **string** | &lt;p&gt;Data Format (Average or Maximum).&lt;/p&gt;   Enumeration values: * **Average** * **Maximum**  | [optional] 
**Metrics** | **[]string** | metrics   Enumeration values: * **PageInTime** -  * **PageOutTime** -  * **EnvironmetalTime** -  * **OtherTime** -  * **SymmkTotalTime** -  * **PercentBusy** - % Busy. * **TotalWorkTime** - Total Work Time.  | 

## Methods

### NewIMEmulationParam

`func NewIMEmulationParam(startDate int64, endDate int64, symmetrixId string, imEmulationId string, metrics []string, ) *IMEmulationParam`

NewIMEmulationParam instantiates a new IMEmulationParam object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewIMEmulationParamWithDefaults

`func NewIMEmulationParamWithDefaults() *IMEmulationParam`

NewIMEmulationParamWithDefaults instantiates a new IMEmulationParam object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetStartDate

`func (o *IMEmulationParam) GetStartDate() int64`

GetStartDate returns the StartDate field if non-nil, zero value otherwise.

### GetStartDateOk

`func (o *IMEmulationParam) GetStartDateOk() (*int64, bool)`

GetStartDateOk returns a tuple with the StartDate field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetStartDate

`func (o *IMEmulationParam) SetStartDate(v int64)`

SetStartDate sets StartDate field to given value.


### GetEndDate

`func (o *IMEmulationParam) GetEndDate() int64`

GetEndDate returns the EndDate field if non-nil, zero value otherwise.

### GetEndDateOk

`func (o *IMEmulationParam) GetEndDateOk() (*int64, bool)`

GetEndDateOk returns a tuple with the EndDate field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetEndDate

`func (o *IMEmulationParam) SetEndDate(v int64)`

SetEndDate sets EndDate field to given value.


### GetSymmetrixId

`func (o *IMEmulationParam) GetSymmetrixId() string`

GetSymmetrixId returns the SymmetrixId field if non-nil, zero value otherwise.

### GetSymmetrixIdOk

`func (o *IMEmulationParam) GetSymmetrixIdOk() (*string, bool)`

GetSymmetrixIdOk returns a tuple with the SymmetrixId field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetSymmetrixId

`func (o *IMEmulationParam) SetSymmetrixId(v string)`

SetSymmetrixId sets SymmetrixId field to given value.


### GetImEmulationId

`func (o *IMEmulationParam) GetImEmulationId() string`

GetImEmulationId returns the ImEmulationId field if non-nil, zero value otherwise.

### GetImEmulationIdOk

`func (o *IMEmulationParam) GetImEmulationIdOk() (*string, bool)`

GetImEmulationIdOk returns a tuple with the ImEmulationId field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetImEmulationId

`func (o *IMEmulationParam) SetImEmulationId(v string)`

SetImEmulationId sets ImEmulationId field to given value.


### GetDataFormat

`func (o *IMEmulationParam) GetDataFormat() string`

GetDataFormat returns the DataFormat field if non-nil, zero value otherwise.

### GetDataFormatOk

`func (o *IMEmulationParam) GetDataFormatOk() (*string, bool)`

GetDataFormatOk returns a tuple with the DataFormat field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetDataFormat

`func (o *IMEmulationParam) SetDataFormat(v string)`

SetDataFormat sets DataFormat field to given value.

### HasDataFormat

`func (o *IMEmulationParam) HasDataFormat() bool`

HasDataFormat returns a boolean if a field has been set.

### GetMetrics

`func (o *IMEmulationParam) GetMetrics() []string`

GetMetrics returns the Metrics field if non-nil, zero value otherwise.

### GetMetricsOk

`func (o *IMEmulationParam) GetMetricsOk() (*[]string, bool)`

GetMetricsOk returns a tuple with the Metrics field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetMetrics

`func (o *IMEmulationParam) SetMetrics(v []string)`

SetMetrics sets Metrics field to given value.



[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


