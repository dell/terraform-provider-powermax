# DmStorageArrayCapabilityList

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**StorageArrayCapability** | [**[]StorageArrayCapability**](StorageArrayCapability.md) | storageArrayCapability | 

## Methods

### NewDmStorageArrayCapabilityList

`func NewDmStorageArrayCapabilityList(storageArrayCapability []StorageArrayCapability, ) *DmStorageArrayCapabilityList`

NewDmStorageArrayCapabilityList instantiates a new DmStorageArrayCapabilityList object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewDmStorageArrayCapabilityListWithDefaults

`func NewDmStorageArrayCapabilityListWithDefaults() *DmStorageArrayCapabilityList`

NewDmStorageArrayCapabilityListWithDefaults instantiates a new DmStorageArrayCapabilityList object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetStorageArrayCapability

`func (o *DmStorageArrayCapabilityList) GetStorageArrayCapability() []StorageArrayCapability`

GetStorageArrayCapability returns the StorageArrayCapability field if non-nil, zero value otherwise.

### GetStorageArrayCapabilityOk

`func (o *DmStorageArrayCapabilityList) GetStorageArrayCapabilityOk() (*[]StorageArrayCapability, bool)`

GetStorageArrayCapabilityOk returns a tuple with the StorageArrayCapability field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetStorageArrayCapability

`func (o *DmStorageArrayCapabilityList) SetStorageArrayCapability(v []StorageArrayCapability)`

SetStorageArrayCapability sets StorageArrayCapability field to given value.



[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


