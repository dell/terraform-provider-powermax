# EditVasaProviderIpaddressParam

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Ipaddress** | Pointer to **string** | The New IP Adresss for the specified VASA Provider | [optional] 

## Methods

### NewEditVasaProviderIpaddressParam

`func NewEditVasaProviderIpaddressParam() *EditVasaProviderIpaddressParam`

NewEditVasaProviderIpaddressParam instantiates a new EditVasaProviderIpaddressParam object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewEditVasaProviderIpaddressParamWithDefaults

`func NewEditVasaProviderIpaddressParamWithDefaults() *EditVasaProviderIpaddressParam`

NewEditVasaProviderIpaddressParamWithDefaults instantiates a new EditVasaProviderIpaddressParam object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetIpaddress

`func (o *EditVasaProviderIpaddressParam) GetIpaddress() string`

GetIpaddress returns the Ipaddress field if non-nil, zero value otherwise.

### GetIpaddressOk

`func (o *EditVasaProviderIpaddressParam) GetIpaddressOk() (*string, bool)`

GetIpaddressOk returns a tuple with the Ipaddress field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetIpaddress

`func (o *EditVasaProviderIpaddressParam) SetIpaddress(v string)`

SetIpaddress sets Ipaddress field to given value.

### HasIpaddress

`func (o *EditVasaProviderIpaddressParam) HasIpaddress() bool`

HasIpaddress returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


