# HealthScoreInstanceMetric

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**InstanceName** | **string** | instance_name | 
**MetricCategory** | Pointer to **string** | metric_category | [optional] 
**MetricName** | Pointer to **string** | metric_name | [optional] 
**MetricValue** | Pointer to **float64** | metric_value | [optional] 
**Severity** | Pointer to **string** | severity | [optional] 
**HealthScoreReduction** | Pointer to **float64** | health_score_reduction | [optional] 

## Methods

### NewHealthScoreInstanceMetric

`func NewHealthScoreInstanceMetric(instanceName string, ) *HealthScoreInstanceMetric`

NewHealthScoreInstanceMetric instantiates a new HealthScoreInstanceMetric object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewHealthScoreInstanceMetricWithDefaults

`func NewHealthScoreInstanceMetricWithDefaults() *HealthScoreInstanceMetric`

NewHealthScoreInstanceMetricWithDefaults instantiates a new HealthScoreInstanceMetric object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetInstanceName

`func (o *HealthScoreInstanceMetric) GetInstanceName() string`

GetInstanceName returns the InstanceName field if non-nil, zero value otherwise.

### GetInstanceNameOk

`func (o *HealthScoreInstanceMetric) GetInstanceNameOk() (*string, bool)`

GetInstanceNameOk returns a tuple with the InstanceName field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetInstanceName

`func (o *HealthScoreInstanceMetric) SetInstanceName(v string)`

SetInstanceName sets InstanceName field to given value.


### GetMetricCategory

`func (o *HealthScoreInstanceMetric) GetMetricCategory() string`

GetMetricCategory returns the MetricCategory field if non-nil, zero value otherwise.

### GetMetricCategoryOk

`func (o *HealthScoreInstanceMetric) GetMetricCategoryOk() (*string, bool)`

GetMetricCategoryOk returns a tuple with the MetricCategory field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetMetricCategory

`func (o *HealthScoreInstanceMetric) SetMetricCategory(v string)`

SetMetricCategory sets MetricCategory field to given value.

### HasMetricCategory

`func (o *HealthScoreInstanceMetric) HasMetricCategory() bool`

HasMetricCategory returns a boolean if a field has been set.

### GetMetricName

`func (o *HealthScoreInstanceMetric) GetMetricName() string`

GetMetricName returns the MetricName field if non-nil, zero value otherwise.

### GetMetricNameOk

`func (o *HealthScoreInstanceMetric) GetMetricNameOk() (*string, bool)`

GetMetricNameOk returns a tuple with the MetricName field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetMetricName

`func (o *HealthScoreInstanceMetric) SetMetricName(v string)`

SetMetricName sets MetricName field to given value.

### HasMetricName

`func (o *HealthScoreInstanceMetric) HasMetricName() bool`

HasMetricName returns a boolean if a field has been set.

### GetMetricValue

`func (o *HealthScoreInstanceMetric) GetMetricValue() float64`

GetMetricValue returns the MetricValue field if non-nil, zero value otherwise.

### GetMetricValueOk

`func (o *HealthScoreInstanceMetric) GetMetricValueOk() (*float64, bool)`

GetMetricValueOk returns a tuple with the MetricValue field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetMetricValue

`func (o *HealthScoreInstanceMetric) SetMetricValue(v float64)`

SetMetricValue sets MetricValue field to given value.

### HasMetricValue

`func (o *HealthScoreInstanceMetric) HasMetricValue() bool`

HasMetricValue returns a boolean if a field has been set.

### GetSeverity

`func (o *HealthScoreInstanceMetric) GetSeverity() string`

GetSeverity returns the Severity field if non-nil, zero value otherwise.

### GetSeverityOk

`func (o *HealthScoreInstanceMetric) GetSeverityOk() (*string, bool)`

GetSeverityOk returns a tuple with the Severity field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetSeverity

`func (o *HealthScoreInstanceMetric) SetSeverity(v string)`

SetSeverity sets Severity field to given value.

### HasSeverity

`func (o *HealthScoreInstanceMetric) HasSeverity() bool`

HasSeverity returns a boolean if a field has been set.

### GetHealthScoreReduction

`func (o *HealthScoreInstanceMetric) GetHealthScoreReduction() float64`

GetHealthScoreReduction returns the HealthScoreReduction field if non-nil, zero value otherwise.

### GetHealthScoreReductionOk

`func (o *HealthScoreInstanceMetric) GetHealthScoreReductionOk() (*float64, bool)`

GetHealthScoreReductionOk returns a tuple with the HealthScoreReduction field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetHealthScoreReduction

`func (o *HealthScoreInstanceMetric) SetHealthScoreReduction(v float64)`

SetHealthScoreReduction sets HealthScoreReduction field to given value.

### HasHealthScoreReduction

`func (o *HealthScoreInstanceMetric) HasHealthScoreReduction() bool`

HasHealthScoreReduction returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


