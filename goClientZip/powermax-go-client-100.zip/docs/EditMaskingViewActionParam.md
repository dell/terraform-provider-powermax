# EditMaskingViewActionParam

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**RenameMaskingViewParam** | Pointer to [**RenameMaskingViewParam**](RenameMaskingViewParam.md) |  | [optional] 

## Methods

### NewEditMaskingViewActionParam

`func NewEditMaskingViewActionParam() *EditMaskingViewActionParam`

NewEditMaskingViewActionParam instantiates a new EditMaskingViewActionParam object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewEditMaskingViewActionParamWithDefaults

`func NewEditMaskingViewActionParamWithDefaults() *EditMaskingViewActionParam`

NewEditMaskingViewActionParamWithDefaults instantiates a new EditMaskingViewActionParam object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetRenameMaskingViewParam

`func (o *EditMaskingViewActionParam) GetRenameMaskingViewParam() RenameMaskingViewParam`

GetRenameMaskingViewParam returns the RenameMaskingViewParam field if non-nil, zero value otherwise.

### GetRenameMaskingViewParamOk

`func (o *EditMaskingViewActionParam) GetRenameMaskingViewParamOk() (*RenameMaskingViewParam, bool)`

GetRenameMaskingViewParamOk returns a tuple with the RenameMaskingViewParam field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetRenameMaskingViewParam

`func (o *EditMaskingViewActionParam) SetRenameMaskingViewParam(v RenameMaskingViewParam)`

SetRenameMaskingViewParam sets RenameMaskingViewParam field to given value.

### HasRenameMaskingViewParam

`func (o *EditMaskingViewActionParam) HasRenameMaskingViewParam() bool`

HasRenameMaskingViewParam returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


