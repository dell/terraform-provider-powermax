# EmDirectorKeyResult

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**EmDirectorInfo** | Pointer to [**[]EmDirectorInfo**](EmDirectorInfo.md) | emDirectorInfo | [optional] 

## Methods

### NewEmDirectorKeyResult

`func NewEmDirectorKeyResult() *EmDirectorKeyResult`

NewEmDirectorKeyResult instantiates a new EmDirectorKeyResult object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewEmDirectorKeyResultWithDefaults

`func NewEmDirectorKeyResultWithDefaults() *EmDirectorKeyResult`

NewEmDirectorKeyResultWithDefaults instantiates a new EmDirectorKeyResult object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetEmDirectorInfo

`func (o *EmDirectorKeyResult) GetEmDirectorInfo() []EmDirectorInfo`

GetEmDirectorInfo returns the EmDirectorInfo field if non-nil, zero value otherwise.

### GetEmDirectorInfoOk

`func (o *EmDirectorKeyResult) GetEmDirectorInfoOk() (*[]EmDirectorInfo, bool)`

GetEmDirectorInfoOk returns a tuple with the EmDirectorInfo field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetEmDirectorInfo

`func (o *EmDirectorKeyResult) SetEmDirectorInfo(v []EmDirectorInfo)`

SetEmDirectorInfo sets EmDirectorInfo field to given value.

### HasEmDirectorInfo

`func (o *EmDirectorKeyResult) HasEmDirectorInfo() bool`

HasEmDirectorInfo returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


