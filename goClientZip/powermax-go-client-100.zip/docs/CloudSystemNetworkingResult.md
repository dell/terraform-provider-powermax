# CloudSystemNetworkingResult

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**NumOfInterfaces** | Pointer to **int32** | The number of Interfaces associated with the Cloud System | [optional] 
**NumOfTeams** | Pointer to **int32** | The number of NIC Teams associated with the Cloud System | [optional] 
**NumOfRoutes** | Pointer to **int32** | The number of routes associated with the Cloud System | [optional] 
**NumOfDnsServers** | Pointer to **int32** | The number of DNS Servers associated with the Cloud System | [optional] 
**BandwidthThrottling** | Pointer to [**BandwidthThrottling**](BandwidthThrottling.md) |  | [optional] 

## Methods

### NewCloudSystemNetworkingResult

`func NewCloudSystemNetworkingResult() *CloudSystemNetworkingResult`

NewCloudSystemNetworkingResult instantiates a new CloudSystemNetworkingResult object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewCloudSystemNetworkingResultWithDefaults

`func NewCloudSystemNetworkingResultWithDefaults() *CloudSystemNetworkingResult`

NewCloudSystemNetworkingResultWithDefaults instantiates a new CloudSystemNetworkingResult object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetNumOfInterfaces

`func (o *CloudSystemNetworkingResult) GetNumOfInterfaces() int32`

GetNumOfInterfaces returns the NumOfInterfaces field if non-nil, zero value otherwise.

### GetNumOfInterfacesOk

`func (o *CloudSystemNetworkingResult) GetNumOfInterfacesOk() (*int32, bool)`

GetNumOfInterfacesOk returns a tuple with the NumOfInterfaces field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetNumOfInterfaces

`func (o *CloudSystemNetworkingResult) SetNumOfInterfaces(v int32)`

SetNumOfInterfaces sets NumOfInterfaces field to given value.

### HasNumOfInterfaces

`func (o *CloudSystemNetworkingResult) HasNumOfInterfaces() bool`

HasNumOfInterfaces returns a boolean if a field has been set.

### GetNumOfTeams

`func (o *CloudSystemNetworkingResult) GetNumOfTeams() int32`

GetNumOfTeams returns the NumOfTeams field if non-nil, zero value otherwise.

### GetNumOfTeamsOk

`func (o *CloudSystemNetworkingResult) GetNumOfTeamsOk() (*int32, bool)`

GetNumOfTeamsOk returns a tuple with the NumOfTeams field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetNumOfTeams

`func (o *CloudSystemNetworkingResult) SetNumOfTeams(v int32)`

SetNumOfTeams sets NumOfTeams field to given value.

### HasNumOfTeams

`func (o *CloudSystemNetworkingResult) HasNumOfTeams() bool`

HasNumOfTeams returns a boolean if a field has been set.

### GetNumOfRoutes

`func (o *CloudSystemNetworkingResult) GetNumOfRoutes() int32`

GetNumOfRoutes returns the NumOfRoutes field if non-nil, zero value otherwise.

### GetNumOfRoutesOk

`func (o *CloudSystemNetworkingResult) GetNumOfRoutesOk() (*int32, bool)`

GetNumOfRoutesOk returns a tuple with the NumOfRoutes field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetNumOfRoutes

`func (o *CloudSystemNetworkingResult) SetNumOfRoutes(v int32)`

SetNumOfRoutes sets NumOfRoutes field to given value.

### HasNumOfRoutes

`func (o *CloudSystemNetworkingResult) HasNumOfRoutes() bool`

HasNumOfRoutes returns a boolean if a field has been set.

### GetNumOfDnsServers

`func (o *CloudSystemNetworkingResult) GetNumOfDnsServers() int32`

GetNumOfDnsServers returns the NumOfDnsServers field if non-nil, zero value otherwise.

### GetNumOfDnsServersOk

`func (o *CloudSystemNetworkingResult) GetNumOfDnsServersOk() (*int32, bool)`

GetNumOfDnsServersOk returns a tuple with the NumOfDnsServers field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetNumOfDnsServers

`func (o *CloudSystemNetworkingResult) SetNumOfDnsServers(v int32)`

SetNumOfDnsServers sets NumOfDnsServers field to given value.

### HasNumOfDnsServers

`func (o *CloudSystemNetworkingResult) HasNumOfDnsServers() bool`

HasNumOfDnsServers returns a boolean if a field has been set.

### GetBandwidthThrottling

`func (o *CloudSystemNetworkingResult) GetBandwidthThrottling() BandwidthThrottling`

GetBandwidthThrottling returns the BandwidthThrottling field if non-nil, zero value otherwise.

### GetBandwidthThrottlingOk

`func (o *CloudSystemNetworkingResult) GetBandwidthThrottlingOk() (*BandwidthThrottling, bool)`

GetBandwidthThrottlingOk returns a tuple with the BandwidthThrottling field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetBandwidthThrottling

`func (o *CloudSystemNetworkingResult) SetBandwidthThrottling(v BandwidthThrottling)`

SetBandwidthThrottling sets BandwidthThrottling field to given value.

### HasBandwidthThrottling

`func (o *CloudSystemNetworkingResult) HasBandwidthThrottling() bool`

HasBandwidthThrottling returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


