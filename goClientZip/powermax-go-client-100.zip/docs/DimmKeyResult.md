# DimmKeyResult

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**DimmInfo** | Pointer to [**[]DimmInfo**](DimmInfo.md) | dimmInfo | [optional] 

## Methods

### NewDimmKeyResult

`func NewDimmKeyResult() *DimmKeyResult`

NewDimmKeyResult instantiates a new DimmKeyResult object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewDimmKeyResultWithDefaults

`func NewDimmKeyResultWithDefaults() *DimmKeyResult`

NewDimmKeyResultWithDefaults instantiates a new DimmKeyResult object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetDimmInfo

`func (o *DimmKeyResult) GetDimmInfo() []DimmInfo`

GetDimmInfo returns the DimmInfo field if non-nil, zero value otherwise.

### GetDimmInfoOk

`func (o *DimmKeyResult) GetDimmInfoOk() (*[]DimmInfo, bool)`

GetDimmInfoOk returns a tuple with the DimmInfo field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetDimmInfo

`func (o *DimmKeyResult) SetDimmInfo(v []DimmInfo)`

SetDimmInfo sets DimmInfo field to given value.

### HasDimmInfo

`func (o *DimmKeyResult) HasDimmInfo() bool`

HasDimmInfo returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


