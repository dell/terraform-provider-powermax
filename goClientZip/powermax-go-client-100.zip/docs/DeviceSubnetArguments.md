# DeviceSubnetArguments

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**SourceDevice** | Pointer to **[]string** |                          FDN of the source device                      | [optional] 
**TargetDevice** | Pointer to **[]string** |                          FDN of the target device                      | [optional] 
**Subnetv4** | Pointer to **string** |                          The value of the subnet                      | [optional] 
**Subnetv6** | Pointer to **string** |                          The value of the subnet                      | [optional] 

## Methods

### NewDeviceSubnetArguments

`func NewDeviceSubnetArguments() *DeviceSubnetArguments`

NewDeviceSubnetArguments instantiates a new DeviceSubnetArguments object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewDeviceSubnetArgumentsWithDefaults

`func NewDeviceSubnetArgumentsWithDefaults() *DeviceSubnetArguments`

NewDeviceSubnetArgumentsWithDefaults instantiates a new DeviceSubnetArguments object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetSourceDevice

`func (o *DeviceSubnetArguments) GetSourceDevice() []string`

GetSourceDevice returns the SourceDevice field if non-nil, zero value otherwise.

### GetSourceDeviceOk

`func (o *DeviceSubnetArguments) GetSourceDeviceOk() (*[]string, bool)`

GetSourceDeviceOk returns a tuple with the SourceDevice field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetSourceDevice

`func (o *DeviceSubnetArguments) SetSourceDevice(v []string)`

SetSourceDevice sets SourceDevice field to given value.

### HasSourceDevice

`func (o *DeviceSubnetArguments) HasSourceDevice() bool`

HasSourceDevice returns a boolean if a field has been set.

### GetTargetDevice

`func (o *DeviceSubnetArguments) GetTargetDevice() []string`

GetTargetDevice returns the TargetDevice field if non-nil, zero value otherwise.

### GetTargetDeviceOk

`func (o *DeviceSubnetArguments) GetTargetDeviceOk() (*[]string, bool)`

GetTargetDeviceOk returns a tuple with the TargetDevice field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetTargetDevice

`func (o *DeviceSubnetArguments) SetTargetDevice(v []string)`

SetTargetDevice sets TargetDevice field to given value.

### HasTargetDevice

`func (o *DeviceSubnetArguments) HasTargetDevice() bool`

HasTargetDevice returns a boolean if a field has been set.

### GetSubnetv4

`func (o *DeviceSubnetArguments) GetSubnetv4() string`

GetSubnetv4 returns the Subnetv4 field if non-nil, zero value otherwise.

### GetSubnetv4Ok

`func (o *DeviceSubnetArguments) GetSubnetv4Ok() (*string, bool)`

GetSubnetv4Ok returns a tuple with the Subnetv4 field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetSubnetv4

`func (o *DeviceSubnetArguments) SetSubnetv4(v string)`

SetSubnetv4 sets Subnetv4 field to given value.

### HasSubnetv4

`func (o *DeviceSubnetArguments) HasSubnetv4() bool`

HasSubnetv4 returns a boolean if a field has been set.

### GetSubnetv6

`func (o *DeviceSubnetArguments) GetSubnetv6() string`

GetSubnetv6 returns the Subnetv6 field if non-nil, zero value otherwise.

### GetSubnetv6Ok

`func (o *DeviceSubnetArguments) GetSubnetv6Ok() (*string, bool)`

GetSubnetv6Ok returns a tuple with the Subnetv6 field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetSubnetv6

`func (o *DeviceSubnetArguments) SetSubnetv6(v string)`

SetSubnetv6 sets Subnetv6 field to given value.

### HasSubnetv6

`func (o *DeviceSubnetArguments) HasSubnetv6() bool`

HasSubnetv6 returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


