# ArrayBackupParam

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**SymmetrixId** | **string** | &lt;p&gt;The local Symmetrix array ID.&lt;/p&gt; | 
**Filename** | **string** | &lt;p&gt;Filename saved as ({symmID}_YYYYMMDDHHmm_GMT_{filename}_SPABackup.dat)&lt;/p&gt; | 
**Lastdayofdiagnostic** | **bool** | &lt;p&gt;True means Backup last day of diagnostic data(5 mins intervals)&lt;/p&gt; | 
**Namedrealtimetraces** | **bool** | &lt;p&gt;True means Backup Named Real Time Traces.)&lt;/p&gt; | 

## Methods

### NewArrayBackupParam

`func NewArrayBackupParam(symmetrixId string, filename string, lastdayofdiagnostic bool, namedrealtimetraces bool, ) *ArrayBackupParam`

NewArrayBackupParam instantiates a new ArrayBackupParam object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewArrayBackupParamWithDefaults

`func NewArrayBackupParamWithDefaults() *ArrayBackupParam`

NewArrayBackupParamWithDefaults instantiates a new ArrayBackupParam object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetSymmetrixId

`func (o *ArrayBackupParam) GetSymmetrixId() string`

GetSymmetrixId returns the SymmetrixId field if non-nil, zero value otherwise.

### GetSymmetrixIdOk

`func (o *ArrayBackupParam) GetSymmetrixIdOk() (*string, bool)`

GetSymmetrixIdOk returns a tuple with the SymmetrixId field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetSymmetrixId

`func (o *ArrayBackupParam) SetSymmetrixId(v string)`

SetSymmetrixId sets SymmetrixId field to given value.


### GetFilename

`func (o *ArrayBackupParam) GetFilename() string`

GetFilename returns the Filename field if non-nil, zero value otherwise.

### GetFilenameOk

`func (o *ArrayBackupParam) GetFilenameOk() (*string, bool)`

GetFilenameOk returns a tuple with the Filename field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetFilename

`func (o *ArrayBackupParam) SetFilename(v string)`

SetFilename sets Filename field to given value.


### GetLastdayofdiagnostic

`func (o *ArrayBackupParam) GetLastdayofdiagnostic() bool`

GetLastdayofdiagnostic returns the Lastdayofdiagnostic field if non-nil, zero value otherwise.

### GetLastdayofdiagnosticOk

`func (o *ArrayBackupParam) GetLastdayofdiagnosticOk() (*bool, bool)`

GetLastdayofdiagnosticOk returns a tuple with the Lastdayofdiagnostic field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetLastdayofdiagnostic

`func (o *ArrayBackupParam) SetLastdayofdiagnostic(v bool)`

SetLastdayofdiagnostic sets Lastdayofdiagnostic field to given value.


### GetNamedrealtimetraces

`func (o *ArrayBackupParam) GetNamedrealtimetraces() bool`

GetNamedrealtimetraces returns the Namedrealtimetraces field if non-nil, zero value otherwise.

### GetNamedrealtimetracesOk

`func (o *ArrayBackupParam) GetNamedrealtimetracesOk() (*bool, bool)`

GetNamedrealtimetracesOk returns a tuple with the Namedrealtimetraces field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetNamedrealtimetraces

`func (o *ArrayBackupParam) SetNamedrealtimetraces(v bool)`

SetNamedrealtimetraces sets Namedrealtimetraces field to given value.



[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


