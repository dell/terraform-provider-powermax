# FiconEmulationThreadInfo

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**FirstAvailableDate** | Pointer to **int64** |  | [optional] 
**LastAvailableDate** | Pointer to **int64** |  | [optional] 
**FiconEmulationThreadId** | **string** | ficonEmulationThreadId | 

## Methods

### NewFiconEmulationThreadInfo

`func NewFiconEmulationThreadInfo(ficonEmulationThreadId string, ) *FiconEmulationThreadInfo`

NewFiconEmulationThreadInfo instantiates a new FiconEmulationThreadInfo object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewFiconEmulationThreadInfoWithDefaults

`func NewFiconEmulationThreadInfoWithDefaults() *FiconEmulationThreadInfo`

NewFiconEmulationThreadInfoWithDefaults instantiates a new FiconEmulationThreadInfo object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetFirstAvailableDate

`func (o *FiconEmulationThreadInfo) GetFirstAvailableDate() int64`

GetFirstAvailableDate returns the FirstAvailableDate field if non-nil, zero value otherwise.

### GetFirstAvailableDateOk

`func (o *FiconEmulationThreadInfo) GetFirstAvailableDateOk() (*int64, bool)`

GetFirstAvailableDateOk returns a tuple with the FirstAvailableDate field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetFirstAvailableDate

`func (o *FiconEmulationThreadInfo) SetFirstAvailableDate(v int64)`

SetFirstAvailableDate sets FirstAvailableDate field to given value.

### HasFirstAvailableDate

`func (o *FiconEmulationThreadInfo) HasFirstAvailableDate() bool`

HasFirstAvailableDate returns a boolean if a field has been set.

### GetLastAvailableDate

`func (o *FiconEmulationThreadInfo) GetLastAvailableDate() int64`

GetLastAvailableDate returns the LastAvailableDate field if non-nil, zero value otherwise.

### GetLastAvailableDateOk

`func (o *FiconEmulationThreadInfo) GetLastAvailableDateOk() (*int64, bool)`

GetLastAvailableDateOk returns a tuple with the LastAvailableDate field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetLastAvailableDate

`func (o *FiconEmulationThreadInfo) SetLastAvailableDate(v int64)`

SetLastAvailableDate sets LastAvailableDate field to given value.

### HasLastAvailableDate

`func (o *FiconEmulationThreadInfo) HasLastAvailableDate() bool`

HasLastAvailableDate returns a boolean if a field has been set.

### GetFiconEmulationThreadId

`func (o *FiconEmulationThreadInfo) GetFiconEmulationThreadId() string`

GetFiconEmulationThreadId returns the FiconEmulationThreadId field if non-nil, zero value otherwise.

### GetFiconEmulationThreadIdOk

`func (o *FiconEmulationThreadInfo) GetFiconEmulationThreadIdOk() (*string, bool)`

GetFiconEmulationThreadIdOk returns a tuple with the FiconEmulationThreadId field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetFiconEmulationThreadId

`func (o *FiconEmulationThreadInfo) SetFiconEmulationThreadId(v string)`

SetFiconEmulationThreadId sets FiconEmulationThreadId field to given value.



[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


