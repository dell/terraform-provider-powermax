# FePortInfo

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**FirstAvailableDate** | Pointer to **int64** |  | [optional] 
**LastAvailableDate** | Pointer to **int64** |  | [optional] 
**PortId** | **string** | portId | 

## Methods

### NewFePortInfo

`func NewFePortInfo(portId string, ) *FePortInfo`

NewFePortInfo instantiates a new FePortInfo object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewFePortInfoWithDefaults

`func NewFePortInfoWithDefaults() *FePortInfo`

NewFePortInfoWithDefaults instantiates a new FePortInfo object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetFirstAvailableDate

`func (o *FePortInfo) GetFirstAvailableDate() int64`

GetFirstAvailableDate returns the FirstAvailableDate field if non-nil, zero value otherwise.

### GetFirstAvailableDateOk

`func (o *FePortInfo) GetFirstAvailableDateOk() (*int64, bool)`

GetFirstAvailableDateOk returns a tuple with the FirstAvailableDate field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetFirstAvailableDate

`func (o *FePortInfo) SetFirstAvailableDate(v int64)`

SetFirstAvailableDate sets FirstAvailableDate field to given value.

### HasFirstAvailableDate

`func (o *FePortInfo) HasFirstAvailableDate() bool`

HasFirstAvailableDate returns a boolean if a field has been set.

### GetLastAvailableDate

`func (o *FePortInfo) GetLastAvailableDate() int64`

GetLastAvailableDate returns the LastAvailableDate field if non-nil, zero value otherwise.

### GetLastAvailableDateOk

`func (o *FePortInfo) GetLastAvailableDateOk() (*int64, bool)`

GetLastAvailableDateOk returns a tuple with the LastAvailableDate field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetLastAvailableDate

`func (o *FePortInfo) SetLastAvailableDate(v int64)`

SetLastAvailableDate sets LastAvailableDate field to given value.

### HasLastAvailableDate

`func (o *FePortInfo) HasLastAvailableDate() bool`

HasLastAvailableDate returns a boolean if a field has been set.

### GetPortId

`func (o *FePortInfo) GetPortId() string`

GetPortId returns the PortId field if non-nil, zero value otherwise.

### GetPortIdOk

`func (o *FePortInfo) GetPortIdOk() (*string, bool)`

GetPortIdOk returns a tuple with the PortId field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetPortId

`func (o *FePortInfo) SetPortId(v string)`

SetPortId sets PortId field to given value.



[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


