# EditCloudSystemNetworkingParam

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ExecutionOption** | Pointer to **string** |  | [optional] [default to "SYNCHRONOUS"]
**EditCloudSystemNetworkingAction** | [**EditCloudSystemNetworkingActionParam**](EditCloudSystemNetworkingActionParam.md) |  | 

## Methods

### NewEditCloudSystemNetworkingParam

`func NewEditCloudSystemNetworkingParam(editCloudSystemNetworkingAction EditCloudSystemNetworkingActionParam, ) *EditCloudSystemNetworkingParam`

NewEditCloudSystemNetworkingParam instantiates a new EditCloudSystemNetworkingParam object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewEditCloudSystemNetworkingParamWithDefaults

`func NewEditCloudSystemNetworkingParamWithDefaults() *EditCloudSystemNetworkingParam`

NewEditCloudSystemNetworkingParamWithDefaults instantiates a new EditCloudSystemNetworkingParam object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetExecutionOption

`func (o *EditCloudSystemNetworkingParam) GetExecutionOption() string`

GetExecutionOption returns the ExecutionOption field if non-nil, zero value otherwise.

### GetExecutionOptionOk

`func (o *EditCloudSystemNetworkingParam) GetExecutionOptionOk() (*string, bool)`

GetExecutionOptionOk returns a tuple with the ExecutionOption field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetExecutionOption

`func (o *EditCloudSystemNetworkingParam) SetExecutionOption(v string)`

SetExecutionOption sets ExecutionOption field to given value.

### HasExecutionOption

`func (o *EditCloudSystemNetworkingParam) HasExecutionOption() bool`

HasExecutionOption returns a boolean if a field has been set.

### GetEditCloudSystemNetworkingAction

`func (o *EditCloudSystemNetworkingParam) GetEditCloudSystemNetworkingAction() EditCloudSystemNetworkingActionParam`

GetEditCloudSystemNetworkingAction returns the EditCloudSystemNetworkingAction field if non-nil, zero value otherwise.

### GetEditCloudSystemNetworkingActionOk

`func (o *EditCloudSystemNetworkingParam) GetEditCloudSystemNetworkingActionOk() (*EditCloudSystemNetworkingActionParam, bool)`

GetEditCloudSystemNetworkingActionOk returns a tuple with the EditCloudSystemNetworkingAction field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetEditCloudSystemNetworkingAction

`func (o *EditCloudSystemNetworkingParam) SetEditCloudSystemNetworkingAction(v EditCloudSystemNetworkingActionParam)`

SetEditCloudSystemNetworkingAction sets EditCloudSystemNetworkingAction field to given value.



[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


