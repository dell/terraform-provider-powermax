# FilesystemCloneArguments

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Name** | **string** |                      Name of the clone                  | 
**Description** | Pointer to **string** |                              Description of the clone                  | [optional] 
**ServiceLevel** | Pointer to **string** |                      Service Level Object                    Enumeration values: * **Optimized** * **Bronze** * **Silver** * **Gold** * **Diamond** * **Platinum**  | [optional] [default to "Optimized"]
**DataReduction** | Pointer to **bool** |                      Platform attribute                     - true if data_reduction enabled                     - false if data_reduction disabled                  | [optional] 
**NasServer** | Pointer to **string** |                      Object ID of the NAS server for the filesystem                  | [optional] 
**SizeTotal** | **int64** |                      Size, in MiB, that the system presents to the host or end user.                  | 
**FsType** | Pointer to **string** |                      - 1: filesystem                     - 2: VMWare file system                    Enumeration values: * **General** * **VMWare**  | [optional] [default to "General"]
**AccessPolicy** | Pointer to **string** |                      File system or protocol snap security access policies.                     - 0: Native Security.                     - 1: UNIX Security.                     - 2: Windows Security.                    Enumeration values: * **Native** * **UNIX** * **Windows**  | [optional] [default to "Native"]
**LockingPolicy** | Pointer to **string** |                      File system or protocol snap locking policies. These policy choices control whether the NFSv4 range locks must be honored. Because NFSv3 is advisory by design, this policy allows specifying whether the NFSv4 locking feature behaves like NFSv3 (advisory mode) in order to be backward compatible with applications expecting an advisory locking scheme.                     - 0: Advisory - No lock checking for NFS and honor SMB lock range only for SMB.                     - 1: Mandatory - Honor SMB and NFS lock range.                    Enumeration values: * **Advisory** * **Mandatory**  | [optional] [default to "Advisory"]
**FolderRenamePolicy** | Pointer to **string** |                      File system or protocol snap folder rename policies. These policy choices control whether directory can be renamed from NFS or SMB clients if at least one file is opened in the directory or in one of its child directories.                     - 0: SMB_Rename_Forbidden - A directory rename from the SMB protocol will be denied if at least one file is opened in the directory or in one of its child directories.                     - 1: All_Rename_Forbidden - Any directory rename request will be denied regardless of the protocol used, if at least one file is opened in the directory or in one of its child directories.                     - 2: All_Rename_Allowed - All protocols are allowed to rename directories without any restrictions.                     Enumeration values: * **SMB_Rename_Forbidden** * **All_Rename_Forbidden** * **All_Rename_Allowed**  | [optional] [default to "SMB_Rename_Forbidden"]
**EventNotifications** | Pointer to **string** |                      State of the event notification services for file system or protocol snap.                     - 0 : off                     - 1 : smb only notifications                     - 2 : nfs only notifications                     - 3 : smb and nfs notifications                    Enumeration values: * **off** * **SMB** * **NFS** * **SMB_NFS**  | [optional] [default to "off"]
**SmbSyncWrites** | Pointer to **bool** |                      Indicates whether the synchronous writes option is enabled on the file system. Values are:                     - true - Synchronous writes option is enabled on the file system.                     - false - Synchronous writes option is disabled on the file system.                  | [optional] 
**SmbNoNotify** | Pointer to **bool** |                      Indicates whether notifications of changes to directory file structure are enabled.                     - true - Notifications are enabled.                     - false - Notifications are disabled.                  | [optional] 
**SmbOpLocks** | Pointer to **bool** |                      Indicates whether opportunistic file locking is enabled on the file system. Values are:                     - true - Opportunistic file locking is enabled on the file system.                     - false - Opportunistic file locking is disabled on the file system.                  | [optional] 
**SmbNotifyOnAccess** | Pointer to **bool** |                      Indicates whether notifications on file access are enabled on the file system. Values are:                     - true - Notifications on file access are enabled on the file system.                     - false - Notifications on file access are disabled on the file system.                  | [optional] 
**SmbNotifyOnWrite** | Pointer to **bool** |                      Indicates whether notifications on file writes are enabled on the file system. Values are:                     - true - Notifications on file writes are enabled on the file system.                     - false - Notifications on file writes are disabled on the file system.                  | [optional] 
**SmbNotifyOnChangeDirDepth** | Pointer to **int32** |                      Lowest directory level to which the enabled notifications apply, if any.                  | [optional] 
**AsyncMtime** | Pointer to **bool** |                      Indicates whether asynchronous MTIME is enabled on the file system. Values are:                     - true - asynchronous MTIME is enabled on the file system.                     - false - asynchronous MTIME is disabled on the file system.                  | [optional] 
**HostIoblockSize** | Pointer to **int32** |                      Typical size of writes from the server or other computer using the file system or LUN to the storage system. This setting is used to match the storage block size to the I/O of the primary application using the storage, which can optimize performance. Choose one of the suggested applications if you are using one of them, or check the setup guide or performance tuning information for the primary application, or stay with default 8K size for general use.  For create operation applies only to vmware datastore fstype filesystems:                     - 8192: General_8K - Host I/O size is 8K for general purpose                     - 16384: General_16K - Host I/O size is 16K for general purpose                     - 32768: General_32K - Host I/O size is 32K for general purpose                     - 65536: General_64K - Host I/O size is 64K for general purpose                  | [optional] [default to 8192]
**ForceFlrClone** | Pointer to **bool** |                      Specifies whether an FLR-C file system should be cloned.  Values are:                     - true - Cloning an FLR-C file system is allowed.                     - false - Cloning an FLR-C file system is not allowed and any attempt to do so will return an error.                  | [optional] 
**InfoThreshold** | Pointer to **int32** |                      The info threshold will trigger info event if the file system used space exceeds this threshold. Default value is 0 (disabled).                  | [optional] 
**HighThreshold** | Pointer to **int32** |                      The high threshold will trigger info event if the file system used space exceeds this threshold. Default value is 75%. (set to 0 to disable)                  | [optional] 
**WarningThreshold** | Pointer to **int32** |                      The warning threshold will trigger alert event if the file system used space exceeds this threshold. Default value is 95%. (set to 0 to disable)                  | [optional] 

## Methods

### NewFilesystemCloneArguments

`func NewFilesystemCloneArguments(name string, sizeTotal int64, ) *FilesystemCloneArguments`

NewFilesystemCloneArguments instantiates a new FilesystemCloneArguments object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewFilesystemCloneArgumentsWithDefaults

`func NewFilesystemCloneArgumentsWithDefaults() *FilesystemCloneArguments`

NewFilesystemCloneArgumentsWithDefaults instantiates a new FilesystemCloneArguments object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetName

`func (o *FilesystemCloneArguments) GetName() string`

GetName returns the Name field if non-nil, zero value otherwise.

### GetNameOk

`func (o *FilesystemCloneArguments) GetNameOk() (*string, bool)`

GetNameOk returns a tuple with the Name field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetName

`func (o *FilesystemCloneArguments) SetName(v string)`

SetName sets Name field to given value.


### GetDescription

`func (o *FilesystemCloneArguments) GetDescription() string`

GetDescription returns the Description field if non-nil, zero value otherwise.

### GetDescriptionOk

`func (o *FilesystemCloneArguments) GetDescriptionOk() (*string, bool)`

GetDescriptionOk returns a tuple with the Description field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetDescription

`func (o *FilesystemCloneArguments) SetDescription(v string)`

SetDescription sets Description field to given value.

### HasDescription

`func (o *FilesystemCloneArguments) HasDescription() bool`

HasDescription returns a boolean if a field has been set.

### GetServiceLevel

`func (o *FilesystemCloneArguments) GetServiceLevel() string`

GetServiceLevel returns the ServiceLevel field if non-nil, zero value otherwise.

### GetServiceLevelOk

`func (o *FilesystemCloneArguments) GetServiceLevelOk() (*string, bool)`

GetServiceLevelOk returns a tuple with the ServiceLevel field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetServiceLevel

`func (o *FilesystemCloneArguments) SetServiceLevel(v string)`

SetServiceLevel sets ServiceLevel field to given value.

### HasServiceLevel

`func (o *FilesystemCloneArguments) HasServiceLevel() bool`

HasServiceLevel returns a boolean if a field has been set.

### GetDataReduction

`func (o *FilesystemCloneArguments) GetDataReduction() bool`

GetDataReduction returns the DataReduction field if non-nil, zero value otherwise.

### GetDataReductionOk

`func (o *FilesystemCloneArguments) GetDataReductionOk() (*bool, bool)`

GetDataReductionOk returns a tuple with the DataReduction field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetDataReduction

`func (o *FilesystemCloneArguments) SetDataReduction(v bool)`

SetDataReduction sets DataReduction field to given value.

### HasDataReduction

`func (o *FilesystemCloneArguments) HasDataReduction() bool`

HasDataReduction returns a boolean if a field has been set.

### GetNasServer

`func (o *FilesystemCloneArguments) GetNasServer() string`

GetNasServer returns the NasServer field if non-nil, zero value otherwise.

### GetNasServerOk

`func (o *FilesystemCloneArguments) GetNasServerOk() (*string, bool)`

GetNasServerOk returns a tuple with the NasServer field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetNasServer

`func (o *FilesystemCloneArguments) SetNasServer(v string)`

SetNasServer sets NasServer field to given value.

### HasNasServer

`func (o *FilesystemCloneArguments) HasNasServer() bool`

HasNasServer returns a boolean if a field has been set.

### GetSizeTotal

`func (o *FilesystemCloneArguments) GetSizeTotal() int64`

GetSizeTotal returns the SizeTotal field if non-nil, zero value otherwise.

### GetSizeTotalOk

`func (o *FilesystemCloneArguments) GetSizeTotalOk() (*int64, bool)`

GetSizeTotalOk returns a tuple with the SizeTotal field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetSizeTotal

`func (o *FilesystemCloneArguments) SetSizeTotal(v int64)`

SetSizeTotal sets SizeTotal field to given value.


### GetFsType

`func (o *FilesystemCloneArguments) GetFsType() string`

GetFsType returns the FsType field if non-nil, zero value otherwise.

### GetFsTypeOk

`func (o *FilesystemCloneArguments) GetFsTypeOk() (*string, bool)`

GetFsTypeOk returns a tuple with the FsType field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetFsType

`func (o *FilesystemCloneArguments) SetFsType(v string)`

SetFsType sets FsType field to given value.

### HasFsType

`func (o *FilesystemCloneArguments) HasFsType() bool`

HasFsType returns a boolean if a field has been set.

### GetAccessPolicy

`func (o *FilesystemCloneArguments) GetAccessPolicy() string`

GetAccessPolicy returns the AccessPolicy field if non-nil, zero value otherwise.

### GetAccessPolicyOk

`func (o *FilesystemCloneArguments) GetAccessPolicyOk() (*string, bool)`

GetAccessPolicyOk returns a tuple with the AccessPolicy field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetAccessPolicy

`func (o *FilesystemCloneArguments) SetAccessPolicy(v string)`

SetAccessPolicy sets AccessPolicy field to given value.

### HasAccessPolicy

`func (o *FilesystemCloneArguments) HasAccessPolicy() bool`

HasAccessPolicy returns a boolean if a field has been set.

### GetLockingPolicy

`func (o *FilesystemCloneArguments) GetLockingPolicy() string`

GetLockingPolicy returns the LockingPolicy field if non-nil, zero value otherwise.

### GetLockingPolicyOk

`func (o *FilesystemCloneArguments) GetLockingPolicyOk() (*string, bool)`

GetLockingPolicyOk returns a tuple with the LockingPolicy field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetLockingPolicy

`func (o *FilesystemCloneArguments) SetLockingPolicy(v string)`

SetLockingPolicy sets LockingPolicy field to given value.

### HasLockingPolicy

`func (o *FilesystemCloneArguments) HasLockingPolicy() bool`

HasLockingPolicy returns a boolean if a field has been set.

### GetFolderRenamePolicy

`func (o *FilesystemCloneArguments) GetFolderRenamePolicy() string`

GetFolderRenamePolicy returns the FolderRenamePolicy field if non-nil, zero value otherwise.

### GetFolderRenamePolicyOk

`func (o *FilesystemCloneArguments) GetFolderRenamePolicyOk() (*string, bool)`

GetFolderRenamePolicyOk returns a tuple with the FolderRenamePolicy field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetFolderRenamePolicy

`func (o *FilesystemCloneArguments) SetFolderRenamePolicy(v string)`

SetFolderRenamePolicy sets FolderRenamePolicy field to given value.

### HasFolderRenamePolicy

`func (o *FilesystemCloneArguments) HasFolderRenamePolicy() bool`

HasFolderRenamePolicy returns a boolean if a field has been set.

### GetEventNotifications

`func (o *FilesystemCloneArguments) GetEventNotifications() string`

GetEventNotifications returns the EventNotifications field if non-nil, zero value otherwise.

### GetEventNotificationsOk

`func (o *FilesystemCloneArguments) GetEventNotificationsOk() (*string, bool)`

GetEventNotificationsOk returns a tuple with the EventNotifications field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetEventNotifications

`func (o *FilesystemCloneArguments) SetEventNotifications(v string)`

SetEventNotifications sets EventNotifications field to given value.

### HasEventNotifications

`func (o *FilesystemCloneArguments) HasEventNotifications() bool`

HasEventNotifications returns a boolean if a field has been set.

### GetSmbSyncWrites

`func (o *FilesystemCloneArguments) GetSmbSyncWrites() bool`

GetSmbSyncWrites returns the SmbSyncWrites field if non-nil, zero value otherwise.

### GetSmbSyncWritesOk

`func (o *FilesystemCloneArguments) GetSmbSyncWritesOk() (*bool, bool)`

GetSmbSyncWritesOk returns a tuple with the SmbSyncWrites field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetSmbSyncWrites

`func (o *FilesystemCloneArguments) SetSmbSyncWrites(v bool)`

SetSmbSyncWrites sets SmbSyncWrites field to given value.

### HasSmbSyncWrites

`func (o *FilesystemCloneArguments) HasSmbSyncWrites() bool`

HasSmbSyncWrites returns a boolean if a field has been set.

### GetSmbNoNotify

`func (o *FilesystemCloneArguments) GetSmbNoNotify() bool`

GetSmbNoNotify returns the SmbNoNotify field if non-nil, zero value otherwise.

### GetSmbNoNotifyOk

`func (o *FilesystemCloneArguments) GetSmbNoNotifyOk() (*bool, bool)`

GetSmbNoNotifyOk returns a tuple with the SmbNoNotify field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetSmbNoNotify

`func (o *FilesystemCloneArguments) SetSmbNoNotify(v bool)`

SetSmbNoNotify sets SmbNoNotify field to given value.

### HasSmbNoNotify

`func (o *FilesystemCloneArguments) HasSmbNoNotify() bool`

HasSmbNoNotify returns a boolean if a field has been set.

### GetSmbOpLocks

`func (o *FilesystemCloneArguments) GetSmbOpLocks() bool`

GetSmbOpLocks returns the SmbOpLocks field if non-nil, zero value otherwise.

### GetSmbOpLocksOk

`func (o *FilesystemCloneArguments) GetSmbOpLocksOk() (*bool, bool)`

GetSmbOpLocksOk returns a tuple with the SmbOpLocks field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetSmbOpLocks

`func (o *FilesystemCloneArguments) SetSmbOpLocks(v bool)`

SetSmbOpLocks sets SmbOpLocks field to given value.

### HasSmbOpLocks

`func (o *FilesystemCloneArguments) HasSmbOpLocks() bool`

HasSmbOpLocks returns a boolean if a field has been set.

### GetSmbNotifyOnAccess

`func (o *FilesystemCloneArguments) GetSmbNotifyOnAccess() bool`

GetSmbNotifyOnAccess returns the SmbNotifyOnAccess field if non-nil, zero value otherwise.

### GetSmbNotifyOnAccessOk

`func (o *FilesystemCloneArguments) GetSmbNotifyOnAccessOk() (*bool, bool)`

GetSmbNotifyOnAccessOk returns a tuple with the SmbNotifyOnAccess field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetSmbNotifyOnAccess

`func (o *FilesystemCloneArguments) SetSmbNotifyOnAccess(v bool)`

SetSmbNotifyOnAccess sets SmbNotifyOnAccess field to given value.

### HasSmbNotifyOnAccess

`func (o *FilesystemCloneArguments) HasSmbNotifyOnAccess() bool`

HasSmbNotifyOnAccess returns a boolean if a field has been set.

### GetSmbNotifyOnWrite

`func (o *FilesystemCloneArguments) GetSmbNotifyOnWrite() bool`

GetSmbNotifyOnWrite returns the SmbNotifyOnWrite field if non-nil, zero value otherwise.

### GetSmbNotifyOnWriteOk

`func (o *FilesystemCloneArguments) GetSmbNotifyOnWriteOk() (*bool, bool)`

GetSmbNotifyOnWriteOk returns a tuple with the SmbNotifyOnWrite field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetSmbNotifyOnWrite

`func (o *FilesystemCloneArguments) SetSmbNotifyOnWrite(v bool)`

SetSmbNotifyOnWrite sets SmbNotifyOnWrite field to given value.

### HasSmbNotifyOnWrite

`func (o *FilesystemCloneArguments) HasSmbNotifyOnWrite() bool`

HasSmbNotifyOnWrite returns a boolean if a field has been set.

### GetSmbNotifyOnChangeDirDepth

`func (o *FilesystemCloneArguments) GetSmbNotifyOnChangeDirDepth() int32`

GetSmbNotifyOnChangeDirDepth returns the SmbNotifyOnChangeDirDepth field if non-nil, zero value otherwise.

### GetSmbNotifyOnChangeDirDepthOk

`func (o *FilesystemCloneArguments) GetSmbNotifyOnChangeDirDepthOk() (*int32, bool)`

GetSmbNotifyOnChangeDirDepthOk returns a tuple with the SmbNotifyOnChangeDirDepth field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetSmbNotifyOnChangeDirDepth

`func (o *FilesystemCloneArguments) SetSmbNotifyOnChangeDirDepth(v int32)`

SetSmbNotifyOnChangeDirDepth sets SmbNotifyOnChangeDirDepth field to given value.

### HasSmbNotifyOnChangeDirDepth

`func (o *FilesystemCloneArguments) HasSmbNotifyOnChangeDirDepth() bool`

HasSmbNotifyOnChangeDirDepth returns a boolean if a field has been set.

### GetAsyncMtime

`func (o *FilesystemCloneArguments) GetAsyncMtime() bool`

GetAsyncMtime returns the AsyncMtime field if non-nil, zero value otherwise.

### GetAsyncMtimeOk

`func (o *FilesystemCloneArguments) GetAsyncMtimeOk() (*bool, bool)`

GetAsyncMtimeOk returns a tuple with the AsyncMtime field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetAsyncMtime

`func (o *FilesystemCloneArguments) SetAsyncMtime(v bool)`

SetAsyncMtime sets AsyncMtime field to given value.

### HasAsyncMtime

`func (o *FilesystemCloneArguments) HasAsyncMtime() bool`

HasAsyncMtime returns a boolean if a field has been set.

### GetHostIoblockSize

`func (o *FilesystemCloneArguments) GetHostIoblockSize() int32`

GetHostIoblockSize returns the HostIoblockSize field if non-nil, zero value otherwise.

### GetHostIoblockSizeOk

`func (o *FilesystemCloneArguments) GetHostIoblockSizeOk() (*int32, bool)`

GetHostIoblockSizeOk returns a tuple with the HostIoblockSize field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetHostIoblockSize

`func (o *FilesystemCloneArguments) SetHostIoblockSize(v int32)`

SetHostIoblockSize sets HostIoblockSize field to given value.

### HasHostIoblockSize

`func (o *FilesystemCloneArguments) HasHostIoblockSize() bool`

HasHostIoblockSize returns a boolean if a field has been set.

### GetForceFlrClone

`func (o *FilesystemCloneArguments) GetForceFlrClone() bool`

GetForceFlrClone returns the ForceFlrClone field if non-nil, zero value otherwise.

### GetForceFlrCloneOk

`func (o *FilesystemCloneArguments) GetForceFlrCloneOk() (*bool, bool)`

GetForceFlrCloneOk returns a tuple with the ForceFlrClone field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetForceFlrClone

`func (o *FilesystemCloneArguments) SetForceFlrClone(v bool)`

SetForceFlrClone sets ForceFlrClone field to given value.

### HasForceFlrClone

`func (o *FilesystemCloneArguments) HasForceFlrClone() bool`

HasForceFlrClone returns a boolean if a field has been set.

### GetInfoThreshold

`func (o *FilesystemCloneArguments) GetInfoThreshold() int32`

GetInfoThreshold returns the InfoThreshold field if non-nil, zero value otherwise.

### GetInfoThresholdOk

`func (o *FilesystemCloneArguments) GetInfoThresholdOk() (*int32, bool)`

GetInfoThresholdOk returns a tuple with the InfoThreshold field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetInfoThreshold

`func (o *FilesystemCloneArguments) SetInfoThreshold(v int32)`

SetInfoThreshold sets InfoThreshold field to given value.

### HasInfoThreshold

`func (o *FilesystemCloneArguments) HasInfoThreshold() bool`

HasInfoThreshold returns a boolean if a field has been set.

### GetHighThreshold

`func (o *FilesystemCloneArguments) GetHighThreshold() int32`

GetHighThreshold returns the HighThreshold field if non-nil, zero value otherwise.

### GetHighThresholdOk

`func (o *FilesystemCloneArguments) GetHighThresholdOk() (*int32, bool)`

GetHighThresholdOk returns a tuple with the HighThreshold field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetHighThreshold

`func (o *FilesystemCloneArguments) SetHighThreshold(v int32)`

SetHighThreshold sets HighThreshold field to given value.

### HasHighThreshold

`func (o *FilesystemCloneArguments) HasHighThreshold() bool`

HasHighThreshold returns a boolean if a field has been set.

### GetWarningThreshold

`func (o *FilesystemCloneArguments) GetWarningThreshold() int32`

GetWarningThreshold returns the WarningThreshold field if non-nil, zero value otherwise.

### GetWarningThresholdOk

`func (o *FilesystemCloneArguments) GetWarningThresholdOk() (*int32, bool)`

GetWarningThresholdOk returns a tuple with the WarningThreshold field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetWarningThreshold

`func (o *FilesystemCloneArguments) SetWarningThreshold(v int32)`

SetWarningThreshold sets WarningThreshold field to given value.

### HasWarningThreshold

`func (o *FilesystemCloneArguments) HasWarningThreshold() bool`

HasWarningThreshold returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


