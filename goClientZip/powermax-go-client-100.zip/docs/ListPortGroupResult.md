# ListPortGroupResult

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**PortGroupId** | Pointer to **[]string** | A list of port groups | [optional] 

## Methods

### NewListPortGroupResult

`func NewListPortGroupResult() *ListPortGroupResult`

NewListPortGroupResult instantiates a new ListPortGroupResult object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewListPortGroupResultWithDefaults

`func NewListPortGroupResultWithDefaults() *ListPortGroupResult`

NewListPortGroupResultWithDefaults instantiates a new ListPortGroupResult object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetPortGroupId

`func (o *ListPortGroupResult) GetPortGroupId() []string`

GetPortGroupId returns the PortGroupId field if non-nil, zero value otherwise.

### GetPortGroupIdOk

`func (o *ListPortGroupResult) GetPortGroupIdOk() (*[]string, bool)`

GetPortGroupIdOk returns a tuple with the PortGroupId field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetPortGroupId

`func (o *ListPortGroupResult) SetPortGroupId(v []string)`

SetPortGroupId sets PortGroupId field to given value.

### HasPortGroupId

`func (o *ListPortGroupResult) HasPortGroupId() bool`

HasPortGroupId returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


