# DpNetworkCreateArguments

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Type** | Pointer to **string** |                          Type of DP Network.                         - 0 - Any.                         - 1 - Import.                        Enumeration values: * **Any** * **Import**  | [optional] 
**ClusterIpAddress** | Pointer to **string** |                          IP address for the cluster on the network interface.                      | [optional] 
**PrefixLength** | Pointer to **int32** |                          IP address prefix length for the interface.                      | [optional] 
**Gateway** | Pointer to **string** |                          IPv4 or IPv6 gateway address for the network interface.                      | [optional] 
**VlanId** | Pointer to **int32** |  Indicates the VLAN this File Interface part of.  | [optional] 
**NodeAddresses** | Pointer to **[]string** |                          The list of addresses for the nodes, starting with node 1.                      | [optional] 
**Name** | Pointer to **string** |                          User friendly name of the data protection network; cluster unique                      | [optional] 
**NetworkDevices** | [**[]NetworkDeviceArguments**](NetworkDeviceArguments.md) |                          Create network devices list                      | 

## Methods

### NewDpNetworkCreateArguments

`func NewDpNetworkCreateArguments(networkDevices []NetworkDeviceArguments, ) *DpNetworkCreateArguments`

NewDpNetworkCreateArguments instantiates a new DpNetworkCreateArguments object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewDpNetworkCreateArgumentsWithDefaults

`func NewDpNetworkCreateArgumentsWithDefaults() *DpNetworkCreateArguments`

NewDpNetworkCreateArgumentsWithDefaults instantiates a new DpNetworkCreateArguments object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetType

`func (o *DpNetworkCreateArguments) GetType() string`

GetType returns the Type field if non-nil, zero value otherwise.

### GetTypeOk

`func (o *DpNetworkCreateArguments) GetTypeOk() (*string, bool)`

GetTypeOk returns a tuple with the Type field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetType

`func (o *DpNetworkCreateArguments) SetType(v string)`

SetType sets Type field to given value.

### HasType

`func (o *DpNetworkCreateArguments) HasType() bool`

HasType returns a boolean if a field has been set.

### GetClusterIpAddress

`func (o *DpNetworkCreateArguments) GetClusterIpAddress() string`

GetClusterIpAddress returns the ClusterIpAddress field if non-nil, zero value otherwise.

### GetClusterIpAddressOk

`func (o *DpNetworkCreateArguments) GetClusterIpAddressOk() (*string, bool)`

GetClusterIpAddressOk returns a tuple with the ClusterIpAddress field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetClusterIpAddress

`func (o *DpNetworkCreateArguments) SetClusterIpAddress(v string)`

SetClusterIpAddress sets ClusterIpAddress field to given value.

### HasClusterIpAddress

`func (o *DpNetworkCreateArguments) HasClusterIpAddress() bool`

HasClusterIpAddress returns a boolean if a field has been set.

### GetPrefixLength

`func (o *DpNetworkCreateArguments) GetPrefixLength() int32`

GetPrefixLength returns the PrefixLength field if non-nil, zero value otherwise.

### GetPrefixLengthOk

`func (o *DpNetworkCreateArguments) GetPrefixLengthOk() (*int32, bool)`

GetPrefixLengthOk returns a tuple with the PrefixLength field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetPrefixLength

`func (o *DpNetworkCreateArguments) SetPrefixLength(v int32)`

SetPrefixLength sets PrefixLength field to given value.

### HasPrefixLength

`func (o *DpNetworkCreateArguments) HasPrefixLength() bool`

HasPrefixLength returns a boolean if a field has been set.

### GetGateway

`func (o *DpNetworkCreateArguments) GetGateway() string`

GetGateway returns the Gateway field if non-nil, zero value otherwise.

### GetGatewayOk

`func (o *DpNetworkCreateArguments) GetGatewayOk() (*string, bool)`

GetGatewayOk returns a tuple with the Gateway field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetGateway

`func (o *DpNetworkCreateArguments) SetGateway(v string)`

SetGateway sets Gateway field to given value.

### HasGateway

`func (o *DpNetworkCreateArguments) HasGateway() bool`

HasGateway returns a boolean if a field has been set.

### GetVlanId

`func (o *DpNetworkCreateArguments) GetVlanId() int32`

GetVlanId returns the VlanId field if non-nil, zero value otherwise.

### GetVlanIdOk

`func (o *DpNetworkCreateArguments) GetVlanIdOk() (*int32, bool)`

GetVlanIdOk returns a tuple with the VlanId field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetVlanId

`func (o *DpNetworkCreateArguments) SetVlanId(v int32)`

SetVlanId sets VlanId field to given value.

### HasVlanId

`func (o *DpNetworkCreateArguments) HasVlanId() bool`

HasVlanId returns a boolean if a field has been set.

### GetNodeAddresses

`func (o *DpNetworkCreateArguments) GetNodeAddresses() []string`

GetNodeAddresses returns the NodeAddresses field if non-nil, zero value otherwise.

### GetNodeAddressesOk

`func (o *DpNetworkCreateArguments) GetNodeAddressesOk() (*[]string, bool)`

GetNodeAddressesOk returns a tuple with the NodeAddresses field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetNodeAddresses

`func (o *DpNetworkCreateArguments) SetNodeAddresses(v []string)`

SetNodeAddresses sets NodeAddresses field to given value.

### HasNodeAddresses

`func (o *DpNetworkCreateArguments) HasNodeAddresses() bool`

HasNodeAddresses returns a boolean if a field has been set.

### GetName

`func (o *DpNetworkCreateArguments) GetName() string`

GetName returns the Name field if non-nil, zero value otherwise.

### GetNameOk

`func (o *DpNetworkCreateArguments) GetNameOk() (*string, bool)`

GetNameOk returns a tuple with the Name field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetName

`func (o *DpNetworkCreateArguments) SetName(v string)`

SetName sets Name field to given value.

### HasName

`func (o *DpNetworkCreateArguments) HasName() bool`

HasName returns a boolean if a field has been set.

### GetNetworkDevices

`func (o *DpNetworkCreateArguments) GetNetworkDevices() []NetworkDeviceArguments`

GetNetworkDevices returns the NetworkDevices field if non-nil, zero value otherwise.

### GetNetworkDevicesOk

`func (o *DpNetworkCreateArguments) GetNetworkDevicesOk() (*[]NetworkDeviceArguments, bool)`

GetNetworkDevicesOk returns a tuple with the NetworkDevices field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetNetworkDevices

`func (o *DpNetworkCreateArguments) SetNetworkDevices(v []NetworkDeviceArguments)`

SetNetworkDevices sets NetworkDevices field to given value.



[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


