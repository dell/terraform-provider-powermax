# BeEmulationKeyResult

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**BeEmulationInfo** | Pointer to [**[]BeEmulationInfo**](BeEmulationInfo.md) | beEmulationInfo | [optional] 

## Methods

### NewBeEmulationKeyResult

`func NewBeEmulationKeyResult() *BeEmulationKeyResult`

NewBeEmulationKeyResult instantiates a new BeEmulationKeyResult object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewBeEmulationKeyResultWithDefaults

`func NewBeEmulationKeyResultWithDefaults() *BeEmulationKeyResult`

NewBeEmulationKeyResultWithDefaults instantiates a new BeEmulationKeyResult object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetBeEmulationInfo

`func (o *BeEmulationKeyResult) GetBeEmulationInfo() []BeEmulationInfo`

GetBeEmulationInfo returns the BeEmulationInfo field if non-nil, zero value otherwise.

### GetBeEmulationInfoOk

`func (o *BeEmulationKeyResult) GetBeEmulationInfoOk() (*[]BeEmulationInfo, bool)`

GetBeEmulationInfoOk returns a tuple with the BeEmulationInfo field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetBeEmulationInfo

`func (o *BeEmulationKeyResult) SetBeEmulationInfo(v []BeEmulationInfo)`

SetBeEmulationInfo sets BeEmulationInfo field to given value.

### HasBeEmulationInfo

`func (o *BeEmulationKeyResult) HasBeEmulationInfo() bool`

HasBeEmulationInfo returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


