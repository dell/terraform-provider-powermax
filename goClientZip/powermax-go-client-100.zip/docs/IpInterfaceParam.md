# IpInterfaceParam

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**IpInterfaceId** | **string** | IP Interface ID with IP Address and Network ID separated by &#39;-&#39;. | 
**IpInterfacePort** | **int64** | Physical Port where the IP Interface exists. | 

## Methods

### NewIpInterfaceParam

`func NewIpInterfaceParam(ipInterfaceId string, ipInterfacePort int64, ) *IpInterfaceParam`

NewIpInterfaceParam instantiates a new IpInterfaceParam object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewIpInterfaceParamWithDefaults

`func NewIpInterfaceParamWithDefaults() *IpInterfaceParam`

NewIpInterfaceParamWithDefaults instantiates a new IpInterfaceParam object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetIpInterfaceId

`func (o *IpInterfaceParam) GetIpInterfaceId() string`

GetIpInterfaceId returns the IpInterfaceId field if non-nil, zero value otherwise.

### GetIpInterfaceIdOk

`func (o *IpInterfaceParam) GetIpInterfaceIdOk() (*string, bool)`

GetIpInterfaceIdOk returns a tuple with the IpInterfaceId field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetIpInterfaceId

`func (o *IpInterfaceParam) SetIpInterfaceId(v string)`

SetIpInterfaceId sets IpInterfaceId field to given value.


### GetIpInterfacePort

`func (o *IpInterfaceParam) GetIpInterfacePort() int64`

GetIpInterfacePort returns the IpInterfacePort field if non-nil, zero value otherwise.

### GetIpInterfacePortOk

`func (o *IpInterfaceParam) GetIpInterfacePortOk() (*int64, bool)`

GetIpInterfacePortOk returns a tuple with the IpInterfacePort field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetIpInterfacePort

`func (o *IpInterfaceParam) SetIpInterfacePort(v int64)`

SetIpInterfacePort sets IpInterfacePort field to given value.



[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


