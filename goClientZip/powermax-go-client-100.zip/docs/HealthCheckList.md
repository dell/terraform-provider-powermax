# HealthCheckList

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**HealthCheckId** | Pointer to **[]string** | health_check_id | [optional] 

## Methods

### NewHealthCheckList

`func NewHealthCheckList() *HealthCheckList`

NewHealthCheckList instantiates a new HealthCheckList object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewHealthCheckListWithDefaults

`func NewHealthCheckListWithDefaults() *HealthCheckList`

NewHealthCheckListWithDefaults instantiates a new HealthCheckList object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetHealthCheckId

`func (o *HealthCheckList) GetHealthCheckId() []string`

GetHealthCheckId returns the HealthCheckId field if non-nil, zero value otherwise.

### GetHealthCheckIdOk

`func (o *HealthCheckList) GetHealthCheckIdOk() (*[]string, bool)`

GetHealthCheckIdOk returns a tuple with the HealthCheckId field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetHealthCheckId

`func (o *HealthCheckList) SetHealthCheckId(v []string)`

SetHealthCheckId sets HealthCheckId field to given value.

### HasHealthCheckId

`func (o *HealthCheckList) HasHealthCheckId() bool`

HasHealthCheckId returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


