# DeviceGroupParam

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**StartDate** | **int64** | Starting date in millisecond. | 
**EndDate** | **int64** | Ending date in millisecond. | 
**SymmetrixId** | **string** | &lt;p&gt;The Symmetrix array ID.&lt;/p&gt; | 
**DeviceGroupId** | **string** | deviceGroupId | 
**DataFormat** | Pointer to **string** | &lt;p&gt;Data Format (Average or Maximum).&lt;/p&gt;   Enumeration values: * **Average** * **Maximum**  | [optional] 
**Metrics** | **[]string** | metrics   Enumeration values: * **HostIOs** - The number of host operations performed each second by the group. * **HostReads** - The number of host read operations performed each second by the group. * **HostWrites** - The number of host write operations performed each second by the group. * **HostHits** - The number of host read/write operations performed each second by the group that were immediately satisfied from cache. * **HostReadHits** - The number of host read operations performed each second by the group that were immediately satisfied from cache. * **HostWriteHits** - The number of host write operations performed each second by the group that were immediately satisfied from cache. * **HostMisses** - The number of host read/write operations performed each second by the group that could not be satisfied from cache. * **HostReadMisses** - The number of host read operations performed each second by the group that were not satisfied from cache. * **HostWriteMisses** - The number of host write operations performed each second by the group that were not satisfied from cache. * **HostMBs** - Cumulative number of host MBs read/writes per second by the group. * **HostMBReads** - The cumulative number of host MBs read per second by the group. * **HostMBWritten** - The cumulative number of host MBs written per second by the group. * **BEReqs** - The number of read/write requests each second performed by the disk directors to cache. * **BEReadReqs** - The number of read requests each second performed by the disk directors to cache. * **BEWriteReqs** - The number of write requests each second performed by the disk directors to cache. * **ReadResponseTime** - The average time that it took the Symmetrix to serve one read IO for this group. * **WriteResponseTime** - The average time that it took the Symmetrix to serve one write IO for this group. * **ReadMissResponseTime** - The average time that it took the Symmetrix to serve one read miss IO for this group. * **WriteMissResponseTime** - The average time that it took the Symmetrix to serve one write miss IO for this group. * **RDFS_WriteResponseTime** - A summary of the read, write, and average response times for the selected SRDF/S group. * **PercentRead** - The percent of IO operations that were reads. * **PercentWrite** - The percent of IO operations that were writes. * **PercentReadHit** - The percent of read operations, performed by the group, that were immediately satisfied by cache. * **PercentWriteHit** - The percent of write operations, performed by the group, that were immediately satisfied by cache. * **PercentReadMiss** - The percent of read miss operations performed each second by the group. A miss occurs when the requested read data is not found in cache. * **PercentWriteMiss** - The percent of write miss operations performed each second by the group. A miss occurs when the write operation had to wait while data was destaged from cache to the disks. * **WPCount** - The number of tracks currently in write pending mode for the group * **SeqIOs** - The number of IO operations performed each second that were sequential. * **SeqReads** - The number of read IO operations performed each second that were sequential. * **SeqWrites** - The number of write IO operations performed each second that were sequential. * **SeqReadHits** - The number of sequential read operations performed each second by the group that were immediately satisfied from cache. * **SeqReadMisses** - The number of sequential read operations performed each second by the group that were misses. * **SeqWriteHits** - The number of sequential write operations performed each second by the group that were immediately satisfied from cache. * **SeqWriteMisses** - The number of sequential write operations performed each second by the group that were misses. * **RandomIOs** - The number of IOs from a host not identified as part of a sequential stream. * **RandomReads** - The number of read IO commands from a host not identified as part of a sequential stream. * **RandomWrites** - The number of write IO commands from a host not identified as part of a sequential stream. * **RandomReadHits** - The number of random read IOs that were satisfied from the cache. * **RandomWriteHits** - The number of random write IOs that were immediately placed in cache because space was available. * **RandomReadMisses** - The number of random read IOs that were misses. * **RandomWriteMisses** - The number of random write IOs that were misses. * **AvgIOSize** - Calculated value: (HA Kbytes transferred per sec/total IOs per sec) * **AvgReadSize** - Calculated value: (Kbytes read per sec/total reads per sec) * **AvgWriteSize** - Calculated value: (Kbytes written per sec/total writes per sec) * **MaxWPThreshold** - The maximum number of write-pending slots available for the group. * **BEMBTransferred** - The number of MBs read per second + MBs written per second. * **BEMBReads** - The number of MBs read by the disk directors from the disk each second. * **BEMBWritten** - The number of MBs written to the disk from the disk director each second. * **BEPrefetchedTrackss** - The total prefetched tracks each second from the disk directors to the cache. * **BEPrefetchedTrackUsed** - The number of prefetched tracks used each second from the disk directors to the cache. * **BEReadRequestTime** - The average time it takes to make a request by the disk directors to the cache. * **BEDiskReadResponseTime** - The average time it takes cache to respond to a read request by the disk directors. * **BEReadTaskTime** - The time from the point when the HA puts the read request on the queue and the DA picks it up - can be considered queue time. * **PercentHit** - The percent of IO operations that were immediately satisfied from cache. * **PercentMisses** - The percent of IO operations that were misses. * **ResponseTime** - The average response time for the reads and writes. * **AllocatedCapacity** - The capacity in GBs of this group. * **BlockSize** - The block size in KBs of the devices in this group. * **BEPrefetchedMBs** - The number of MBs prefetched from disk to cache in a second. * **IODensity** - The number of back-end requests per GB of disk. * **BEPercentReads** - BE % Reads * **BEPercentWrites** - BE % Writes * **PercentRandomReads** - % Random Reads * **PercentRandomWrites** - % Random Writes * **BEThroughputReadForCopy** - BE Reads For Copy (KB)/ BE Reads For Copy * **BEThroughputWrittenForCopy** - BE Writes For Copy (KB)/ BE Write Throughput For Copy * **BEThroughputWrittenForRebuild** - BE Writes For Rebuild (KB)/ BE Write Throughput For Rebuild * **DAOptimizeWriteThroughput** - BE Optimize Writes (KB)/ BE Optimize Write Throughput * **BEPartialSectorWriteThroughput** - BE Partial Sector Writes (KB)/ BE Partial Sector Write Throughput * **BEReadsForCopy** - BE Reads For Copy * **BEWritesForCopy** - BE Writes For Copy * **BEWritesForRebuild** - BE Writes For Rebuild * **BEXORReadThroughput** - BE XOR Read (KB)/ BE XOR Read Throughput * **BEXORReads** - BE XOR Reads * **TotalCapacity** - Total Capacity (GB)/ Total Capacity * **XtremSWCacheIOs** - The number of IOs per second received in the XtremSW Cache. * **PercentXtremSWCacheReadHit** - The percent of total XtremSW Cache read IO operations performed each second by all of the Symmetrix volumes that were served by the XtremSW Cache cache. * **XtremSWCacheMBs** - Cumulative number of host MBs read and written by the StremSW Cache per second. * **XtremSWCacheResponseTime** - The average time it took the XtremSW cache to serve one IO. * **OptimizedReadMisses** - Number of read requests each second performed directly from disks bypassing the cache. * **OptimizedMBReadMisss** - Dreprecated:                         Number of host MBs read each second directly from disks bypassing the cache. * **AvgOptimizedReadMissSize** - The average read size of the read requests performed directly from disks bypassing the cache. * **WritePacedDelay** - The total delay in milliseconds that the RDF directors impose on RDF devices in order to better serve remote IOs. * **AvgWritePacedDelay** - The average time in milliseconds that host writes on RDF devices are delayed by the RDF directors. * **RdfReads** - RDF Reads. * **RdfWrites** - RDF Writes. * **RdfMBRead** - RDF MB Read. * **RdfMBWritten** - RDFMB Written. * **RdfReadHits** - RDF Read Hits. * **RDFRewrites** - RDF Rewrites. * **IOServiceTimeLong** - RDF Avg IO Service Time Long ms. * **IOServiceTimeShort** - RDF Avg IO Service Time Short. * **MaxIOServiceTime** - RDF Max IO Service Time ms. * **MinIOServiceTime** - RDF Min IO Service Time ms. * **RdfResponseTime** - RDF Response Time ms. * **PercentSeqIO** - % Seq IO * **PercentSeqRead** - % Seq Read * **PercentSeqReadHit** - % Seq Read Hit * **PercentSeqReadMiss** - % Seq Read Miss * **PercentSeqWrites** - % Seq Writes * **PercentSeqWriteHit** - % Seq Write Hit * **PercentSeqWriteMiss** - % Seq Write Miss * **PercentRandomIO** - % Random IO * **PercentRandomReadHit** - % Random Read Hit * **PercentRandomReadMiss** - % Random Read Miss * **PercentRandomWriteHit** - % Random Write Hit * **PercentRandomWriteMiss** - % Random Write Miss * **BERdfCopy** - DA RDF Copy * **BERdfCopyMB** - DA MBs RDF Copy * **WPUsedCapacity** - WP Used Capacity * **AVG_BE_DISK_TIME** - The average time it takes cache to respond to a read request by the disk directors. * **AVG_BE_REQ_TIME** - The average time it takes to make a request by the disk directors to the cache. * **AVG_BE_TASK_TIME** - The time from the point when the HA puts the read request on the queue and the DA picks it up - can be considered queue time. * **AVG_IO_SIZE_KB** - Calculated value: (HA Kbytes transferred per sec/total IOs per sec) * **AVG_READ_SIZE** - Calculated value: (Kbytes read per sec/total reads per sec) * **AVG_WRITE_SIZE** - Calculated value: (Kbytes written per sec/total writes per sec) * **BE_MB_READ_RATE** - The number of MBs read by the disk directors from the disk each second. * **BE_MB_TRANSFERED_PER_SEC** - The number of MBs read per second + MBs written per second. * **BE_MB_WRITE_RATE** - The number of MBs written to the disk from the disk director each second. * **BE_PERCENT_READ** - The percent of the back-end IO that were read requests. * **BE_PERFETCHED_TRACK_PER_SEC** - The total prefetched tracks each second from the disk directors to the cache. * **BE_PERFETCHED_TRACK_USED_PER_SEC** - The number of prefetched tracks used each second from the disk directors to the cache. * **BE_PERCENT_WRITE** - The percent of the back-end IO that were write requests. * **BE_READS** - The number of read requests each second performed by the disk directors to cache. * **BE_WRITES** - The number of write requests each second performed by the disk directors to cache. * **HA_MB_PER_SEC** - Cumulative number of host MBs read/writes per second by the group. * **IO_DENSITY** - The number of back-end requests per GB of disk. * **IO_RATE** - The number of host operations performed each second by the group. * **MAX_WRITE_PENDING_THRLD** - The maximum number of write-pending slots available for the group. * **MB_READ_PER_SEC** - The cumulative number of host MBs read per second by the group. * **MB_WRITE_PER_SEC** - The cumulative number of host MBs written per second by the group. * **PERCENT_HIT** - The percent of IO operations that were immediately satisfied from cache. * **PERCENT_MISS** - The percent of IO operations that were misses. * **PERCENT_RANDOM_IO** - The percent of IO operations that were random. * **PERCENT_RANDOM_WRITES** - The percent of all write IOs that were random. * **PERCENT_RANDOM_READ_HIT** - Calculated value: 100 * (random read hits per sec/total ios per sec) * **PERCENT_RANDOM_READ_MISS** - Calculated value: 100 * (random read misses per sec/total ios per sec) * **PERCENT_RANDOM_READS** - The percent of all read IOs that were random. * **PERCENT_RANDOM_WRITE_HIT** - Calculated value: 100 * (random write hits per sec / total ios per sec) * **PERCENT_RANDOM_WRITE_MISS** - Calculated value: 100 * (random write misses per sec / total ios per sec) * **PERCENT_READ** - The percent of IO operations that were reads. * **PERCENT_READ_HIT** - The percent of read operations, performed by the group, that were immediately satisfied by cache. * **PERCENT_READ_MISS** - The percent of read miss operations performed each second by the group. A miss occurs when the requested read data is not found in cache. * **PERCENT_SEQ_READ_HIT** - The percent of the sequential read operations that were immediately satisfied from cache. * **PERCENT_SEQ_READ_MISS** - The percent of the sequential read operations that were misses. * **PERCENT_SEQ_READS** - Calculated value: 100 * (seq reads per sec/total ios per sec) * **PERCENT_SEQ_WRITE_MISS** - The percent of the sequential write operations that were misses. * **PERCENT_SEQ_WRITE_HIT** - The percent of the sequential write operations that were immediately satisfied from cache. * **PERCENT_SEQ_WRITES** - Calculated value: 100*(seq writes per sec/total ios per sec) * **PERCENT_WRITE** - The percent of IO operations that were writes. * **PERCENT_WRITE_HIT** - The percent of write operations, performed by the group, that were immediately satisfied by cache. * **PERCENT_WRITE_MISS** - The percent of write miss operations performed each second by the group. A miss occurs when the write operation had to wait while data was destaged from cache to the disks. * **PREFETCHED_TRACK_MB_PER_SEC** - The number of MBs prefetched from disk to cache in a second. * **RANDOM_IO_PER_SEC** - The number of IOs from a host not identified as part of a sequential stream. * **RANDOM_READ_HIT_PER_SEC** - The number of random read IOs that were satisfied from the cache. * **RANDOM_READ_MISS_PER_SEC** - The number of random read IOs that were misses. * **RANDOM_READ_PER_SEC** - The number of read IO commands from a host not identified as part of a sequential stream. * **RANDOM_WRITE_HIT_PER_SEC** - The number of random write IOs that were immediately placed in cache because space was available. * **RANDOM_WRITE_MISS_PER_SEC** - The number of random write IOs that were misses. * **RANDOM_WRITE_PER_SEC** - The number of write IO commands from a host not identified as part of a sequential stream. * **READ_HIT_PER_SEC** - The number of host read operations performed each second by the group that were immediately satisfied from cache. * **READ_MISS_PER_SEC** - The number of host read operations performed each second by the group that were not satisfied from cache. * **READS** - The number of host read operations performed each second by the group. * **RESPONSE_TIME** - The average time it takes to satisfy IO requests. * **SAMPLED_AVG_READ_MISS_TIME** - The average time that it took the Symmetrix to serve one read miss IO for this group. * **SAMPLED_AVG_RDF_WRITE_TIME** - A summary of the read, write, and average response times for the selected SRDF/S group. * **SAMPLED_AVG_READ_TIME** - The average time that it took the Symmetrix to serve one read IO for this group. * **SAMPLED_AVG_WP_DISCONNECT_TIME** - The average time that it took the Symmetrix to serve one write miss IO for this group. * **SAMPLED_AVG_WRITE_TIME** - The average time that it took the Symmetrix to serve one write IO for this group. * **SEQ_READ_HIT_PER_SEC** - The number of sequential read operations performed each second by the group that were immediately satisfied from cache. * **SEQ_READ_MISS_PER_SEC** - The number of sequential read operations performed each second by the group that were misses. * **SEQ_READ_PER_SEC** - The number of read IO operations performed each second that were sequential. * **SEQ_WRITE_HIT_PER_SEC** - The number of sequential write operations performed each second by the group that were immediately satisfied from cache. * **SEQ_WRITE_MISS_PER_SEC** - The number of sequential write operations performed each second by the group that were misses. * **SEQ_WRITE_PER_SEC** - The number of write IO operations performed each second that were sequential. * **WRITE_MISS_PER_SEC** - The number of host write operations performed each second by the group that were not satisfied from cache. * **WRITE_HIT_PER_SEC** - The number of host write operations performed each second by the group that were immediately satisfied from cache. * **TOTAL_MISS_PER_SEC** - The number of host read/write operations performed each second by the group that could not be satisfied from cache. * **TOTAL_HIT_PER_SEC** - The number of host read/write operations performed each second by the group that were immediately satisfied from cache. * **TOTAL_BE_REQ_PER_SEC** - The number of read/write requests each second performed by the disk directors to cache. * **TOTAL_SEQ_IO_PER_SEC** - The number of IO operations performed each second that were sequential. * **WP** - The number of tracks currently in write pending mode for the group * **WRITES** - The number of host write operations performed each second by the group. * **XC_READ_HITS** - The number of reads per second that found in the XtremSW Cache. * **XC_WRITE_HITS** - The number of writes per second that found in the XtremSW Cache. * **XC_READS** - The number of Reads per second received in the XtremSW Cache. * **XC_WRITES** - The number of Writes per second received in the XtremSW Cache. * **XC_IOS** - The number of IOs per second received in the XtremSW Cache. * **XC_SKIPPED_IOS** - The number of Reads/Writes that skipped the XtremSW Cache. * **XC_DEDUP_HITS** - The number of reads/writes per second that has been found in the XtremSW Cache de-dup cache. * **XC_DEDUP_READS** - The number  of reads per second that has been found in the XtremSW Cache de-dup cache. * **XC_DEDUP_WRITES** - The number  of writes per second that has been found in the XtremSW Cache de-dup cache. * **XC_PER_READS** - The percent of total XtremSW Cache read IO operations performed each second by all of the Symmetrix volumes. * **XC_PER_WRITES** - The percent of total XtremSW Cache write IO operations performed each second by all of the Symmetrix volumes. * **XC_PER_READ_HITS** - The percent of total XtremSW Cache read IO operations performed each second by all of the Symmetrix volumes that were served by the XtremSW Cache cache. * **XC_TOTAL_MBS_READ** - Cumulative number of host MBs read by the StremSW Cache per second. * **XC_TOTAL_MBS_WRITTEN** - Cumulative number of host MBs written by the StremSW Cache per second. * **XC_TOTAL_MBS** - Cumulative number of host MBs read and written by the StremSW Cache per second. * **XC_READ_RESPONSE_TIME** - The average time it took the XtremSW cache to serve one read. * **XC_WRITE_RESPONSE_TIME** - The average time it took the XtremSW cache to serve one write. * **XC_RESPONSE_TIME** - The average time it took the XtremSW cache to serve one IO. * **XC_AVG_READ_SIZE** - The average size of a read served by the XtremSW Cache. * **XC_AVG_WRITE_SIZE** - The average size of a write served by the XtremSW Cache. * **XC_AVG_IO_SIZE** - The average size of an IO served by the XtremSW Cache. * **ORM_READS** - Number of read requests each second performed directly from disks bypassing the cache. * **ORM_MB_READ** - Number of host MBs read each second directly from disks bypassing the cache. * **ORM_AVG_READ_SIZE** - The average read size of the read requests performed directly from disks bypassing the cache. * **FE_WORKLOAD_SCORE** - A score metric that reflects the contribution of a volume or list of volumes to front end directors serving their IOs. * **BE_WORKLOAD_SCORE** - A score metric that reflects the contribution of a volume or list of volumes to back end directors serving their IOs. * **DISK_WORKLOAD_SCORE** - A score metric that reflects the contribution of a volume or list of volumes to disks serving their IOs. * **WORKLOAD_SCORE** - A combined score metric that reflects the overall contribution of a volume or list of volumes to the array. * **WRITE_PACED_DELAY** - The total delay in milliseconds that the RDF directors impose on RDF devices in order to better serve remote IOs. * **AVG_WRITE_PACED_DELAY** - The average time in milliseconds that host writes on RDF devices are delayed by the RDF directors.  | 

## Methods

### NewDeviceGroupParam

`func NewDeviceGroupParam(startDate int64, endDate int64, symmetrixId string, deviceGroupId string, metrics []string, ) *DeviceGroupParam`

NewDeviceGroupParam instantiates a new DeviceGroupParam object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewDeviceGroupParamWithDefaults

`func NewDeviceGroupParamWithDefaults() *DeviceGroupParam`

NewDeviceGroupParamWithDefaults instantiates a new DeviceGroupParam object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetStartDate

`func (o *DeviceGroupParam) GetStartDate() int64`

GetStartDate returns the StartDate field if non-nil, zero value otherwise.

### GetStartDateOk

`func (o *DeviceGroupParam) GetStartDateOk() (*int64, bool)`

GetStartDateOk returns a tuple with the StartDate field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetStartDate

`func (o *DeviceGroupParam) SetStartDate(v int64)`

SetStartDate sets StartDate field to given value.


### GetEndDate

`func (o *DeviceGroupParam) GetEndDate() int64`

GetEndDate returns the EndDate field if non-nil, zero value otherwise.

### GetEndDateOk

`func (o *DeviceGroupParam) GetEndDateOk() (*int64, bool)`

GetEndDateOk returns a tuple with the EndDate field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetEndDate

`func (o *DeviceGroupParam) SetEndDate(v int64)`

SetEndDate sets EndDate field to given value.


### GetSymmetrixId

`func (o *DeviceGroupParam) GetSymmetrixId() string`

GetSymmetrixId returns the SymmetrixId field if non-nil, zero value otherwise.

### GetSymmetrixIdOk

`func (o *DeviceGroupParam) GetSymmetrixIdOk() (*string, bool)`

GetSymmetrixIdOk returns a tuple with the SymmetrixId field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetSymmetrixId

`func (o *DeviceGroupParam) SetSymmetrixId(v string)`

SetSymmetrixId sets SymmetrixId field to given value.


### GetDeviceGroupId

`func (o *DeviceGroupParam) GetDeviceGroupId() string`

GetDeviceGroupId returns the DeviceGroupId field if non-nil, zero value otherwise.

### GetDeviceGroupIdOk

`func (o *DeviceGroupParam) GetDeviceGroupIdOk() (*string, bool)`

GetDeviceGroupIdOk returns a tuple with the DeviceGroupId field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetDeviceGroupId

`func (o *DeviceGroupParam) SetDeviceGroupId(v string)`

SetDeviceGroupId sets DeviceGroupId field to given value.


### GetDataFormat

`func (o *DeviceGroupParam) GetDataFormat() string`

GetDataFormat returns the DataFormat field if non-nil, zero value otherwise.

### GetDataFormatOk

`func (o *DeviceGroupParam) GetDataFormatOk() (*string, bool)`

GetDataFormatOk returns a tuple with the DataFormat field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetDataFormat

`func (o *DeviceGroupParam) SetDataFormat(v string)`

SetDataFormat sets DataFormat field to given value.

### HasDataFormat

`func (o *DeviceGroupParam) HasDataFormat() bool`

HasDataFormat returns a boolean if a field has been set.

### GetMetrics

`func (o *DeviceGroupParam) GetMetrics() []string`

GetMetrics returns the Metrics field if non-nil, zero value otherwise.

### GetMetricsOk

`func (o *DeviceGroupParam) GetMetricsOk() (*[]string, bool)`

GetMetricsOk returns a tuple with the Metrics field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetMetrics

`func (o *DeviceGroupParam) SetMetrics(v []string)`

SetMetrics sets Metrics field to given value.



[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


