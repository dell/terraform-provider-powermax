# FileInterfaceModifyArguments

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**IpAddress** | Pointer to **string** | ip_address | [optional] 
**Netmask** | Pointer to **string** | netmask | [optional] 
**V6PrefixLength** | Pointer to **int32** | v6_prefix_length | [optional] 
**Gateway** | Pointer to **string** | gateway | [optional] 
**IsDisabled** | Pointer to **bool** | is_disabled | [optional] 
**VlanId** | Pointer to **int32** | vlan_id | [optional] 
**NetworkDevices** | Pointer to [**[]NetworkDeviceArguments**](NetworkDeviceArguments.md) | network_devices | [optional] 
**Override** | Pointer to **bool** | override | [optional] 
**AttachDevice** | Pointer to **bool** | attach_device | [optional] [default to false]

## Methods

### NewFileInterfaceModifyArguments

`func NewFileInterfaceModifyArguments() *FileInterfaceModifyArguments`

NewFileInterfaceModifyArguments instantiates a new FileInterfaceModifyArguments object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewFileInterfaceModifyArgumentsWithDefaults

`func NewFileInterfaceModifyArgumentsWithDefaults() *FileInterfaceModifyArguments`

NewFileInterfaceModifyArgumentsWithDefaults instantiates a new FileInterfaceModifyArguments object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetIpAddress

`func (o *FileInterfaceModifyArguments) GetIpAddress() string`

GetIpAddress returns the IpAddress field if non-nil, zero value otherwise.

### GetIpAddressOk

`func (o *FileInterfaceModifyArguments) GetIpAddressOk() (*string, bool)`

GetIpAddressOk returns a tuple with the IpAddress field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetIpAddress

`func (o *FileInterfaceModifyArguments) SetIpAddress(v string)`

SetIpAddress sets IpAddress field to given value.

### HasIpAddress

`func (o *FileInterfaceModifyArguments) HasIpAddress() bool`

HasIpAddress returns a boolean if a field has been set.

### GetNetmask

`func (o *FileInterfaceModifyArguments) GetNetmask() string`

GetNetmask returns the Netmask field if non-nil, zero value otherwise.

### GetNetmaskOk

`func (o *FileInterfaceModifyArguments) GetNetmaskOk() (*string, bool)`

GetNetmaskOk returns a tuple with the Netmask field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetNetmask

`func (o *FileInterfaceModifyArguments) SetNetmask(v string)`

SetNetmask sets Netmask field to given value.

### HasNetmask

`func (o *FileInterfaceModifyArguments) HasNetmask() bool`

HasNetmask returns a boolean if a field has been set.

### GetV6PrefixLength

`func (o *FileInterfaceModifyArguments) GetV6PrefixLength() int32`

GetV6PrefixLength returns the V6PrefixLength field if non-nil, zero value otherwise.

### GetV6PrefixLengthOk

`func (o *FileInterfaceModifyArguments) GetV6PrefixLengthOk() (*int32, bool)`

GetV6PrefixLengthOk returns a tuple with the V6PrefixLength field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetV6PrefixLength

`func (o *FileInterfaceModifyArguments) SetV6PrefixLength(v int32)`

SetV6PrefixLength sets V6PrefixLength field to given value.

### HasV6PrefixLength

`func (o *FileInterfaceModifyArguments) HasV6PrefixLength() bool`

HasV6PrefixLength returns a boolean if a field has been set.

### GetGateway

`func (o *FileInterfaceModifyArguments) GetGateway() string`

GetGateway returns the Gateway field if non-nil, zero value otherwise.

### GetGatewayOk

`func (o *FileInterfaceModifyArguments) GetGatewayOk() (*string, bool)`

GetGatewayOk returns a tuple with the Gateway field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetGateway

`func (o *FileInterfaceModifyArguments) SetGateway(v string)`

SetGateway sets Gateway field to given value.

### HasGateway

`func (o *FileInterfaceModifyArguments) HasGateway() bool`

HasGateway returns a boolean if a field has been set.

### GetIsDisabled

`func (o *FileInterfaceModifyArguments) GetIsDisabled() bool`

GetIsDisabled returns the IsDisabled field if non-nil, zero value otherwise.

### GetIsDisabledOk

`func (o *FileInterfaceModifyArguments) GetIsDisabledOk() (*bool, bool)`

GetIsDisabledOk returns a tuple with the IsDisabled field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetIsDisabled

`func (o *FileInterfaceModifyArguments) SetIsDisabled(v bool)`

SetIsDisabled sets IsDisabled field to given value.

### HasIsDisabled

`func (o *FileInterfaceModifyArguments) HasIsDisabled() bool`

HasIsDisabled returns a boolean if a field has been set.

### GetVlanId

`func (o *FileInterfaceModifyArguments) GetVlanId() int32`

GetVlanId returns the VlanId field if non-nil, zero value otherwise.

### GetVlanIdOk

`func (o *FileInterfaceModifyArguments) GetVlanIdOk() (*int32, bool)`

GetVlanIdOk returns a tuple with the VlanId field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetVlanId

`func (o *FileInterfaceModifyArguments) SetVlanId(v int32)`

SetVlanId sets VlanId field to given value.

### HasVlanId

`func (o *FileInterfaceModifyArguments) HasVlanId() bool`

HasVlanId returns a boolean if a field has been set.

### GetNetworkDevices

`func (o *FileInterfaceModifyArguments) GetNetworkDevices() []NetworkDeviceArguments`

GetNetworkDevices returns the NetworkDevices field if non-nil, zero value otherwise.

### GetNetworkDevicesOk

`func (o *FileInterfaceModifyArguments) GetNetworkDevicesOk() (*[]NetworkDeviceArguments, bool)`

GetNetworkDevicesOk returns a tuple with the NetworkDevices field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetNetworkDevices

`func (o *FileInterfaceModifyArguments) SetNetworkDevices(v []NetworkDeviceArguments)`

SetNetworkDevices sets NetworkDevices field to given value.

### HasNetworkDevices

`func (o *FileInterfaceModifyArguments) HasNetworkDevices() bool`

HasNetworkDevices returns a boolean if a field has been set.

### GetOverride

`func (o *FileInterfaceModifyArguments) GetOverride() bool`

GetOverride returns the Override field if non-nil, zero value otherwise.

### GetOverrideOk

`func (o *FileInterfaceModifyArguments) GetOverrideOk() (*bool, bool)`

GetOverrideOk returns a tuple with the Override field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetOverride

`func (o *FileInterfaceModifyArguments) SetOverride(v bool)`

SetOverride sets Override field to given value.

### HasOverride

`func (o *FileInterfaceModifyArguments) HasOverride() bool`

HasOverride returns a boolean if a field has been set.

### GetAttachDevice

`func (o *FileInterfaceModifyArguments) GetAttachDevice() bool`

GetAttachDevice returns the AttachDevice field if non-nil, zero value otherwise.

### GetAttachDeviceOk

`func (o *FileInterfaceModifyArguments) GetAttachDeviceOk() (*bool, bool)`

GetAttachDeviceOk returns a tuple with the AttachDevice field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetAttachDevice

`func (o *FileInterfaceModifyArguments) SetAttachDevice(v bool)`

SetAttachDevice sets AttachDevice field to given value.

### HasAttachDevice

`func (o *FileInterfaceModifyArguments) HasAttachDevice() bool`

HasAttachDevice returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


