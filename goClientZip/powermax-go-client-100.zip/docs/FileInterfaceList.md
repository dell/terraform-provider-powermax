# FileInterfaceList

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Entries** | Pointer to [**[]FileInterfaceIdentifier**](FileInterfaceIdentifier.md) |                                  List of the File Interface Identifier                              | [optional] 

## Methods

### NewFileInterfaceList

`func NewFileInterfaceList() *FileInterfaceList`

NewFileInterfaceList instantiates a new FileInterfaceList object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewFileInterfaceListWithDefaults

`func NewFileInterfaceListWithDefaults() *FileInterfaceList`

NewFileInterfaceListWithDefaults instantiates a new FileInterfaceList object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetEntries

`func (o *FileInterfaceList) GetEntries() []FileInterfaceIdentifier`

GetEntries returns the Entries field if non-nil, zero value otherwise.

### GetEntriesOk

`func (o *FileInterfaceList) GetEntriesOk() (*[]FileInterfaceIdentifier, bool)`

GetEntriesOk returns a tuple with the Entries field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetEntries

`func (o *FileInterfaceList) SetEntries(v []FileInterfaceIdentifier)`

SetEntries sets Entries field to given value.

### HasEntries

`func (o *FileInterfaceList) HasEntries() bool`

HasEntries returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


