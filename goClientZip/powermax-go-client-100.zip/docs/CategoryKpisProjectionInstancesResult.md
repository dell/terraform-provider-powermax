# CategoryKpisProjectionInstancesResult

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**CategoryKpisProjectionResultType** | Pointer to [**[]CategoryKpisProjectionResultType**](CategoryKpisProjectionResultType.md) | categoryKpisProjectionResultType | [optional] 
**InstanceId** | Pointer to **string** | instanceId | [optional] 

## Methods

### NewCategoryKpisProjectionInstancesResult

`func NewCategoryKpisProjectionInstancesResult() *CategoryKpisProjectionInstancesResult`

NewCategoryKpisProjectionInstancesResult instantiates a new CategoryKpisProjectionInstancesResult object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewCategoryKpisProjectionInstancesResultWithDefaults

`func NewCategoryKpisProjectionInstancesResultWithDefaults() *CategoryKpisProjectionInstancesResult`

NewCategoryKpisProjectionInstancesResultWithDefaults instantiates a new CategoryKpisProjectionInstancesResult object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetCategoryKpisProjectionResultType

`func (o *CategoryKpisProjectionInstancesResult) GetCategoryKpisProjectionResultType() []CategoryKpisProjectionResultType`

GetCategoryKpisProjectionResultType returns the CategoryKpisProjectionResultType field if non-nil, zero value otherwise.

### GetCategoryKpisProjectionResultTypeOk

`func (o *CategoryKpisProjectionInstancesResult) GetCategoryKpisProjectionResultTypeOk() (*[]CategoryKpisProjectionResultType, bool)`

GetCategoryKpisProjectionResultTypeOk returns a tuple with the CategoryKpisProjectionResultType field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetCategoryKpisProjectionResultType

`func (o *CategoryKpisProjectionInstancesResult) SetCategoryKpisProjectionResultType(v []CategoryKpisProjectionResultType)`

SetCategoryKpisProjectionResultType sets CategoryKpisProjectionResultType field to given value.

### HasCategoryKpisProjectionResultType

`func (o *CategoryKpisProjectionInstancesResult) HasCategoryKpisProjectionResultType() bool`

HasCategoryKpisProjectionResultType returns a boolean if a field has been set.

### GetInstanceId

`func (o *CategoryKpisProjectionInstancesResult) GetInstanceId() string`

GetInstanceId returns the InstanceId field if non-nil, zero value otherwise.

### GetInstanceIdOk

`func (o *CategoryKpisProjectionInstancesResult) GetInstanceIdOk() (*string, bool)`

GetInstanceIdOk returns a tuple with the InstanceId field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetInstanceId

`func (o *CategoryKpisProjectionInstancesResult) SetInstanceId(v string)`

SetInstanceId sets InstanceId field to given value.

### HasInstanceId

`func (o *CategoryKpisProjectionInstancesResult) HasInstanceId() bool`

HasInstanceId returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


