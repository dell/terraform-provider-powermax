# ComplianceSummary

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**PercentStable** | **float64** | Percentage of time spent in the stable state for the specified time window. | 
**PercentMarginal** | **float64** | Percentage of time spent in the marginal state for the specified time window. | 
**PercentCritical** | **float64** | Percentage of time spent in the critical state for the specified time window. | 

## Methods

### NewComplianceSummary

`func NewComplianceSummary(percentStable float64, percentMarginal float64, percentCritical float64, ) *ComplianceSummary`

NewComplianceSummary instantiates a new ComplianceSummary object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewComplianceSummaryWithDefaults

`func NewComplianceSummaryWithDefaults() *ComplianceSummary`

NewComplianceSummaryWithDefaults instantiates a new ComplianceSummary object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetPercentStable

`func (o *ComplianceSummary) GetPercentStable() float64`

GetPercentStable returns the PercentStable field if non-nil, zero value otherwise.

### GetPercentStableOk

`func (o *ComplianceSummary) GetPercentStableOk() (*float64, bool)`

GetPercentStableOk returns a tuple with the PercentStable field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetPercentStable

`func (o *ComplianceSummary) SetPercentStable(v float64)`

SetPercentStable sets PercentStable field to given value.


### GetPercentMarginal

`func (o *ComplianceSummary) GetPercentMarginal() float64`

GetPercentMarginal returns the PercentMarginal field if non-nil, zero value otherwise.

### GetPercentMarginalOk

`func (o *ComplianceSummary) GetPercentMarginalOk() (*float64, bool)`

GetPercentMarginalOk returns a tuple with the PercentMarginal field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetPercentMarginal

`func (o *ComplianceSummary) SetPercentMarginal(v float64)`

SetPercentMarginal sets PercentMarginal field to given value.


### GetPercentCritical

`func (o *ComplianceSummary) GetPercentCritical() float64`

GetPercentCritical returns the PercentCritical field if non-nil, zero value otherwise.

### GetPercentCriticalOk

`func (o *ComplianceSummary) GetPercentCriticalOk() (*float64, bool)`

GetPercentCriticalOk returns a tuple with the PercentCritical field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetPercentCritical

`func (o *ComplianceSummary) SetPercentCritical(v float64)`

SetPercentCritical sets PercentCritical field to given value.



[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


