# EditStorageResourceAttributesParam

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**SubscribedLimitGb** | Pointer to **string** | The New Storage Resource Subscribed Limit (GB) | [optional] 

## Methods

### NewEditStorageResourceAttributesParam

`func NewEditStorageResourceAttributesParam() *EditStorageResourceAttributesParam`

NewEditStorageResourceAttributesParam instantiates a new EditStorageResourceAttributesParam object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewEditStorageResourceAttributesParamWithDefaults

`func NewEditStorageResourceAttributesParamWithDefaults() *EditStorageResourceAttributesParam`

NewEditStorageResourceAttributesParamWithDefaults instantiates a new EditStorageResourceAttributesParam object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetSubscribedLimitGb

`func (o *EditStorageResourceAttributesParam) GetSubscribedLimitGb() string`

GetSubscribedLimitGb returns the SubscribedLimitGb field if non-nil, zero value otherwise.

### GetSubscribedLimitGbOk

`func (o *EditStorageResourceAttributesParam) GetSubscribedLimitGbOk() (*string, bool)`

GetSubscribedLimitGbOk returns a tuple with the SubscribedLimitGb field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetSubscribedLimitGb

`func (o *EditStorageResourceAttributesParam) SetSubscribedLimitGb(v string)`

SetSubscribedLimitGb sets SubscribedLimitGb field to given value.

### HasSubscribedLimitGb

`func (o *EditStorageResourceAttributesParam) HasSubscribedLimitGb() bool`

HasSubscribedLimitGb returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


