# CreateHostGroupParam

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ExecutionOption** | Pointer to **string** |  | [optional] [default to "SYNCHRONOUS"]
**HostGroupId** | **string** | ID/name of the host group | 
**HostId** | Pointer to **[]string** | Ids of existing hosts to be added to host group | [optional] 
**NewHosts** | Pointer to [**[]CreateHostParam**](CreateHostParam.md) | New host objects to be added to host group | [optional] 
**HostFlags** | Pointer to [**HostFlags**](HostFlags.md) |  | [optional] 

## Methods

### NewCreateHostGroupParam

`func NewCreateHostGroupParam(hostGroupId string, ) *CreateHostGroupParam`

NewCreateHostGroupParam instantiates a new CreateHostGroupParam object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewCreateHostGroupParamWithDefaults

`func NewCreateHostGroupParamWithDefaults() *CreateHostGroupParam`

NewCreateHostGroupParamWithDefaults instantiates a new CreateHostGroupParam object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetExecutionOption

`func (o *CreateHostGroupParam) GetExecutionOption() string`

GetExecutionOption returns the ExecutionOption field if non-nil, zero value otherwise.

### GetExecutionOptionOk

`func (o *CreateHostGroupParam) GetExecutionOptionOk() (*string, bool)`

GetExecutionOptionOk returns a tuple with the ExecutionOption field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetExecutionOption

`func (o *CreateHostGroupParam) SetExecutionOption(v string)`

SetExecutionOption sets ExecutionOption field to given value.

### HasExecutionOption

`func (o *CreateHostGroupParam) HasExecutionOption() bool`

HasExecutionOption returns a boolean if a field has been set.

### GetHostGroupId

`func (o *CreateHostGroupParam) GetHostGroupId() string`

GetHostGroupId returns the HostGroupId field if non-nil, zero value otherwise.

### GetHostGroupIdOk

`func (o *CreateHostGroupParam) GetHostGroupIdOk() (*string, bool)`

GetHostGroupIdOk returns a tuple with the HostGroupId field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetHostGroupId

`func (o *CreateHostGroupParam) SetHostGroupId(v string)`

SetHostGroupId sets HostGroupId field to given value.


### GetHostId

`func (o *CreateHostGroupParam) GetHostId() []string`

GetHostId returns the HostId field if non-nil, zero value otherwise.

### GetHostIdOk

`func (o *CreateHostGroupParam) GetHostIdOk() (*[]string, bool)`

GetHostIdOk returns a tuple with the HostId field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetHostId

`func (o *CreateHostGroupParam) SetHostId(v []string)`

SetHostId sets HostId field to given value.

### HasHostId

`func (o *CreateHostGroupParam) HasHostId() bool`

HasHostId returns a boolean if a field has been set.

### GetNewHosts

`func (o *CreateHostGroupParam) GetNewHosts() []CreateHostParam`

GetNewHosts returns the NewHosts field if non-nil, zero value otherwise.

### GetNewHostsOk

`func (o *CreateHostGroupParam) GetNewHostsOk() (*[]CreateHostParam, bool)`

GetNewHostsOk returns a tuple with the NewHosts field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetNewHosts

`func (o *CreateHostGroupParam) SetNewHosts(v []CreateHostParam)`

SetNewHosts sets NewHosts field to given value.

### HasNewHosts

`func (o *CreateHostGroupParam) HasNewHosts() bool`

HasNewHosts returns a boolean if a field has been set.

### GetHostFlags

`func (o *CreateHostGroupParam) GetHostFlags() HostFlags`

GetHostFlags returns the HostFlags field if non-nil, zero value otherwise.

### GetHostFlagsOk

`func (o *CreateHostGroupParam) GetHostFlagsOk() (*HostFlags, bool)`

GetHostFlagsOk returns a tuple with the HostFlags field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetHostFlags

`func (o *CreateHostGroupParam) SetHostFlags(v HostFlags)`

SetHostFlags sets HostFlags field to given value.

### HasHostFlags

`func (o *CreateHostGroupParam) HasHostFlags() bool`

HasHostFlags returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


