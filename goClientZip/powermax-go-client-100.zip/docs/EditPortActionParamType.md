# EditPortActionParamType

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**SetPortAttributesActionParamType** | Pointer to [**SetPortAttributesActionParamType**](SetPortAttributesActionParamType.md) |  | [optional] 
**EditISCSITargetActionParam** | Pointer to [**EditISCSITargetActionParam**](EditISCSITargetActionParam.md) |  | [optional] 
**EditEndpointActionParam** | Pointer to [**EditEndpointActionParam**](EditEndpointActionParam.md) |  | [optional] 
**OnlineOfflineParamType** | Pointer to [**OnlineOfflineParamType**](OnlineOfflineParamType.md) |  | [optional] 

## Methods

### NewEditPortActionParamType

`func NewEditPortActionParamType() *EditPortActionParamType`

NewEditPortActionParamType instantiates a new EditPortActionParamType object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewEditPortActionParamTypeWithDefaults

`func NewEditPortActionParamTypeWithDefaults() *EditPortActionParamType`

NewEditPortActionParamTypeWithDefaults instantiates a new EditPortActionParamType object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetSetPortAttributesActionParamType

`func (o *EditPortActionParamType) GetSetPortAttributesActionParamType() SetPortAttributesActionParamType`

GetSetPortAttributesActionParamType returns the SetPortAttributesActionParamType field if non-nil, zero value otherwise.

### GetSetPortAttributesActionParamTypeOk

`func (o *EditPortActionParamType) GetSetPortAttributesActionParamTypeOk() (*SetPortAttributesActionParamType, bool)`

GetSetPortAttributesActionParamTypeOk returns a tuple with the SetPortAttributesActionParamType field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetSetPortAttributesActionParamType

`func (o *EditPortActionParamType) SetSetPortAttributesActionParamType(v SetPortAttributesActionParamType)`

SetSetPortAttributesActionParamType sets SetPortAttributesActionParamType field to given value.

### HasSetPortAttributesActionParamType

`func (o *EditPortActionParamType) HasSetPortAttributesActionParamType() bool`

HasSetPortAttributesActionParamType returns a boolean if a field has been set.

### GetEditISCSITargetActionParam

`func (o *EditPortActionParamType) GetEditISCSITargetActionParam() EditISCSITargetActionParam`

GetEditISCSITargetActionParam returns the EditISCSITargetActionParam field if non-nil, zero value otherwise.

### GetEditISCSITargetActionParamOk

`func (o *EditPortActionParamType) GetEditISCSITargetActionParamOk() (*EditISCSITargetActionParam, bool)`

GetEditISCSITargetActionParamOk returns a tuple with the EditISCSITargetActionParam field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetEditISCSITargetActionParam

`func (o *EditPortActionParamType) SetEditISCSITargetActionParam(v EditISCSITargetActionParam)`

SetEditISCSITargetActionParam sets EditISCSITargetActionParam field to given value.

### HasEditISCSITargetActionParam

`func (o *EditPortActionParamType) HasEditISCSITargetActionParam() bool`

HasEditISCSITargetActionParam returns a boolean if a field has been set.

### GetEditEndpointActionParam

`func (o *EditPortActionParamType) GetEditEndpointActionParam() EditEndpointActionParam`

GetEditEndpointActionParam returns the EditEndpointActionParam field if non-nil, zero value otherwise.

### GetEditEndpointActionParamOk

`func (o *EditPortActionParamType) GetEditEndpointActionParamOk() (*EditEndpointActionParam, bool)`

GetEditEndpointActionParamOk returns a tuple with the EditEndpointActionParam field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetEditEndpointActionParam

`func (o *EditPortActionParamType) SetEditEndpointActionParam(v EditEndpointActionParam)`

SetEditEndpointActionParam sets EditEndpointActionParam field to given value.

### HasEditEndpointActionParam

`func (o *EditPortActionParamType) HasEditEndpointActionParam() bool`

HasEditEndpointActionParam returns a boolean if a field has been set.

### GetOnlineOfflineParamType

`func (o *EditPortActionParamType) GetOnlineOfflineParamType() OnlineOfflineParamType`

GetOnlineOfflineParamType returns the OnlineOfflineParamType field if non-nil, zero value otherwise.

### GetOnlineOfflineParamTypeOk

`func (o *EditPortActionParamType) GetOnlineOfflineParamTypeOk() (*OnlineOfflineParamType, bool)`

GetOnlineOfflineParamTypeOk returns a tuple with the OnlineOfflineParamType field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetOnlineOfflineParamType

`func (o *EditPortActionParamType) SetOnlineOfflineParamType(v OnlineOfflineParamType)`

SetOnlineOfflineParamType sets OnlineOfflineParamType field to given value.

### HasOnlineOfflineParamType

`func (o *EditPortActionParamType) HasOnlineOfflineParamType() bool`

HasOnlineOfflineParamType returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


