# AmazonConnectionDetails

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Key** | Pointer to **string** | The Cloud Provider Key | [optional] 
**Secret** | Pointer to **string** | The Cloud Provider Secret | [optional] 
**Secure** | Pointer to **bool** | Is The Cloud Provider Secure, HTTPS &#x3D; true | [optional] 
**Bucket** | Pointer to **string** | The Cloud Provider Bucket Name | [optional] 
**Node** | Pointer to **string** | The Cloud Provider Node | [optional] 
**Port** | Pointer to **int32** | The Cloud Provider Port | [optional] 
**StorageClass** | Pointer to **string** | The Cloud Provider Storage Class | [optional] 
**Region** | Pointer to **string** | The Cloud Provider Region | [optional] 

## Methods

### NewAmazonConnectionDetails

`func NewAmazonConnectionDetails() *AmazonConnectionDetails`

NewAmazonConnectionDetails instantiates a new AmazonConnectionDetails object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewAmazonConnectionDetailsWithDefaults

`func NewAmazonConnectionDetailsWithDefaults() *AmazonConnectionDetails`

NewAmazonConnectionDetailsWithDefaults instantiates a new AmazonConnectionDetails object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetKey

`func (o *AmazonConnectionDetails) GetKey() string`

GetKey returns the Key field if non-nil, zero value otherwise.

### GetKeyOk

`func (o *AmazonConnectionDetails) GetKeyOk() (*string, bool)`

GetKeyOk returns a tuple with the Key field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetKey

`func (o *AmazonConnectionDetails) SetKey(v string)`

SetKey sets Key field to given value.

### HasKey

`func (o *AmazonConnectionDetails) HasKey() bool`

HasKey returns a boolean if a field has been set.

### GetSecret

`func (o *AmazonConnectionDetails) GetSecret() string`

GetSecret returns the Secret field if non-nil, zero value otherwise.

### GetSecretOk

`func (o *AmazonConnectionDetails) GetSecretOk() (*string, bool)`

GetSecretOk returns a tuple with the Secret field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetSecret

`func (o *AmazonConnectionDetails) SetSecret(v string)`

SetSecret sets Secret field to given value.

### HasSecret

`func (o *AmazonConnectionDetails) HasSecret() bool`

HasSecret returns a boolean if a field has been set.

### GetSecure

`func (o *AmazonConnectionDetails) GetSecure() bool`

GetSecure returns the Secure field if non-nil, zero value otherwise.

### GetSecureOk

`func (o *AmazonConnectionDetails) GetSecureOk() (*bool, bool)`

GetSecureOk returns a tuple with the Secure field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetSecure

`func (o *AmazonConnectionDetails) SetSecure(v bool)`

SetSecure sets Secure field to given value.

### HasSecure

`func (o *AmazonConnectionDetails) HasSecure() bool`

HasSecure returns a boolean if a field has been set.

### GetBucket

`func (o *AmazonConnectionDetails) GetBucket() string`

GetBucket returns the Bucket field if non-nil, zero value otherwise.

### GetBucketOk

`func (o *AmazonConnectionDetails) GetBucketOk() (*string, bool)`

GetBucketOk returns a tuple with the Bucket field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetBucket

`func (o *AmazonConnectionDetails) SetBucket(v string)`

SetBucket sets Bucket field to given value.

### HasBucket

`func (o *AmazonConnectionDetails) HasBucket() bool`

HasBucket returns a boolean if a field has been set.

### GetNode

`func (o *AmazonConnectionDetails) GetNode() string`

GetNode returns the Node field if non-nil, zero value otherwise.

### GetNodeOk

`func (o *AmazonConnectionDetails) GetNodeOk() (*string, bool)`

GetNodeOk returns a tuple with the Node field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetNode

`func (o *AmazonConnectionDetails) SetNode(v string)`

SetNode sets Node field to given value.

### HasNode

`func (o *AmazonConnectionDetails) HasNode() bool`

HasNode returns a boolean if a field has been set.

### GetPort

`func (o *AmazonConnectionDetails) GetPort() int32`

GetPort returns the Port field if non-nil, zero value otherwise.

### GetPortOk

`func (o *AmazonConnectionDetails) GetPortOk() (*int32, bool)`

GetPortOk returns a tuple with the Port field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetPort

`func (o *AmazonConnectionDetails) SetPort(v int32)`

SetPort sets Port field to given value.

### HasPort

`func (o *AmazonConnectionDetails) HasPort() bool`

HasPort returns a boolean if a field has been set.

### GetStorageClass

`func (o *AmazonConnectionDetails) GetStorageClass() string`

GetStorageClass returns the StorageClass field if non-nil, zero value otherwise.

### GetStorageClassOk

`func (o *AmazonConnectionDetails) GetStorageClassOk() (*string, bool)`

GetStorageClassOk returns a tuple with the StorageClass field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetStorageClass

`func (o *AmazonConnectionDetails) SetStorageClass(v string)`

SetStorageClass sets StorageClass field to given value.

### HasStorageClass

`func (o *AmazonConnectionDetails) HasStorageClass() bool`

HasStorageClass returns a boolean if a field has been set.

### GetRegion

`func (o *AmazonConnectionDetails) GetRegion() string`

GetRegion returns the Region field if non-nil, zero value otherwise.

### GetRegionOk

`func (o *AmazonConnectionDetails) GetRegionOk() (*string, bool)`

GetRegionOk returns a tuple with the Region field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetRegion

`func (o *AmazonConnectionDetails) SetRegion(v string)`

SetRegion sets Region field to given value.

### HasRegion

`func (o *AmazonConnectionDetails) HasRegion() bool`

HasRegion returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


