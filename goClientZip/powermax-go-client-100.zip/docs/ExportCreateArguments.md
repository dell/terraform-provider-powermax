# ExportCreateArguments

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**StorageResource** | **string** |                          Unique identifier of the filesystem or snap on wich the export will be created.                      | 
**Path** | **string** |                          Local path to a location within the file system.                         With NFS, each export must have a unique local path. The path is specified relative to the root of the file system (top-most directory).                         Before you can create additional exports within an NFS exported folder, you must create directories within it from a Linux/Unix host that is connected to the file system. After a directory has been created from a mounted host in the readWriteRootHosts list, you can create a corresponding export and set access permissions accordingly.                      | 
**Name** | **string** |                          NFS export name. May be a directory path, but leading slash must be omitted. Export name is reported as a directory path to behave as a symbolic link to the exported directory path.                      | 
**Description** | Pointer to **string** |                          User defined NFS export description.                      | [optional] 
**DefaultAccess** | Pointer to **string** |                          Default access level for all hosts that can access the export.                         - 0 : **NoAccess** &#x3D;&gt; Deny access to the export for the hosts.                         - 1 : **ReadOnly** &#x3D;&gt; Allow read only access to the export for the hosts.                         - 2 : **ReadWrite** &#x3D;&gt; Allow read write access to the export for the hosts.                         - 3 : **Root** &#x3D;&gt; Allow read write access to the export for the hosts. Allow access to the share for root user.                         - 4 : **RoRoot** &#x3D;&gt; Allow read only root access to the export for the hosts.                        Enumeration values: * **NoAccess** * **ReadOnly** * **ReadWrite** * **Root** * **RoRoot**  | [optional] 
**MinSecurity** | Pointer to **string** |                          NFS minimum enforced security type for users accessing an NFS export.                         - 0 : **Sys** &#x3D;&gt; Allow user to authenticate with any NFS security types: UNIX, Kerberos, Kerberos with integrity and Kerberos with encryption. *sys/krb5/krb5i/krb5p*                         - 1 : **Kerberos** &#x3D;&gt; Allow only Kerberos security for user authentication. *krb5/krb5i/krb5p*                         - 2 : **KerberosWithIntegrity** &#x3D;&gt; Allow only Kerberos with integrity and Kerberos with encryption security for user authentication. *krb5i/krb5p*                         - 3 : **KerberosWithEncryption** &#x3D;&gt; Allow only Kerberos with encryption security for user authentication. *krb5p*                         Enumeration values: * **Sys** * **Kerberos** * **KerberosWithIntegrity** * **KerberosWithEncryption**  | [optional] 
**NoAccessHosts** | Pointer to **[]string** |                          Hosts with **no** access to the NFS export or its snapshots. This list is useful when \&quot;defaultAccess\&quot; is not \&quot;NoAccess\&quot;.                      | [optional] 
**ReadOnlyHosts** | Pointer to **[]string** |                          Hosts with **read-only** access to the NFS export and its snapshots.                      | [optional] 
**ReadOnlyRootHosts** | Pointer to **[]string** |                          Hosts with **read-only** *and* **ready-only for root user** access * to the NFS export and its snapshots.                      | [optional] 
**ReadWriteHosts** | Pointer to **[]string** |                          Hosts with **read and write** access to the NFS export and its snapshots.                      | [optional] 
**ReadWriteRootHosts** | Pointer to **[]string** |                          Hosts with **read and write** *and* **read and write for root user** access to the NFS export and its snapshots.                      | [optional] 
**AnonymousUid** | Pointer to **int32** |                          Specifies the user ID of the anonymous account.                      | [optional] 
**AnonymousGid** | Pointer to **int32** |                          Specifies the group ID of the anonymous account.                      | [optional] 
**NoSuid** | Pointer to **bool** |                          if set, do not allow access to set SUID. Otherwise, allow access.                      | [optional] 
**NfsOwnerUsername** | Pointer to **bool** |                          Set the owner of the local path this export points to.                         *  Required when the storage resource is used as a VMWare datastore with secure NFS enabled.                         *  When a username (string) is provided, the nas Server will try to resolve its UID using its current Unix Directory Service settings, operation will fail if no mapping is found.                         *  When a number is provided, ownership of the local path will be set using this UID.  The default owner is root.                      | [optional] 

## Methods

### NewExportCreateArguments

`func NewExportCreateArguments(storageResource string, path string, name string, ) *ExportCreateArguments`

NewExportCreateArguments instantiates a new ExportCreateArguments object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewExportCreateArgumentsWithDefaults

`func NewExportCreateArgumentsWithDefaults() *ExportCreateArguments`

NewExportCreateArgumentsWithDefaults instantiates a new ExportCreateArguments object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetStorageResource

`func (o *ExportCreateArguments) GetStorageResource() string`

GetStorageResource returns the StorageResource field if non-nil, zero value otherwise.

### GetStorageResourceOk

`func (o *ExportCreateArguments) GetStorageResourceOk() (*string, bool)`

GetStorageResourceOk returns a tuple with the StorageResource field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetStorageResource

`func (o *ExportCreateArguments) SetStorageResource(v string)`

SetStorageResource sets StorageResource field to given value.


### GetPath

`func (o *ExportCreateArguments) GetPath() string`

GetPath returns the Path field if non-nil, zero value otherwise.

### GetPathOk

`func (o *ExportCreateArguments) GetPathOk() (*string, bool)`

GetPathOk returns a tuple with the Path field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetPath

`func (o *ExportCreateArguments) SetPath(v string)`

SetPath sets Path field to given value.


### GetName

`func (o *ExportCreateArguments) GetName() string`

GetName returns the Name field if non-nil, zero value otherwise.

### GetNameOk

`func (o *ExportCreateArguments) GetNameOk() (*string, bool)`

GetNameOk returns a tuple with the Name field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetName

`func (o *ExportCreateArguments) SetName(v string)`

SetName sets Name field to given value.


### GetDescription

`func (o *ExportCreateArguments) GetDescription() string`

GetDescription returns the Description field if non-nil, zero value otherwise.

### GetDescriptionOk

`func (o *ExportCreateArguments) GetDescriptionOk() (*string, bool)`

GetDescriptionOk returns a tuple with the Description field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetDescription

`func (o *ExportCreateArguments) SetDescription(v string)`

SetDescription sets Description field to given value.

### HasDescription

`func (o *ExportCreateArguments) HasDescription() bool`

HasDescription returns a boolean if a field has been set.

### GetDefaultAccess

`func (o *ExportCreateArguments) GetDefaultAccess() string`

GetDefaultAccess returns the DefaultAccess field if non-nil, zero value otherwise.

### GetDefaultAccessOk

`func (o *ExportCreateArguments) GetDefaultAccessOk() (*string, bool)`

GetDefaultAccessOk returns a tuple with the DefaultAccess field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetDefaultAccess

`func (o *ExportCreateArguments) SetDefaultAccess(v string)`

SetDefaultAccess sets DefaultAccess field to given value.

### HasDefaultAccess

`func (o *ExportCreateArguments) HasDefaultAccess() bool`

HasDefaultAccess returns a boolean if a field has been set.

### GetMinSecurity

`func (o *ExportCreateArguments) GetMinSecurity() string`

GetMinSecurity returns the MinSecurity field if non-nil, zero value otherwise.

### GetMinSecurityOk

`func (o *ExportCreateArguments) GetMinSecurityOk() (*string, bool)`

GetMinSecurityOk returns a tuple with the MinSecurity field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetMinSecurity

`func (o *ExportCreateArguments) SetMinSecurity(v string)`

SetMinSecurity sets MinSecurity field to given value.

### HasMinSecurity

`func (o *ExportCreateArguments) HasMinSecurity() bool`

HasMinSecurity returns a boolean if a field has been set.

### GetNoAccessHosts

`func (o *ExportCreateArguments) GetNoAccessHosts() []string`

GetNoAccessHosts returns the NoAccessHosts field if non-nil, zero value otherwise.

### GetNoAccessHostsOk

`func (o *ExportCreateArguments) GetNoAccessHostsOk() (*[]string, bool)`

GetNoAccessHostsOk returns a tuple with the NoAccessHosts field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetNoAccessHosts

`func (o *ExportCreateArguments) SetNoAccessHosts(v []string)`

SetNoAccessHosts sets NoAccessHosts field to given value.

### HasNoAccessHosts

`func (o *ExportCreateArguments) HasNoAccessHosts() bool`

HasNoAccessHosts returns a boolean if a field has been set.

### GetReadOnlyHosts

`func (o *ExportCreateArguments) GetReadOnlyHosts() []string`

GetReadOnlyHosts returns the ReadOnlyHosts field if non-nil, zero value otherwise.

### GetReadOnlyHostsOk

`func (o *ExportCreateArguments) GetReadOnlyHostsOk() (*[]string, bool)`

GetReadOnlyHostsOk returns a tuple with the ReadOnlyHosts field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetReadOnlyHosts

`func (o *ExportCreateArguments) SetReadOnlyHosts(v []string)`

SetReadOnlyHosts sets ReadOnlyHosts field to given value.

### HasReadOnlyHosts

`func (o *ExportCreateArguments) HasReadOnlyHosts() bool`

HasReadOnlyHosts returns a boolean if a field has been set.

### GetReadOnlyRootHosts

`func (o *ExportCreateArguments) GetReadOnlyRootHosts() []string`

GetReadOnlyRootHosts returns the ReadOnlyRootHosts field if non-nil, zero value otherwise.

### GetReadOnlyRootHostsOk

`func (o *ExportCreateArguments) GetReadOnlyRootHostsOk() (*[]string, bool)`

GetReadOnlyRootHostsOk returns a tuple with the ReadOnlyRootHosts field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetReadOnlyRootHosts

`func (o *ExportCreateArguments) SetReadOnlyRootHosts(v []string)`

SetReadOnlyRootHosts sets ReadOnlyRootHosts field to given value.

### HasReadOnlyRootHosts

`func (o *ExportCreateArguments) HasReadOnlyRootHosts() bool`

HasReadOnlyRootHosts returns a boolean if a field has been set.

### GetReadWriteHosts

`func (o *ExportCreateArguments) GetReadWriteHosts() []string`

GetReadWriteHosts returns the ReadWriteHosts field if non-nil, zero value otherwise.

### GetReadWriteHostsOk

`func (o *ExportCreateArguments) GetReadWriteHostsOk() (*[]string, bool)`

GetReadWriteHostsOk returns a tuple with the ReadWriteHosts field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetReadWriteHosts

`func (o *ExportCreateArguments) SetReadWriteHosts(v []string)`

SetReadWriteHosts sets ReadWriteHosts field to given value.

### HasReadWriteHosts

`func (o *ExportCreateArguments) HasReadWriteHosts() bool`

HasReadWriteHosts returns a boolean if a field has been set.

### GetReadWriteRootHosts

`func (o *ExportCreateArguments) GetReadWriteRootHosts() []string`

GetReadWriteRootHosts returns the ReadWriteRootHosts field if non-nil, zero value otherwise.

### GetReadWriteRootHostsOk

`func (o *ExportCreateArguments) GetReadWriteRootHostsOk() (*[]string, bool)`

GetReadWriteRootHostsOk returns a tuple with the ReadWriteRootHosts field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetReadWriteRootHosts

`func (o *ExportCreateArguments) SetReadWriteRootHosts(v []string)`

SetReadWriteRootHosts sets ReadWriteRootHosts field to given value.

### HasReadWriteRootHosts

`func (o *ExportCreateArguments) HasReadWriteRootHosts() bool`

HasReadWriteRootHosts returns a boolean if a field has been set.

### GetAnonymousUid

`func (o *ExportCreateArguments) GetAnonymousUid() int32`

GetAnonymousUid returns the AnonymousUid field if non-nil, zero value otherwise.

### GetAnonymousUidOk

`func (o *ExportCreateArguments) GetAnonymousUidOk() (*int32, bool)`

GetAnonymousUidOk returns a tuple with the AnonymousUid field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetAnonymousUid

`func (o *ExportCreateArguments) SetAnonymousUid(v int32)`

SetAnonymousUid sets AnonymousUid field to given value.

### HasAnonymousUid

`func (o *ExportCreateArguments) HasAnonymousUid() bool`

HasAnonymousUid returns a boolean if a field has been set.

### GetAnonymousGid

`func (o *ExportCreateArguments) GetAnonymousGid() int32`

GetAnonymousGid returns the AnonymousGid field if non-nil, zero value otherwise.

### GetAnonymousGidOk

`func (o *ExportCreateArguments) GetAnonymousGidOk() (*int32, bool)`

GetAnonymousGidOk returns a tuple with the AnonymousGid field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetAnonymousGid

`func (o *ExportCreateArguments) SetAnonymousGid(v int32)`

SetAnonymousGid sets AnonymousGid field to given value.

### HasAnonymousGid

`func (o *ExportCreateArguments) HasAnonymousGid() bool`

HasAnonymousGid returns a boolean if a field has been set.

### GetNoSuid

`func (o *ExportCreateArguments) GetNoSuid() bool`

GetNoSuid returns the NoSuid field if non-nil, zero value otherwise.

### GetNoSuidOk

`func (o *ExportCreateArguments) GetNoSuidOk() (*bool, bool)`

GetNoSuidOk returns a tuple with the NoSuid field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetNoSuid

`func (o *ExportCreateArguments) SetNoSuid(v bool)`

SetNoSuid sets NoSuid field to given value.

### HasNoSuid

`func (o *ExportCreateArguments) HasNoSuid() bool`

HasNoSuid returns a boolean if a field has been set.

### GetNfsOwnerUsername

`func (o *ExportCreateArguments) GetNfsOwnerUsername() bool`

GetNfsOwnerUsername returns the NfsOwnerUsername field if non-nil, zero value otherwise.

### GetNfsOwnerUsernameOk

`func (o *ExportCreateArguments) GetNfsOwnerUsernameOk() (*bool, bool)`

GetNfsOwnerUsernameOk returns a tuple with the NfsOwnerUsername field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetNfsOwnerUsername

`func (o *ExportCreateArguments) SetNfsOwnerUsername(v bool)`

SetNfsOwnerUsername sets NfsOwnerUsername field to given value.

### HasNfsOwnerUsername

`func (o *ExportCreateArguments) HasNfsOwnerUsername() bool`

HasNfsOwnerUsername returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


