# EditStorageGroupActionParam

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**TagManagementParam** | Pointer to [**TagManagementParam**](TagManagementParam.md) |  | [optional] 
**MergeStorageGroupParam** | Pointer to [**MergeStorageGroupParam**](MergeStorageGroupParam.md) |  | [optional] 
**SplitStorageGroupVolumesParam** | Pointer to [**SplitStorageGroupVolumesParam**](SplitStorageGroupVolumesParam.md) |  | [optional] 
**SplitChildStorageGroupParam** | Pointer to [**SplitChildStorageGroupParam**](SplitChildStorageGroupParam.md) |  | [optional] 
**MoveVolumeToStorageGroupParam** | Pointer to [**MoveVolumeToStorageGroupParam**](MoveVolumeToStorageGroupParam.md) |  | [optional] 
**EditCompressionParam** | Pointer to [**EditCompressionParam**](EditCompressionParam.md) |  | [optional] 
**SetHostIOLimitsParam** | Pointer to [**SetHostIOLimitsParam**](SetHostIOLimitsParam.md) |  | [optional] 
**RemoveVolumeParam** | Pointer to [**RemoveVolumeParam**](RemoveVolumeParam.md) |  | [optional] 
**ExpandStorageGroupParam** | Pointer to [**ExpandStorageGroupParam**](ExpandStorageGroupParam.md) |  | [optional] 
**EditStorageGroupWorkloadParam** | Pointer to [**EditStorageGroupWorkloadParam**](EditStorageGroupWorkloadParam.md) |  | [optional] 
**EditSnapshotPoliciesParam** | Pointer to [**EditSnapshotPoliciesParam**](EditSnapshotPoliciesParam.md) |  | [optional] 
**EditStorageGroupSLOParam** | Pointer to [**EditStorageGroupSLOParam**](EditStorageGroupSLOParam.md) |  | [optional] 
**EditStorageGroupSRPParam** | Pointer to [**EditStorageGroupSRPParam**](EditStorageGroupSRPParam.md) |  | [optional] 
**RemoveStorageGroupParam** | Pointer to [**RemoveStorageGroupParam**](RemoveStorageGroupParam.md) |  | [optional] 
**RenameStorageGroupParam** | Pointer to [**RenameStorageGroupParam**](RenameStorageGroupParam.md) |  | [optional] 

## Methods

### NewEditStorageGroupActionParam

`func NewEditStorageGroupActionParam() *EditStorageGroupActionParam`

NewEditStorageGroupActionParam instantiates a new EditStorageGroupActionParam object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewEditStorageGroupActionParamWithDefaults

`func NewEditStorageGroupActionParamWithDefaults() *EditStorageGroupActionParam`

NewEditStorageGroupActionParamWithDefaults instantiates a new EditStorageGroupActionParam object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetTagManagementParam

`func (o *EditStorageGroupActionParam) GetTagManagementParam() TagManagementParam`

GetTagManagementParam returns the TagManagementParam field if non-nil, zero value otherwise.

### GetTagManagementParamOk

`func (o *EditStorageGroupActionParam) GetTagManagementParamOk() (*TagManagementParam, bool)`

GetTagManagementParamOk returns a tuple with the TagManagementParam field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetTagManagementParam

`func (o *EditStorageGroupActionParam) SetTagManagementParam(v TagManagementParam)`

SetTagManagementParam sets TagManagementParam field to given value.

### HasTagManagementParam

`func (o *EditStorageGroupActionParam) HasTagManagementParam() bool`

HasTagManagementParam returns a boolean if a field has been set.

### GetMergeStorageGroupParam

`func (o *EditStorageGroupActionParam) GetMergeStorageGroupParam() MergeStorageGroupParam`

GetMergeStorageGroupParam returns the MergeStorageGroupParam field if non-nil, zero value otherwise.

### GetMergeStorageGroupParamOk

`func (o *EditStorageGroupActionParam) GetMergeStorageGroupParamOk() (*MergeStorageGroupParam, bool)`

GetMergeStorageGroupParamOk returns a tuple with the MergeStorageGroupParam field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetMergeStorageGroupParam

`func (o *EditStorageGroupActionParam) SetMergeStorageGroupParam(v MergeStorageGroupParam)`

SetMergeStorageGroupParam sets MergeStorageGroupParam field to given value.

### HasMergeStorageGroupParam

`func (o *EditStorageGroupActionParam) HasMergeStorageGroupParam() bool`

HasMergeStorageGroupParam returns a boolean if a field has been set.

### GetSplitStorageGroupVolumesParam

`func (o *EditStorageGroupActionParam) GetSplitStorageGroupVolumesParam() SplitStorageGroupVolumesParam`

GetSplitStorageGroupVolumesParam returns the SplitStorageGroupVolumesParam field if non-nil, zero value otherwise.

### GetSplitStorageGroupVolumesParamOk

`func (o *EditStorageGroupActionParam) GetSplitStorageGroupVolumesParamOk() (*SplitStorageGroupVolumesParam, bool)`

GetSplitStorageGroupVolumesParamOk returns a tuple with the SplitStorageGroupVolumesParam field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetSplitStorageGroupVolumesParam

`func (o *EditStorageGroupActionParam) SetSplitStorageGroupVolumesParam(v SplitStorageGroupVolumesParam)`

SetSplitStorageGroupVolumesParam sets SplitStorageGroupVolumesParam field to given value.

### HasSplitStorageGroupVolumesParam

`func (o *EditStorageGroupActionParam) HasSplitStorageGroupVolumesParam() bool`

HasSplitStorageGroupVolumesParam returns a boolean if a field has been set.

### GetSplitChildStorageGroupParam

`func (o *EditStorageGroupActionParam) GetSplitChildStorageGroupParam() SplitChildStorageGroupParam`

GetSplitChildStorageGroupParam returns the SplitChildStorageGroupParam field if non-nil, zero value otherwise.

### GetSplitChildStorageGroupParamOk

`func (o *EditStorageGroupActionParam) GetSplitChildStorageGroupParamOk() (*SplitChildStorageGroupParam, bool)`

GetSplitChildStorageGroupParamOk returns a tuple with the SplitChildStorageGroupParam field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetSplitChildStorageGroupParam

`func (o *EditStorageGroupActionParam) SetSplitChildStorageGroupParam(v SplitChildStorageGroupParam)`

SetSplitChildStorageGroupParam sets SplitChildStorageGroupParam field to given value.

### HasSplitChildStorageGroupParam

`func (o *EditStorageGroupActionParam) HasSplitChildStorageGroupParam() bool`

HasSplitChildStorageGroupParam returns a boolean if a field has been set.

### GetMoveVolumeToStorageGroupParam

`func (o *EditStorageGroupActionParam) GetMoveVolumeToStorageGroupParam() MoveVolumeToStorageGroupParam`

GetMoveVolumeToStorageGroupParam returns the MoveVolumeToStorageGroupParam field if non-nil, zero value otherwise.

### GetMoveVolumeToStorageGroupParamOk

`func (o *EditStorageGroupActionParam) GetMoveVolumeToStorageGroupParamOk() (*MoveVolumeToStorageGroupParam, bool)`

GetMoveVolumeToStorageGroupParamOk returns a tuple with the MoveVolumeToStorageGroupParam field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetMoveVolumeToStorageGroupParam

`func (o *EditStorageGroupActionParam) SetMoveVolumeToStorageGroupParam(v MoveVolumeToStorageGroupParam)`

SetMoveVolumeToStorageGroupParam sets MoveVolumeToStorageGroupParam field to given value.

### HasMoveVolumeToStorageGroupParam

`func (o *EditStorageGroupActionParam) HasMoveVolumeToStorageGroupParam() bool`

HasMoveVolumeToStorageGroupParam returns a boolean if a field has been set.

### GetEditCompressionParam

`func (o *EditStorageGroupActionParam) GetEditCompressionParam() EditCompressionParam`

GetEditCompressionParam returns the EditCompressionParam field if non-nil, zero value otherwise.

### GetEditCompressionParamOk

`func (o *EditStorageGroupActionParam) GetEditCompressionParamOk() (*EditCompressionParam, bool)`

GetEditCompressionParamOk returns a tuple with the EditCompressionParam field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetEditCompressionParam

`func (o *EditStorageGroupActionParam) SetEditCompressionParam(v EditCompressionParam)`

SetEditCompressionParam sets EditCompressionParam field to given value.

### HasEditCompressionParam

`func (o *EditStorageGroupActionParam) HasEditCompressionParam() bool`

HasEditCompressionParam returns a boolean if a field has been set.

### GetSetHostIOLimitsParam

`func (o *EditStorageGroupActionParam) GetSetHostIOLimitsParam() SetHostIOLimitsParam`

GetSetHostIOLimitsParam returns the SetHostIOLimitsParam field if non-nil, zero value otherwise.

### GetSetHostIOLimitsParamOk

`func (o *EditStorageGroupActionParam) GetSetHostIOLimitsParamOk() (*SetHostIOLimitsParam, bool)`

GetSetHostIOLimitsParamOk returns a tuple with the SetHostIOLimitsParam field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetSetHostIOLimitsParam

`func (o *EditStorageGroupActionParam) SetSetHostIOLimitsParam(v SetHostIOLimitsParam)`

SetSetHostIOLimitsParam sets SetHostIOLimitsParam field to given value.

### HasSetHostIOLimitsParam

`func (o *EditStorageGroupActionParam) HasSetHostIOLimitsParam() bool`

HasSetHostIOLimitsParam returns a boolean if a field has been set.

### GetRemoveVolumeParam

`func (o *EditStorageGroupActionParam) GetRemoveVolumeParam() RemoveVolumeParam`

GetRemoveVolumeParam returns the RemoveVolumeParam field if non-nil, zero value otherwise.

### GetRemoveVolumeParamOk

`func (o *EditStorageGroupActionParam) GetRemoveVolumeParamOk() (*RemoveVolumeParam, bool)`

GetRemoveVolumeParamOk returns a tuple with the RemoveVolumeParam field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetRemoveVolumeParam

`func (o *EditStorageGroupActionParam) SetRemoveVolumeParam(v RemoveVolumeParam)`

SetRemoveVolumeParam sets RemoveVolumeParam field to given value.

### HasRemoveVolumeParam

`func (o *EditStorageGroupActionParam) HasRemoveVolumeParam() bool`

HasRemoveVolumeParam returns a boolean if a field has been set.

### GetExpandStorageGroupParam

`func (o *EditStorageGroupActionParam) GetExpandStorageGroupParam() ExpandStorageGroupParam`

GetExpandStorageGroupParam returns the ExpandStorageGroupParam field if non-nil, zero value otherwise.

### GetExpandStorageGroupParamOk

`func (o *EditStorageGroupActionParam) GetExpandStorageGroupParamOk() (*ExpandStorageGroupParam, bool)`

GetExpandStorageGroupParamOk returns a tuple with the ExpandStorageGroupParam field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetExpandStorageGroupParam

`func (o *EditStorageGroupActionParam) SetExpandStorageGroupParam(v ExpandStorageGroupParam)`

SetExpandStorageGroupParam sets ExpandStorageGroupParam field to given value.

### HasExpandStorageGroupParam

`func (o *EditStorageGroupActionParam) HasExpandStorageGroupParam() bool`

HasExpandStorageGroupParam returns a boolean if a field has been set.

### GetEditStorageGroupWorkloadParam

`func (o *EditStorageGroupActionParam) GetEditStorageGroupWorkloadParam() EditStorageGroupWorkloadParam`

GetEditStorageGroupWorkloadParam returns the EditStorageGroupWorkloadParam field if non-nil, zero value otherwise.

### GetEditStorageGroupWorkloadParamOk

`func (o *EditStorageGroupActionParam) GetEditStorageGroupWorkloadParamOk() (*EditStorageGroupWorkloadParam, bool)`

GetEditStorageGroupWorkloadParamOk returns a tuple with the EditStorageGroupWorkloadParam field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetEditStorageGroupWorkloadParam

`func (o *EditStorageGroupActionParam) SetEditStorageGroupWorkloadParam(v EditStorageGroupWorkloadParam)`

SetEditStorageGroupWorkloadParam sets EditStorageGroupWorkloadParam field to given value.

### HasEditStorageGroupWorkloadParam

`func (o *EditStorageGroupActionParam) HasEditStorageGroupWorkloadParam() bool`

HasEditStorageGroupWorkloadParam returns a boolean if a field has been set.

### GetEditSnapshotPoliciesParam

`func (o *EditStorageGroupActionParam) GetEditSnapshotPoliciesParam() EditSnapshotPoliciesParam`

GetEditSnapshotPoliciesParam returns the EditSnapshotPoliciesParam field if non-nil, zero value otherwise.

### GetEditSnapshotPoliciesParamOk

`func (o *EditStorageGroupActionParam) GetEditSnapshotPoliciesParamOk() (*EditSnapshotPoliciesParam, bool)`

GetEditSnapshotPoliciesParamOk returns a tuple with the EditSnapshotPoliciesParam field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetEditSnapshotPoliciesParam

`func (o *EditStorageGroupActionParam) SetEditSnapshotPoliciesParam(v EditSnapshotPoliciesParam)`

SetEditSnapshotPoliciesParam sets EditSnapshotPoliciesParam field to given value.

### HasEditSnapshotPoliciesParam

`func (o *EditStorageGroupActionParam) HasEditSnapshotPoliciesParam() bool`

HasEditSnapshotPoliciesParam returns a boolean if a field has been set.

### GetEditStorageGroupSLOParam

`func (o *EditStorageGroupActionParam) GetEditStorageGroupSLOParam() EditStorageGroupSLOParam`

GetEditStorageGroupSLOParam returns the EditStorageGroupSLOParam field if non-nil, zero value otherwise.

### GetEditStorageGroupSLOParamOk

`func (o *EditStorageGroupActionParam) GetEditStorageGroupSLOParamOk() (*EditStorageGroupSLOParam, bool)`

GetEditStorageGroupSLOParamOk returns a tuple with the EditStorageGroupSLOParam field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetEditStorageGroupSLOParam

`func (o *EditStorageGroupActionParam) SetEditStorageGroupSLOParam(v EditStorageGroupSLOParam)`

SetEditStorageGroupSLOParam sets EditStorageGroupSLOParam field to given value.

### HasEditStorageGroupSLOParam

`func (o *EditStorageGroupActionParam) HasEditStorageGroupSLOParam() bool`

HasEditStorageGroupSLOParam returns a boolean if a field has been set.

### GetEditStorageGroupSRPParam

`func (o *EditStorageGroupActionParam) GetEditStorageGroupSRPParam() EditStorageGroupSRPParam`

GetEditStorageGroupSRPParam returns the EditStorageGroupSRPParam field if non-nil, zero value otherwise.

### GetEditStorageGroupSRPParamOk

`func (o *EditStorageGroupActionParam) GetEditStorageGroupSRPParamOk() (*EditStorageGroupSRPParam, bool)`

GetEditStorageGroupSRPParamOk returns a tuple with the EditStorageGroupSRPParam field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetEditStorageGroupSRPParam

`func (o *EditStorageGroupActionParam) SetEditStorageGroupSRPParam(v EditStorageGroupSRPParam)`

SetEditStorageGroupSRPParam sets EditStorageGroupSRPParam field to given value.

### HasEditStorageGroupSRPParam

`func (o *EditStorageGroupActionParam) HasEditStorageGroupSRPParam() bool`

HasEditStorageGroupSRPParam returns a boolean if a field has been set.

### GetRemoveStorageGroupParam

`func (o *EditStorageGroupActionParam) GetRemoveStorageGroupParam() RemoveStorageGroupParam`

GetRemoveStorageGroupParam returns the RemoveStorageGroupParam field if non-nil, zero value otherwise.

### GetRemoveStorageGroupParamOk

`func (o *EditStorageGroupActionParam) GetRemoveStorageGroupParamOk() (*RemoveStorageGroupParam, bool)`

GetRemoveStorageGroupParamOk returns a tuple with the RemoveStorageGroupParam field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetRemoveStorageGroupParam

`func (o *EditStorageGroupActionParam) SetRemoveStorageGroupParam(v RemoveStorageGroupParam)`

SetRemoveStorageGroupParam sets RemoveStorageGroupParam field to given value.

### HasRemoveStorageGroupParam

`func (o *EditStorageGroupActionParam) HasRemoveStorageGroupParam() bool`

HasRemoveStorageGroupParam returns a boolean if a field has been set.

### GetRenameStorageGroupParam

`func (o *EditStorageGroupActionParam) GetRenameStorageGroupParam() RenameStorageGroupParam`

GetRenameStorageGroupParam returns the RenameStorageGroupParam field if non-nil, zero value otherwise.

### GetRenameStorageGroupParamOk

`func (o *EditStorageGroupActionParam) GetRenameStorageGroupParamOk() (*RenameStorageGroupParam, bool)`

GetRenameStorageGroupParamOk returns a tuple with the RenameStorageGroupParam field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetRenameStorageGroupParam

`func (o *EditStorageGroupActionParam) SetRenameStorageGroupParam(v RenameStorageGroupParam)`

SetRenameStorageGroupParam sets RenameStorageGroupParam field to given value.

### HasRenameStorageGroupParam

`func (o *EditStorageGroupActionParam) HasRenameStorageGroupParam() bool`

HasRenameStorageGroupParam returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


