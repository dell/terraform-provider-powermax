# EditSymmetrixActionParam

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**TagManagementParam** | Pointer to [**TagManagementParam**](TagManagementParam.md) |  | [optional] 

## Methods

### NewEditSymmetrixActionParam

`func NewEditSymmetrixActionParam() *EditSymmetrixActionParam`

NewEditSymmetrixActionParam instantiates a new EditSymmetrixActionParam object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewEditSymmetrixActionParamWithDefaults

`func NewEditSymmetrixActionParamWithDefaults() *EditSymmetrixActionParam`

NewEditSymmetrixActionParamWithDefaults instantiates a new EditSymmetrixActionParam object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetTagManagementParam

`func (o *EditSymmetrixActionParam) GetTagManagementParam() TagManagementParam`

GetTagManagementParam returns the TagManagementParam field if non-nil, zero value otherwise.

### GetTagManagementParamOk

`func (o *EditSymmetrixActionParam) GetTagManagementParamOk() (*TagManagementParam, bool)`

GetTagManagementParamOk returns a tuple with the TagManagementParam field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetTagManagementParam

`func (o *EditSymmetrixActionParam) SetTagManagementParam(v TagManagementParam)`

SetTagManagementParam sets TagManagementParam field to given value.

### HasTagManagementParam

`func (o *EditSymmetrixActionParam) HasTagManagementParam() bool`

HasTagManagementParam returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


