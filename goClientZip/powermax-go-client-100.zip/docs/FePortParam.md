# FePortParam

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**StartDate** | **int64** | Starting date in millisecond. | 
**EndDate** | **int64** | Ending date in millisecond. | 
**SymmetrixId** | **string** | &lt;p&gt;The Symmetrix array ID.&lt;/p&gt; | 
**DirectorId** | **string** | directorId | 
**PortId** | **string** | portId | 
**DataFormat** | Pointer to **string** | &lt;p&gt;Data Format (Average or Maximum).&lt;/p&gt;   Enumeration values: * **Average** * **Maximum**  | [optional] 
**Metrics** | **[]string** | metrics   Enumeration values: * **ResponseTime** - Response Time (ms) * **ReadResponseTime** - Read Response Time (ms) * **WriteResponseTime** - Write Response Time (ms) * **Reads** - Areaddatatransferbetweenthedirectorandthecache.AnIOmayrequiremultiplerequestsdependingonIOsize,alignmentorboth.TherequestsrateshouldbeeitherequaltoorgreaterthantheIOrate. * **Writes** - Awritedatatransferbetweenthedirectorandthecache.AnIOmayrequiremultiplerequestsdependingonIOsize,alignmentorboth.TherequestsrateshouldbeeitherequaltoorgreaterthantheIOrate. * **IOs** - An IO command to the disk. * **MBRead** - The reads per second in MBs. * **MBWritten** - The writes per second in MBs. * **MBs** - The total IO (reads and writes) per second in MBs. * **AvgIOSize** - The average IO size served by the port * **SpeedGBs** - The number of gigabits moving through the port  per second. * **MaxSpeedGBs** - The max number of gigabits moving through the port  per second. * **PercentBusy** - The percent of time the port is busy. * **BadReceiveCharCount** - Bad Receive Char Count * **DiscardedFramesCount** - Discarded Frames Count * **ExpiredFramesCount** - Expired Frames Count * **InvalidCRCCount** - Invalid CRC Count * **LinkFailureCount** - Link Failure Count * **LossOfSignalCount** - Loss of Signal Count * **LossOfSyncCount** - Loss of Sync Count * **PrimSeqErrorCount** - Primative Sequence Error  Count * **ReceivedEOFACount** - Received EOFA Count * **ISCSIChecksumErrorCount** - iSCSI Checksum Error Count * **RxPower** -                          Port Link Error RxPower                      * **TxPower** -                          Port Link Error TxPower                      * **HostIOLimitIOs** - Host IO Limit IOs/sec. * **HostIOLimitMBs** - Host IO Limit MBs/sec.  | 

## Methods

### NewFePortParam

`func NewFePortParam(startDate int64, endDate int64, symmetrixId string, directorId string, portId string, metrics []string, ) *FePortParam`

NewFePortParam instantiates a new FePortParam object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewFePortParamWithDefaults

`func NewFePortParamWithDefaults() *FePortParam`

NewFePortParamWithDefaults instantiates a new FePortParam object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetStartDate

`func (o *FePortParam) GetStartDate() int64`

GetStartDate returns the StartDate field if non-nil, zero value otherwise.

### GetStartDateOk

`func (o *FePortParam) GetStartDateOk() (*int64, bool)`

GetStartDateOk returns a tuple with the StartDate field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetStartDate

`func (o *FePortParam) SetStartDate(v int64)`

SetStartDate sets StartDate field to given value.


### GetEndDate

`func (o *FePortParam) GetEndDate() int64`

GetEndDate returns the EndDate field if non-nil, zero value otherwise.

### GetEndDateOk

`func (o *FePortParam) GetEndDateOk() (*int64, bool)`

GetEndDateOk returns a tuple with the EndDate field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetEndDate

`func (o *FePortParam) SetEndDate(v int64)`

SetEndDate sets EndDate field to given value.


### GetSymmetrixId

`func (o *FePortParam) GetSymmetrixId() string`

GetSymmetrixId returns the SymmetrixId field if non-nil, zero value otherwise.

### GetSymmetrixIdOk

`func (o *FePortParam) GetSymmetrixIdOk() (*string, bool)`

GetSymmetrixIdOk returns a tuple with the SymmetrixId field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetSymmetrixId

`func (o *FePortParam) SetSymmetrixId(v string)`

SetSymmetrixId sets SymmetrixId field to given value.


### GetDirectorId

`func (o *FePortParam) GetDirectorId() string`

GetDirectorId returns the DirectorId field if non-nil, zero value otherwise.

### GetDirectorIdOk

`func (o *FePortParam) GetDirectorIdOk() (*string, bool)`

GetDirectorIdOk returns a tuple with the DirectorId field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetDirectorId

`func (o *FePortParam) SetDirectorId(v string)`

SetDirectorId sets DirectorId field to given value.


### GetPortId

`func (o *FePortParam) GetPortId() string`

GetPortId returns the PortId field if non-nil, zero value otherwise.

### GetPortIdOk

`func (o *FePortParam) GetPortIdOk() (*string, bool)`

GetPortIdOk returns a tuple with the PortId field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetPortId

`func (o *FePortParam) SetPortId(v string)`

SetPortId sets PortId field to given value.


### GetDataFormat

`func (o *FePortParam) GetDataFormat() string`

GetDataFormat returns the DataFormat field if non-nil, zero value otherwise.

### GetDataFormatOk

`func (o *FePortParam) GetDataFormatOk() (*string, bool)`

GetDataFormatOk returns a tuple with the DataFormat field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetDataFormat

`func (o *FePortParam) SetDataFormat(v string)`

SetDataFormat sets DataFormat field to given value.

### HasDataFormat

`func (o *FePortParam) HasDataFormat() bool`

HasDataFormat returns a boolean if a field has been set.

### GetMetrics

`func (o *FePortParam) GetMetrics() []string`

GetMetrics returns the Metrics field if non-nil, zero value otherwise.

### GetMetricsOk

`func (o *FePortParam) GetMetricsOk() (*[]string, bool)`

GetMetricsOk returns a tuple with the Metrics field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetMetrics

`func (o *FePortParam) SetMetrics(v []string)`

SetMetrics sets Metrics field to given value.



[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


