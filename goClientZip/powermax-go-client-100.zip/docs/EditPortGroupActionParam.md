# EditPortGroupActionParam

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**RemovePortParam** | Pointer to [**RemovePortParam**](RemovePortParam.md) |  | [optional] 
**AddPortParam** | Pointer to [**AddPortParam**](AddPortParam.md) |  | [optional] 
**RenamePortGroupParam** | Pointer to [**RenamePortGroupParam**](RenamePortGroupParam.md) |  | [optional] 

## Methods

### NewEditPortGroupActionParam

`func NewEditPortGroupActionParam() *EditPortGroupActionParam`

NewEditPortGroupActionParam instantiates a new EditPortGroupActionParam object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewEditPortGroupActionParamWithDefaults

`func NewEditPortGroupActionParamWithDefaults() *EditPortGroupActionParam`

NewEditPortGroupActionParamWithDefaults instantiates a new EditPortGroupActionParam object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetRemovePortParam

`func (o *EditPortGroupActionParam) GetRemovePortParam() RemovePortParam`

GetRemovePortParam returns the RemovePortParam field if non-nil, zero value otherwise.

### GetRemovePortParamOk

`func (o *EditPortGroupActionParam) GetRemovePortParamOk() (*RemovePortParam, bool)`

GetRemovePortParamOk returns a tuple with the RemovePortParam field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetRemovePortParam

`func (o *EditPortGroupActionParam) SetRemovePortParam(v RemovePortParam)`

SetRemovePortParam sets RemovePortParam field to given value.

### HasRemovePortParam

`func (o *EditPortGroupActionParam) HasRemovePortParam() bool`

HasRemovePortParam returns a boolean if a field has been set.

### GetAddPortParam

`func (o *EditPortGroupActionParam) GetAddPortParam() AddPortParam`

GetAddPortParam returns the AddPortParam field if non-nil, zero value otherwise.

### GetAddPortParamOk

`func (o *EditPortGroupActionParam) GetAddPortParamOk() (*AddPortParam, bool)`

GetAddPortParamOk returns a tuple with the AddPortParam field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetAddPortParam

`func (o *EditPortGroupActionParam) SetAddPortParam(v AddPortParam)`

SetAddPortParam sets AddPortParam field to given value.

### HasAddPortParam

`func (o *EditPortGroupActionParam) HasAddPortParam() bool`

HasAddPortParam returns a boolean if a field has been set.

### GetRenamePortGroupParam

`func (o *EditPortGroupActionParam) GetRenamePortGroupParam() RenamePortGroupParam`

GetRenamePortGroupParam returns the RenamePortGroupParam field if non-nil, zero value otherwise.

### GetRenamePortGroupParamOk

`func (o *EditPortGroupActionParam) GetRenamePortGroupParamOk() (*RenamePortGroupParam, bool)`

GetRenamePortGroupParamOk returns a tuple with the RenamePortGroupParam field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetRenamePortGroupParam

`func (o *EditPortGroupActionParam) SetRenamePortGroupParam(v RenamePortGroupParam)`

SetRenamePortGroupParam sets RenamePortGroupParam field to given value.

### HasRenamePortGroupParam

`func (o *EditPortGroupActionParam) HasRenamePortGroupParam() bool`

HasRenamePortGroupParam returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


