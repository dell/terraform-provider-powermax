# CreateCloudSystemRouteParam

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ExecutionOption** | Pointer to **string** |  | [optional] [default to "SYNCHRONOUS"]
**DestinationIpAddress** | **string** | The destination IP Address of the Cloud System Route | 
**Prefix** | **string** | The Netmask Prefix Number of the Cloud System Route | 
**GatewayIpAddress** | **string** | The Gateway IP Address of the Cloud System Route | 
**TeamId** | Pointer to **string** | The ID of the Team associated with the Cloud System Route | [optional] 
**InterfaceId** | Pointer to **string** | The ID of the Interface associated with the Cloud System Route | [optional] 

## Methods

### NewCreateCloudSystemRouteParam

`func NewCreateCloudSystemRouteParam(destinationIpAddress string, prefix string, gatewayIpAddress string, ) *CreateCloudSystemRouteParam`

NewCreateCloudSystemRouteParam instantiates a new CreateCloudSystemRouteParam object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewCreateCloudSystemRouteParamWithDefaults

`func NewCreateCloudSystemRouteParamWithDefaults() *CreateCloudSystemRouteParam`

NewCreateCloudSystemRouteParamWithDefaults instantiates a new CreateCloudSystemRouteParam object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetExecutionOption

`func (o *CreateCloudSystemRouteParam) GetExecutionOption() string`

GetExecutionOption returns the ExecutionOption field if non-nil, zero value otherwise.

### GetExecutionOptionOk

`func (o *CreateCloudSystemRouteParam) GetExecutionOptionOk() (*string, bool)`

GetExecutionOptionOk returns a tuple with the ExecutionOption field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetExecutionOption

`func (o *CreateCloudSystemRouteParam) SetExecutionOption(v string)`

SetExecutionOption sets ExecutionOption field to given value.

### HasExecutionOption

`func (o *CreateCloudSystemRouteParam) HasExecutionOption() bool`

HasExecutionOption returns a boolean if a field has been set.

### GetDestinationIpAddress

`func (o *CreateCloudSystemRouteParam) GetDestinationIpAddress() string`

GetDestinationIpAddress returns the DestinationIpAddress field if non-nil, zero value otherwise.

### GetDestinationIpAddressOk

`func (o *CreateCloudSystemRouteParam) GetDestinationIpAddressOk() (*string, bool)`

GetDestinationIpAddressOk returns a tuple with the DestinationIpAddress field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetDestinationIpAddress

`func (o *CreateCloudSystemRouteParam) SetDestinationIpAddress(v string)`

SetDestinationIpAddress sets DestinationIpAddress field to given value.


### GetPrefix

`func (o *CreateCloudSystemRouteParam) GetPrefix() string`

GetPrefix returns the Prefix field if non-nil, zero value otherwise.

### GetPrefixOk

`func (o *CreateCloudSystemRouteParam) GetPrefixOk() (*string, bool)`

GetPrefixOk returns a tuple with the Prefix field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetPrefix

`func (o *CreateCloudSystemRouteParam) SetPrefix(v string)`

SetPrefix sets Prefix field to given value.


### GetGatewayIpAddress

`func (o *CreateCloudSystemRouteParam) GetGatewayIpAddress() string`

GetGatewayIpAddress returns the GatewayIpAddress field if non-nil, zero value otherwise.

### GetGatewayIpAddressOk

`func (o *CreateCloudSystemRouteParam) GetGatewayIpAddressOk() (*string, bool)`

GetGatewayIpAddressOk returns a tuple with the GatewayIpAddress field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetGatewayIpAddress

`func (o *CreateCloudSystemRouteParam) SetGatewayIpAddress(v string)`

SetGatewayIpAddress sets GatewayIpAddress field to given value.


### GetTeamId

`func (o *CreateCloudSystemRouteParam) GetTeamId() string`

GetTeamId returns the TeamId field if non-nil, zero value otherwise.

### GetTeamIdOk

`func (o *CreateCloudSystemRouteParam) GetTeamIdOk() (*string, bool)`

GetTeamIdOk returns a tuple with the TeamId field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetTeamId

`func (o *CreateCloudSystemRouteParam) SetTeamId(v string)`

SetTeamId sets TeamId field to given value.

### HasTeamId

`func (o *CreateCloudSystemRouteParam) HasTeamId() bool`

HasTeamId returns a boolean if a field has been set.

### GetInterfaceId

`func (o *CreateCloudSystemRouteParam) GetInterfaceId() string`

GetInterfaceId returns the InterfaceId field if non-nil, zero value otherwise.

### GetInterfaceIdOk

`func (o *CreateCloudSystemRouteParam) GetInterfaceIdOk() (*string, bool)`

GetInterfaceIdOk returns a tuple with the InterfaceId field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetInterfaceId

`func (o *CreateCloudSystemRouteParam) SetInterfaceId(v string)`

SetInterfaceId sets InterfaceId field to given value.

### HasInterfaceId

`func (o *CreateCloudSystemRouteParam) HasInterfaceId() bool`

HasInterfaceId returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


