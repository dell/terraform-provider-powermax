# FiconPortThreadParam

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**StartDate** | **int64** | Starting date in millisecond. | 
**EndDate** | **int64** | Ending date in millisecond. | 
**SymmetrixId** | **string** | &lt;p&gt;The Symmetrix array ID.&lt;/p&gt; | 
**FiconPortThreadId** | **string** | ficonPortThreadId | 
**DataFormat** | Pointer to **string** | &lt;p&gt;Data Format (Average or Maximum).&lt;/p&gt;   Enumeration values: * **Average** * **Maximum**  | [optional] 
**Metrics** | **[]string** | metrics   Enumeration values: * **PercentBusy** - % Busy * **PercentIdle** - % Idle  | 

## Methods

### NewFiconPortThreadParam

`func NewFiconPortThreadParam(startDate int64, endDate int64, symmetrixId string, ficonPortThreadId string, metrics []string, ) *FiconPortThreadParam`

NewFiconPortThreadParam instantiates a new FiconPortThreadParam object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewFiconPortThreadParamWithDefaults

`func NewFiconPortThreadParamWithDefaults() *FiconPortThreadParam`

NewFiconPortThreadParamWithDefaults instantiates a new FiconPortThreadParam object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetStartDate

`func (o *FiconPortThreadParam) GetStartDate() int64`

GetStartDate returns the StartDate field if non-nil, zero value otherwise.

### GetStartDateOk

`func (o *FiconPortThreadParam) GetStartDateOk() (*int64, bool)`

GetStartDateOk returns a tuple with the StartDate field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetStartDate

`func (o *FiconPortThreadParam) SetStartDate(v int64)`

SetStartDate sets StartDate field to given value.


### GetEndDate

`func (o *FiconPortThreadParam) GetEndDate() int64`

GetEndDate returns the EndDate field if non-nil, zero value otherwise.

### GetEndDateOk

`func (o *FiconPortThreadParam) GetEndDateOk() (*int64, bool)`

GetEndDateOk returns a tuple with the EndDate field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetEndDate

`func (o *FiconPortThreadParam) SetEndDate(v int64)`

SetEndDate sets EndDate field to given value.


### GetSymmetrixId

`func (o *FiconPortThreadParam) GetSymmetrixId() string`

GetSymmetrixId returns the SymmetrixId field if non-nil, zero value otherwise.

### GetSymmetrixIdOk

`func (o *FiconPortThreadParam) GetSymmetrixIdOk() (*string, bool)`

GetSymmetrixIdOk returns a tuple with the SymmetrixId field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetSymmetrixId

`func (o *FiconPortThreadParam) SetSymmetrixId(v string)`

SetSymmetrixId sets SymmetrixId field to given value.


### GetFiconPortThreadId

`func (o *FiconPortThreadParam) GetFiconPortThreadId() string`

GetFiconPortThreadId returns the FiconPortThreadId field if non-nil, zero value otherwise.

### GetFiconPortThreadIdOk

`func (o *FiconPortThreadParam) GetFiconPortThreadIdOk() (*string, bool)`

GetFiconPortThreadIdOk returns a tuple with the FiconPortThreadId field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetFiconPortThreadId

`func (o *FiconPortThreadParam) SetFiconPortThreadId(v string)`

SetFiconPortThreadId sets FiconPortThreadId field to given value.


### GetDataFormat

`func (o *FiconPortThreadParam) GetDataFormat() string`

GetDataFormat returns the DataFormat field if non-nil, zero value otherwise.

### GetDataFormatOk

`func (o *FiconPortThreadParam) GetDataFormatOk() (*string, bool)`

GetDataFormatOk returns a tuple with the DataFormat field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetDataFormat

`func (o *FiconPortThreadParam) SetDataFormat(v string)`

SetDataFormat sets DataFormat field to given value.

### HasDataFormat

`func (o *FiconPortThreadParam) HasDataFormat() bool`

HasDataFormat returns a boolean if a field has been set.

### GetMetrics

`func (o *FiconPortThreadParam) GetMetrics() []string`

GetMetrics returns the Metrics field if non-nil, zero value otherwise.

### GetMetricsOk

`func (o *FiconPortThreadParam) GetMetricsOk() (*[]string, bool)`

GetMetricsOk returns a tuple with the Metrics field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetMetrics

`func (o *FiconPortThreadParam) SetMetrics(v []string)`

SetMetrics sets Metrics field to given value.



[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


