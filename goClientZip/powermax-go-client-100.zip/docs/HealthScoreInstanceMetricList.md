# HealthScoreInstanceMetricList

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**HealthScoreInstanceMetric** | Pointer to [**[]HealthScoreInstanceMetric**](HealthScoreInstanceMetric.md) | health_score_instance_metric | [optional] 

## Methods

### NewHealthScoreInstanceMetricList

`func NewHealthScoreInstanceMetricList() *HealthScoreInstanceMetricList`

NewHealthScoreInstanceMetricList instantiates a new HealthScoreInstanceMetricList object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewHealthScoreInstanceMetricListWithDefaults

`func NewHealthScoreInstanceMetricListWithDefaults() *HealthScoreInstanceMetricList`

NewHealthScoreInstanceMetricListWithDefaults instantiates a new HealthScoreInstanceMetricList object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetHealthScoreInstanceMetric

`func (o *HealthScoreInstanceMetricList) GetHealthScoreInstanceMetric() []HealthScoreInstanceMetric`

GetHealthScoreInstanceMetric returns the HealthScoreInstanceMetric field if non-nil, zero value otherwise.

### GetHealthScoreInstanceMetricOk

`func (o *HealthScoreInstanceMetricList) GetHealthScoreInstanceMetricOk() (*[]HealthScoreInstanceMetric, bool)`

GetHealthScoreInstanceMetricOk returns a tuple with the HealthScoreInstanceMetric field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetHealthScoreInstanceMetric

`func (o *HealthScoreInstanceMetricList) SetHealthScoreInstanceMetric(v []HealthScoreInstanceMetric)`

SetHealthScoreInstanceMetric sets HealthScoreInstanceMetric field to given value.

### HasHealthScoreInstanceMetric

`func (o *HealthScoreInstanceMetricList) HasHealthScoreInstanceMetric() bool`

HasHealthScoreInstanceMetric returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


