# ListStorageResourceResult

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**StorageResourceId** | Pointer to **[]string** | The Storage Resource ID. | [optional] 

## Methods

### NewListStorageResourceResult

`func NewListStorageResourceResult() *ListStorageResourceResult`

NewListStorageResourceResult instantiates a new ListStorageResourceResult object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewListStorageResourceResultWithDefaults

`func NewListStorageResourceResultWithDefaults() *ListStorageResourceResult`

NewListStorageResourceResultWithDefaults instantiates a new ListStorageResourceResult object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetStorageResourceId

`func (o *ListStorageResourceResult) GetStorageResourceId() []string`

GetStorageResourceId returns the StorageResourceId field if non-nil, zero value otherwise.

### GetStorageResourceIdOk

`func (o *ListStorageResourceResult) GetStorageResourceIdOk() (*[]string, bool)`

GetStorageResourceIdOk returns a tuple with the StorageResourceId field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetStorageResourceId

`func (o *ListStorageResourceResult) SetStorageResourceId(v []string)`

SetStorageResourceId sets StorageResourceId field to given value.

### HasStorageResourceId

`func (o *ListStorageResourceResult) HasStorageResourceId() bool`

HasStorageResourceId returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


