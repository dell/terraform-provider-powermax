# MaskingViewParam

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**StartDate** | **int64** | &lt;p&gt;Starting date in millisecond.&lt;/p&gt; | 
**EndDate** | **int64** | &lt;p&gt;Ending date in millisecond.&lt;/p&gt; | 
**SymmetrixId** | **string** | &lt;p&gt;The Symmetrix array ID.&lt;/p&gt; | 
**MaskingViewId** | **string** | &lt;p&gt;Masking View ID.&lt;/p&gt; | 
**DataFormat** | Pointer to **string** | &lt;p&gt;Data Format (Average or Maximum).&lt;/p&gt;   Enumeration values: * **Average** * **Maximum**  | [optional] 
**Metrics** | **[]string** | metrics   Enumeration values: * **HostIOs** - An IO command to the disk. * **HostMBs** - The total IO (reads and writes) per second in MBs. * **ResponseTime** - The average response time for the reads and writes. * **ReadResponseTime** - A calculated average response time for reads. * **WriteResponseTime** - A calculated average response time for writes. * **Capacity** - Capacity (GB).  | 

## Methods

### NewMaskingViewParam

`func NewMaskingViewParam(startDate int64, endDate int64, symmetrixId string, maskingViewId string, metrics []string, ) *MaskingViewParam`

NewMaskingViewParam instantiates a new MaskingViewParam object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewMaskingViewParamWithDefaults

`func NewMaskingViewParamWithDefaults() *MaskingViewParam`

NewMaskingViewParamWithDefaults instantiates a new MaskingViewParam object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetStartDate

`func (o *MaskingViewParam) GetStartDate() int64`

GetStartDate returns the StartDate field if non-nil, zero value otherwise.

### GetStartDateOk

`func (o *MaskingViewParam) GetStartDateOk() (*int64, bool)`

GetStartDateOk returns a tuple with the StartDate field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetStartDate

`func (o *MaskingViewParam) SetStartDate(v int64)`

SetStartDate sets StartDate field to given value.


### GetEndDate

`func (o *MaskingViewParam) GetEndDate() int64`

GetEndDate returns the EndDate field if non-nil, zero value otherwise.

### GetEndDateOk

`func (o *MaskingViewParam) GetEndDateOk() (*int64, bool)`

GetEndDateOk returns a tuple with the EndDate field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetEndDate

`func (o *MaskingViewParam) SetEndDate(v int64)`

SetEndDate sets EndDate field to given value.


### GetSymmetrixId

`func (o *MaskingViewParam) GetSymmetrixId() string`

GetSymmetrixId returns the SymmetrixId field if non-nil, zero value otherwise.

### GetSymmetrixIdOk

`func (o *MaskingViewParam) GetSymmetrixIdOk() (*string, bool)`

GetSymmetrixIdOk returns a tuple with the SymmetrixId field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetSymmetrixId

`func (o *MaskingViewParam) SetSymmetrixId(v string)`

SetSymmetrixId sets SymmetrixId field to given value.


### GetMaskingViewId

`func (o *MaskingViewParam) GetMaskingViewId() string`

GetMaskingViewId returns the MaskingViewId field if non-nil, zero value otherwise.

### GetMaskingViewIdOk

`func (o *MaskingViewParam) GetMaskingViewIdOk() (*string, bool)`

GetMaskingViewIdOk returns a tuple with the MaskingViewId field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetMaskingViewId

`func (o *MaskingViewParam) SetMaskingViewId(v string)`

SetMaskingViewId sets MaskingViewId field to given value.


### GetDataFormat

`func (o *MaskingViewParam) GetDataFormat() string`

GetDataFormat returns the DataFormat field if non-nil, zero value otherwise.

### GetDataFormatOk

`func (o *MaskingViewParam) GetDataFormatOk() (*string, bool)`

GetDataFormatOk returns a tuple with the DataFormat field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetDataFormat

`func (o *MaskingViewParam) SetDataFormat(v string)`

SetDataFormat sets DataFormat field to given value.

### HasDataFormat

`func (o *MaskingViewParam) HasDataFormat() bool`

HasDataFormat returns a boolean if a field has been set.

### GetMetrics

`func (o *MaskingViewParam) GetMetrics() []string`

GetMetrics returns the Metrics field if non-nil, zero value otherwise.

### GetMetricsOk

`func (o *MaskingViewParam) GetMetricsOk() (*[]string, bool)`

GetMetricsOk returns a tuple with the Metrics field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetMetrics

`func (o *MaskingViewParam) SetMetrics(v []string)`

SetMetrics sets Metrics field to given value.



[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


