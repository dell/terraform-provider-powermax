# ListSRPResult

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**SrpId** | Pointer to **[]string** | The SRP names. | [optional] 

## Methods

### NewListSRPResult

`func NewListSRPResult() *ListSRPResult`

NewListSRPResult instantiates a new ListSRPResult object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewListSRPResultWithDefaults

`func NewListSRPResultWithDefaults() *ListSRPResult`

NewListSRPResultWithDefaults instantiates a new ListSRPResult object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetSrpId

`func (o *ListSRPResult) GetSrpId() []string`

GetSrpId returns the SrpId field if non-nil, zero value otherwise.

### GetSrpIdOk

`func (o *ListSRPResult) GetSrpIdOk() (*[]string, bool)`

GetSrpIdOk returns a tuple with the SrpId field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetSrpId

`func (o *ListSRPResult) SetSrpId(v []string)`

SetSrpId sets SrpId field to given value.

### HasSrpId

`func (o *ListSRPResult) HasSrpId() bool`

HasSrpId returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


